/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Comment;
import org.eclipse.eatop.eastadl21.Context;
import org.eclipse.eatop.eastadl21.EAElement;
import org.eclipse.eatop.eastadl21.EAPackage;
import org.eclipse.eatop.eastadl21.EAPackageableElement;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.FunctionConnector;
import org.eclipse.eatop.eastadl21.FunctionPort;
import org.eclipse.eatop.eastadl21.FunctionType;
import org.eclipse.eatop.eastadl21.Identifiable;
import org.eclipse.eatop.eastadl21.PortGroup;
import org.eclipse.eatop.eastadl21.Referrable;
import org.eclipse.eatop.eastadl21.Relationship;
import org.eclipse.eatop.eastadl21.TraceableSpecification;

import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackage;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackageableElement;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GIdentifiable;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GReferrable;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GelementsPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Function Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#gGetShortName <em>GShort Name</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getShortName <em>Short Name</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getCategory <em>Category</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getUuid <em>Uuid</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getOwnedComment <em>Owned Comment</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#gGetEAPackage_element <em>GEA Package element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getEAPackage_element <em>EA Package element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getTraceableSpecification <em>Traceable Specification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getOwnedRelationship <em>Owned Relationship</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getIsElementary <em>Is Elementary</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getPort <em>Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getPortGroup <em>Port Group</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FunctionTypeImpl#getConnector <em>Connector</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class FunctionTypeImpl extends EATypeImpl implements FunctionType
{
  /**
   * The default value of the '{@link #gGetShortName() <em>GShort Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #gGetShortName()
   * @generated
   * @ordered
   */
  protected static final String GSHORT_NAME_EDEFAULT = null;

  /**
   * The default value of the '{@link #getShortName() <em>Short Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getShortName()
   * @generated
   * @ordered
   */
  protected static final String SHORT_NAME_EDEFAULT = "";

  /**
   * The cached value of the '{@link #getShortName() <em>Short Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getShortName()
   * @generated
   * @ordered
   */
  protected String shortName = SHORT_NAME_EDEFAULT;

  /**
   * This is true if the Short Name attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean shortNameESet;

  /**
   * The default value of the '{@link #getCategory() <em>Category</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCategory()
   * @generated
   * @ordered
   */
  protected static final String CATEGORY_EDEFAULT = "";

  /**
   * The cached value of the '{@link #getCategory() <em>Category</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCategory()
   * @generated
   * @ordered
   */
  protected String category = CATEGORY_EDEFAULT;

  /**
   * This is true if the Category attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean categoryESet;

  /**
   * The default value of the '{@link #getUuid() <em>Uuid</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUuid()
   * @generated
   * @ordered
   */
  protected static final String UUID_EDEFAULT = "";

  /**
   * The cached value of the '{@link #getUuid() <em>Uuid</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUuid()
   * @generated
   * @ordered
   */
  protected String uuid = UUID_EDEFAULT;

  /**
   * This is true if the Uuid attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean uuidESet;

  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = "";

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * This is true if the Name attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean nameESet;

  /**
   * The cached value of the '{@link #getOwnedComment() <em>Owned Comment</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOwnedComment()
   * @generated
   * @ordered
   */
  protected EList<Comment> ownedComment;

  /**
   * The cached value of the '{@link #getTraceableSpecification() <em>Traceable Specification</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTraceableSpecification()
   * @generated
   * @ordered
   */
  protected EList<TraceableSpecification> traceableSpecification;

  /**
   * The cached value of the '{@link #getOwnedRelationship() <em>Owned Relationship</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOwnedRelationship()
   * @generated
   * @ordered
   */
  protected EList<Relationship> ownedRelationship;

  /**
   * The default value of the '{@link #getIsElementary() <em>Is Elementary</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsElementary()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_ELEMENTARY_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsElementary() <em>Is Elementary</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsElementary()
   * @generated
   * @ordered
   */
  protected Boolean isElementary = IS_ELEMENTARY_EDEFAULT;

  /**
   * This is true if the Is Elementary attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isElementaryESet;

  /**
   * The cached value of the '{@link #getPort() <em>Port</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPort()
   * @generated
   * @ordered
   */
  protected EList<FunctionPort> port;

  /**
   * The cached value of the '{@link #getPortGroup() <em>Port Group</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPortGroup()
   * @generated
   * @ordered
   */
  protected EList<PortGroup> portGroup;

  /**
   * The cached value of the '{@link #getConnector() <em>Connector</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConnector()
   * @generated
   * @ordered
   */
  protected EList<FunctionConnector> connector;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected FunctionTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getFunctionType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String gGetShortName()
  {
  
  
    
    
      
                
          String tgtFeatureValue = getShortName();
                      
  return tgtFeatureValue;					
                
      
      
      
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void gSetShortName(String newGShortName)
  {
  
        
    
    
              
      
        
                                        
                      
  setShortName(newGShortName);
                
        
      
      
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void gUnsetShortName()
  {
// Class/GEastadl/gUnsetImplementation.insert.javajetinc

  
    unsetShortName();
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean gIsSetShortName()
  {
// Class/GEastadl/gIsSetImplementation.insert.javajetinc


  
    return isSetShortName();		
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getShortName()
  {
    return shortName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setShortName(String newShortName)
  {
    String oldShortName = shortName;
    shortName = newShortName;
    boolean oldShortNameESet = shortNameESet;
    shortNameESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FUNCTION_TYPE__SHORT_NAME, oldShortName, shortName, !oldShortNameESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetShortName()
  {
    String oldShortName = shortName;
    boolean oldShortNameESet = shortNameESet;
    shortName = SHORT_NAME_EDEFAULT;
    shortNameESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.FUNCTION_TYPE__SHORT_NAME, oldShortName, SHORT_NAME_EDEFAULT, oldShortNameESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetShortName()
  {
    return shortNameESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCategory()
  {
    return category;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCategory(String newCategory)
  {
    String oldCategory = category;
    category = newCategory;
    boolean oldCategoryESet = categoryESet;
    categoryESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FUNCTION_TYPE__CATEGORY, oldCategory, category, !oldCategoryESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetCategory()
  {
    String oldCategory = category;
    boolean oldCategoryESet = categoryESet;
    category = CATEGORY_EDEFAULT;
    categoryESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.FUNCTION_TYPE__CATEGORY, oldCategory, CATEGORY_EDEFAULT, oldCategoryESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetCategory()
  {
    return categoryESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUuid()
  {
    return uuid;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUuid(String newUuid)
  {
    String oldUuid = uuid;
    uuid = newUuid;
    boolean oldUuidESet = uuidESet;
    uuidESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FUNCTION_TYPE__UUID, oldUuid, uuid, !oldUuidESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetUuid()
  {
    String oldUuid = uuid;
    boolean oldUuidESet = uuidESet;
    uuid = UUID_EDEFAULT;
    uuidESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.FUNCTION_TYPE__UUID, oldUuid, UUID_EDEFAULT, oldUuidESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetUuid()
  {
    return uuidESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    boolean oldNameESet = nameESet;
    nameESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FUNCTION_TYPE__NAME, oldName, name, !oldNameESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetName()
  {
    String oldName = name;
    boolean oldNameESet = nameESet;
    name = NAME_EDEFAULT;
    nameESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.FUNCTION_TYPE__NAME, oldName, NAME_EDEFAULT, oldNameESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetName()
  {
    return nameESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Comment> getOwnedComment()
  {
    if (ownedComment == null)
    {
      ownedComment = new EObjectContainmentEList<Comment>(Comment.class, this, Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT);
    }
    return ownedComment;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GEAPackage gGetEAPackage_element()
  {
  
  
    
    
      
                  
          return getEAPackage_element();								
        
      
      
      
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void gSetEAPackage_element(GEAPackage newGEAPackage_element)
  {
  
        
    
    
              
      
                            
          setEAPackage_element((EAPackage) newGEAPackage_element);													
        
        
      
      
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAPackage getEAPackage_element()
  {
    if (eContainerFeatureID() != Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT) return null;
    return (EAPackage)eContainer();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEAPackage_element(EAPackage newEAPackage_element, NotificationChain msgs)
  {
    msgs = eBasicSetContainer((InternalEObject)newEAPackage_element, Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT, msgs);
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEAPackage_element(EAPackage newEAPackage_element)
  {
    if (newEAPackage_element != eInternalContainer() || (eContainerFeatureID() != Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT && newEAPackage_element != null))
    {
      if (EcoreUtil.isAncestor(this, newEAPackage_element))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eInternalContainer() != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newEAPackage_element != null)
        msgs = ((InternalEObject)newEAPackage_element).eInverseAdd(this, Eastadl21Package.EA_PACKAGE__ELEMENT, EAPackage.class, msgs);
      msgs = basicSetEAPackage_element(newEAPackage_element, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT, newEAPackage_element, newEAPackage_element));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<TraceableSpecification> getTraceableSpecification()
  {
    if (traceableSpecification == null)
    {
      traceableSpecification = new EObjectResolvingEList<TraceableSpecification>(TraceableSpecification.class, this, Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION);
    }
    return traceableSpecification;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Relationship> getOwnedRelationship()
  {
    if (ownedRelationship == null)
    {
      ownedRelationship = new EObjectContainmentEList<Relationship>(Relationship.class, this, Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP);
    }
    return ownedRelationship;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsElementary()
  {
    return isElementary;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsElementary(Boolean newIsElementary)
  {
    Boolean oldIsElementary = isElementary;
    isElementary = newIsElementary;
    boolean oldIsElementaryESet = isElementaryESet;
    isElementaryESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FUNCTION_TYPE__IS_ELEMENTARY, oldIsElementary, isElementary, !oldIsElementaryESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsElementary()
  {
    Boolean oldIsElementary = isElementary;
    boolean oldIsElementaryESet = isElementaryESet;
    isElementary = IS_ELEMENTARY_EDEFAULT;
    isElementaryESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.FUNCTION_TYPE__IS_ELEMENTARY, oldIsElementary, IS_ELEMENTARY_EDEFAULT, oldIsElementaryESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsElementary()
  {
    return isElementaryESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<FunctionPort> getPort()
  {
    if (port == null)
    {
      port = new EObjectContainmentEList<FunctionPort>(FunctionPort.class, this, Eastadl21Package.FUNCTION_TYPE__PORT);
    }
    return port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<PortGroup> getPortGroup()
  {
    if (portGroup == null)
    {
      portGroup = new EObjectContainmentEList<PortGroup>(PortGroup.class, this, Eastadl21Package.FUNCTION_TYPE__PORT_GROUP);
    }
    return portGroup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<FunctionConnector> getConnector()
  {
    if (connector == null)
    {
      connector = new EObjectContainmentEList<FunctionConnector>(FunctionConnector.class, this, Eastadl21Package.FUNCTION_TYPE__CONNECTOR);
    }
    return connector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
        if (eInternalContainer() != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return basicSetEAPackage_element((EAPackage)otherEnd, msgs);
    }
    return super.eInverseAdd(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT:
        return ((InternalEList<?>)getOwnedComment()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
        return basicSetEAPackage_element(null, msgs);
      case Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP:
        return ((InternalEList<?>)getOwnedRelationship()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.FUNCTION_TYPE__PORT:
        return ((InternalEList<?>)getPort()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.FUNCTION_TYPE__PORT_GROUP:
        return ((InternalEList<?>)getPortGroup()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.FUNCTION_TYPE__CONNECTOR:
        return ((InternalEList<?>)getConnector()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs)
  {
    switch (eContainerFeatureID())
    {
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
        return eInternalContainer().eInverseRemove(this, Eastadl21Package.EA_PACKAGE__ELEMENT, EAPackage.class, msgs);
    }
    return super.eBasicRemoveFromContainerFeature(msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.FUNCTION_TYPE__GSHORT_NAME:
        return gGetShortName();
      case Eastadl21Package.FUNCTION_TYPE__SHORT_NAME:
        return getShortName();
      case Eastadl21Package.FUNCTION_TYPE__CATEGORY:
        return getCategory();
      case Eastadl21Package.FUNCTION_TYPE__UUID:
        return getUuid();
      case Eastadl21Package.FUNCTION_TYPE__NAME:
        return getName();
      case Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT:
        return getOwnedComment();
      case Eastadl21Package.FUNCTION_TYPE__GEA_PACKAGE_ELEMENT:
        return gGetEAPackage_element();
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
        return getEAPackage_element();
      case Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION:
        return getTraceableSpecification();
      case Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP:
        return getOwnedRelationship();
      case Eastadl21Package.FUNCTION_TYPE__IS_ELEMENTARY:
        return getIsElementary();
      case Eastadl21Package.FUNCTION_TYPE__PORT:
        return getPort();
      case Eastadl21Package.FUNCTION_TYPE__PORT_GROUP:
        return getPortGroup();
      case Eastadl21Package.FUNCTION_TYPE__CONNECTOR:
        return getConnector();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.FUNCTION_TYPE__GSHORT_NAME:
   			gSetShortName((String)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__SHORT_NAME:
   			setShortName((String)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__CATEGORY:
   			setCategory((String)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__UUID:
   			setUuid((String)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__NAME:
   			setName((String)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT:
        getOwnedComment().clear();
        getOwnedComment().addAll((Collection<? extends Comment>)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__GEA_PACKAGE_ELEMENT:
   			gSetEAPackage_element((GEAPackage)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
   			setEAPackage_element((EAPackage)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION:
        getTraceableSpecification().clear();
        getTraceableSpecification().addAll((Collection<? extends TraceableSpecification>)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP:
        getOwnedRelationship().clear();
        getOwnedRelationship().addAll((Collection<? extends Relationship>)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__IS_ELEMENTARY:
   			setIsElementary((Boolean)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__PORT:
        getPort().clear();
        getPort().addAll((Collection<? extends FunctionPort>)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__PORT_GROUP:
        getPortGroup().clear();
        getPortGroup().addAll((Collection<? extends PortGroup>)newValue);
        return;
      case Eastadl21Package.FUNCTION_TYPE__CONNECTOR:
        getConnector().clear();
        getConnector().addAll((Collection<? extends FunctionConnector>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.FUNCTION_TYPE__GSHORT_NAME:
        gUnsetShortName();
        return;
      case Eastadl21Package.FUNCTION_TYPE__SHORT_NAME:
        unsetShortName();
        return;
      case Eastadl21Package.FUNCTION_TYPE__CATEGORY:
        unsetCategory();
        return;
      case Eastadl21Package.FUNCTION_TYPE__UUID:
        unsetUuid();
        return;
      case Eastadl21Package.FUNCTION_TYPE__NAME:
        unsetName();
        return;
      case Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT:
        getOwnedComment().clear();
        return;
      case Eastadl21Package.FUNCTION_TYPE__GEA_PACKAGE_ELEMENT:
        	gSetEAPackage_element((GEAPackage)null);
        return;
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
        	setEAPackage_element((EAPackage)null);
        return;
      case Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION:
        getTraceableSpecification().clear();
        return;
      case Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP:
        getOwnedRelationship().clear();
        return;
      case Eastadl21Package.FUNCTION_TYPE__IS_ELEMENTARY:
        unsetIsElementary();
        return;
      case Eastadl21Package.FUNCTION_TYPE__PORT:
        getPort().clear();
        return;
      case Eastadl21Package.FUNCTION_TYPE__PORT_GROUP:
        getPortGroup().clear();
        return;
      case Eastadl21Package.FUNCTION_TYPE__CONNECTOR:
        getConnector().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.FUNCTION_TYPE__GSHORT_NAME:
        return gIsSetShortName();
      case Eastadl21Package.FUNCTION_TYPE__SHORT_NAME:
        return isSetShortName();
      case Eastadl21Package.FUNCTION_TYPE__CATEGORY:
        return isSetCategory();
      case Eastadl21Package.FUNCTION_TYPE__UUID:
        return isSetUuid();
      case Eastadl21Package.FUNCTION_TYPE__NAME:
        return isSetName();
      case Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT:
        return ownedComment != null && !ownedComment.isEmpty();
      case Eastadl21Package.FUNCTION_TYPE__GEA_PACKAGE_ELEMENT:
        return gGetEAPackage_element() != null;
      case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT:
        return getEAPackage_element() != null;
      case Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION:
        return traceableSpecification != null && !traceableSpecification.isEmpty();
      case Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP:
        return ownedRelationship != null && !ownedRelationship.isEmpty();
      case Eastadl21Package.FUNCTION_TYPE__IS_ELEMENTARY:
        return isSetIsElementary();
      case Eastadl21Package.FUNCTION_TYPE__PORT:
        return port != null && !port.isEmpty();
      case Eastadl21Package.FUNCTION_TYPE__PORT_GROUP:
        return portGroup != null && !portGroup.isEmpty();
      case Eastadl21Package.FUNCTION_TYPE__CONNECTOR:
        return connector != null && !connector.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass)
  {
    if (baseClass == GReferrable.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__GSHORT_NAME: return GelementsPackage.GREFERRABLE__GSHORT_NAME;
        default: return -1;
      }
    }
    if (baseClass == Referrable.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__SHORT_NAME: return Eastadl21Package.REFERRABLE__SHORT_NAME;
        default: return -1;
      }
    }
    if (baseClass == GIdentifiable.class)
    {
      switch (derivedFeatureID)
      {
        default: return -1;
      }
    }
    if (baseClass == Identifiable.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__CATEGORY: return Eastadl21Package.IDENTIFIABLE__CATEGORY;
        case Eastadl21Package.FUNCTION_TYPE__UUID: return Eastadl21Package.IDENTIFIABLE__UUID;
        default: return -1;
      }
    }
    if (baseClass == EAElement.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__NAME: return Eastadl21Package.EA_ELEMENT__NAME;
        case Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT: return Eastadl21Package.EA_ELEMENT__OWNED_COMMENT;
        default: return -1;
      }
    }
    if (baseClass == GEAPackageableElement.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__GEA_PACKAGE_ELEMENT: return GelementsPackage.GEA_PACKAGEABLE_ELEMENT__GEA_PACKAGE_ELEMENT;
        default: return -1;
      }
    }
    if (baseClass == EAPackageableElement.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT: return Eastadl21Package.EA_PACKAGEABLE_ELEMENT__EA_PACKAGE_ELEMENT;
        default: return -1;
      }
    }
    if (baseClass == Context.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION: return Eastadl21Package.CONTEXT__TRACEABLE_SPECIFICATION;
        case Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP: return Eastadl21Package.CONTEXT__OWNED_RELATIONSHIP;
        default: return -1;
      }
    }
    return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass)
  {
    if (baseClass == GReferrable.class)
    {
      switch (baseFeatureID)
      {
        case GelementsPackage.GREFERRABLE__GSHORT_NAME: return Eastadl21Package.FUNCTION_TYPE__GSHORT_NAME;
        default: return -1;
      }
    }
    if (baseClass == Referrable.class)
    {
      switch (baseFeatureID)
      {
        case Eastadl21Package.REFERRABLE__SHORT_NAME: return Eastadl21Package.FUNCTION_TYPE__SHORT_NAME;
        default: return -1;
      }
    }
    if (baseClass == GIdentifiable.class)
    {
      switch (baseFeatureID)
      {
        default: return -1;
      }
    }
    if (baseClass == Identifiable.class)
    {
      switch (baseFeatureID)
      {
        case Eastadl21Package.IDENTIFIABLE__CATEGORY: return Eastadl21Package.FUNCTION_TYPE__CATEGORY;
        case Eastadl21Package.IDENTIFIABLE__UUID: return Eastadl21Package.FUNCTION_TYPE__UUID;
        default: return -1;
      }
    }
    if (baseClass == EAElement.class)
    {
      switch (baseFeatureID)
      {
        case Eastadl21Package.EA_ELEMENT__NAME: return Eastadl21Package.FUNCTION_TYPE__NAME;
        case Eastadl21Package.EA_ELEMENT__OWNED_COMMENT: return Eastadl21Package.FUNCTION_TYPE__OWNED_COMMENT;
        default: return -1;
      }
    }
    if (baseClass == GEAPackageableElement.class)
    {
      switch (baseFeatureID)
      {
        case GelementsPackage.GEA_PACKAGEABLE_ELEMENT__GEA_PACKAGE_ELEMENT: return Eastadl21Package.FUNCTION_TYPE__GEA_PACKAGE_ELEMENT;
        default: return -1;
      }
    }
    if (baseClass == EAPackageableElement.class)
    {
      switch (baseFeatureID)
      {
        case Eastadl21Package.EA_PACKAGEABLE_ELEMENT__EA_PACKAGE_ELEMENT: return Eastadl21Package.FUNCTION_TYPE__EA_PACKAGE_ELEMENT;
        default: return -1;
      }
    }
    if (baseClass == Context.class)
    {
      switch (baseFeatureID)
      {
        case Eastadl21Package.CONTEXT__TRACEABLE_SPECIFICATION: return Eastadl21Package.FUNCTION_TYPE__TRACEABLE_SPECIFICATION;
        case Eastadl21Package.CONTEXT__OWNED_RELATIONSHIP: return Eastadl21Package.FUNCTION_TYPE__OWNED_RELATIONSHIP;
        default: return -1;
      }
    }
    return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (shortName: ");
    if (shortNameESet) result.append(shortName); else result.append("<unset>");
    result.append(", category: ");
    if (categoryESet) result.append(category); else result.append("<unset>");
    result.append(", uuid: ");
    if (uuidESet) result.append(uuid); else result.append("<unset>");
    result.append(", name: ");
    if (nameESet) result.append(name); else result.append("<unset>");
    result.append(", isElementary: ");
    if (isElementaryESet) result.append(isElementary); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //FunctionTypeImpl
