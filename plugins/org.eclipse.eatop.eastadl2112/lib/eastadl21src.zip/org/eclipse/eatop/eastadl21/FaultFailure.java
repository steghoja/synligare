/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The FaultFailure represents a certain fault or failure on its referenced Anomal(ies). The faultFailureValue specifies the value of the Anomaly that corresponds to the condition represented by the FaultFailure. Alternatively, a boolean expression over the referenced anomalies defines the condition represented by the FaultFailure. 
 * 
 * Semantics:
 * A FaultFailure represents a fault or failure on the referenced Anomal(ies). The Faultfailure condition is satisfied when a) faultFailureValue is an EAValue and at least one of the referenced anomal(ies) is equal to this value or b) when faultFailureValue is a boolean EAExpression and the referenced anomal(ies) satisfies the expression, i.e. it evaluates to true. 
 * 
 * Constraints:
 * [1] faultFailureValue shall have the same datatype as the referenced Anomal(ies) or be of type EABoolean.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.SafetyConstraints.FaultFailure</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailure#getAnomaly <em>Anomaly</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailure#getFaultFailureValue <em>Fault Failure Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailure()
 * @model annotation="MetaData guid='{ED03F886-9D2C-4711-8606-6EFD4666D771}' id='-30448989' EA\040name='FaultFailure'"
 *        extendedMetaData="name='FAULT-FAILURE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURES'"
 * @generated
 */
public interface FaultFailure extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Anomaly</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Anomaly</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Anomaly</em>' containment reference.
   * @see #setAnomaly(FaultFailure_anomaly)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailure_Anomaly()
   * @model containment="true"
   *        annotation="MetaData guid='{5B73461E-7372-420c-B7DD-631D7C0B3657}' id='1653007619' EA\040name=''"
   *        annotation="TaggedValues xml.name='ANOMALY-IREF' xml.namePlural='ANOMALY-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='ANOMALY-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ANOMALY-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FaultFailure_anomaly getAnomaly();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailure#getAnomaly <em>Anomaly</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Anomaly</em>' containment reference.
   * @see #getAnomaly()
   * @generated
   */
  void setAnomaly(FaultFailure_anomaly value);

  /**
   * Returns the value of the '<em><b>Fault Failure Value</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Fault Failure Value</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Fault Failure Value</em>' containment reference.
   * @see #setFaultFailureValue(EAValue)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailure_FaultFailureValue()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{859D9295-BAB8-4326-89EE-0BB7A70F6CE6}' id='-1474986368' EA\040name=''"
   *        extendedMetaData="name='FAULT-FAILURE-VALUE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-VALUES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EAValue getFaultFailureValue();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailure#getFaultFailureValue <em>Fault Failure Value</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Fault Failure Value</em>' containment reference.
   * @see #getFaultFailureValue()
   * @generated
   */
  void setFaultFailureValue(EAValue value);

} // FaultFailure
