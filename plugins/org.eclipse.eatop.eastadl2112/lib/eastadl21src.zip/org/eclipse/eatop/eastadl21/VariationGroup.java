/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variation Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A VariationGroup defines a relation between an arbitrary number of VariableElements. It is primarily intended for defining how these VariableElements may be combined (e.g. one requires the other, alternative, etc.).
 * 
 * 
 * Semantics:
 * Defines a dependency or constraint between the variable elements denoted by association variableElement. The actual constraint is specified by attribute kind.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Variability.VariationGroup</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariationGroup#getConstraint <em>Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariationGroup#getKind <em>Kind</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariationGroup#getVariableElement <em>Variable Element</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariationGroup()
 * @model annotation="MetaData guid='{77A5FE55-CFAA-4252-B133-CD54F5FCE664}' id='138' EA\040name='VariationGroup'"
 *        extendedMetaData="name='VARIATION-GROUP' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIATION-GROUPS'"
 * @generated
 */
public interface VariationGroup extends EAElement
{
  /**
   * Returns the value of the '<em><b>Constraint</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Only defined iff kind=="custom". A constraint specifying how the VariableElements in the variation group can be combined. This attribute adheres to the syntax and semantics of the VSL language.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Constraint</em>' attribute.
   * @see #isSetConstraint()
   * @see #unsetConstraint()
   * @see #setConstraint(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariationGroup_Constraint()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{B76BA733-AF61-4ca1-9296-18B3D2CA2599}' id='116' EA\040name='constraint'"
   *        extendedMetaData="name='CONSTRAINT' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINTS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getConstraint();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VariationGroup#getConstraint <em>Constraint</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Constraint</em>' attribute.
   * @see #isSetConstraint()
   * @see #Constraint()
   * @see #getConstraint()
   * @generated
   */
  void setConstraint(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.VariationGroup#getConstraint <em>Constraint</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetConstraint()
   * @see #getConstraint()
   * @see #setConstraint(String)
   * @generated
   */
  void unsetConstraint();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.VariationGroup#getConstraint <em>Constraint</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Constraint</em>' attribute is set.
   * @see #Constraint()
   * @see #getConstraint()
   * @see #setConstraint(String)
   * @generated
   */
  boolean isSetConstraint();

  /**
   * Returns the value of the '<em><b>Kind</b></em>' attribute.
   * The default value is <code>"NEEDS"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.VariabilityDependencyKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The kind of the variation group (see enumeration VariationGroupKind).
   * <!-- end-model-doc -->
   * @return the value of the '<em>Kind</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.VariabilityDependencyKind
   * @see #isSetKind()
   * @see #unsetKind()
   * @see #setKind(VariabilityDependencyKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariationGroup_Kind()
   * @model default="NEEDS" unsettable="true" required="true"
   *        annotation="MetaData guid='{F69FEFD2-9993-45f6-BEFE-921A1ADC1EAA}' id='117' EA\040name='kind'"
   *        extendedMetaData="name='KIND' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='KINDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  VariabilityDependencyKind getKind();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VariationGroup#getKind <em>Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Kind</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.VariabilityDependencyKind
   * @see #isSetKind()
   * @see #Kind()
   * @see #getKind()
   * @generated
   */
  void setKind(VariabilityDependencyKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.VariationGroup#getKind <em>Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetKind()
   * @see #getKind()
   * @see #setKind(VariabilityDependencyKind)
   * @generated
   */
  void unsetKind();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.VariationGroup#getKind <em>Kind</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Kind</em>' attribute is set.
   * @see #Kind()
   * @see #getKind()
   * @see #setKind(VariabilityDependencyKind)
   * @generated
   */
  boolean isSetKind();

  /**
   * Returns the value of the '<em><b>Variable Element</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.VariableElement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Variable Element</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Variable Element</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariationGroup_VariableElement()
   * @model required="true"
   *        annotation="MetaData guid='{597B9728-418B-41ad-AA19-737796D284C2}' id='58' EA\040name=''"
   *        extendedMetaData="name='VARIABLE-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABLE-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<VariableElement> getVariableElement();

} // VariationGroup
