/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Target element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.VerificationValidation._instanceRef.VVTarget_element</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVTarget_element#getIdentifiable_context <em>Identifiable context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVTarget_element#getIdentifiable_target <em>Identifiable target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVTarget_element()
 * @model annotation="MetaData guid='{F640304C-3F95-4e14-8ECE-46A19BEB566C}' id='-282343243' EA\040name='VVTarget_element'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='VV-TARGET--ELEMENT-IREF'"
 *        extendedMetaData="name='VV-TARGET--ELEMENT-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-TARGET--ELEMENT-IREFS'"
 * @generated
 */
public interface VVTarget_element extends EObject
{
  /**
   * Returns the value of the '<em><b>Identifiable context</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Identifiable}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Identifiable context</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Identifiable context</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVTarget_element_Identifiable_context()
   * @model annotation="MetaData guid='{98F919B6-B2CC-4e31-A999-381687940245}' id='580883985' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='IDENTIFIABLE-CONTEXT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIABLE-CONTEXT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Identifiable> getIdentifiable_context();

  /**
   * Returns the value of the '<em><b>Identifiable target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Identifiable target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Identifiable target</em>' reference.
   * @see #setIdentifiable_target(Identifiable)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVTarget_element_Identifiable_target()
   * @model required="true"
   *        annotation="MetaData guid='{18A407FB-D20C-4ac9-99E4-1959DA88D24F}' id='1713415934' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='IDENTIFIABLE-TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIABLE-TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Identifiable getIdentifiable_target();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VVTarget_element#getIdentifiable_target <em>Identifiable target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Identifiable target</em>' reference.
   * @see #getIdentifiable_target()
   * @generated
   */
  void setIdentifiable_target(Identifiable value);

} // VVTarget_element
