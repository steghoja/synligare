/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hardware Port Connector</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Structure.HardwareModeling.HardwarePortConnector</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusType <em>Bus Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusSpeed <em>Bus Speed</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getConnector <em>Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getPort <em>Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePortConnector()
 * @model annotation="MetaData guid='{13CD52D4-1F53-4be2-9264-00E219AE7E83}' id='-494097061' EA\040name='HardwarePortConnector'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='HARDWARE-PORT-CONNECTOR' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-PORT-CONNECTORS'"
 * @generated
 */
public interface HardwarePortConnector extends AllocationTarget, EAConnector
{
  /**
   * Returns the value of the '<em><b>Bus Type</b></em>' attribute.
   * The default value is <code>"TIMETRIGGERED"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.HardwareBusKind}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bus Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bus Type</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.HardwareBusKind
   * @see #isSetBusType()
   * @see #unsetBusType()
   * @see #setBusType(HardwareBusKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePortConnector_BusType()
   * @model default="TIMETRIGGERED" unsettable="true" required="true"
   *        annotation="MetaData guid='{9478D065-BB67-4c88-ABEE-38287D043D9B}' id='1703572440' EA\040name='busType'"
   *        extendedMetaData="name='BUS-TYPE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BUS-TYPES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  HardwareBusKind getBusType();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusType <em>Bus Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Bus Type</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.HardwareBusKind
   * @see #isSetBusType()
   * @see #BusType()
   * @see #getBusType()
   * @generated
   */
  void setBusType(HardwareBusKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusType <em>Bus Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetBusType()
   * @see #getBusType()
   * @see #setBusType(HardwareBusKind)
   * @generated
   */
  void unsetBusType();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusType <em>Bus Type</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Bus Type</em>' attribute is set.
   * @see #BusType()
   * @see #getBusType()
   * @see #setBusType(HardwareBusKind)
   * @generated
   */
  boolean isSetBusType();

  /**
   * Returns the value of the '<em><b>Bus Speed</b></em>' attribute.
   * The default value is <code>"0.0"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bus Speed</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bus Speed</em>' attribute.
   * @see #isSetBusSpeed()
   * @see #unsetBusSpeed()
   * @see #setBusSpeed(Double)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePortConnector_BusSpeed()
   * @model default="0.0" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Float" required="true"
   *        annotation="MetaData guid='{8CBB34BD-806F-44b1-953C-D8330E872A99}' id='-76911367' EA\040name='busSpeed'"
   *        extendedMetaData="name='BUS-SPEED' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BUS-SPEEDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Double getBusSpeed();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusSpeed <em>Bus Speed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Bus Speed</em>' attribute.
   * @see #isSetBusSpeed()
   * @see #BusSpeed()
   * @see #getBusSpeed()
   * @generated
   */
  void setBusSpeed(Double value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusSpeed <em>Bus Speed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetBusSpeed()
   * @see #getBusSpeed()
   * @see #setBusSpeed(Double)
   * @generated
   */
  void unsetBusSpeed();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector#getBusSpeed <em>Bus Speed</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Bus Speed</em>' attribute is set.
   * @see #BusSpeed()
   * @see #getBusSpeed()
   * @see #setBusSpeed(Double)
   * @generated
   */
  boolean isSetBusSpeed();

  /**
   * Returns the value of the '<em><b>Connector</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HardwareConnector}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Connector</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Connector</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePortConnector_Connector()
   * @model containment="true"
   *        annotation="MetaData guid='{7A73A93C-376A-4b21-9F62-1811EFDC1ECB}' id='1119306007' EA\040name=''"
   *        extendedMetaData="name='CONNECTOR' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONNECTORS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<HardwareConnector> getConnector();

  /**
   * Returns the value of the '<em><b>Port</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HardwarePortConnector_port}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Port</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Port</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePortConnector_Port()
   * @model containment="true" lower="2" upper="2"
   *        annotation="MetaData guid='{9480F58F-5086-4dd1-9391-1CCBD530026E}' id='-1889687530' EA\040name=''"
   *        annotation="TaggedValues xml.name='PORT-IREF' xml.namePlural='PORT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='PORT-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PORT-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<HardwarePortConnector_port> getPort();

} // HardwarePortConnector
