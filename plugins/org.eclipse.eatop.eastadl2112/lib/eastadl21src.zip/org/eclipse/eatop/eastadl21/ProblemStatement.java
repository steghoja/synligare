/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Problem Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The problem statement represents a brief statement summarizing the problem being solved which gives the opportunity to establish traceability from artifacts created later, for example to provide rationales to design decisions or trade-off analysis.
 * 
 * The problem statement could be extended with further modeling of dependencies between different problems and deduction of root problems
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.Needs.ProblemStatement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProblemStatement#getImpact <em>Impact</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProblemStatement#getProblem <em>Problem</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProblemStatement#getSolutionBenefits <em>Solution Benefits</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProblemStatement#getAffects <em>Affects</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProblemStatement()
 * @model annotation="MetaData guid='{DDC69F95-1AB2-4746-9B18-5C973285945A}' id='-1742338348' EA\040name='ProblemStatement'"
 *        extendedMetaData="name='PROBLEM-STATEMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROBLEM-STATEMENTS'"
 * @generated
 */
public interface ProblemStatement extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Impact</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The impact of the problem.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Impact</em>' attribute.
   * @see #isSetImpact()
   * @see #unsetImpact()
   * @see #setImpact(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProblemStatement_Impact()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{F29A09B7-6A02-4958-935B-4B8AC1E7253E}' id='272103163' EA\040name='impact'"
   *        extendedMetaData="name='IMPACT' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IMPACTS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getImpact();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getImpact <em>Impact</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Impact</em>' attribute.
   * @see #isSetImpact()
   * @see #Impact()
   * @see #getImpact()
   * @generated
   */
  void setImpact(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getImpact <em>Impact</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetImpact()
   * @see #getImpact()
   * @see #setImpact(String)
   * @generated
   */
  void unsetImpact();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getImpact <em>Impact</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Impact</em>' attribute is set.
   * @see #Impact()
   * @see #getImpact()
   * @see #setImpact(String)
   * @generated
   */
  boolean isSetImpact();

  /**
   * Returns the value of the '<em><b>Problem</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The brief problem statement. This redefines the text attribute in TraceableSpecification.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Problem</em>' attribute.
   * @see #isSetProblem()
   * @see #unsetProblem()
   * @see #setProblem(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProblemStatement_Problem()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{AE3B4DFB-1052-4e27-8672-7171133B1CF1}' id='2043784005' EA\040name='problem'"
   *        extendedMetaData="name='PROBLEM' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROBLEMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getProblem();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getProblem <em>Problem</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Problem</em>' attribute.
   * @see #isSetProblem()
   * @see #Problem()
   * @see #getProblem()
   * @generated
   */
  void setProblem(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getProblem <em>Problem</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetProblem()
   * @see #getProblem()
   * @see #setProblem(String)
   * @generated
   */
  void unsetProblem();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getProblem <em>Problem</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Problem</em>' attribute is set.
   * @see #Problem()
   * @see #getProblem()
   * @see #setProblem(String)
   * @generated
   */
  boolean isSetProblem();

  /**
   * Returns the value of the '<em><b>Solution Benefits</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Lists some key benefits of a successful solution.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Solution Benefits</em>' attribute.
   * @see #isSetSolutionBenefits()
   * @see #unsetSolutionBenefits()
   * @see #setSolutionBenefits(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProblemStatement_SolutionBenefits()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{84F337AA-1A02-4c2e-92A2-3BD94F539B98}' id='964422688' EA\040name='solutionBenefits'"
   *        extendedMetaData="name='SOLUTION-BENEFITS' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOLUTION-BENEFITSS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getSolutionBenefits();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getSolutionBenefits <em>Solution Benefits</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Solution Benefits</em>' attribute.
   * @see #isSetSolutionBenefits()
   * @see #SolutionBenefits()
   * @see #getSolutionBenefits()
   * @generated
   */
  void setSolutionBenefits(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getSolutionBenefits <em>Solution Benefits</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetSolutionBenefits()
   * @see #getSolutionBenefits()
   * @see #setSolutionBenefits(String)
   * @generated
   */
  void unsetSolutionBenefits();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProblemStatement#getSolutionBenefits <em>Solution Benefits</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Solution Benefits</em>' attribute is set.
   * @see #SolutionBenefits()
   * @see #getSolutionBenefits()
   * @see #setSolutionBenefits(String)
   * @generated
   */
  boolean isSetSolutionBenefits();

  /**
   * Returns the value of the '<em><b>Affects</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Stakeholder}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Affects</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Affects</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProblemStatement_Affects()
   * @model annotation="MetaData guid='{24650B62-2373-4fb8-896B-C98F113EB1C5}' id='-948795142' EA\040name=''"
   *        extendedMetaData="name='AFFECTS-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='AFFECTS-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Stakeholder> getAffects();

} // ProblemStatement
