/**
 */
package org.eclipse.eatop.eastadl21.impl;

import org.eclipse.eatop.eastadl21.ASILKind;
import org.eclipse.eatop.eastadl21.AUTOSAREvent;
import org.eclipse.eatop.eastadl21.Actor;
import org.eclipse.eatop.eastadl21.Actuator;
import org.eclipse.eatop.eastadl21.AgeConstraint;
import org.eclipse.eatop.eastadl21.Allocation;
import org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype;
import org.eclipse.eatop.eastadl21.AnalysisFunctionType;
import org.eclipse.eatop.eastadl21.AnalysisLevel;
import org.eclipse.eatop.eastadl21.ArbitraryConstraint;
import org.eclipse.eatop.eastadl21.ArchitecturalDescription;
import org.eclipse.eatop.eastadl21.ArchitecturalModel;
import org.eclipse.eatop.eastadl21.Architecture;
import org.eclipse.eatop.eastadl21.ArrayDatatype;
import org.eclipse.eatop.eastadl21.Attribute;
import org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint;
import org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType;
import org.eclipse.eatop.eastadl21.Behavior;
import org.eclipse.eatop.eastadl21.BehaviorAttributeBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintType;
import org.eclipse.eatop.eastadl21.BindingTime;
import org.eclipse.eatop.eastadl21.BindingTimeKind;
import org.eclipse.eatop.eastadl21.BurstConstraint;
import org.eclipse.eatop.eastadl21.BusinessOpportunity;
import org.eclipse.eatop.eastadl21.Claim;
import org.eclipse.eatop.eastadl21.ClampConnector;
import org.eclipse.eatop.eastadl21.ClampConnector_port;
import org.eclipse.eatop.eastadl21.ClientServerKind;
import org.eclipse.eatop.eastadl21.Comment;
import org.eclipse.eatop.eastadl21.CommunicationHardwarePin;
import org.eclipse.eatop.eastadl21.ComparisonConstraint;
import org.eclipse.eatop.eastadl21.ComparisonKind;
import org.eclipse.eatop.eastadl21.CompositeDatatype;
import org.eclipse.eatop.eastadl21.ComputationConstraint;
import org.eclipse.eatop.eastadl21.ConfigurableContainer;
import org.eclipse.eatop.eastadl21.ConfigurationDecision;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder;
import org.eclipse.eatop.eastadl21.ContainerConfiguration;
import org.eclipse.eatop.eastadl21.ControllabilityClassKind;
import org.eclipse.eatop.eastadl21.DelayConstraint;
import org.eclipse.eatop.eastadl21.Dependability;
import org.eclipse.eatop.eastadl21.DeriveRequirement;
import org.eclipse.eatop.eastadl21.DesignFunctionPrototype;
import org.eclipse.eatop.eastadl21.DesignFunctionType;
import org.eclipse.eatop.eastadl21.DesignLevel;
import org.eclipse.eatop.eastadl21.DevelopmentCategoryKind;
import org.eclipse.eatop.eastadl21.DeviationAttributeSet;
import org.eclipse.eatop.eastadl21.DeviationPermissionKind;
import org.eclipse.eatop.eastadl21.EAArrayValue;
import org.eclipse.eatop.eastadl21.EABoolean;
import org.eclipse.eatop.eastadl21.EABooleanValue;
import org.eclipse.eatop.eastadl21.EACompositeValue;
import org.eclipse.eatop.eastadl21.EADatatypePrototype;
import org.eclipse.eatop.eastadl21.EADirectionKind;
import org.eclipse.eatop.eastadl21.EAEnumerationValue;
import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.EANumerical;
import org.eclipse.eatop.eastadl21.EANumericalValue;
import org.eclipse.eatop.eastadl21.EAPackage;
import org.eclipse.eatop.eastadl21.EAString;
import org.eclipse.eatop.eastadl21.EAStringValue;
import org.eclipse.eatop.eastadl21.EAXML;
import org.eclipse.eatop.eastadl21.Eastadl21Factory;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ElectricalComponent;
import org.eclipse.eatop.eastadl21.Enumeration;
import org.eclipse.eatop.eastadl21.EnumerationLiteral;
import org.eclipse.eatop.eastadl21.Environment;
import org.eclipse.eatop.eastadl21.ErrorBehavior;
import org.eclipse.eatop.eastadl21.ErrorBehaviorKind;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget;
import org.eclipse.eatop.eastadl21.ErrorModelType;
import org.eclipse.eatop.eastadl21.EventChain;
import org.eclipse.eatop.eastadl21.EventFaultFailure;
import org.eclipse.eatop.eastadl21.EventFeatureFlaw;
import org.eclipse.eatop.eastadl21.EventFunction;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPortKind;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port;
import org.eclipse.eatop.eastadl21.EventFunction_function;
import org.eclipse.eatop.eastadl21.ExecutionTimeConstraint;
import org.eclipse.eatop.eastadl21.ExposureClassKind;
import org.eclipse.eatop.eastadl21.Extend;
import org.eclipse.eatop.eastadl21.ExtensionPoint;
import org.eclipse.eatop.eastadl21.ExternalEvent;
import org.eclipse.eatop.eastadl21.FailureOutPort;
import org.eclipse.eatop.eastadl21.FaultFailure;
import org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort;
import org.eclipse.eatop.eastadl21.FaultFailure_anomaly;
import org.eclipse.eatop.eastadl21.FaultInPort;
import org.eclipse.eatop.eastadl21.Feature;
import org.eclipse.eatop.eastadl21.FeatureConfiguration;
import org.eclipse.eatop.eastadl21.FeatureConstraint;
import org.eclipse.eatop.eastadl21.FeatureFlaw;
import org.eclipse.eatop.eastadl21.FeatureGroup;
import org.eclipse.eatop.eastadl21.FeatureLink;
import org.eclipse.eatop.eastadl21.FeatureModel;
import org.eclipse.eatop.eastadl21.FunctionAllocation;
import org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement;
import org.eclipse.eatop.eastadl21.FunctionAllocation_target;
import org.eclipse.eatop.eastadl21.FunctionBehavior;
import org.eclipse.eatop.eastadl21.FunctionBehaviorKind;
import org.eclipse.eatop.eastadl21.FunctionClientServerInterface;
import org.eclipse.eatop.eastadl21.FunctionClientServerPort;
import org.eclipse.eatop.eastadl21.FunctionConnector;
import org.eclipse.eatop.eastadl21.FunctionConnector_port;
import org.eclipse.eatop.eastadl21.FunctionFlowPort;
import org.eclipse.eatop.eastadl21.FunctionPowerPort;
import org.eclipse.eatop.eastadl21.FunctionTrigger;
import org.eclipse.eatop.eastadl21.FunctionalDevice;
import org.eclipse.eatop.eastadl21.FunctionalSafetyConcept;
import org.eclipse.eatop.eastadl21.GenericConstraint;
import org.eclipse.eatop.eastadl21.GenericConstraintKind;
import org.eclipse.eatop.eastadl21.GenericConstraintSet;
import org.eclipse.eatop.eastadl21.Ground;
import org.eclipse.eatop.eastadl21.HardwareBusKind;
import org.eclipse.eatop.eastadl21.HardwareComponentPrototype;
import org.eclipse.eatop.eastadl21.HardwareComponentType;
import org.eclipse.eatop.eastadl21.HardwareConnector;
import org.eclipse.eatop.eastadl21.HardwareConnector_port;
import org.eclipse.eatop.eastadl21.HardwareFunctionType;
import org.eclipse.eatop.eastadl21.HardwarePort;
import org.eclipse.eatop.eastadl21.HardwarePortConnector;
import org.eclipse.eatop.eastadl21.HardwarePortConnector_port;
import org.eclipse.eatop.eastadl21.Hazard;
import org.eclipse.eatop.eastadl21.HazardousEvent;
import org.eclipse.eatop.eastadl21.IOHardwarePin;
import org.eclipse.eatop.eastadl21.IOHardwarePinKind;
import org.eclipse.eatop.eastadl21.ImplementationLevel;
import org.eclipse.eatop.eastadl21.Include;
import org.eclipse.eatop.eastadl21.InputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.InternalBinding;
import org.eclipse.eatop.eastadl21.InternalFaultPrototype;
import org.eclipse.eatop.eastadl21.Item;
import org.eclipse.eatop.eastadl21.LifecycleStageKind;
import org.eclipse.eatop.eastadl21.LocalDeviceManager;
import org.eclipse.eatop.eastadl21.LogicalEvent;
import org.eclipse.eatop.eastadl21.LogicalPath;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.LogicalTransformation;
import org.eclipse.eatop.eastadl21.Mission;
import org.eclipse.eatop.eastadl21.Mode;
import org.eclipse.eatop.eastadl21.ModeEvent;
import org.eclipse.eatop.eastadl21.ModeGroup;
import org.eclipse.eatop.eastadl21.Node;
import org.eclipse.eatop.eastadl21.Operation;
import org.eclipse.eatop.eastadl21.OperationalSituation;
import org.eclipse.eatop.eastadl21.OrderConstraint;
import org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.PatternConstraint;
import org.eclipse.eatop.eastadl21.PeriodicConstraint;
import org.eclipse.eatop.eastadl21.PortGroup;
import org.eclipse.eatop.eastadl21.PowerHardwarePin;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive;
import org.eclipse.eatop.eastadl21.PrivateContent;
import org.eclipse.eatop.eastadl21.ProblemStatement;
import org.eclipse.eatop.eastadl21.ProcessFaultPrototype;
import org.eclipse.eatop.eastadl21.ProductPositioning;
import org.eclipse.eatop.eastadl21.QualityRequirement;
import org.eclipse.eatop.eastadl21.QualityRequirementKind;
import org.eclipse.eatop.eastadl21.Quantification;
import org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint;
import org.eclipse.eatop.eastadl21.Quantity;
import org.eclipse.eatop.eastadl21.RangeableValueType;
import org.eclipse.eatop.eastadl21.Rationale;
import org.eclipse.eatop.eastadl21.ReactionConstraint;
import org.eclipse.eatop.eastadl21.Realization;
import org.eclipse.eatop.eastadl21.Realization_realized;
import org.eclipse.eatop.eastadl21.Realization_realizedBy;
import org.eclipse.eatop.eastadl21.Refine;
import org.eclipse.eatop.eastadl21.Refine_refinedBy;
import org.eclipse.eatop.eastadl21.RepetitionConstraint;
import org.eclipse.eatop.eastadl21.Requirement;
import org.eclipse.eatop.eastadl21.RequirementsHierarchy;
import org.eclipse.eatop.eastadl21.RequirementsLink;
import org.eclipse.eatop.eastadl21.RequirementsModel;
import org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup;
import org.eclipse.eatop.eastadl21.ReuseMetaInformation;
import org.eclipse.eatop.eastadl21.SafetyCase;
import org.eclipse.eatop.eastadl21.SafetyConstraint;
import org.eclipse.eatop.eastadl21.SafetyGoal;
import org.eclipse.eatop.eastadl21.Satisfy;
import org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy;
import org.eclipse.eatop.eastadl21.SelectionCriterion;
import org.eclipse.eatop.eastadl21.Sensor;
import org.eclipse.eatop.eastadl21.SeverityClassKind;
import org.eclipse.eatop.eastadl21.SporadicConstraint;
import org.eclipse.eatop.eastadl21.Stakeholder;
import org.eclipse.eatop.eastadl21.StakeholderNeed;
import org.eclipse.eatop.eastadl21.State;
import org.eclipse.eatop.eastadl21.StateEvent;
import org.eclipse.eatop.eastadl21.StrongDelayConstraint;
import org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronousTransition;
import org.eclipse.eatop.eastadl21.SystemModel;
import org.eclipse.eatop.eastadl21.TakeRateConstraint;
import org.eclipse.eatop.eastadl21.TechnicalSafetyConcept;
import org.eclipse.eatop.eastadl21.TemporalConstraint;
import org.eclipse.eatop.eastadl21.Timing;
import org.eclipse.eatop.eastadl21.TimingExpression;
import org.eclipse.eatop.eastadl21.TransformationOccurrence;
import org.eclipse.eatop.eastadl21.Transition;
import org.eclipse.eatop.eastadl21.TransitionEvent;
import org.eclipse.eatop.eastadl21.TriggerPolicyKind;
import org.eclipse.eatop.eastadl21.Unit;
import org.eclipse.eatop.eastadl21.UseCase;
import org.eclipse.eatop.eastadl21.UserAttributeDefinition;
import org.eclipse.eatop.eastadl21.UserAttributedElement;
import org.eclipse.eatop.eastadl21.UserElementType;
import org.eclipse.eatop.eastadl21.VVActualOutcome;
import org.eclipse.eatop.eastadl21.VVCase;
import org.eclipse.eatop.eastadl21.VVCase_vvSubject;
import org.eclipse.eatop.eastadl21.VVIntendedOutcome;
import org.eclipse.eatop.eastadl21.VVLog;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.VVStimuli;
import org.eclipse.eatop.eastadl21.VVTarget;
import org.eclipse.eatop.eastadl21.VVTarget_element;
import org.eclipse.eatop.eastadl21.Variability;
import org.eclipse.eatop.eastadl21.VariabilityDependencyKind;
import org.eclipse.eatop.eastadl21.VariableElement;
import org.eclipse.eatop.eastadl21.VariationGroup;
import org.eclipse.eatop.eastadl21.VehicleFeature;
import org.eclipse.eatop.eastadl21.VehicleLevel;
import org.eclipse.eatop.eastadl21.VehicleLevelBinding;
import org.eclipse.eatop.eastadl21.VehicleSystem;
import org.eclipse.eatop.eastadl21.VerificationValidation;
import org.eclipse.eatop.eastadl21.Verify;
import org.eclipse.eatop.eastadl21.Warrant;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Eastadl21FactoryImpl extends EFactoryImpl implements Eastadl21Factory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Eastadl21Factory init()
  {
    try
    {
      Eastadl21Factory theEastadl21Factory = (Eastadl21Factory)EPackage.Registry.INSTANCE.getEFactory(Eastadl21Package.eNS_URI);
      if (theEastadl21Factory != null)
      {
        return theEastadl21Factory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new Eastadl21FactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eastadl21FactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case Eastadl21Package.VEHICLE_LEVEL: return createVehicleLevel();
      case Eastadl21Package.SYSTEM_MODEL: return createSystemModel();
      case Eastadl21Package.ANALYSIS_LEVEL: return createAnalysisLevel();
      case Eastadl21Package.DESIGN_LEVEL: return createDesignLevel();
      case Eastadl21Package.IMPLEMENTATION_LEVEL: return createImplementationLevel();
      case Eastadl21Package.BINDING_TIME: return createBindingTime();
      case Eastadl21Package.FEATURE: return createFeature();
      case Eastadl21Package.FEATURE_CONSTRAINT: return createFeatureConstraint();
      case Eastadl21Package.FEATURE_GROUP: return createFeatureGroup();
      case Eastadl21Package.FEATURE_LINK: return createFeatureLink();
      case Eastadl21Package.FEATURE_MODEL: return createFeatureModel();
      case Eastadl21Package.DEVIATION_ATTRIBUTE_SET: return createDeviationAttributeSet();
      case Eastadl21Package.VEHICLE_FEATURE: return createVehicleFeature();
      case Eastadl21Package.ALLOCATION: return createAllocation();
      case Eastadl21Package.ANALYSIS_FUNCTION_PROTOTYPE: return createAnalysisFunctionPrototype();
      case Eastadl21Package.ANALYSIS_FUNCTION_TYPE: return createAnalysisFunctionType();
      case Eastadl21Package.BASIC_SOFTWARE_FUNCTION_TYPE: return createBasicSoftwareFunctionType();
      case Eastadl21Package.DESIGN_FUNCTION_PROTOTYPE: return createDesignFunctionPrototype();
      case Eastadl21Package.DESIGN_FUNCTION_TYPE: return createDesignFunctionType();
      case Eastadl21Package.FUNCTIONAL_DEVICE: return createFunctionalDevice();
      case Eastadl21Package.FUNCTION_ALLOCATION: return createFunctionAllocation();
      case Eastadl21Package.FUNCTION_CLIENT_SERVER_INTERFACE: return createFunctionClientServerInterface();
      case Eastadl21Package.FUNCTION_CLIENT_SERVER_PORT: return createFunctionClientServerPort();
      case Eastadl21Package.FUNCTION_CONNECTOR: return createFunctionConnector();
      case Eastadl21Package.FUNCTION_FLOW_PORT: return createFunctionFlowPort();
      case Eastadl21Package.FUNCTION_POWER_PORT: return createFunctionPowerPort();
      case Eastadl21Package.HARDWARE_FUNCTION_TYPE: return createHardwareFunctionType();
      case Eastadl21Package.LOCAL_DEVICE_MANAGER: return createLocalDeviceManager();
      case Eastadl21Package.OPERATION: return createOperation();
      case Eastadl21Package.PORT_GROUP: return createPortGroup();
      case Eastadl21Package.FUNCTION_ALLOCATION_ALLOCATED_ELEMENT: return createFunctionAllocation_allocatedElement();
      case Eastadl21Package.FUNCTION_ALLOCATION_TARGET: return createFunctionAllocation_target();
      case Eastadl21Package.FUNCTION_CONNECTOR_PORT: return createFunctionConnector_port();
      case Eastadl21Package.ACTUATOR: return createActuator();
      case Eastadl21Package.COMMUNICATION_HARDWARE_PIN: return createCommunicationHardwarePin();
      case Eastadl21Package.ELECTRICAL_COMPONENT: return createElectricalComponent();
      case Eastadl21Package.HARDWARE_COMPONENT_PROTOTYPE: return createHardwareComponentPrototype();
      case Eastadl21Package.HARDWARE_COMPONENT_TYPE: return createHardwareComponentType();
      case Eastadl21Package.HARDWARE_CONNECTOR: return createHardwareConnector();
      case Eastadl21Package.HARDWARE_PORT: return createHardwarePort();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR: return createHardwarePortConnector();
      case Eastadl21Package.IO_HARDWARE_PIN: return createIOHardwarePin();
      case Eastadl21Package.NODE: return createNode();
      case Eastadl21Package.POWER_HARDWARE_PIN: return createPowerHardwarePin();
      case Eastadl21Package.SENSOR: return createSensor();
      case Eastadl21Package.HARDWARE_CONNECTOR_PORT: return createHardwareConnector_port();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR_PORT: return createHardwarePortConnector_port();
      case Eastadl21Package.CLAMP_CONNECTOR: return createClampConnector();
      case Eastadl21Package.ENVIRONMENT: return createEnvironment();
      case Eastadl21Package.CLAMP_CONNECTOR_PORT: return createClampConnector_port();
      case Eastadl21Package.BEHAVIOR: return createBehavior();
      case Eastadl21Package.MODE: return createMode();
      case Eastadl21Package.MODE_GROUP: return createModeGroup();
      case Eastadl21Package.FUNCTION_BEHAVIOR: return createFunctionBehavior();
      case Eastadl21Package.FUNCTION_TRIGGER: return createFunctionTrigger();
      case Eastadl21Package.CONFIGURABLE_CONTAINER: return createConfigurableContainer();
      case Eastadl21Package.CONFIGURATION_DECISION: return createConfigurationDecision();
      case Eastadl21Package.CONFIGURATION_DECISION_FOLDER: return createConfigurationDecisionFolder();
      case Eastadl21Package.CONTAINER_CONFIGURATION: return createContainerConfiguration();
      case Eastadl21Package.FEATURE_CONFIGURATION: return createFeatureConfiguration();
      case Eastadl21Package.INTERNAL_BINDING: return createInternalBinding();
      case Eastadl21Package.PRIVATE_CONTENT: return createPrivateContent();
      case Eastadl21Package.REUSE_META_INFORMATION: return createReuseMetaInformation();
      case Eastadl21Package.SELECTION_CRITERION: return createSelectionCriterion();
      case Eastadl21Package.VARIABILITY: return createVariability();
      case Eastadl21Package.VARIABLE_ELEMENT: return createVariableElement();
      case Eastadl21Package.VARIATION_GROUP: return createVariationGroup();
      case Eastadl21Package.VEHICLE_LEVEL_BINDING: return createVehicleLevelBinding();
      case Eastadl21Package.DERIVE_REQUIREMENT: return createDeriveRequirement();
      case Eastadl21Package.OPERATIONAL_SITUATION: return createOperationalSituation();
      case Eastadl21Package.REQUIREMENTS_MODEL: return createRequirementsModel();
      case Eastadl21Package.REQUIREMENT: return createRequirement();
      case Eastadl21Package.REQUIREMENTS_HIERARCHY: return createRequirementsHierarchy();
      case Eastadl21Package.REFINE: return createRefine();
      case Eastadl21Package.SATISFY: return createSatisfy();
      case Eastadl21Package.REQUIREMENTS_LINK: return createRequirementsLink();
      case Eastadl21Package.REQUIREMENTS_RELATIONSHIP_GROUP: return createRequirementsRelationshipGroup();
      case Eastadl21Package.QUALITY_REQUIREMENT: return createQualityRequirement();
      case Eastadl21Package.REFINE_REFINED_BY: return createRefine_refinedBy();
      case Eastadl21Package.SATISFY_SATISFIED_BY: return createSatisfy_satisfiedBy();
      case Eastadl21Package.ACTOR: return createActor();
      case Eastadl21Package.EXTEND: return createExtend();
      case Eastadl21Package.EXTENSION_POINT: return createExtensionPoint();
      case Eastadl21Package.INCLUDE: return createInclude();
      case Eastadl21Package.USE_CASE: return createUseCase();
      case Eastadl21Package.VERIFICATION_VALIDATION: return createVerificationValidation();
      case Eastadl21Package.VERIFY: return createVerify();
      case Eastadl21Package.VV_ACTUAL_OUTCOME: return createVVActualOutcome();
      case Eastadl21Package.VV_CASE: return createVVCase();
      case Eastadl21Package.VV_INTENDED_OUTCOME: return createVVIntendedOutcome();
      case Eastadl21Package.VV_LOG: return createVVLog();
      case Eastadl21Package.VV_PROCEDURE: return createVVProcedure();
      case Eastadl21Package.VV_STIMULI: return createVVStimuli();
      case Eastadl21Package.VV_TARGET: return createVVTarget();
      case Eastadl21Package.VV_CASE_VV_SUBJECT: return createVVCase_vvSubject();
      case Eastadl21Package.VV_TARGET_ELEMENT: return createVVTarget_element();
      case Eastadl21Package.EVENT_CHAIN: return createEventChain();
      case Eastadl21Package.PRECEDENCE_CONSTRAINT: return createPrecedenceConstraint();
      case Eastadl21Package.TIMING: return createTiming();
      case Eastadl21Package.TIMING_EXPRESSION: return createTimingExpression();
      case Eastadl21Package.AUTOSAR_EVENT: return createAUTOSAREvent();
      case Eastadl21Package.EVENT_FAULT_FAILURE: return createEventFaultFailure();
      case Eastadl21Package.EVENT_FEATURE_FLAW: return createEventFeatureFlaw();
      case Eastadl21Package.EVENT_FUNCTION: return createEventFunction();
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT: return createEventFunctionClientServerPort();
      case Eastadl21Package.EVENT_FUNCTION_FLOW_PORT: return createEventFunctionFlowPort();
      case Eastadl21Package.EXTERNAL_EVENT: return createExternalEvent();
      case Eastadl21Package.MODE_EVENT: return createModeEvent();
      case Eastadl21Package.EVENT_FUNCTION_FUNCTION: return createEventFunction_function();
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT: return createEventFunctionClientServerPort_port();
      case Eastadl21Package.EVENT_FUNCTION_FLOW_PORT_PORT: return createEventFunctionFlowPort_port();
      case Eastadl21Package.AGE_CONSTRAINT: return createAgeConstraint();
      case Eastadl21Package.ARBITRARY_CONSTRAINT: return createArbitraryConstraint();
      case Eastadl21Package.BURST_CONSTRAINT: return createBurstConstraint();
      case Eastadl21Package.COMPARISON_CONSTRAINT: return createComparisonConstraint();
      case Eastadl21Package.DELAY_CONSTRAINT: return createDelayConstraint();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT: return createExecutionTimeConstraint();
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT: return createInputSynchronizationConstraint();
      case Eastadl21Package.ORDER_CONSTRAINT: return createOrderConstraint();
      case Eastadl21Package.OUTPUT_SYNCHRONIZATION_CONSTRAINT: return createOutputSynchronizationConstraint();
      case Eastadl21Package.PATTERN_CONSTRAINT: return createPatternConstraint();
      case Eastadl21Package.PERIODIC_CONSTRAINT: return createPeriodicConstraint();
      case Eastadl21Package.REACTION_CONSTRAINT: return createReactionConstraint();
      case Eastadl21Package.REPETITION_CONSTRAINT: return createRepetitionConstraint();
      case Eastadl21Package.SPORADIC_CONSTRAINT: return createSporadicConstraint();
      case Eastadl21Package.STRONG_DELAY_CONSTRAINT: return createStrongDelayConstraint();
      case Eastadl21Package.STRONG_SYNCHRONIZATION_CONSTRAINT: return createStrongSynchronizationConstraint();
      case Eastadl21Package.SYNCHRONIZATION_CONSTRAINT: return createSynchronizationConstraint();
      case Eastadl21Package.PRECEDENCE_CONSTRAINT_PRECEDING: return createPrecedenceConstraint_preceding();
      case Eastadl21Package.PRECEDENCE_CONSTRAINT_SUCCESSIVE: return createPrecedenceConstraint_successive();
      case Eastadl21Package.DEPENDABILITY: return createDependability();
      case Eastadl21Package.FEATURE_FLAW: return createFeatureFlaw();
      case Eastadl21Package.HAZARD: return createHazard();
      case Eastadl21Package.HAZARDOUS_EVENT: return createHazardousEvent();
      case Eastadl21Package.ITEM: return createItem();
      case Eastadl21Package.FAULT_FAILURE: return createFaultFailure();
      case Eastadl21Package.QUANTITATIVE_SAFETY_CONSTRAINT: return createQuantitativeSafetyConstraint();
      case Eastadl21Package.SAFETY_CONSTRAINT: return createSafetyConstraint();
      case Eastadl21Package.FAULT_FAILURE_ANOMALY: return createFaultFailure_anomaly();
      case Eastadl21Package.ERROR_BEHAVIOR: return createErrorBehavior();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE: return createErrorModelPrototype();
      case Eastadl21Package.ERROR_MODEL_TYPE: return createErrorModelType();
      case Eastadl21Package.FAILURE_OUT_PORT: return createFailureOutPort();
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK: return createFaultFailurePropagationLink();
      case Eastadl21Package.FAULT_IN_PORT: return createFaultInPort();
      case Eastadl21Package.INTERNAL_FAULT_PROTOTYPE: return createInternalFaultPrototype();
      case Eastadl21Package.PROCESS_FAULT_PROTOTYPE: return createProcessFaultPrototype();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE_FUNCTION_TARGET: return createErrorModelPrototype_functionTarget();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE_HW_TARGET: return createErrorModelPrototype_hwTarget();
      case Eastadl21Package.FAULT_FAILURE_PORT_FUNCTION_TARGET: return createFaultFailurePort_functionTarget();
      case Eastadl21Package.FAULT_FAILURE_PORT_HW_TARGET: return createFaultFailurePort_hwTarget();
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT: return createFaultFailurePropagationLink_fromPort();
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_TO_PORT: return createFaultFailurePropagationLink_toPort();
      case Eastadl21Package.FUNCTIONAL_SAFETY_CONCEPT: return createFunctionalSafetyConcept();
      case Eastadl21Package.SAFETY_GOAL: return createSafetyGoal();
      case Eastadl21Package.TECHNICAL_SAFETY_CONCEPT: return createTechnicalSafetyConcept();
      case Eastadl21Package.CLAIM: return createClaim();
      case Eastadl21Package.GROUND: return createGround();
      case Eastadl21Package.SAFETY_CASE: return createSafetyCase();
      case Eastadl21Package.WARRANT: return createWarrant();
      case Eastadl21Package.GENERIC_CONSTRAINT: return createGenericConstraint();
      case Eastadl21Package.GENERIC_CONSTRAINT_SET: return createGenericConstraintSet();
      case Eastadl21Package.TAKE_RATE_CONSTRAINT: return createTakeRateConstraint();
      case Eastadl21Package.COMMENT: return createComment();
      case Eastadl21Package.EA_PACKAGE: return createEAPackage();
      case Eastadl21Package.EAXML: return createEAXML();
      case Eastadl21Package.RATIONALE: return createRationale();
      case Eastadl21Package.REALIZATION: return createRealization();
      case Eastadl21Package.REALIZATION_REALIZED: return createRealization_realized();
      case Eastadl21Package.REALIZATION_REALIZED_BY: return createRealization_realizedBy();
      case Eastadl21Package.ARRAY_DATATYPE: return createArrayDatatype();
      case Eastadl21Package.COMPOSITE_DATATYPE: return createCompositeDatatype();
      case Eastadl21Package.EA_BOOLEAN: return createEABoolean();
      case Eastadl21Package.EA_DATATYPE_PROTOTYPE: return createEADatatypePrototype();
      case Eastadl21Package.EA_NUMERICAL: return createEANumerical();
      case Eastadl21Package.EA_STRING: return createEAString();
      case Eastadl21Package.ENUMERATION: return createEnumeration();
      case Eastadl21Package.ENUMERATION_LITERAL: return createEnumerationLiteral();
      case Eastadl21Package.QUANTITY: return createQuantity();
      case Eastadl21Package.RANGEABLE_VALUE_TYPE: return createRangeableValueType();
      case Eastadl21Package.UNIT: return createUnit();
      case Eastadl21Package.EA_ARRAY_VALUE: return createEAArrayValue();
      case Eastadl21Package.EA_BOOLEAN_VALUE: return createEABooleanValue();
      case Eastadl21Package.EA_COMPOSITE_VALUE: return createEACompositeValue();
      case Eastadl21Package.EA_ENUMERATION_VALUE: return createEAEnumerationValue();
      case Eastadl21Package.EA_EXPRESSION: return createEAExpression();
      case Eastadl21Package.EA_NUMERICAL_VALUE: return createEANumericalValue();
      case Eastadl21Package.EA_STRING_VALUE: return createEAStringValue();
      case Eastadl21Package.USER_ATTRIBUTE_DEFINITION: return createUserAttributeDefinition();
      case Eastadl21Package.USER_ATTRIBUTED_ELEMENT: return createUserAttributedElement();
      case Eastadl21Package.USER_ELEMENT_TYPE: return createUserElementType();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_BINDING_ATTRIBUTE: return createBehaviorConstraintBindingAttribute();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT: return createBehaviorConstraintBindingEvent();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE: return createBehaviorConstraintPrototype();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING: return createBehaviorConstraintTargetBinding();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE: return createBehaviorConstraintType();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR: return createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_HARDWARE_CONNECTOR: return createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET: return createBehaviorConstraintPrototype_errorModelTarget();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_FUNCTION_TARGET: return createBehaviorConstraintPrototype_functionTarget();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_HARDWARE_COMPONENT_TARGET: return createBehaviorConstraintPrototype_hardwareComponentTarget();
      case Eastadl21Package.ATTRIBUTE: return createAttribute();
      case Eastadl21Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT: return createAttributeQuantificationConstraint();
      case Eastadl21Package.BEHAVIOR_ATTRIBUTE_BINDING: return createBehaviorAttributeBinding();
      case Eastadl21Package.LOGICAL_EVENT: return createLogicalEvent();
      case Eastadl21Package.QUANTIFICATION: return createQuantification();
      case Eastadl21Package.COMPUTATION_CONSTRAINT: return createComputationConstraint();
      case Eastadl21Package.LOGICAL_PATH: return createLogicalPath();
      case Eastadl21Package.LOGICAL_TRANSFORMATION: return createLogicalTransformation();
      case Eastadl21Package.TRANSFORMATION_OCCURRENCE: return createTransformationOccurrence();
      case Eastadl21Package.LOGICAL_TIME_CONDITION: return createLogicalTimeCondition();
      case Eastadl21Package.STATE: return createState();
      case Eastadl21Package.STATE_EVENT: return createStateEvent();
      case Eastadl21Package.SYNCHRONOUS_TRANSITION: return createSynchronousTransition();
      case Eastadl21Package.TEMPORAL_CONSTRAINT: return createTemporalConstraint();
      case Eastadl21Package.TRANSITION: return createTransition();
      case Eastadl21Package.TRANSITION_EVENT: return createTransitionEvent();
      case Eastadl21Package.ARCHITECTURAL_DESCRIPTION: return createArchitecturalDescription();
      case Eastadl21Package.ARCHITECTURAL_MODEL: return createArchitecturalModel();
      case Eastadl21Package.ARCHITECTURE: return createArchitecture();
      case Eastadl21Package.MISSION: return createMission();
      case Eastadl21Package.VEHICLE_SYSTEM: return createVehicleSystem();
      case Eastadl21Package.STAKEHOLDER: return createStakeholder();
      case Eastadl21Package.STAKEHOLDER_NEED: return createStakeholderNeed();
      case Eastadl21Package.BUSINESS_OPPORTUNITY: return createBusinessOpportunity();
      case Eastadl21Package.PROBLEM_STATEMENT: return createProblemStatement();
      case Eastadl21Package.PRODUCT_POSITIONING: return createProductPositioning();
      case Eastadl21Package.SYSTEM: return createSystem();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object createFromString(EDataType eDataType, String initialValue)
  {
    switch (eDataType.getClassifierID())
    {
      case Eastadl21Package.BINDING_TIME_KIND:
        return createBindingTimeKindFromString(eDataType, initialValue);
      case Eastadl21Package.VARIABILITY_DEPENDENCY_KIND:
        return createVariabilityDependencyKindFromString(eDataType, initialValue);
      case Eastadl21Package.DEVIATION_PERMISSION_KIND:
        return createDeviationPermissionKindFromString(eDataType, initialValue);
      case Eastadl21Package.CLIENT_SERVER_KIND:
        return createClientServerKindFromString(eDataType, initialValue);
      case Eastadl21Package.EA_DIRECTION_KIND:
        return createEADirectionKindFromString(eDataType, initialValue);
      case Eastadl21Package.HARDWARE_BUS_KIND:
        return createHardwareBusKindFromString(eDataType, initialValue);
      case Eastadl21Package.IO_HARDWARE_PIN_KIND:
        return createIOHardwarePinKindFromString(eDataType, initialValue);
      case Eastadl21Package.FUNCTION_BEHAVIOR_KIND:
        return createFunctionBehaviorKindFromString(eDataType, initialValue);
      case Eastadl21Package.TRIGGER_POLICY_KIND:
        return createTriggerPolicyKindFromString(eDataType, initialValue);
      case Eastadl21Package.QUALITY_REQUIREMENT_KIND:
        return createQualityRequirementKindFromString(eDataType, initialValue);
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_KIND:
        return createEventFunctionClientServerPortKindFromString(eDataType, initialValue);
      case Eastadl21Package.COMPARISON_KIND:
        return createComparisonKindFromString(eDataType, initialValue);
      case Eastadl21Package.CONTROLLABILITY_CLASS_KIND:
        return createControllabilityClassKindFromString(eDataType, initialValue);
      case Eastadl21Package.DEVELOPMENT_CATEGORY_KIND:
        return createDevelopmentCategoryKindFromString(eDataType, initialValue);
      case Eastadl21Package.EXPOSURE_CLASS_KIND:
        return createExposureClassKindFromString(eDataType, initialValue);
      case Eastadl21Package.SEVERITY_CLASS_KIND:
        return createSeverityClassKindFromString(eDataType, initialValue);
      case Eastadl21Package.ASIL_KIND:
        return createASILKindFromString(eDataType, initialValue);
      case Eastadl21Package.ERROR_BEHAVIOR_KIND:
        return createErrorBehaviorKindFromString(eDataType, initialValue);
      case Eastadl21Package.LIFECYCLE_STAGE_KIND:
        return createLifecycleStageKindFromString(eDataType, initialValue);
      case Eastadl21Package.GENERIC_CONSTRAINT_KIND:
        return createGenericConstraintKindFromString(eDataType, initialValue);
      case Eastadl21Package.BOOLEAN:
        return createBooleanFromString(eDataType, initialValue);
      case Eastadl21Package.FLOAT:
        return createFloatFromString(eDataType, initialValue);
      case Eastadl21Package.IDENTIFIER:
        return createIdentifierFromString(eDataType, initialValue);
      case Eastadl21Package.INTEGER:
        return createIntegerFromString(eDataType, initialValue);
      case Eastadl21Package.NUMERICAL:
        return createNumericalFromString(eDataType, initialValue);
      case Eastadl21Package.REF:
        return createRefFromString(eDataType, initialValue);
      case Eastadl21Package.STRING:
        return createStringFromString(eDataType, initialValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String convertToString(EDataType eDataType, Object instanceValue)
  {
    switch (eDataType.getClassifierID())
    {
      case Eastadl21Package.BINDING_TIME_KIND:
        return convertBindingTimeKindToString(eDataType, instanceValue);
      case Eastadl21Package.VARIABILITY_DEPENDENCY_KIND:
        return convertVariabilityDependencyKindToString(eDataType, instanceValue);
      case Eastadl21Package.DEVIATION_PERMISSION_KIND:
        return convertDeviationPermissionKindToString(eDataType, instanceValue);
      case Eastadl21Package.CLIENT_SERVER_KIND:
        return convertClientServerKindToString(eDataType, instanceValue);
      case Eastadl21Package.EA_DIRECTION_KIND:
        return convertEADirectionKindToString(eDataType, instanceValue);
      case Eastadl21Package.HARDWARE_BUS_KIND:
        return convertHardwareBusKindToString(eDataType, instanceValue);
      case Eastadl21Package.IO_HARDWARE_PIN_KIND:
        return convertIOHardwarePinKindToString(eDataType, instanceValue);
      case Eastadl21Package.FUNCTION_BEHAVIOR_KIND:
        return convertFunctionBehaviorKindToString(eDataType, instanceValue);
      case Eastadl21Package.TRIGGER_POLICY_KIND:
        return convertTriggerPolicyKindToString(eDataType, instanceValue);
      case Eastadl21Package.QUALITY_REQUIREMENT_KIND:
        return convertQualityRequirementKindToString(eDataType, instanceValue);
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_KIND:
        return convertEventFunctionClientServerPortKindToString(eDataType, instanceValue);
      case Eastadl21Package.COMPARISON_KIND:
        return convertComparisonKindToString(eDataType, instanceValue);
      case Eastadl21Package.CONTROLLABILITY_CLASS_KIND:
        return convertControllabilityClassKindToString(eDataType, instanceValue);
      case Eastadl21Package.DEVELOPMENT_CATEGORY_KIND:
        return convertDevelopmentCategoryKindToString(eDataType, instanceValue);
      case Eastadl21Package.EXPOSURE_CLASS_KIND:
        return convertExposureClassKindToString(eDataType, instanceValue);
      case Eastadl21Package.SEVERITY_CLASS_KIND:
        return convertSeverityClassKindToString(eDataType, instanceValue);
      case Eastadl21Package.ASIL_KIND:
        return convertASILKindToString(eDataType, instanceValue);
      case Eastadl21Package.ERROR_BEHAVIOR_KIND:
        return convertErrorBehaviorKindToString(eDataType, instanceValue);
      case Eastadl21Package.LIFECYCLE_STAGE_KIND:
        return convertLifecycleStageKindToString(eDataType, instanceValue);
      case Eastadl21Package.GENERIC_CONSTRAINT_KIND:
        return convertGenericConstraintKindToString(eDataType, instanceValue);
      case Eastadl21Package.BOOLEAN:
        return convertBooleanToString(eDataType, instanceValue);
      case Eastadl21Package.FLOAT:
        return convertFloatToString(eDataType, instanceValue);
      case Eastadl21Package.IDENTIFIER:
        return convertIdentifierToString(eDataType, instanceValue);
      case Eastadl21Package.INTEGER:
        return convertIntegerToString(eDataType, instanceValue);
      case Eastadl21Package.NUMERICAL:
        return convertNumericalToString(eDataType, instanceValue);
      case Eastadl21Package.REF:
        return convertRefToString(eDataType, instanceValue);
      case Eastadl21Package.STRING:
        return convertStringToString(eDataType, instanceValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VehicleLevel createVehicleLevel()
  {
    VehicleLevelImpl vehicleLevel = new VehicleLevelImpl();
    return vehicleLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SystemModel createSystemModel()
  {
    SystemModelImpl systemModel = new SystemModelImpl();
    return systemModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AnalysisLevel createAnalysisLevel()
  {
    AnalysisLevelImpl analysisLevel = new AnalysisLevelImpl();
    return analysisLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DesignLevel createDesignLevel()
  {
    DesignLevelImpl designLevel = new DesignLevelImpl();
    return designLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ImplementationLevel createImplementationLevel()
  {
    ImplementationLevelImpl implementationLevel = new ImplementationLevelImpl();
    return implementationLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BindingTime createBindingTime()
  {
    BindingTimeImpl bindingTime = new BindingTimeImpl();
    return bindingTime;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Feature createFeature()
  {
    FeatureImpl feature = new FeatureImpl();
    return feature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureConstraint createFeatureConstraint()
  {
    FeatureConstraintImpl featureConstraint = new FeatureConstraintImpl();
    return featureConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureGroup createFeatureGroup()
  {
    FeatureGroupImpl featureGroup = new FeatureGroupImpl();
    return featureGroup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureLink createFeatureLink()
  {
    FeatureLinkImpl featureLink = new FeatureLinkImpl();
    return featureLink;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureModel createFeatureModel()
  {
    FeatureModelImpl featureModel = new FeatureModelImpl();
    return featureModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DeviationAttributeSet createDeviationAttributeSet()
  {
    DeviationAttributeSetImpl deviationAttributeSet = new DeviationAttributeSetImpl();
    return deviationAttributeSet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VehicleFeature createVehicleFeature()
  {
    VehicleFeatureImpl vehicleFeature = new VehicleFeatureImpl();
    return vehicleFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Allocation createAllocation()
  {
    AllocationImpl allocation = new AllocationImpl();
    return allocation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AnalysisFunctionPrototype createAnalysisFunctionPrototype()
  {
    AnalysisFunctionPrototypeImpl analysisFunctionPrototype = new AnalysisFunctionPrototypeImpl();
    return analysisFunctionPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AnalysisFunctionType createAnalysisFunctionType()
  {
    AnalysisFunctionTypeImpl analysisFunctionType = new AnalysisFunctionTypeImpl();
    return analysisFunctionType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BasicSoftwareFunctionType createBasicSoftwareFunctionType()
  {
    BasicSoftwareFunctionTypeImpl basicSoftwareFunctionType = new BasicSoftwareFunctionTypeImpl();
    return basicSoftwareFunctionType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DesignFunctionPrototype createDesignFunctionPrototype()
  {
    DesignFunctionPrototypeImpl designFunctionPrototype = new DesignFunctionPrototypeImpl();
    return designFunctionPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DesignFunctionType createDesignFunctionType()
  {
    DesignFunctionTypeImpl designFunctionType = new DesignFunctionTypeImpl();
    return designFunctionType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionalDevice createFunctionalDevice()
  {
    FunctionalDeviceImpl functionalDevice = new FunctionalDeviceImpl();
    return functionalDevice;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionAllocation createFunctionAllocation()
  {
    FunctionAllocationImpl functionAllocation = new FunctionAllocationImpl();
    return functionAllocation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionClientServerInterface createFunctionClientServerInterface()
  {
    FunctionClientServerInterfaceImpl functionClientServerInterface = new FunctionClientServerInterfaceImpl();
    return functionClientServerInterface;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionClientServerPort createFunctionClientServerPort()
  {
    FunctionClientServerPortImpl functionClientServerPort = new FunctionClientServerPortImpl();
    return functionClientServerPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionConnector createFunctionConnector()
  {
    FunctionConnectorImpl functionConnector = new FunctionConnectorImpl();
    return functionConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionFlowPort createFunctionFlowPort()
  {
    FunctionFlowPortImpl functionFlowPort = new FunctionFlowPortImpl();
    return functionFlowPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionPowerPort createFunctionPowerPort()
  {
    FunctionPowerPortImpl functionPowerPort = new FunctionPowerPortImpl();
    return functionPowerPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareFunctionType createHardwareFunctionType()
  {
    HardwareFunctionTypeImpl hardwareFunctionType = new HardwareFunctionTypeImpl();
    return hardwareFunctionType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LocalDeviceManager createLocalDeviceManager()
  {
    LocalDeviceManagerImpl localDeviceManager = new LocalDeviceManagerImpl();
    return localDeviceManager;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Operation createOperation()
  {
    OperationImpl operation = new OperationImpl();
    return operation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PortGroup createPortGroup()
  {
    PortGroupImpl portGroup = new PortGroupImpl();
    return portGroup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionAllocation_allocatedElement createFunctionAllocation_allocatedElement()
  {
    FunctionAllocation_allocatedElementImpl functionAllocation_allocatedElement = new FunctionAllocation_allocatedElementImpl();
    return functionAllocation_allocatedElement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionAllocation_target createFunctionAllocation_target()
  {
    FunctionAllocation_targetImpl functionAllocation_target = new FunctionAllocation_targetImpl();
    return functionAllocation_target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionConnector_port createFunctionConnector_port()
  {
    FunctionConnector_portImpl functionConnector_port = new FunctionConnector_portImpl();
    return functionConnector_port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Actuator createActuator()
  {
    ActuatorImpl actuator = new ActuatorImpl();
    return actuator;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CommunicationHardwarePin createCommunicationHardwarePin()
  {
    CommunicationHardwarePinImpl communicationHardwarePin = new CommunicationHardwarePinImpl();
    return communicationHardwarePin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ElectricalComponent createElectricalComponent()
  {
    ElectricalComponentImpl electricalComponent = new ElectricalComponentImpl();
    return electricalComponent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareComponentPrototype createHardwareComponentPrototype()
  {
    HardwareComponentPrototypeImpl hardwareComponentPrototype = new HardwareComponentPrototypeImpl();
    return hardwareComponentPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareComponentType createHardwareComponentType()
  {
    HardwareComponentTypeImpl hardwareComponentType = new HardwareComponentTypeImpl();
    return hardwareComponentType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareConnector createHardwareConnector()
  {
    HardwareConnectorImpl hardwareConnector = new HardwareConnectorImpl();
    return hardwareConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwarePort createHardwarePort()
  {
    HardwarePortImpl hardwarePort = new HardwarePortImpl();
    return hardwarePort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwarePortConnector createHardwarePortConnector()
  {
    HardwarePortConnectorImpl hardwarePortConnector = new HardwarePortConnectorImpl();
    return hardwarePortConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IOHardwarePin createIOHardwarePin()
  {
    IOHardwarePinImpl ioHardwarePin = new IOHardwarePinImpl();
    return ioHardwarePin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Node createNode()
  {
    NodeImpl node = new NodeImpl();
    return node;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PowerHardwarePin createPowerHardwarePin()
  {
    PowerHardwarePinImpl powerHardwarePin = new PowerHardwarePinImpl();
    return powerHardwarePin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Sensor createSensor()
  {
    SensorImpl sensor = new SensorImpl();
    return sensor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareConnector_port createHardwareConnector_port()
  {
    HardwareConnector_portImpl hardwareConnector_port = new HardwareConnector_portImpl();
    return hardwareConnector_port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwarePortConnector_port createHardwarePortConnector_port()
  {
    HardwarePortConnector_portImpl hardwarePortConnector_port = new HardwarePortConnector_portImpl();
    return hardwarePortConnector_port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ClampConnector createClampConnector()
  {
    ClampConnectorImpl clampConnector = new ClampConnectorImpl();
    return clampConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Environment createEnvironment()
  {
    EnvironmentImpl environment = new EnvironmentImpl();
    return environment;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ClampConnector_port createClampConnector_port()
  {
    ClampConnector_portImpl clampConnector_port = new ClampConnector_portImpl();
    return clampConnector_port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Behavior createBehavior()
  {
    BehaviorImpl behavior = new BehaviorImpl();
    return behavior;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Mode createMode()
  {
    ModeImpl mode = new ModeImpl();
    return mode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModeGroup createModeGroup()
  {
    ModeGroupImpl modeGroup = new ModeGroupImpl();
    return modeGroup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionBehavior createFunctionBehavior()
  {
    FunctionBehaviorImpl functionBehavior = new FunctionBehaviorImpl();
    return functionBehavior;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionTrigger createFunctionTrigger()
  {
    FunctionTriggerImpl functionTrigger = new FunctionTriggerImpl();
    return functionTrigger;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigurableContainer createConfigurableContainer()
  {
    ConfigurableContainerImpl configurableContainer = new ConfigurableContainerImpl();
    return configurableContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigurationDecision createConfigurationDecision()
  {
    ConfigurationDecisionImpl configurationDecision = new ConfigurationDecisionImpl();
    return configurationDecision;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigurationDecisionFolder createConfigurationDecisionFolder()
  {
    ConfigurationDecisionFolderImpl configurationDecisionFolder = new ConfigurationDecisionFolderImpl();
    return configurationDecisionFolder;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ContainerConfiguration createContainerConfiguration()
  {
    ContainerConfigurationImpl containerConfiguration = new ContainerConfigurationImpl();
    return containerConfiguration;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureConfiguration createFeatureConfiguration()
  {
    FeatureConfigurationImpl featureConfiguration = new FeatureConfigurationImpl();
    return featureConfiguration;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InternalBinding createInternalBinding()
  {
    InternalBindingImpl internalBinding = new InternalBindingImpl();
    return internalBinding;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PrivateContent createPrivateContent()
  {
    PrivateContentImpl privateContent = new PrivateContentImpl();
    return privateContent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ReuseMetaInformation createReuseMetaInformation()
  {
    ReuseMetaInformationImpl reuseMetaInformation = new ReuseMetaInformationImpl();
    return reuseMetaInformation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SelectionCriterion createSelectionCriterion()
  {
    SelectionCriterionImpl selectionCriterion = new SelectionCriterionImpl();
    return selectionCriterion;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Variability createVariability()
  {
    VariabilityImpl variability = new VariabilityImpl();
    return variability;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VariableElement createVariableElement()
  {
    VariableElementImpl variableElement = new VariableElementImpl();
    return variableElement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VariationGroup createVariationGroup()
  {
    VariationGroupImpl variationGroup = new VariationGroupImpl();
    return variationGroup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VehicleLevelBinding createVehicleLevelBinding()
  {
    VehicleLevelBindingImpl vehicleLevelBinding = new VehicleLevelBindingImpl();
    return vehicleLevelBinding;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DeriveRequirement createDeriveRequirement()
  {
    DeriveRequirementImpl deriveRequirement = new DeriveRequirementImpl();
    return deriveRequirement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OperationalSituation createOperationalSituation()
  {
    OperationalSituationImpl operationalSituation = new OperationalSituationImpl();
    return operationalSituation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RequirementsModel createRequirementsModel()
  {
    RequirementsModelImpl requirementsModel = new RequirementsModelImpl();
    return requirementsModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Requirement createRequirement()
  {
    RequirementImpl requirement = new RequirementImpl();
    return requirement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RequirementsHierarchy createRequirementsHierarchy()
  {
    RequirementsHierarchyImpl requirementsHierarchy = new RequirementsHierarchyImpl();
    return requirementsHierarchy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Refine createRefine()
  {
    RefineImpl refine = new RefineImpl();
    return refine;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Satisfy createSatisfy()
  {
    SatisfyImpl satisfy = new SatisfyImpl();
    return satisfy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RequirementsLink createRequirementsLink()
  {
    RequirementsLinkImpl requirementsLink = new RequirementsLinkImpl();
    return requirementsLink;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RequirementsRelationshipGroup createRequirementsRelationshipGroup()
  {
    RequirementsRelationshipGroupImpl requirementsRelationshipGroup = new RequirementsRelationshipGroupImpl();
    return requirementsRelationshipGroup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public QualityRequirement createQualityRequirement()
  {
    QualityRequirementImpl qualityRequirement = new QualityRequirementImpl();
    return qualityRequirement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Refine_refinedBy createRefine_refinedBy()
  {
    Refine_refinedByImpl refine_refinedBy = new Refine_refinedByImpl();
    return refine_refinedBy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Satisfy_satisfiedBy createSatisfy_satisfiedBy()
  {
    Satisfy_satisfiedByImpl satisfy_satisfiedBy = new Satisfy_satisfiedByImpl();
    return satisfy_satisfiedBy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Actor createActor()
  {
    ActorImpl actor = new ActorImpl();
    return actor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Extend createExtend()
  {
    ExtendImpl extend = new ExtendImpl();
    return extend;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExtensionPoint createExtensionPoint()
  {
    ExtensionPointImpl extensionPoint = new ExtensionPointImpl();
    return extensionPoint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Include createInclude()
  {
    IncludeImpl include = new IncludeImpl();
    return include;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UseCase createUseCase()
  {
    UseCaseImpl useCase = new UseCaseImpl();
    return useCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VerificationValidation createVerificationValidation()
  {
    VerificationValidationImpl verificationValidation = new VerificationValidationImpl();
    return verificationValidation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Verify createVerify()
  {
    VerifyImpl verify = new VerifyImpl();
    return verify;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVActualOutcome createVVActualOutcome()
  {
    VVActualOutcomeImpl vvActualOutcome = new VVActualOutcomeImpl();
    return vvActualOutcome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVCase createVVCase()
  {
    VVCaseImpl vvCase = new VVCaseImpl();
    return vvCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVIntendedOutcome createVVIntendedOutcome()
  {
    VVIntendedOutcomeImpl vvIntendedOutcome = new VVIntendedOutcomeImpl();
    return vvIntendedOutcome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVLog createVVLog()
  {
    VVLogImpl vvLog = new VVLogImpl();
    return vvLog;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVProcedure createVVProcedure()
  {
    VVProcedureImpl vvProcedure = new VVProcedureImpl();
    return vvProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVStimuli createVVStimuli()
  {
    VVStimuliImpl vvStimuli = new VVStimuliImpl();
    return vvStimuli;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVTarget createVVTarget()
  {
    VVTargetImpl vvTarget = new VVTargetImpl();
    return vvTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVCase_vvSubject createVVCase_vvSubject()
  {
    VVCase_vvSubjectImpl vvCase_vvSubject = new VVCase_vvSubjectImpl();
    return vvCase_vvSubject;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVTarget_element createVVTarget_element()
  {
    VVTarget_elementImpl vvTarget_element = new VVTarget_elementImpl();
    return vvTarget_element;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventChain createEventChain()
  {
    EventChainImpl eventChain = new EventChainImpl();
    return eventChain;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PrecedenceConstraint createPrecedenceConstraint()
  {
    PrecedenceConstraintImpl precedenceConstraint = new PrecedenceConstraintImpl();
    return precedenceConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Timing createTiming()
  {
    TimingImpl timing = new TimingImpl();
    return timing;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression createTimingExpression()
  {
    TimingExpressionImpl timingExpression = new TimingExpressionImpl();
    return timingExpression;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AUTOSAREvent createAUTOSAREvent()
  {
    AUTOSAREventImpl autosarEvent = new AUTOSAREventImpl();
    return autosarEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFaultFailure createEventFaultFailure()
  {
    EventFaultFailureImpl eventFaultFailure = new EventFaultFailureImpl();
    return eventFaultFailure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFeatureFlaw createEventFeatureFlaw()
  {
    EventFeatureFlawImpl eventFeatureFlaw = new EventFeatureFlawImpl();
    return eventFeatureFlaw;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunction createEventFunction()
  {
    EventFunctionImpl eventFunction = new EventFunctionImpl();
    return eventFunction;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunctionClientServerPort createEventFunctionClientServerPort()
  {
    EventFunctionClientServerPortImpl eventFunctionClientServerPort = new EventFunctionClientServerPortImpl();
    return eventFunctionClientServerPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunctionFlowPort createEventFunctionFlowPort()
  {
    EventFunctionFlowPortImpl eventFunctionFlowPort = new EventFunctionFlowPortImpl();
    return eventFunctionFlowPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExternalEvent createExternalEvent()
  {
    ExternalEventImpl externalEvent = new ExternalEventImpl();
    return externalEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModeEvent createModeEvent()
  {
    ModeEventImpl modeEvent = new ModeEventImpl();
    return modeEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunction_function createEventFunction_function()
  {
    EventFunction_functionImpl eventFunction_function = new EventFunction_functionImpl();
    return eventFunction_function;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunctionClientServerPort_port createEventFunctionClientServerPort_port()
  {
    EventFunctionClientServerPort_portImpl eventFunctionClientServerPort_port = new EventFunctionClientServerPort_portImpl();
    return eventFunctionClientServerPort_port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunctionFlowPort_port createEventFunctionFlowPort_port()
  {
    EventFunctionFlowPort_portImpl eventFunctionFlowPort_port = new EventFunctionFlowPort_portImpl();
    return eventFunctionFlowPort_port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AgeConstraint createAgeConstraint()
  {
    AgeConstraintImpl ageConstraint = new AgeConstraintImpl();
    return ageConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ArbitraryConstraint createArbitraryConstraint()
  {
    ArbitraryConstraintImpl arbitraryConstraint = new ArbitraryConstraintImpl();
    return arbitraryConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BurstConstraint createBurstConstraint()
  {
    BurstConstraintImpl burstConstraint = new BurstConstraintImpl();
    return burstConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ComparisonConstraint createComparisonConstraint()
  {
    ComparisonConstraintImpl comparisonConstraint = new ComparisonConstraintImpl();
    return comparisonConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DelayConstraint createDelayConstraint()
  {
    DelayConstraintImpl delayConstraint = new DelayConstraintImpl();
    return delayConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExecutionTimeConstraint createExecutionTimeConstraint()
  {
    ExecutionTimeConstraintImpl executionTimeConstraint = new ExecutionTimeConstraintImpl();
    return executionTimeConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSynchronizationConstraint createInputSynchronizationConstraint()
  {
    InputSynchronizationConstraintImpl inputSynchronizationConstraint = new InputSynchronizationConstraintImpl();
    return inputSynchronizationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OrderConstraint createOrderConstraint()
  {
    OrderConstraintImpl orderConstraint = new OrderConstraintImpl();
    return orderConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputSynchronizationConstraint createOutputSynchronizationConstraint()
  {
    OutputSynchronizationConstraintImpl outputSynchronizationConstraint = new OutputSynchronizationConstraintImpl();
    return outputSynchronizationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PatternConstraint createPatternConstraint()
  {
    PatternConstraintImpl patternConstraint = new PatternConstraintImpl();
    return patternConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PeriodicConstraint createPeriodicConstraint()
  {
    PeriodicConstraintImpl periodicConstraint = new PeriodicConstraintImpl();
    return periodicConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ReactionConstraint createReactionConstraint()
  {
    ReactionConstraintImpl reactionConstraint = new ReactionConstraintImpl();
    return reactionConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RepetitionConstraint createRepetitionConstraint()
  {
    RepetitionConstraintImpl repetitionConstraint = new RepetitionConstraintImpl();
    return repetitionConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SporadicConstraint createSporadicConstraint()
  {
    SporadicConstraintImpl sporadicConstraint = new SporadicConstraintImpl();
    return sporadicConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StrongDelayConstraint createStrongDelayConstraint()
  {
    StrongDelayConstraintImpl strongDelayConstraint = new StrongDelayConstraintImpl();
    return strongDelayConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StrongSynchronizationConstraint createStrongSynchronizationConstraint()
  {
    StrongSynchronizationConstraintImpl strongSynchronizationConstraint = new StrongSynchronizationConstraintImpl();
    return strongSynchronizationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SynchronizationConstraint createSynchronizationConstraint()
  {
    SynchronizationConstraintImpl synchronizationConstraint = new SynchronizationConstraintImpl();
    return synchronizationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PrecedenceConstraint_preceding createPrecedenceConstraint_preceding()
  {
    PrecedenceConstraint_precedingImpl precedenceConstraint_preceding = new PrecedenceConstraint_precedingImpl();
    return precedenceConstraint_preceding;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PrecedenceConstraint_successive createPrecedenceConstraint_successive()
  {
    PrecedenceConstraint_successiveImpl precedenceConstraint_successive = new PrecedenceConstraint_successiveImpl();
    return precedenceConstraint_successive;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Dependability createDependability()
  {
    DependabilityImpl dependability = new DependabilityImpl();
    return dependability;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureFlaw createFeatureFlaw()
  {
    FeatureFlawImpl featureFlaw = new FeatureFlawImpl();
    return featureFlaw;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Hazard createHazard()
  {
    HazardImpl hazard = new HazardImpl();
    return hazard;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HazardousEvent createHazardousEvent()
  {
    HazardousEventImpl hazardousEvent = new HazardousEventImpl();
    return hazardousEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Item createItem()
  {
    ItemImpl item = new ItemImpl();
    return item;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailure createFaultFailure()
  {
    FaultFailureImpl faultFailure = new FaultFailureImpl();
    return faultFailure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public QuantitativeSafetyConstraint createQuantitativeSafetyConstraint()
  {
    QuantitativeSafetyConstraintImpl quantitativeSafetyConstraint = new QuantitativeSafetyConstraintImpl();
    return quantitativeSafetyConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SafetyConstraint createSafetyConstraint()
  {
    SafetyConstraintImpl safetyConstraint = new SafetyConstraintImpl();
    return safetyConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailure_anomaly createFaultFailure_anomaly()
  {
    FaultFailure_anomalyImpl faultFailure_anomaly = new FaultFailure_anomalyImpl();
    return faultFailure_anomaly;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorBehavior createErrorBehavior()
  {
    ErrorBehaviorImpl errorBehavior = new ErrorBehaviorImpl();
    return errorBehavior;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelPrototype createErrorModelPrototype()
  {
    ErrorModelPrototypeImpl errorModelPrototype = new ErrorModelPrototypeImpl();
    return errorModelPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelType createErrorModelType()
  {
    ErrorModelTypeImpl errorModelType = new ErrorModelTypeImpl();
    return errorModelType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FailureOutPort createFailureOutPort()
  {
    FailureOutPortImpl failureOutPort = new FailureOutPortImpl();
    return failureOutPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePropagationLink createFaultFailurePropagationLink()
  {
    FaultFailurePropagationLinkImpl faultFailurePropagationLink = new FaultFailurePropagationLinkImpl();
    return faultFailurePropagationLink;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultInPort createFaultInPort()
  {
    FaultInPortImpl faultInPort = new FaultInPortImpl();
    return faultInPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InternalFaultPrototype createInternalFaultPrototype()
  {
    InternalFaultPrototypeImpl internalFaultPrototype = new InternalFaultPrototypeImpl();
    return internalFaultPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ProcessFaultPrototype createProcessFaultPrototype()
  {
    ProcessFaultPrototypeImpl processFaultPrototype = new ProcessFaultPrototypeImpl();
    return processFaultPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelPrototype_functionTarget createErrorModelPrototype_functionTarget()
  {
    ErrorModelPrototype_functionTargetImpl errorModelPrototype_functionTarget = new ErrorModelPrototype_functionTargetImpl();
    return errorModelPrototype_functionTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelPrototype_hwTarget createErrorModelPrototype_hwTarget()
  {
    ErrorModelPrototype_hwTargetImpl errorModelPrototype_hwTarget = new ErrorModelPrototype_hwTargetImpl();
    return errorModelPrototype_hwTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePort_functionTarget createFaultFailurePort_functionTarget()
  {
    FaultFailurePort_functionTargetImpl faultFailurePort_functionTarget = new FaultFailurePort_functionTargetImpl();
    return faultFailurePort_functionTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePort_hwTarget createFaultFailurePort_hwTarget()
  {
    FaultFailurePort_hwTargetImpl faultFailurePort_hwTarget = new FaultFailurePort_hwTargetImpl();
    return faultFailurePort_hwTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePropagationLink_fromPort createFaultFailurePropagationLink_fromPort()
  {
    FaultFailurePropagationLink_fromPortImpl faultFailurePropagationLink_fromPort = new FaultFailurePropagationLink_fromPortImpl();
    return faultFailurePropagationLink_fromPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePropagationLink_toPort createFaultFailurePropagationLink_toPort()
  {
    FaultFailurePropagationLink_toPortImpl faultFailurePropagationLink_toPort = new FaultFailurePropagationLink_toPortImpl();
    return faultFailurePropagationLink_toPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionalSafetyConcept createFunctionalSafetyConcept()
  {
    FunctionalSafetyConceptImpl functionalSafetyConcept = new FunctionalSafetyConceptImpl();
    return functionalSafetyConcept;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SafetyGoal createSafetyGoal()
  {
    SafetyGoalImpl safetyGoal = new SafetyGoalImpl();
    return safetyGoal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TechnicalSafetyConcept createTechnicalSafetyConcept()
  {
    TechnicalSafetyConceptImpl technicalSafetyConcept = new TechnicalSafetyConceptImpl();
    return technicalSafetyConcept;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Claim createClaim()
  {
    ClaimImpl claim = new ClaimImpl();
    return claim;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Ground createGround()
  {
    GroundImpl ground = new GroundImpl();
    return ground;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SafetyCase createSafetyCase()
  {
    SafetyCaseImpl safetyCase = new SafetyCaseImpl();
    return safetyCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Warrant createWarrant()
  {
    WarrantImpl warrant = new WarrantImpl();
    return warrant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenericConstraint createGenericConstraint()
  {
    GenericConstraintImpl genericConstraint = new GenericConstraintImpl();
    return genericConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenericConstraintSet createGenericConstraintSet()
  {
    GenericConstraintSetImpl genericConstraintSet = new GenericConstraintSetImpl();
    return genericConstraintSet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TakeRateConstraint createTakeRateConstraint()
  {
    TakeRateConstraintImpl takeRateConstraint = new TakeRateConstraintImpl();
    return takeRateConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Comment createComment()
  {
    CommentImpl comment = new CommentImpl();
    return comment;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAPackage createEAPackage()
  {
    EAPackageImpl eaPackage = new EAPackageImpl();
    return eaPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAXML createEAXML()
  {
    EAXMLImpl eaxml = new EAXMLImpl();
    return eaxml;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Rationale createRationale()
  {
    RationaleImpl rationale = new RationaleImpl();
    return rationale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Realization createRealization()
  {
    RealizationImpl realization = new RealizationImpl();
    return realization;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Realization_realized createRealization_realized()
  {
    Realization_realizedImpl realization_realized = new Realization_realizedImpl();
    return realization_realized;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Realization_realizedBy createRealization_realizedBy()
  {
    Realization_realizedByImpl realization_realizedBy = new Realization_realizedByImpl();
    return realization_realizedBy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ArrayDatatype createArrayDatatype()
  {
    ArrayDatatypeImpl arrayDatatype = new ArrayDatatypeImpl();
    return arrayDatatype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CompositeDatatype createCompositeDatatype()
  {
    CompositeDatatypeImpl compositeDatatype = new CompositeDatatypeImpl();
    return compositeDatatype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EABoolean createEABoolean()
  {
    EABooleanImpl eaBoolean = new EABooleanImpl();
    return eaBoolean;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EADatatypePrototype createEADatatypePrototype()
  {
    EADatatypePrototypeImpl eaDatatypePrototype = new EADatatypePrototypeImpl();
    return eaDatatypePrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EANumerical createEANumerical()
  {
    EANumericalImpl eaNumerical = new EANumericalImpl();
    return eaNumerical;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAString createEAString()
  {
    EAStringImpl eaString = new EAStringImpl();
    return eaString;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Enumeration createEnumeration()
  {
    EnumerationImpl enumeration = new EnumerationImpl();
    return enumeration;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EnumerationLiteral createEnumerationLiteral()
  {
    EnumerationLiteralImpl enumerationLiteral = new EnumerationLiteralImpl();
    return enumerationLiteral;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Quantity createQuantity()
  {
    QuantityImpl quantity = new QuantityImpl();
    return quantity;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RangeableValueType createRangeableValueType()
  {
    RangeableValueTypeImpl rangeableValueType = new RangeableValueTypeImpl();
    return rangeableValueType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Unit createUnit()
  {
    UnitImpl unit = new UnitImpl();
    return unit;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAArrayValue createEAArrayValue()
  {
    EAArrayValueImpl eaArrayValue = new EAArrayValueImpl();
    return eaArrayValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EABooleanValue createEABooleanValue()
  {
    EABooleanValueImpl eaBooleanValue = new EABooleanValueImpl();
    return eaBooleanValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EACompositeValue createEACompositeValue()
  {
    EACompositeValueImpl eaCompositeValue = new EACompositeValueImpl();
    return eaCompositeValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAEnumerationValue createEAEnumerationValue()
  {
    EAEnumerationValueImpl eaEnumerationValue = new EAEnumerationValueImpl();
    return eaEnumerationValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAExpression createEAExpression()
  {
    EAExpressionImpl eaExpression = new EAExpressionImpl();
    return eaExpression;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EANumericalValue createEANumericalValue()
  {
    EANumericalValueImpl eaNumericalValue = new EANumericalValueImpl();
    return eaNumericalValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAStringValue createEAStringValue()
  {
    EAStringValueImpl eaStringValue = new EAStringValueImpl();
    return eaStringValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UserAttributeDefinition createUserAttributeDefinition()
  {
    UserAttributeDefinitionImpl userAttributeDefinition = new UserAttributeDefinitionImpl();
    return userAttributeDefinition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UserAttributedElement createUserAttributedElement()
  {
    UserAttributedElementImpl userAttributedElement = new UserAttributedElementImpl();
    return userAttributedElement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UserElementType createUserElementType()
  {
    UserElementTypeImpl userElementType = new UserElementTypeImpl();
    return userElementType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintBindingAttribute createBehaviorConstraintBindingAttribute()
  {
    BehaviorConstraintBindingAttributeImpl behaviorConstraintBindingAttribute = new BehaviorConstraintBindingAttributeImpl();
    return behaviorConstraintBindingAttribute;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintBindingEvent createBehaviorConstraintBindingEvent()
  {
    BehaviorConstraintBindingEventImpl behaviorConstraintBindingEvent = new BehaviorConstraintBindingEventImpl();
    return behaviorConstraintBindingEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintPrototype createBehaviorConstraintPrototype()
  {
    BehaviorConstraintPrototypeImpl behaviorConstraintPrototype = new BehaviorConstraintPrototypeImpl();
    return behaviorConstraintPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintTargetBinding createBehaviorConstraintTargetBinding()
  {
    BehaviorConstraintTargetBindingImpl behaviorConstraintTargetBinding = new BehaviorConstraintTargetBindingImpl();
    return behaviorConstraintTargetBinding;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintType createBehaviorConstraintType()
  {
    BehaviorConstraintTypeImpl behaviorConstraintType = new BehaviorConstraintTypeImpl();
    return behaviorConstraintType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintInternalBinding_bindingThroughFunctionConnector createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector()
  {
    BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl behaviorConstraintInternalBinding_bindingThroughFunctionConnector = new BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl();
    return behaviorConstraintInternalBinding_bindingThroughFunctionConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintInternalBinding_bindingThroughHardwareConnector createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector()
  {
    BehaviorConstraintInternalBinding_bindingThroughHardwareConnectorImpl behaviorConstraintInternalBinding_bindingThroughHardwareConnector = new BehaviorConstraintInternalBinding_bindingThroughHardwareConnectorImpl();
    return behaviorConstraintInternalBinding_bindingThroughHardwareConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintPrototype_errorModelTarget createBehaviorConstraintPrototype_errorModelTarget()
  {
    BehaviorConstraintPrototype_errorModelTargetImpl behaviorConstraintPrototype_errorModelTarget = new BehaviorConstraintPrototype_errorModelTargetImpl();
    return behaviorConstraintPrototype_errorModelTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintPrototype_functionTarget createBehaviorConstraintPrototype_functionTarget()
  {
    BehaviorConstraintPrototype_functionTargetImpl behaviorConstraintPrototype_functionTarget = new BehaviorConstraintPrototype_functionTargetImpl();
    return behaviorConstraintPrototype_functionTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintPrototype_hardwareComponentTarget createBehaviorConstraintPrototype_hardwareComponentTarget()
  {
    BehaviorConstraintPrototype_hardwareComponentTargetImpl behaviorConstraintPrototype_hardwareComponentTarget = new BehaviorConstraintPrototype_hardwareComponentTargetImpl();
    return behaviorConstraintPrototype_hardwareComponentTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Attribute createAttribute()
  {
    AttributeImpl attribute = new AttributeImpl();
    return attribute;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AttributeQuantificationConstraint createAttributeQuantificationConstraint()
  {
    AttributeQuantificationConstraintImpl attributeQuantificationConstraint = new AttributeQuantificationConstraintImpl();
    return attributeQuantificationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorAttributeBinding createBehaviorAttributeBinding()
  {
    BehaviorAttributeBindingImpl behaviorAttributeBinding = new BehaviorAttributeBindingImpl();
    return behaviorAttributeBinding;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalEvent createLogicalEvent()
  {
    LogicalEventImpl logicalEvent = new LogicalEventImpl();
    return logicalEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Quantification createQuantification()
  {
    QuantificationImpl quantification = new QuantificationImpl();
    return quantification;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ComputationConstraint createComputationConstraint()
  {
    ComputationConstraintImpl computationConstraint = new ComputationConstraintImpl();
    return computationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalPath createLogicalPath()
  {
    LogicalPathImpl logicalPath = new LogicalPathImpl();
    return logicalPath;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTransformation createLogicalTransformation()
  {
    LogicalTransformationImpl logicalTransformation = new LogicalTransformationImpl();
    return logicalTransformation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransformationOccurrence createTransformationOccurrence()
  {
    TransformationOccurrenceImpl transformationOccurrence = new TransformationOccurrenceImpl();
    return transformationOccurrence;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition createLogicalTimeCondition()
  {
    LogicalTimeConditionImpl logicalTimeCondition = new LogicalTimeConditionImpl();
    return logicalTimeCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public State createState()
  {
    StateImpl state = new StateImpl();
    return state;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StateEvent createStateEvent()
  {
    StateEventImpl stateEvent = new StateEventImpl();
    return stateEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SynchronousTransition createSynchronousTransition()
  {
    SynchronousTransitionImpl synchronousTransition = new SynchronousTransitionImpl();
    return synchronousTransition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TemporalConstraint createTemporalConstraint()
  {
    TemporalConstraintImpl temporalConstraint = new TemporalConstraintImpl();
    return temporalConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Transition createTransition()
  {
    TransitionImpl transition = new TransitionImpl();
    return transition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent createTransitionEvent()
  {
    TransitionEventImpl transitionEvent = new TransitionEventImpl();
    return transitionEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ArchitecturalDescription createArchitecturalDescription()
  {
    ArchitecturalDescriptionImpl architecturalDescription = new ArchitecturalDescriptionImpl();
    return architecturalDescription;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ArchitecturalModel createArchitecturalModel()
  {
    ArchitecturalModelImpl architecturalModel = new ArchitecturalModelImpl();
    return architecturalModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Architecture createArchitecture()
  {
    ArchitectureImpl architecture = new ArchitectureImpl();
    return architecture;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Mission createMission()
  {
    MissionImpl mission = new MissionImpl();
    return mission;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VehicleSystem createVehicleSystem()
  {
    VehicleSystemImpl vehicleSystem = new VehicleSystemImpl();
    return vehicleSystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Stakeholder createStakeholder()
  {
    StakeholderImpl stakeholder = new StakeholderImpl();
    return stakeholder;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StakeholderNeed createStakeholderNeed()
  {
    StakeholderNeedImpl stakeholderNeed = new StakeholderNeedImpl();
    return stakeholderNeed;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BusinessOpportunity createBusinessOpportunity()
  {
    BusinessOpportunityImpl businessOpportunity = new BusinessOpportunityImpl();
    return businessOpportunity;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ProblemStatement createProblemStatement()
  {
    ProblemStatementImpl problemStatement = new ProblemStatementImpl();
    return problemStatement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ProductPositioning createProductPositioning()
  {
    ProductPositioningImpl productPositioning = new ProductPositioningImpl();
    return productPositioning;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public org.eclipse.eatop.eastadl21.System createSystem()
  {
    SystemImpl system = new SystemImpl();
    return system;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BindingTimeKind createBindingTimeKindFromString(EDataType eDataType, String initialValue)
  {
    BindingTimeKind result = BindingTimeKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertBindingTimeKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VariabilityDependencyKind createVariabilityDependencyKindFromString(EDataType eDataType, String initialValue)
  {
    VariabilityDependencyKind result = VariabilityDependencyKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertVariabilityDependencyKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DeviationPermissionKind createDeviationPermissionKindFromString(EDataType eDataType, String initialValue)
  {
    DeviationPermissionKind result = DeviationPermissionKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertDeviationPermissionKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ClientServerKind createClientServerKindFromString(EDataType eDataType, String initialValue)
  {
    ClientServerKind result = ClientServerKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertClientServerKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EADirectionKind createEADirectionKindFromString(EDataType eDataType, String initialValue)
  {
    EADirectionKind result = EADirectionKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertEADirectionKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareBusKind createHardwareBusKindFromString(EDataType eDataType, String initialValue)
  {
    HardwareBusKind result = HardwareBusKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertHardwareBusKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IOHardwarePinKind createIOHardwarePinKindFromString(EDataType eDataType, String initialValue)
  {
    IOHardwarePinKind result = IOHardwarePinKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertIOHardwarePinKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionBehaviorKind createFunctionBehaviorKindFromString(EDataType eDataType, String initialValue)
  {
    FunctionBehaviorKind result = FunctionBehaviorKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertFunctionBehaviorKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TriggerPolicyKind createTriggerPolicyKindFromString(EDataType eDataType, String initialValue)
  {
    TriggerPolicyKind result = TriggerPolicyKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertTriggerPolicyKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public QualityRequirementKind createQualityRequirementKindFromString(EDataType eDataType, String initialValue)
  {
    QualityRequirementKind result = QualityRequirementKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertQualityRequirementKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventFunctionClientServerPortKind createEventFunctionClientServerPortKindFromString(EDataType eDataType, String initialValue)
  {
    EventFunctionClientServerPortKind result = EventFunctionClientServerPortKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertEventFunctionClientServerPortKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ComparisonKind createComparisonKindFromString(EDataType eDataType, String initialValue)
  {
    ComparisonKind result = ComparisonKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertComparisonKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ControllabilityClassKind createControllabilityClassKindFromString(EDataType eDataType, String initialValue)
  {
    ControllabilityClassKind result = ControllabilityClassKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertControllabilityClassKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DevelopmentCategoryKind createDevelopmentCategoryKindFromString(EDataType eDataType, String initialValue)
  {
    DevelopmentCategoryKind result = DevelopmentCategoryKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertDevelopmentCategoryKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExposureClassKind createExposureClassKindFromString(EDataType eDataType, String initialValue)
  {
    ExposureClassKind result = ExposureClassKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertExposureClassKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SeverityClassKind createSeverityClassKindFromString(EDataType eDataType, String initialValue)
  {
    SeverityClassKind result = SeverityClassKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertSeverityClassKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ASILKind createASILKindFromString(EDataType eDataType, String initialValue)
  {
    ASILKind result = ASILKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertASILKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorBehaviorKind createErrorBehaviorKindFromString(EDataType eDataType, String initialValue)
  {
    ErrorBehaviorKind result = ErrorBehaviorKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertErrorBehaviorKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LifecycleStageKind createLifecycleStageKindFromString(EDataType eDataType, String initialValue)
  {
    LifecycleStageKind result = LifecycleStageKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertLifecycleStageKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenericConstraintKind createGenericConstraintKindFromString(EDataType eDataType, String initialValue)
  {
    GenericConstraintKind result = GenericConstraintKind.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertGenericConstraintKindToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean createBooleanFromString(EDataType eDataType, String initialValue)
  {
    return (Boolean)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertBooleanToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Double createFloatFromString(EDataType eDataType, String initialValue)
  {
    return (Double)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertFloatToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String createIdentifierFromString(EDataType eDataType, String initialValue)
  {
    return (String)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertIdentifierToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Integer createIntegerFromString(EDataType eDataType, String initialValue)
  {
    return (Integer)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertIntegerToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String createNumericalFromString(EDataType eDataType, String initialValue)
  {
    return (String)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertNumericalToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String createRefFromString(EDataType eDataType, String initialValue)
  {
    return (String)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertRefToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String createStringFromString(EDataType eDataType, String initialValue)
  {
    return (String)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertStringToString(EDataType eDataType, Object instanceValue)
  {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eastadl21Package getEastadl21Package()
  {
    return (Eastadl21Package)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static Eastadl21Package getPackage()
  {
    return Eastadl21Package.eINSTANCE;
  }

} //Eastadl21FactoryImpl
