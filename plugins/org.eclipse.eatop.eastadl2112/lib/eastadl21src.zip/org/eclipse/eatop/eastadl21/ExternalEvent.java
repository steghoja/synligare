/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>External Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An ExternalEvent instance stands for some particular form of state change.
 * 
 * It is implied that the attribute description uniquely identifies the intended form of state change. It is also assumed that a description string is sufficiently informative to determine an unambiguous set of occurrences for each observation.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Events.ExternalEvent</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExternalEvent()
 * @model annotation="MetaData guid='{C62DCC34-EEA5-490c-86CA-4B76C61EB6B3}' id='832760891' EA\040name='ExternalEvent'"
 *        extendedMetaData="name='EXTERNAL-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTERNAL-EVENTS'"
 * @generated
 */
public interface ExternalEvent extends Event
{
} // ExternalEvent
