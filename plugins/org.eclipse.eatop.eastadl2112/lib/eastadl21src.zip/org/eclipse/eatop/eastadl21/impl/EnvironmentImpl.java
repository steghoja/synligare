/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.ClampConnector;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Environment;
import org.eclipse.eatop.eastadl21.FunctionPrototype;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Environment</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.EnvironmentImpl#getClampConnector <em>Clamp Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.EnvironmentImpl#getEnvironmentModel <em>Environment Model</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EnvironmentImpl extends ContextImpl implements Environment
{
  /**
   * The cached value of the '{@link #getClampConnector() <em>Clamp Connector</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getClampConnector()
   * @generated
   * @ordered
   */
  protected EList<ClampConnector> clampConnector;

  /**
   * The cached value of the '{@link #getEnvironmentModel() <em>Environment Model</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnvironmentModel()
   * @generated
   * @ordered
   */
  protected FunctionPrototype environmentModel;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EnvironmentImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getEnvironment();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ClampConnector> getClampConnector()
  {
    if (clampConnector == null)
    {
      clampConnector = new EObjectContainmentEList<ClampConnector>(ClampConnector.class, this, Eastadl21Package.ENVIRONMENT__CLAMP_CONNECTOR);
    }
    return clampConnector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FunctionPrototype getEnvironmentModel()
  {
    return environmentModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEnvironmentModel(FunctionPrototype newEnvironmentModel, NotificationChain msgs)
  {
    FunctionPrototype oldEnvironmentModel = environmentModel;
    environmentModel = newEnvironmentModel;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL, oldEnvironmentModel, newEnvironmentModel);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEnvironmentModel(FunctionPrototype newEnvironmentModel)
  {
    if (newEnvironmentModel != environmentModel)
    {
      NotificationChain msgs = null;
      if (environmentModel != null)
        msgs = ((InternalEObject)environmentModel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL, null, msgs);
      if (newEnvironmentModel != null)
        msgs = ((InternalEObject)newEnvironmentModel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL, null, msgs);
      msgs = basicSetEnvironmentModel(newEnvironmentModel, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL, newEnvironmentModel, newEnvironmentModel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.ENVIRONMENT__CLAMP_CONNECTOR:
        return ((InternalEList<?>)getClampConnector()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL:
        return basicSetEnvironmentModel(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.ENVIRONMENT__CLAMP_CONNECTOR:
        return getClampConnector();
      case Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL:
        return getEnvironmentModel();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.ENVIRONMENT__CLAMP_CONNECTOR:
        getClampConnector().clear();
        getClampConnector().addAll((Collection<? extends ClampConnector>)newValue);
        return;
      case Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL:
   			setEnvironmentModel((FunctionPrototype)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.ENVIRONMENT__CLAMP_CONNECTOR:
        getClampConnector().clear();
        return;
      case Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL:
        	setEnvironmentModel((FunctionPrototype)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.ENVIRONMENT__CLAMP_CONNECTOR:
        return clampConnector != null && !clampConnector.isEmpty();
      case Eastadl21Package.ENVIRONMENT__ENVIRONMENT_MODEL:
        return environmentModel != null;
    }
    return super.eIsSet(featureID);
  }

} //EnvironmentImpl
