/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure Propagation Link</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The FaultFailurePropagationLink metaclass represents the links for the propagations of faults/failures across system elements. In particular, it defines that one error model provides the faults/failures that another error model receives.
 * 
 * A fault/failure link can only be applied to compatible ports, either for fault/failure delegation within an error model or for fault/failure transmission across two error models. A FaultFailurePropagationLink can only connect fault/failure ports that have compatible types. 
 * 
 * Constraints:
 * [1] Only compatible fromPort-toPort pairs may be connected.
 * 
 * [2] Two fault/failure ports are compatible if the EADatatype of the fromPort represents a subset of the Fault/Failure set represented by the toPort�s EADatatype. 
 * 
 * 
 * Semantics:
 * The FaultFailurePropagationLink defines a Failure propagation path, from the fromPort on one error model to the toPort of another error model. 
 * 
 * 
 * Extension:
 * UML::Connector
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel.FaultFailurePropagationLink</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getImmediatePropagation <em>Immediate Propagation</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getFromPort <em>From Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getToPort <em>To Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink()
 * @model annotation="MetaData guid='{57BE9BD3-BEE4-4b4a-8596-4E366AC3E1CD}' id='34132384' EA\040name='FaultFailurePropagationLink'"
 *        extendedMetaData="name='FAULT-FAILURE-PROPAGATION-LINK' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-PROPAGATION-LINKS'"
 * @generated
 */
public interface FaultFailurePropagationLink extends EAElement, EAConnector
{
  /**
   * Returns the value of the '<em><b>Immediate Propagation</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Immediate Propagation</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Immediate Propagation</em>' attribute.
   * @see #isSetImmediatePropagation()
   * @see #unsetImmediatePropagation()
   * @see #setImmediatePropagation(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink_ImmediatePropagation()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{C9D390D9-9404-4456-B2B2-D36A5CB2564B}' id='-1284191635' EA\040name='immediatePropagation'"
   *        extendedMetaData="name='IMMEDIATE-PROPAGATION' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IMMEDIATE-PROPAGATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getImmediatePropagation();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getImmediatePropagation <em>Immediate Propagation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Immediate Propagation</em>' attribute.
   * @see #isSetImmediatePropagation()
   * @see #ImmediatePropagation()
   * @see #getImmediatePropagation()
   * @generated
   */
  void setImmediatePropagation(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getImmediatePropagation <em>Immediate Propagation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetImmediatePropagation()
   * @see #getImmediatePropagation()
   * @see #setImmediatePropagation(Boolean)
   * @generated
   */
  void unsetImmediatePropagation();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getImmediatePropagation <em>Immediate Propagation</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Immediate Propagation</em>' attribute is set.
   * @see #ImmediatePropagation()
   * @see #getImmediatePropagation()
   * @see #setImmediatePropagation(Boolean)
   * @generated
   */
  boolean isSetImmediatePropagation();

  /**
   * Returns the value of the '<em><b>From Port</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>From Port</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>From Port</em>' containment reference.
   * @see #setFromPort(FaultFailurePropagationLink_fromPort)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink_FromPort()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{0E228C78-01A3-4435-8740-D33C507427A4}' id='2057846672' EA\040name=''"
   *        annotation="TaggedValues xml.name='FROM-PORT-IREF' xml.namePlural='FROM-PORT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='FROM-PORT-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FROM-PORT-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FaultFailurePropagationLink_fromPort getFromPort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getFromPort <em>From Port</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>From Port</em>' containment reference.
   * @see #getFromPort()
   * @generated
   */
  void setFromPort(FaultFailurePropagationLink_fromPort value);

  /**
   * Returns the value of the '<em><b>To Port</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>To Port</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>To Port</em>' containment reference.
   * @see #setToPort(FaultFailurePropagationLink_toPort)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink_ToPort()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{D55C762C-313E-498f-8489-E91378EC57C0}' id='1556758445' EA\040name=''"
   *        annotation="TaggedValues xml.name='TO-PORT-IREF' xml.namePlural='TO-PORT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='TO-PORT-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TO-PORT-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FaultFailurePropagationLink_toPort getToPort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink#getToPort <em>To Port</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>To Port</em>' containment reference.
   * @see #getToPort()
   * @generated
   */
  void setToPort(FaultFailurePropagationLink_toPort value);

} // FaultFailurePropagationLink
