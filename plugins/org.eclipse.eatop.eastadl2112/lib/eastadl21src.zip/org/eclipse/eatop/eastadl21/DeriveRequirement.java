/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Derive Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The DeriveRequirement is a relationship metaclass, which signifies a dependency relationship between two sets of Requirements, showing the relationship when a set of derived client Requirement (client requirement) is derived from a set of Requirements (supplier requirement).
 * 
 * Semantics:
 * The DeriveRequirement metaclass signifies a derived/derived by relationship between Requirements, where the modification of the supplier Requirement may impact the derived client Requirement.
 * 
 * Notation: 
 * A DeriveRequirement relationship is shown as a dashed arrow between two Requirements. The Requirement at the tail of the arrow (the derived Requirement) depends on the Requirement at the arrowhead (the Requirement derived from).
 * 
 * Extension: 
 * To specialize SysML DeriveReqt, which specializes UML2 stereotype Trace, which extends Dependency.
 * 
 * Temporary change in the profile (to overcome bug in Eclipse/UML2 concerning standard stereotypes)
 * - added extension towards Dependency
 * - removed generalization link towards SysML::DeriveReqt
 * 
 * TODO:
 * Move to Requirement package
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.DeriveRequirement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.DeriveRequirement#getDerived <em>Derived</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.DeriveRequirement#getDerivedFrom <em>Derived From</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDeriveRequirement()
 * @model annotation="MetaData guid='{06E94250-F158-4b2f-AF61-EC3DDB65AB41}' id='171' EA\040name='DeriveRequirement'"
 *        extendedMetaData="name='DERIVE-REQUIREMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DERIVE-REQUIREMENTS'"
 * @generated
 */
public interface DeriveRequirement extends RequirementsRelationship
{
  /**
   * Returns the value of the '<em><b>Derived</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Derived</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Derived</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDeriveRequirement_Derived()
   * @model required="true"
   *        annotation="MetaData guid='{AE47AD55-52B7-404d-A570-0A1B8289CDB2}' id='96' EA\040name=''"
   *        extendedMetaData="name='DERIVED-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DERIVED-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getDerived();

  /**
   * Returns the value of the '<em><b>Derived From</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Derived From</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Derived From</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDeriveRequirement_DerivedFrom()
   * @model required="true"
   *        annotation="MetaData guid='{08F11D19-6FF8-4ac0-A4C3-2953E3D9E64E}' id='100' EA\040name=''"
   *        extendedMetaData="name='DERIVED-FROM-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DERIVED-FROM-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getDerivedFrom();

} // DeriveRequirement
