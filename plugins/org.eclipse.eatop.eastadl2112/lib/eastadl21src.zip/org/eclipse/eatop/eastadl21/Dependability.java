/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dependability</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of dependability related information. This includes safety requirements, safety cases, safety constraints, and error modeling. This collection can be used across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * Dependability is a container element that collects elements related to dependability. It is possible to have several Dependability elements to organize related dependability information in dedicated containers. 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.Dependability</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getFeatureFlaw <em>Feature Flaw</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getTechnicalSafetyConcept <em>Technical Safety Concept</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getSafetyCase <em>Safety Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getHazard <em>Hazard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getFaultFailure <em>Fault Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getEaDatatype <em>Ea Datatype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getHazardousEvent <em>Hazardous Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getSafetyConstraint <em>Safety Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getErrorModelType <em>Error Model Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getFunctionalSafetyConcept <em>Functional Safety Concept</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getQuantitiativeSafetyConstraint <em>Quantitiative Safety Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getItem <em>Item</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Dependability#getSafetyGoal <em>Safety Goal</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability()
 * @model annotation="MetaData guid='{2A223DF6-1940-4673-AA86-F22C44AA1423}' id='1957333437' EA\040name='Dependability'"
 *        extendedMetaData="name='DEPENDABILITY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DEPENDABILITYS'"
 * @generated
 */
public interface Dependability extends Context
{
  /**
   * Returns the value of the '<em><b>Feature Flaw</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FeatureFlaw}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Feature Flaw</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Feature Flaw</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_FeatureFlaw()
   * @model containment="true"
   *        annotation="MetaData guid='{77DBAE0D-28FC-42ad-BE14-3D258639471F}' id='-1496381176' EA\040name=''"
   *        extendedMetaData="name='FEATURE-FLAW' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-FLAWS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<FeatureFlaw> getFeatureFlaw();

  /**
   * Returns the value of the '<em><b>Technical Safety Concept</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.TechnicalSafetyConcept}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Technical Safety Concept</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Technical Safety Concept</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_TechnicalSafetyConcept()
   * @model containment="true"
   *        annotation="MetaData guid='{184F6BFF-67C6-48ed-A14F-18282CB70141}' id='-1009341124' EA\040name=''"
   *        extendedMetaData="name='TECHNICAL-SAFETY-CONCEPT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TECHNICAL-SAFETY-CONCEPTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<TechnicalSafetyConcept> getTechnicalSafetyConcept();

  /**
   * Returns the value of the '<em><b>Safety Case</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.SafetyCase}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Safety Case</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Safety Case</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_SafetyCase()
   * @model containment="true"
   *        annotation="MetaData guid='{3BE86EF3-7D83-41f8-9E39-D7A5A45B9EAF}' id='-915395618' EA\040name=''"
   *        extendedMetaData="name='SAFETY-CASE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-CASES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<SafetyCase> getSafetyCase();

  /**
   * Returns the value of the '<em><b>Hazard</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Hazard}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hazard</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hazard</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_Hazard()
   * @model containment="true"
   *        annotation="MetaData guid='{61DABB67-632D-4986-BF46-AC8B84FF6296}' id='-838451069' EA\040name=''"
   *        extendedMetaData="name='HAZARD' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARDS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Hazard> getHazard();

  /**
   * Returns the value of the '<em><b>Fault Failure</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FaultFailure}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Fault Failure</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Fault Failure</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_FaultFailure()
   * @model containment="true"
   *        annotation="MetaData guid='{6BF1B93D-8C9F-4fbe-9854-59D23804668E}' id='54262320' EA\040name=''"
   *        extendedMetaData="name='FAULT-FAILURE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<FaultFailure> getFaultFailure();

  /**
   * Returns the value of the '<em><b>Ea Datatype</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.EADatatype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ea Datatype</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ea Datatype</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_EaDatatype()
   * @model containment="true"
   *        annotation="MetaData guid='{2DF72D3F-177C-4013-8855-299622B9483F}' id='79314098' EA\040name=''"
   *        extendedMetaData="name='EA-DATATYPE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-DATATYPES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<EADatatype> getEaDatatype();

  /**
   * Returns the value of the '<em><b>Hazardous Event</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HazardousEvent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hazardous Event</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hazardous Event</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_HazardousEvent()
   * @model containment="true"
   *        annotation="MetaData guid='{D2AB10C6-4EF4-4e50-96E6-7B7AD737275B}' id='141608394' EA\040name=''"
   *        extendedMetaData="name='HAZARDOUS-EVENT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARDOUS-EVENTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<HazardousEvent> getHazardousEvent();

  /**
   * Returns the value of the '<em><b>Safety Constraint</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.SafetyConstraint}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Safety Constraint</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Safety Constraint</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_SafetyConstraint()
   * @model containment="true"
   *        annotation="MetaData guid='{BCF65364-94C0-477f-AD0D-0C22A51C16EB}' id='273816177' EA\040name=''"
   *        extendedMetaData="name='SAFETY-CONSTRAINT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<SafetyConstraint> getSafetyConstraint();

  /**
   * Returns the value of the '<em><b>Error Model Type</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.ErrorModelType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Error Model Type</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Error Model Type</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_ErrorModelType()
   * @model containment="true"
   *        annotation="MetaData guid='{74E53DCB-4A5E-4b8c-ADAA-378A632CBB4D}' id='1117365220' EA\040name=''"
   *        extendedMetaData="name='ERROR-MODEL-TYPE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-TYPES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<ErrorModelType> getErrorModelType();

  /**
   * Returns the value of the '<em><b>Functional Safety Concept</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FunctionalSafetyConcept}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Functional Safety Concept</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Functional Safety Concept</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_FunctionalSafetyConcept()
   * @model containment="true"
   *        annotation="MetaData guid='{669FB38D-CF18-40ff-AA89-DBBC7F452FAD}' id='1369516551' EA\040name=''"
   *        extendedMetaData="name='FUNCTIONAL-SAFETY-CONCEPT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTIONAL-SAFETY-CONCEPTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<FunctionalSafetyConcept> getFunctionalSafetyConcept();

  /**
   * Returns the value of the '<em><b>Quantitiative Safety Constraint</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Quantitiative Safety Constraint</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Quantitiative Safety Constraint</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_QuantitiativeSafetyConstraint()
   * @model containment="true"
   *        annotation="MetaData guid='{3E6CA995-2E20-4f8d-8CB0-451D76F86DC8}' id='1506056011' EA\040name=''"
   *        extendedMetaData="name='QUANTITIATIVE-SAFETY-CONSTRAINT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTITIATIVE-SAFETY-CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<QuantitativeSafetyConstraint> getQuantitiativeSafetyConstraint();

  /**
   * Returns the value of the '<em><b>Item</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Item}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Item</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Item</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_Item()
   * @model containment="true"
   *        annotation="MetaData guid='{7D511135-2F7F-44c9-A334-DC5418F7014B}' id='1853998697' EA\040name=''"
   *        extendedMetaData="name='ITEM' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ITEMS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Item> getItem();

  /**
   * Returns the value of the '<em><b>Safety Goal</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.SafetyGoal}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Safety Goal</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Safety Goal</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDependability_SafetyGoal()
   * @model containment="true"
   *        annotation="MetaData guid='{8274CE41-A950-40f7-A128-A876AB44915B}' id='1868585869' EA\040name=''"
   *        extendedMetaData="name='SAFETY-GOAL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-GOALS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<SafetyGoal> getSafetyGoal();

} // Dependability
