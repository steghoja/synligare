/**
 */
package org.eclipse.eatop.eastadl21.util;

import org.eclipse.eatop.eastadl21.AUTOSAREvent;
import org.eclipse.eatop.eastadl21.Actor;
import org.eclipse.eatop.eastadl21.Actuator;
import org.eclipse.eatop.eastadl21.AgeConstraint;
import org.eclipse.eatop.eastadl21.AllocateableElement;
import org.eclipse.eatop.eastadl21.Allocation;
import org.eclipse.eatop.eastadl21.AllocationTarget;
import org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype;
import org.eclipse.eatop.eastadl21.AnalysisFunctionType;
import org.eclipse.eatop.eastadl21.AnalysisLevel;
import org.eclipse.eatop.eastadl21.Anomaly;
import org.eclipse.eatop.eastadl21.ArbitraryConstraint;
import org.eclipse.eatop.eastadl21.ArchitecturalDescription;
import org.eclipse.eatop.eastadl21.ArchitecturalModel;
import org.eclipse.eatop.eastadl21.Architecture;
import org.eclipse.eatop.eastadl21.ArrayDatatype;
import org.eclipse.eatop.eastadl21.Attribute;
import org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint;
import org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType;
import org.eclipse.eatop.eastadl21.Behavior;
import org.eclipse.eatop.eastadl21.BehaviorAttributeBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintParameter;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintType;
import org.eclipse.eatop.eastadl21.BindingTime;
import org.eclipse.eatop.eastadl21.BurstConstraint;
import org.eclipse.eatop.eastadl21.BusinessOpportunity;
import org.eclipse.eatop.eastadl21.Claim;
import org.eclipse.eatop.eastadl21.ClampConnector;
import org.eclipse.eatop.eastadl21.ClampConnector_port;
import org.eclipse.eatop.eastadl21.Comment;
import org.eclipse.eatop.eastadl21.CommunicationHardwarePin;
import org.eclipse.eatop.eastadl21.ComparisonConstraint;
import org.eclipse.eatop.eastadl21.CompositeDatatype;
import org.eclipse.eatop.eastadl21.ComputationConstraint;
import org.eclipse.eatop.eastadl21.Concept;
import org.eclipse.eatop.eastadl21.ConfigurableContainer;
import org.eclipse.eatop.eastadl21.ConfigurationDecision;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionModel;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionModelEntry;
import org.eclipse.eatop.eastadl21.ContainerConfiguration;
import org.eclipse.eatop.eastadl21.Context;
import org.eclipse.eatop.eastadl21.DelayConstraint;
import org.eclipse.eatop.eastadl21.Dependability;
import org.eclipse.eatop.eastadl21.DeriveRequirement;
import org.eclipse.eatop.eastadl21.DesignFunctionPrototype;
import org.eclipse.eatop.eastadl21.DesignFunctionType;
import org.eclipse.eatop.eastadl21.DesignLevel;
import org.eclipse.eatop.eastadl21.DeviationAttributeSet;
import org.eclipse.eatop.eastadl21.EAArrayValue;
import org.eclipse.eatop.eastadl21.EABoolean;
import org.eclipse.eatop.eastadl21.EABooleanValue;
import org.eclipse.eatop.eastadl21.EACompositeValue;
import org.eclipse.eatop.eastadl21.EAConnector;
import org.eclipse.eatop.eastadl21.EADatatype;
import org.eclipse.eatop.eastadl21.EADatatypePrototype;
import org.eclipse.eatop.eastadl21.EAElement;
import org.eclipse.eatop.eastadl21.EAEnumerationValue;
import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.EANumerical;
import org.eclipse.eatop.eastadl21.EANumericalValue;
import org.eclipse.eatop.eastadl21.EAPackage;
import org.eclipse.eatop.eastadl21.EAPackageableElement;
import org.eclipse.eatop.eastadl21.EAPort;
import org.eclipse.eatop.eastadl21.EAPrototype;
import org.eclipse.eatop.eastadl21.EAString;
import org.eclipse.eatop.eastadl21.EAStringValue;
import org.eclipse.eatop.eastadl21.EAType;
import org.eclipse.eatop.eastadl21.EAValue;
import org.eclipse.eatop.eastadl21.EAXML;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ElectricalComponent;
import org.eclipse.eatop.eastadl21.Enumeration;
import org.eclipse.eatop.eastadl21.EnumerationLiteral;
import org.eclipse.eatop.eastadl21.Environment;
import org.eclipse.eatop.eastadl21.ErrorBehavior;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget;
import org.eclipse.eatop.eastadl21.ErrorModelType;
import org.eclipse.eatop.eastadl21.Event;
import org.eclipse.eatop.eastadl21.EventChain;
import org.eclipse.eatop.eastadl21.EventFaultFailure;
import org.eclipse.eatop.eastadl21.EventFeatureFlaw;
import org.eclipse.eatop.eastadl21.EventFunction;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port;
import org.eclipse.eatop.eastadl21.EventFunction_function;
import org.eclipse.eatop.eastadl21.ExecutionTimeConstraint;
import org.eclipse.eatop.eastadl21.Extend;
import org.eclipse.eatop.eastadl21.ExtensionPoint;
import org.eclipse.eatop.eastadl21.ExternalEvent;
import org.eclipse.eatop.eastadl21.FailureOutPort;
import org.eclipse.eatop.eastadl21.FaultFailure;
import org.eclipse.eatop.eastadl21.FaultFailurePort;
import org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort;
import org.eclipse.eatop.eastadl21.FaultFailure_anomaly;
import org.eclipse.eatop.eastadl21.FaultInPort;
import org.eclipse.eatop.eastadl21.Feature;
import org.eclipse.eatop.eastadl21.FeatureConfiguration;
import org.eclipse.eatop.eastadl21.FeatureConstraint;
import org.eclipse.eatop.eastadl21.FeatureFlaw;
import org.eclipse.eatop.eastadl21.FeatureGroup;
import org.eclipse.eatop.eastadl21.FeatureLink;
import org.eclipse.eatop.eastadl21.FeatureModel;
import org.eclipse.eatop.eastadl21.FeatureTreeNode;
import org.eclipse.eatop.eastadl21.FunctionAllocation;
import org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement;
import org.eclipse.eatop.eastadl21.FunctionAllocation_target;
import org.eclipse.eatop.eastadl21.FunctionBehavior;
import org.eclipse.eatop.eastadl21.FunctionClientServerInterface;
import org.eclipse.eatop.eastadl21.FunctionClientServerPort;
import org.eclipse.eatop.eastadl21.FunctionConnector;
import org.eclipse.eatop.eastadl21.FunctionConnector_port;
import org.eclipse.eatop.eastadl21.FunctionFlowPort;
import org.eclipse.eatop.eastadl21.FunctionPort;
import org.eclipse.eatop.eastadl21.FunctionPowerPort;
import org.eclipse.eatop.eastadl21.FunctionPrototype;
import org.eclipse.eatop.eastadl21.FunctionTrigger;
import org.eclipse.eatop.eastadl21.FunctionType;
import org.eclipse.eatop.eastadl21.FunctionalDevice;
import org.eclipse.eatop.eastadl21.FunctionalSafetyConcept;
import org.eclipse.eatop.eastadl21.GenericConstraint;
import org.eclipse.eatop.eastadl21.GenericConstraintSet;
import org.eclipse.eatop.eastadl21.Ground;
import org.eclipse.eatop.eastadl21.HardwareComponentPrototype;
import org.eclipse.eatop.eastadl21.HardwareComponentType;
import org.eclipse.eatop.eastadl21.HardwareConnector;
import org.eclipse.eatop.eastadl21.HardwareConnector_port;
import org.eclipse.eatop.eastadl21.HardwareFunctionType;
import org.eclipse.eatop.eastadl21.HardwarePin;
import org.eclipse.eatop.eastadl21.HardwarePort;
import org.eclipse.eatop.eastadl21.HardwarePortConnector;
import org.eclipse.eatop.eastadl21.HardwarePortConnector_port;
import org.eclipse.eatop.eastadl21.Hazard;
import org.eclipse.eatop.eastadl21.HazardousEvent;
import org.eclipse.eatop.eastadl21.IOHardwarePin;
import org.eclipse.eatop.eastadl21.Identifiable;
import org.eclipse.eatop.eastadl21.ImplementationLevel;
import org.eclipse.eatop.eastadl21.Include;
import org.eclipse.eatop.eastadl21.InputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.InternalBinding;
import org.eclipse.eatop.eastadl21.InternalFaultPrototype;
import org.eclipse.eatop.eastadl21.Item;
import org.eclipse.eatop.eastadl21.LocalDeviceManager;
import org.eclipse.eatop.eastadl21.LogicalEvent;
import org.eclipse.eatop.eastadl21.LogicalPath;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.LogicalTransformation;
import org.eclipse.eatop.eastadl21.Mission;
import org.eclipse.eatop.eastadl21.Mode;
import org.eclipse.eatop.eastadl21.ModeEvent;
import org.eclipse.eatop.eastadl21.ModeGroup;
import org.eclipse.eatop.eastadl21.Node;
import org.eclipse.eatop.eastadl21.Operation;
import org.eclipse.eatop.eastadl21.OperationalSituation;
import org.eclipse.eatop.eastadl21.OrderConstraint;
import org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.PatternConstraint;
import org.eclipse.eatop.eastadl21.PeriodicConstraint;
import org.eclipse.eatop.eastadl21.PortGroup;
import org.eclipse.eatop.eastadl21.PowerHardwarePin;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive;
import org.eclipse.eatop.eastadl21.PrivateContent;
import org.eclipse.eatop.eastadl21.ProblemStatement;
import org.eclipse.eatop.eastadl21.ProcessFaultPrototype;
import org.eclipse.eatop.eastadl21.ProductPositioning;
import org.eclipse.eatop.eastadl21.QualityRequirement;
import org.eclipse.eatop.eastadl21.Quantification;
import org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint;
import org.eclipse.eatop.eastadl21.Quantity;
import org.eclipse.eatop.eastadl21.RangeableValueType;
import org.eclipse.eatop.eastadl21.Rationale;
import org.eclipse.eatop.eastadl21.ReactionConstraint;
import org.eclipse.eatop.eastadl21.Realization;
import org.eclipse.eatop.eastadl21.Realization_realized;
import org.eclipse.eatop.eastadl21.Realization_realizedBy;
import org.eclipse.eatop.eastadl21.RedefinableElement;
import org.eclipse.eatop.eastadl21.Referrable;
import org.eclipse.eatop.eastadl21.Refine;
import org.eclipse.eatop.eastadl21.Refine_refinedBy;
import org.eclipse.eatop.eastadl21.Relationship;
import org.eclipse.eatop.eastadl21.RepetitionConstraint;
import org.eclipse.eatop.eastadl21.Requirement;
import org.eclipse.eatop.eastadl21.RequirementsHierarchy;
import org.eclipse.eatop.eastadl21.RequirementsLink;
import org.eclipse.eatop.eastadl21.RequirementsModel;
import org.eclipse.eatop.eastadl21.RequirementsRelationship;
import org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup;
import org.eclipse.eatop.eastadl21.ReuseMetaInformation;
import org.eclipse.eatop.eastadl21.SafetyCase;
import org.eclipse.eatop.eastadl21.SafetyConstraint;
import org.eclipse.eatop.eastadl21.SafetyGoal;
import org.eclipse.eatop.eastadl21.Satisfy;
import org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy;
import org.eclipse.eatop.eastadl21.SelectionCriterion;
import org.eclipse.eatop.eastadl21.Sensor;
import org.eclipse.eatop.eastadl21.SporadicConstraint;
import org.eclipse.eatop.eastadl21.Stakeholder;
import org.eclipse.eatop.eastadl21.StakeholderNeed;
import org.eclipse.eatop.eastadl21.State;
import org.eclipse.eatop.eastadl21.StateEvent;
import org.eclipse.eatop.eastadl21.StrongDelayConstraint;
import org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronousTransition;
import org.eclipse.eatop.eastadl21.SystemModel;
import org.eclipse.eatop.eastadl21.TakeRateConstraint;
import org.eclipse.eatop.eastadl21.TechnicalSafetyConcept;
import org.eclipse.eatop.eastadl21.TemporalConstraint;
import org.eclipse.eatop.eastadl21.Timing;
import org.eclipse.eatop.eastadl21.TimingConstraint;
import org.eclipse.eatop.eastadl21.TimingDescription;
import org.eclipse.eatop.eastadl21.TimingDescriptionEvent;
import org.eclipse.eatop.eastadl21.TimingExpression;
import org.eclipse.eatop.eastadl21.TraceableSpecification;
import org.eclipse.eatop.eastadl21.TransformationOccurrence;
import org.eclipse.eatop.eastadl21.Transition;
import org.eclipse.eatop.eastadl21.TransitionEvent;
import org.eclipse.eatop.eastadl21.Unit;
import org.eclipse.eatop.eastadl21.UseCase;
import org.eclipse.eatop.eastadl21.UserAttributeDefinition;
import org.eclipse.eatop.eastadl21.UserAttributedElement;
import org.eclipse.eatop.eastadl21.UserElementType;
import org.eclipse.eatop.eastadl21.VVActualOutcome;
import org.eclipse.eatop.eastadl21.VVCase;
import org.eclipse.eatop.eastadl21.VVCase_vvSubject;
import org.eclipse.eatop.eastadl21.VVIntendedOutcome;
import org.eclipse.eatop.eastadl21.VVLog;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.VVStimuli;
import org.eclipse.eatop.eastadl21.VVTarget;
import org.eclipse.eatop.eastadl21.VVTarget_element;
import org.eclipse.eatop.eastadl21.Variability;
import org.eclipse.eatop.eastadl21.VariableElement;
import org.eclipse.eatop.eastadl21.VariationGroup;
import org.eclipse.eatop.eastadl21.VehicleFeature;
import org.eclipse.eatop.eastadl21.VehicleLevel;
import org.eclipse.eatop.eastadl21.VehicleLevelBinding;
import org.eclipse.eatop.eastadl21.VehicleSystem;
import org.eclipse.eatop.eastadl21.VerificationValidation;
import org.eclipse.eatop.eastadl21.Verify;
import org.eclipse.eatop.eastadl21.Warrant;

import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackage;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackageableElement;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAXML;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GIdentifiable;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GReferrable;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package
 * @generated
 */
public class Eastadl21AdapterFactory extends AdapterFactoryImpl
{
  /**
   * The cached model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static Eastadl21Package modelPackage;

  /**
   * Creates an instance of the adapter factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eastadl21AdapterFactory()
  {
    if (modelPackage == null)
    {
      modelPackage = Eastadl21Package.eINSTANCE;
    }
  }

  /**
   * Returns whether this factory is applicable for the type of the object.
   * <!-- begin-user-doc -->
   * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
   * <!-- end-user-doc -->
   * @return whether this factory is applicable for the type of the object.
   * @generated
   */
  @Override
  public boolean isFactoryForType(Object object)
  {
    if (object == modelPackage)
    {
      return true;
    }
    if (object instanceof EObject)
    {
      return ((EObject)object).eClass().getEPackage() == modelPackage;
    }
    return false;
  }

  /**
   * The switch that delegates to the <code>createXXX</code> methods.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Eastadl21Switch<Adapter> modelSwitch =
    new Eastadl21Switch<Adapter>()
    {
      @Override
      public Adapter caseVehicleLevel(VehicleLevel object)
      {
        return createVehicleLevelAdapter();
      }
      @Override
      public Adapter caseSystemModel(SystemModel object)
      {
        return createSystemModelAdapter();
      }
      @Override
      public Adapter caseAnalysisLevel(AnalysisLevel object)
      {
        return createAnalysisLevelAdapter();
      }
      @Override
      public Adapter caseDesignLevel(DesignLevel object)
      {
        return createDesignLevelAdapter();
      }
      @Override
      public Adapter caseImplementationLevel(ImplementationLevel object)
      {
        return createImplementationLevelAdapter();
      }
      @Override
      public Adapter caseBindingTime(BindingTime object)
      {
        return createBindingTimeAdapter();
      }
      @Override
      public Adapter caseFeature(Feature object)
      {
        return createFeatureAdapter();
      }
      @Override
      public Adapter caseFeatureConstraint(FeatureConstraint object)
      {
        return createFeatureConstraintAdapter();
      }
      @Override
      public Adapter caseFeatureGroup(FeatureGroup object)
      {
        return createFeatureGroupAdapter();
      }
      @Override
      public Adapter caseFeatureLink(FeatureLink object)
      {
        return createFeatureLinkAdapter();
      }
      @Override
      public Adapter caseFeatureModel(FeatureModel object)
      {
        return createFeatureModelAdapter();
      }
      @Override
      public Adapter caseFeatureTreeNode(FeatureTreeNode object)
      {
        return createFeatureTreeNodeAdapter();
      }
      @Override
      public Adapter caseDeviationAttributeSet(DeviationAttributeSet object)
      {
        return createDeviationAttributeSetAdapter();
      }
      @Override
      public Adapter caseVehicleFeature(VehicleFeature object)
      {
        return createVehicleFeatureAdapter();
      }
      @Override
      public Adapter caseAllocateableElement(AllocateableElement object)
      {
        return createAllocateableElementAdapter();
      }
      @Override
      public Adapter caseAllocation(Allocation object)
      {
        return createAllocationAdapter();
      }
      @Override
      public Adapter caseAnalysisFunctionPrototype(AnalysisFunctionPrototype object)
      {
        return createAnalysisFunctionPrototypeAdapter();
      }
      @Override
      public Adapter caseAnalysisFunctionType(AnalysisFunctionType object)
      {
        return createAnalysisFunctionTypeAdapter();
      }
      @Override
      public Adapter caseBasicSoftwareFunctionType(BasicSoftwareFunctionType object)
      {
        return createBasicSoftwareFunctionTypeAdapter();
      }
      @Override
      public Adapter caseDesignFunctionPrototype(DesignFunctionPrototype object)
      {
        return createDesignFunctionPrototypeAdapter();
      }
      @Override
      public Adapter caseDesignFunctionType(DesignFunctionType object)
      {
        return createDesignFunctionTypeAdapter();
      }
      @Override
      public Adapter caseFunctionalDevice(FunctionalDevice object)
      {
        return createFunctionalDeviceAdapter();
      }
      @Override
      public Adapter caseFunctionAllocation(FunctionAllocation object)
      {
        return createFunctionAllocationAdapter();
      }
      @Override
      public Adapter caseFunctionClientServerInterface(FunctionClientServerInterface object)
      {
        return createFunctionClientServerInterfaceAdapter();
      }
      @Override
      public Adapter caseFunctionClientServerPort(FunctionClientServerPort object)
      {
        return createFunctionClientServerPortAdapter();
      }
      @Override
      public Adapter caseFunctionConnector(FunctionConnector object)
      {
        return createFunctionConnectorAdapter();
      }
      @Override
      public Adapter caseFunctionFlowPort(FunctionFlowPort object)
      {
        return createFunctionFlowPortAdapter();
      }
      @Override
      public Adapter caseFunctionPort(FunctionPort object)
      {
        return createFunctionPortAdapter();
      }
      @Override
      public Adapter caseFunctionPowerPort(FunctionPowerPort object)
      {
        return createFunctionPowerPortAdapter();
      }
      @Override
      public Adapter caseFunctionPrototype(FunctionPrototype object)
      {
        return createFunctionPrototypeAdapter();
      }
      @Override
      public Adapter caseFunctionType(FunctionType object)
      {
        return createFunctionTypeAdapter();
      }
      @Override
      public Adapter caseHardwareFunctionType(HardwareFunctionType object)
      {
        return createHardwareFunctionTypeAdapter();
      }
      @Override
      public Adapter caseLocalDeviceManager(LocalDeviceManager object)
      {
        return createLocalDeviceManagerAdapter();
      }
      @Override
      public Adapter caseOperation(Operation object)
      {
        return createOperationAdapter();
      }
      @Override
      public Adapter casePortGroup(PortGroup object)
      {
        return createPortGroupAdapter();
      }
      @Override
      public Adapter caseFunctionAllocation_allocatedElement(FunctionAllocation_allocatedElement object)
      {
        return createFunctionAllocation_allocatedElementAdapter();
      }
      @Override
      public Adapter caseFunctionAllocation_target(FunctionAllocation_target object)
      {
        return createFunctionAllocation_targetAdapter();
      }
      @Override
      public Adapter caseFunctionConnector_port(FunctionConnector_port object)
      {
        return createFunctionConnector_portAdapter();
      }
      @Override
      public Adapter caseActuator(Actuator object)
      {
        return createActuatorAdapter();
      }
      @Override
      public Adapter caseCommunicationHardwarePin(CommunicationHardwarePin object)
      {
        return createCommunicationHardwarePinAdapter();
      }
      @Override
      public Adapter caseElectricalComponent(ElectricalComponent object)
      {
        return createElectricalComponentAdapter();
      }
      @Override
      public Adapter caseHardwareComponentPrototype(HardwareComponentPrototype object)
      {
        return createHardwareComponentPrototypeAdapter();
      }
      @Override
      public Adapter caseHardwareComponentType(HardwareComponentType object)
      {
        return createHardwareComponentTypeAdapter();
      }
      @Override
      public Adapter caseHardwareConnector(HardwareConnector object)
      {
        return createHardwareConnectorAdapter();
      }
      @Override
      public Adapter caseHardwarePin(HardwarePin object)
      {
        return createHardwarePinAdapter();
      }
      @Override
      public Adapter caseHardwarePort(HardwarePort object)
      {
        return createHardwarePortAdapter();
      }
      @Override
      public Adapter caseHardwarePortConnector(HardwarePortConnector object)
      {
        return createHardwarePortConnectorAdapter();
      }
      @Override
      public Adapter caseIOHardwarePin(IOHardwarePin object)
      {
        return createIOHardwarePinAdapter();
      }
      @Override
      public Adapter caseNode(Node object)
      {
        return createNodeAdapter();
      }
      @Override
      public Adapter casePowerHardwarePin(PowerHardwarePin object)
      {
        return createPowerHardwarePinAdapter();
      }
      @Override
      public Adapter caseSensor(Sensor object)
      {
        return createSensorAdapter();
      }
      @Override
      public Adapter caseAllocationTarget(AllocationTarget object)
      {
        return createAllocationTargetAdapter();
      }
      @Override
      public Adapter caseHardwareConnector_port(HardwareConnector_port object)
      {
        return createHardwareConnector_portAdapter();
      }
      @Override
      public Adapter caseHardwarePortConnector_port(HardwarePortConnector_port object)
      {
        return createHardwarePortConnector_portAdapter();
      }
      @Override
      public Adapter caseClampConnector(ClampConnector object)
      {
        return createClampConnectorAdapter();
      }
      @Override
      public Adapter caseEnvironment(Environment object)
      {
        return createEnvironmentAdapter();
      }
      @Override
      public Adapter caseClampConnector_port(ClampConnector_port object)
      {
        return createClampConnector_portAdapter();
      }
      @Override
      public Adapter caseBehavior(Behavior object)
      {
        return createBehaviorAdapter();
      }
      @Override
      public Adapter caseMode(Mode object)
      {
        return createModeAdapter();
      }
      @Override
      public Adapter caseModeGroup(ModeGroup object)
      {
        return createModeGroupAdapter();
      }
      @Override
      public Adapter caseFunctionBehavior(FunctionBehavior object)
      {
        return createFunctionBehaviorAdapter();
      }
      @Override
      public Adapter caseFunctionTrigger(FunctionTrigger object)
      {
        return createFunctionTriggerAdapter();
      }
      @Override
      public Adapter caseConfigurableContainer(ConfigurableContainer object)
      {
        return createConfigurableContainerAdapter();
      }
      @Override
      public Adapter caseConfigurationDecision(ConfigurationDecision object)
      {
        return createConfigurationDecisionAdapter();
      }
      @Override
      public Adapter caseConfigurationDecisionFolder(ConfigurationDecisionFolder object)
      {
        return createConfigurationDecisionFolderAdapter();
      }
      @Override
      public Adapter caseConfigurationDecisionModel(ConfigurationDecisionModel object)
      {
        return createConfigurationDecisionModelAdapter();
      }
      @Override
      public Adapter caseConfigurationDecisionModelEntry(ConfigurationDecisionModelEntry object)
      {
        return createConfigurationDecisionModelEntryAdapter();
      }
      @Override
      public Adapter caseContainerConfiguration(ContainerConfiguration object)
      {
        return createContainerConfigurationAdapter();
      }
      @Override
      public Adapter caseFeatureConfiguration(FeatureConfiguration object)
      {
        return createFeatureConfigurationAdapter();
      }
      @Override
      public Adapter caseInternalBinding(InternalBinding object)
      {
        return createInternalBindingAdapter();
      }
      @Override
      public Adapter casePrivateContent(PrivateContent object)
      {
        return createPrivateContentAdapter();
      }
      @Override
      public Adapter caseReuseMetaInformation(ReuseMetaInformation object)
      {
        return createReuseMetaInformationAdapter();
      }
      @Override
      public Adapter caseSelectionCriterion(SelectionCriterion object)
      {
        return createSelectionCriterionAdapter();
      }
      @Override
      public Adapter caseVariability(Variability object)
      {
        return createVariabilityAdapter();
      }
      @Override
      public Adapter caseVariableElement(VariableElement object)
      {
        return createVariableElementAdapter();
      }
      @Override
      public Adapter caseVariationGroup(VariationGroup object)
      {
        return createVariationGroupAdapter();
      }
      @Override
      public Adapter caseVehicleLevelBinding(VehicleLevelBinding object)
      {
        return createVehicleLevelBindingAdapter();
      }
      @Override
      public Adapter caseDeriveRequirement(DeriveRequirement object)
      {
        return createDeriveRequirementAdapter();
      }
      @Override
      public Adapter caseOperationalSituation(OperationalSituation object)
      {
        return createOperationalSituationAdapter();
      }
      @Override
      public Adapter caseRequirementsModel(RequirementsModel object)
      {
        return createRequirementsModelAdapter();
      }
      @Override
      public Adapter caseRequirementsRelationship(RequirementsRelationship object)
      {
        return createRequirementsRelationshipAdapter();
      }
      @Override
      public Adapter caseRequirement(Requirement object)
      {
        return createRequirementAdapter();
      }
      @Override
      public Adapter caseRequirementsHierarchy(RequirementsHierarchy object)
      {
        return createRequirementsHierarchyAdapter();
      }
      @Override
      public Adapter caseRefine(Refine object)
      {
        return createRefineAdapter();
      }
      @Override
      public Adapter caseSatisfy(Satisfy object)
      {
        return createSatisfyAdapter();
      }
      @Override
      public Adapter caseRequirementsLink(RequirementsLink object)
      {
        return createRequirementsLinkAdapter();
      }
      @Override
      public Adapter caseRequirementsRelationshipGroup(RequirementsRelationshipGroup object)
      {
        return createRequirementsRelationshipGroupAdapter();
      }
      @Override
      public Adapter caseQualityRequirement(QualityRequirement object)
      {
        return createQualityRequirementAdapter();
      }
      @Override
      public Adapter caseRefine_refinedBy(Refine_refinedBy object)
      {
        return createRefine_refinedByAdapter();
      }
      @Override
      public Adapter caseSatisfy_satisfiedBy(Satisfy_satisfiedBy object)
      {
        return createSatisfy_satisfiedByAdapter();
      }
      @Override
      public Adapter caseActor(Actor object)
      {
        return createActorAdapter();
      }
      @Override
      public Adapter caseExtend(Extend object)
      {
        return createExtendAdapter();
      }
      @Override
      public Adapter caseExtensionPoint(ExtensionPoint object)
      {
        return createExtensionPointAdapter();
      }
      @Override
      public Adapter caseInclude(Include object)
      {
        return createIncludeAdapter();
      }
      @Override
      public Adapter caseRedefinableElement(RedefinableElement object)
      {
        return createRedefinableElementAdapter();
      }
      @Override
      public Adapter caseUseCase(UseCase object)
      {
        return createUseCaseAdapter();
      }
      @Override
      public Adapter caseVerificationValidation(VerificationValidation object)
      {
        return createVerificationValidationAdapter();
      }
      @Override
      public Adapter caseVerify(Verify object)
      {
        return createVerifyAdapter();
      }
      @Override
      public Adapter caseVVActualOutcome(VVActualOutcome object)
      {
        return createVVActualOutcomeAdapter();
      }
      @Override
      public Adapter caseVVCase(VVCase object)
      {
        return createVVCaseAdapter();
      }
      @Override
      public Adapter caseVVIntendedOutcome(VVIntendedOutcome object)
      {
        return createVVIntendedOutcomeAdapter();
      }
      @Override
      public Adapter caseVVLog(VVLog object)
      {
        return createVVLogAdapter();
      }
      @Override
      public Adapter caseVVProcedure(VVProcedure object)
      {
        return createVVProcedureAdapter();
      }
      @Override
      public Adapter caseVVStimuli(VVStimuli object)
      {
        return createVVStimuliAdapter();
      }
      @Override
      public Adapter caseVVTarget(VVTarget object)
      {
        return createVVTargetAdapter();
      }
      @Override
      public Adapter caseVVCase_vvSubject(VVCase_vvSubject object)
      {
        return createVVCase_vvSubjectAdapter();
      }
      @Override
      public Adapter caseVVTarget_element(VVTarget_element object)
      {
        return createVVTarget_elementAdapter();
      }
      @Override
      public Adapter caseEvent(Event object)
      {
        return createEventAdapter();
      }
      @Override
      public Adapter caseEventChain(EventChain object)
      {
        return createEventChainAdapter();
      }
      @Override
      public Adapter casePrecedenceConstraint(PrecedenceConstraint object)
      {
        return createPrecedenceConstraintAdapter();
      }
      @Override
      public Adapter caseTiming(Timing object)
      {
        return createTimingAdapter();
      }
      @Override
      public Adapter caseTimingConstraint(TimingConstraint object)
      {
        return createTimingConstraintAdapter();
      }
      @Override
      public Adapter caseTimingDescription(TimingDescription object)
      {
        return createTimingDescriptionAdapter();
      }
      @Override
      public Adapter caseTimingExpression(TimingExpression object)
      {
        return createTimingExpressionAdapter();
      }
      @Override
      public Adapter caseAUTOSAREvent(AUTOSAREvent object)
      {
        return createAUTOSAREventAdapter();
      }
      @Override
      public Adapter caseEventFaultFailure(EventFaultFailure object)
      {
        return createEventFaultFailureAdapter();
      }
      @Override
      public Adapter caseEventFeatureFlaw(EventFeatureFlaw object)
      {
        return createEventFeatureFlawAdapter();
      }
      @Override
      public Adapter caseEventFunction(EventFunction object)
      {
        return createEventFunctionAdapter();
      }
      @Override
      public Adapter caseEventFunctionClientServerPort(EventFunctionClientServerPort object)
      {
        return createEventFunctionClientServerPortAdapter();
      }
      @Override
      public Adapter caseEventFunctionFlowPort(EventFunctionFlowPort object)
      {
        return createEventFunctionFlowPortAdapter();
      }
      @Override
      public Adapter caseExternalEvent(ExternalEvent object)
      {
        return createExternalEventAdapter();
      }
      @Override
      public Adapter caseModeEvent(ModeEvent object)
      {
        return createModeEventAdapter();
      }
      @Override
      public Adapter caseEventFunction_function(EventFunction_function object)
      {
        return createEventFunction_functionAdapter();
      }
      @Override
      public Adapter caseEventFunctionClientServerPort_port(EventFunctionClientServerPort_port object)
      {
        return createEventFunctionClientServerPort_portAdapter();
      }
      @Override
      public Adapter caseEventFunctionFlowPort_port(EventFunctionFlowPort_port object)
      {
        return createEventFunctionFlowPort_portAdapter();
      }
      @Override
      public Adapter caseAgeConstraint(AgeConstraint object)
      {
        return createAgeConstraintAdapter();
      }
      @Override
      public Adapter caseArbitraryConstraint(ArbitraryConstraint object)
      {
        return createArbitraryConstraintAdapter();
      }
      @Override
      public Adapter caseBurstConstraint(BurstConstraint object)
      {
        return createBurstConstraintAdapter();
      }
      @Override
      public Adapter caseComparisonConstraint(ComparisonConstraint object)
      {
        return createComparisonConstraintAdapter();
      }
      @Override
      public Adapter caseDelayConstraint(DelayConstraint object)
      {
        return createDelayConstraintAdapter();
      }
      @Override
      public Adapter caseExecutionTimeConstraint(ExecutionTimeConstraint object)
      {
        return createExecutionTimeConstraintAdapter();
      }
      @Override
      public Adapter caseInputSynchronizationConstraint(InputSynchronizationConstraint object)
      {
        return createInputSynchronizationConstraintAdapter();
      }
      @Override
      public Adapter caseOrderConstraint(OrderConstraint object)
      {
        return createOrderConstraintAdapter();
      }
      @Override
      public Adapter caseOutputSynchronizationConstraint(OutputSynchronizationConstraint object)
      {
        return createOutputSynchronizationConstraintAdapter();
      }
      @Override
      public Adapter casePatternConstraint(PatternConstraint object)
      {
        return createPatternConstraintAdapter();
      }
      @Override
      public Adapter casePeriodicConstraint(PeriodicConstraint object)
      {
        return createPeriodicConstraintAdapter();
      }
      @Override
      public Adapter caseReactionConstraint(ReactionConstraint object)
      {
        return createReactionConstraintAdapter();
      }
      @Override
      public Adapter caseRepetitionConstraint(RepetitionConstraint object)
      {
        return createRepetitionConstraintAdapter();
      }
      @Override
      public Adapter caseSporadicConstraint(SporadicConstraint object)
      {
        return createSporadicConstraintAdapter();
      }
      @Override
      public Adapter caseStrongDelayConstraint(StrongDelayConstraint object)
      {
        return createStrongDelayConstraintAdapter();
      }
      @Override
      public Adapter caseStrongSynchronizationConstraint(StrongSynchronizationConstraint object)
      {
        return createStrongSynchronizationConstraintAdapter();
      }
      @Override
      public Adapter caseSynchronizationConstraint(SynchronizationConstraint object)
      {
        return createSynchronizationConstraintAdapter();
      }
      @Override
      public Adapter casePrecedenceConstraint_preceding(PrecedenceConstraint_preceding object)
      {
        return createPrecedenceConstraint_precedingAdapter();
      }
      @Override
      public Adapter casePrecedenceConstraint_successive(PrecedenceConstraint_successive object)
      {
        return createPrecedenceConstraint_successiveAdapter();
      }
      @Override
      public Adapter caseDependability(Dependability object)
      {
        return createDependabilityAdapter();
      }
      @Override
      public Adapter caseFeatureFlaw(FeatureFlaw object)
      {
        return createFeatureFlawAdapter();
      }
      @Override
      public Adapter caseHazard(Hazard object)
      {
        return createHazardAdapter();
      }
      @Override
      public Adapter caseHazardousEvent(HazardousEvent object)
      {
        return createHazardousEventAdapter();
      }
      @Override
      public Adapter caseItem(Item object)
      {
        return createItemAdapter();
      }
      @Override
      public Adapter caseFaultFailure(FaultFailure object)
      {
        return createFaultFailureAdapter();
      }
      @Override
      public Adapter caseQuantitativeSafetyConstraint(QuantitativeSafetyConstraint object)
      {
        return createQuantitativeSafetyConstraintAdapter();
      }
      @Override
      public Adapter caseSafetyConstraint(SafetyConstraint object)
      {
        return createSafetyConstraintAdapter();
      }
      @Override
      public Adapter caseFaultFailure_anomaly(FaultFailure_anomaly object)
      {
        return createFaultFailure_anomalyAdapter();
      }
      @Override
      public Adapter caseAnomaly(Anomaly object)
      {
        return createAnomalyAdapter();
      }
      @Override
      public Adapter caseErrorBehavior(ErrorBehavior object)
      {
        return createErrorBehaviorAdapter();
      }
      @Override
      public Adapter caseErrorModelPrototype(ErrorModelPrototype object)
      {
        return createErrorModelPrototypeAdapter();
      }
      @Override
      public Adapter caseErrorModelType(ErrorModelType object)
      {
        return createErrorModelTypeAdapter();
      }
      @Override
      public Adapter caseFailureOutPort(FailureOutPort object)
      {
        return createFailureOutPortAdapter();
      }
      @Override
      public Adapter caseFaultFailurePort(FaultFailurePort object)
      {
        return createFaultFailurePortAdapter();
      }
      @Override
      public Adapter caseFaultFailurePropagationLink(FaultFailurePropagationLink object)
      {
        return createFaultFailurePropagationLinkAdapter();
      }
      @Override
      public Adapter caseFaultInPort(FaultInPort object)
      {
        return createFaultInPortAdapter();
      }
      @Override
      public Adapter caseInternalFaultPrototype(InternalFaultPrototype object)
      {
        return createInternalFaultPrototypeAdapter();
      }
      @Override
      public Adapter caseProcessFaultPrototype(ProcessFaultPrototype object)
      {
        return createProcessFaultPrototypeAdapter();
      }
      @Override
      public Adapter caseErrorModelPrototype_functionTarget(ErrorModelPrototype_functionTarget object)
      {
        return createErrorModelPrototype_functionTargetAdapter();
      }
      @Override
      public Adapter caseErrorModelPrototype_hwTarget(ErrorModelPrototype_hwTarget object)
      {
        return createErrorModelPrototype_hwTargetAdapter();
      }
      @Override
      public Adapter caseFaultFailurePort_functionTarget(FaultFailurePort_functionTarget object)
      {
        return createFaultFailurePort_functionTargetAdapter();
      }
      @Override
      public Adapter caseFaultFailurePort_hwTarget(FaultFailurePort_hwTarget object)
      {
        return createFaultFailurePort_hwTargetAdapter();
      }
      @Override
      public Adapter caseFaultFailurePropagationLink_fromPort(FaultFailurePropagationLink_fromPort object)
      {
        return createFaultFailurePropagationLink_fromPortAdapter();
      }
      @Override
      public Adapter caseFaultFailurePropagationLink_toPort(FaultFailurePropagationLink_toPort object)
      {
        return createFaultFailurePropagationLink_toPortAdapter();
      }
      @Override
      public Adapter caseFunctionalSafetyConcept(FunctionalSafetyConcept object)
      {
        return createFunctionalSafetyConceptAdapter();
      }
      @Override
      public Adapter caseSafetyGoal(SafetyGoal object)
      {
        return createSafetyGoalAdapter();
      }
      @Override
      public Adapter caseTechnicalSafetyConcept(TechnicalSafetyConcept object)
      {
        return createTechnicalSafetyConceptAdapter();
      }
      @Override
      public Adapter caseClaim(Claim object)
      {
        return createClaimAdapter();
      }
      @Override
      public Adapter caseGround(Ground object)
      {
        return createGroundAdapter();
      }
      @Override
      public Adapter caseSafetyCase(SafetyCase object)
      {
        return createSafetyCaseAdapter();
      }
      @Override
      public Adapter caseWarrant(Warrant object)
      {
        return createWarrantAdapter();
      }
      @Override
      public Adapter caseGenericConstraint(GenericConstraint object)
      {
        return createGenericConstraintAdapter();
      }
      @Override
      public Adapter caseGenericConstraintSet(GenericConstraintSet object)
      {
        return createGenericConstraintSetAdapter();
      }
      @Override
      public Adapter caseTakeRateConstraint(TakeRateConstraint object)
      {
        return createTakeRateConstraintAdapter();
      }
      @Override
      public Adapter caseComment(Comment object)
      {
        return createCommentAdapter();
      }
      @Override
      public Adapter caseContext(Context object)
      {
        return createContextAdapter();
      }
      @Override
      public Adapter caseEAConnector(EAConnector object)
      {
        return createEAConnectorAdapter();
      }
      @Override
      public Adapter caseEAElement(EAElement object)
      {
        return createEAElementAdapter();
      }
      @Override
      public Adapter caseEAPackage(EAPackage object)
      {
        return createEAPackageAdapter();
      }
      @Override
      public Adapter caseEAPackageableElement(EAPackageableElement object)
      {
        return createEAPackageableElementAdapter();
      }
      @Override
      public Adapter caseEAPort(EAPort object)
      {
        return createEAPortAdapter();
      }
      @Override
      public Adapter caseEAPrototype(EAPrototype object)
      {
        return createEAPrototypeAdapter();
      }
      @Override
      public Adapter caseEAType(EAType object)
      {
        return createEATypeAdapter();
      }
      @Override
      public Adapter caseEAXML(EAXML object)
      {
        return createEAXMLAdapter();
      }
      @Override
      public Adapter caseRationale(Rationale object)
      {
        return createRationaleAdapter();
      }
      @Override
      public Adapter caseRealization(Realization object)
      {
        return createRealizationAdapter();
      }
      @Override
      public Adapter caseReferrable(Referrable object)
      {
        return createReferrableAdapter();
      }
      @Override
      public Adapter caseRelationship(Relationship object)
      {
        return createRelationshipAdapter();
      }
      @Override
      public Adapter caseTraceableSpecification(TraceableSpecification object)
      {
        return createTraceableSpecificationAdapter();
      }
      @Override
      public Adapter caseIdentifiable(Identifiable object)
      {
        return createIdentifiableAdapter();
      }
      @Override
      public Adapter caseRealization_realized(Realization_realized object)
      {
        return createRealization_realizedAdapter();
      }
      @Override
      public Adapter caseRealization_realizedBy(Realization_realizedBy object)
      {
        return createRealization_realizedByAdapter();
      }
      @Override
      public Adapter caseArrayDatatype(ArrayDatatype object)
      {
        return createArrayDatatypeAdapter();
      }
      @Override
      public Adapter caseCompositeDatatype(CompositeDatatype object)
      {
        return createCompositeDatatypeAdapter();
      }
      @Override
      public Adapter caseEABoolean(EABoolean object)
      {
        return createEABooleanAdapter();
      }
      @Override
      public Adapter caseEADatatype(EADatatype object)
      {
        return createEADatatypeAdapter();
      }
      @Override
      public Adapter caseEADatatypePrototype(EADatatypePrototype object)
      {
        return createEADatatypePrototypeAdapter();
      }
      @Override
      public Adapter caseEANumerical(EANumerical object)
      {
        return createEANumericalAdapter();
      }
      @Override
      public Adapter caseEAString(EAString object)
      {
        return createEAStringAdapter();
      }
      @Override
      public Adapter caseEnumeration(Enumeration object)
      {
        return createEnumerationAdapter();
      }
      @Override
      public Adapter caseEnumerationLiteral(EnumerationLiteral object)
      {
        return createEnumerationLiteralAdapter();
      }
      @Override
      public Adapter caseQuantity(Quantity object)
      {
        return createQuantityAdapter();
      }
      @Override
      public Adapter caseRangeableValueType(RangeableValueType object)
      {
        return createRangeableValueTypeAdapter();
      }
      @Override
      public Adapter caseUnit(Unit object)
      {
        return createUnitAdapter();
      }
      @Override
      public Adapter caseEAArrayValue(EAArrayValue object)
      {
        return createEAArrayValueAdapter();
      }
      @Override
      public Adapter caseEABooleanValue(EABooleanValue object)
      {
        return createEABooleanValueAdapter();
      }
      @Override
      public Adapter caseEACompositeValue(EACompositeValue object)
      {
        return createEACompositeValueAdapter();
      }
      @Override
      public Adapter caseEAEnumerationValue(EAEnumerationValue object)
      {
        return createEAEnumerationValueAdapter();
      }
      @Override
      public Adapter caseEAExpression(EAExpression object)
      {
        return createEAExpressionAdapter();
      }
      @Override
      public Adapter caseEANumericalValue(EANumericalValue object)
      {
        return createEANumericalValueAdapter();
      }
      @Override
      public Adapter caseEAStringValue(EAStringValue object)
      {
        return createEAStringValueAdapter();
      }
      @Override
      public Adapter caseEAValue(EAValue object)
      {
        return createEAValueAdapter();
      }
      @Override
      public Adapter caseUserAttributeDefinition(UserAttributeDefinition object)
      {
        return createUserAttributeDefinitionAdapter();
      }
      @Override
      public Adapter caseUserAttributedElement(UserAttributedElement object)
      {
        return createUserAttributedElementAdapter();
      }
      @Override
      public Adapter caseUserElementType(UserElementType object)
      {
        return createUserElementTypeAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintBindingAttribute(BehaviorConstraintBindingAttribute object)
      {
        return createBehaviorConstraintBindingAttributeAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintBindingEvent(BehaviorConstraintBindingEvent object)
      {
        return createBehaviorConstraintBindingEventAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintInternalBinding(BehaviorConstraintInternalBinding object)
      {
        return createBehaviorConstraintInternalBindingAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintParameter(BehaviorConstraintParameter object)
      {
        return createBehaviorConstraintParameterAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintPrototype(BehaviorConstraintPrototype object)
      {
        return createBehaviorConstraintPrototypeAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintTargetBinding(BehaviorConstraintTargetBinding object)
      {
        return createBehaviorConstraintTargetBindingAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintType(BehaviorConstraintType object)
      {
        return createBehaviorConstraintTypeAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintInternalBinding_bindingThroughFunctionConnector(BehaviorConstraintInternalBinding_bindingThroughFunctionConnector object)
      {
        return createBehaviorConstraintInternalBinding_bindingThroughFunctionConnectorAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintInternalBinding_bindingThroughHardwareConnector(BehaviorConstraintInternalBinding_bindingThroughHardwareConnector object)
      {
        return createBehaviorConstraintInternalBinding_bindingThroughHardwareConnectorAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintPrototype_errorModelTarget(BehaviorConstraintPrototype_errorModelTarget object)
      {
        return createBehaviorConstraintPrototype_errorModelTargetAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintPrototype_functionTarget(BehaviorConstraintPrototype_functionTarget object)
      {
        return createBehaviorConstraintPrototype_functionTargetAdapter();
      }
      @Override
      public Adapter caseBehaviorConstraintPrototype_hardwareComponentTarget(BehaviorConstraintPrototype_hardwareComponentTarget object)
      {
        return createBehaviorConstraintPrototype_hardwareComponentTargetAdapter();
      }
      @Override
      public Adapter caseAttribute(Attribute object)
      {
        return createAttributeAdapter();
      }
      @Override
      public Adapter caseAttributeQuantificationConstraint(AttributeQuantificationConstraint object)
      {
        return createAttributeQuantificationConstraintAdapter();
      }
      @Override
      public Adapter caseBehaviorAttributeBinding(BehaviorAttributeBinding object)
      {
        return createBehaviorAttributeBindingAdapter();
      }
      @Override
      public Adapter caseLogicalEvent(LogicalEvent object)
      {
        return createLogicalEventAdapter();
      }
      @Override
      public Adapter caseQuantification(Quantification object)
      {
        return createQuantificationAdapter();
      }
      @Override
      public Adapter caseComputationConstraint(ComputationConstraint object)
      {
        return createComputationConstraintAdapter();
      }
      @Override
      public Adapter caseLogicalPath(LogicalPath object)
      {
        return createLogicalPathAdapter();
      }
      @Override
      public Adapter caseLogicalTransformation(LogicalTransformation object)
      {
        return createLogicalTransformationAdapter();
      }
      @Override
      public Adapter caseTransformationOccurrence(TransformationOccurrence object)
      {
        return createTransformationOccurrenceAdapter();
      }
      @Override
      public Adapter caseLogicalTimeCondition(LogicalTimeCondition object)
      {
        return createLogicalTimeConditionAdapter();
      }
      @Override
      public Adapter caseState(State object)
      {
        return createStateAdapter();
      }
      @Override
      public Adapter caseStateEvent(StateEvent object)
      {
        return createStateEventAdapter();
      }
      @Override
      public Adapter caseSynchronousTransition(SynchronousTransition object)
      {
        return createSynchronousTransitionAdapter();
      }
      @Override
      public Adapter caseTemporalConstraint(TemporalConstraint object)
      {
        return createTemporalConstraintAdapter();
      }
      @Override
      public Adapter caseTransition(Transition object)
      {
        return createTransitionAdapter();
      }
      @Override
      public Adapter caseTransitionEvent(TransitionEvent object)
      {
        return createTransitionEventAdapter();
      }
      @Override
      public Adapter caseArchitecturalDescription(ArchitecturalDescription object)
      {
        return createArchitecturalDescriptionAdapter();
      }
      @Override
      public Adapter caseArchitecturalModel(ArchitecturalModel object)
      {
        return createArchitecturalModelAdapter();
      }
      @Override
      public Adapter caseArchitecture(Architecture object)
      {
        return createArchitectureAdapter();
      }
      @Override
      public Adapter caseConcept(Concept object)
      {
        return createConceptAdapter();
      }
      @Override
      public Adapter caseMission(Mission object)
      {
        return createMissionAdapter();
      }
      @Override
      public Adapter caseVehicleSystem(VehicleSystem object)
      {
        return createVehicleSystemAdapter();
      }
      @Override
      public Adapter caseStakeholder(Stakeholder object)
      {
        return createStakeholderAdapter();
      }
      @Override
      public Adapter caseStakeholderNeed(StakeholderNeed object)
      {
        return createStakeholderNeedAdapter();
      }
      @Override
      public Adapter caseBusinessOpportunity(BusinessOpportunity object)
      {
        return createBusinessOpportunityAdapter();
      }
      @Override
      public Adapter caseProblemStatement(ProblemStatement object)
      {
        return createProblemStatementAdapter();
      }
      @Override
      public Adapter caseProductPositioning(ProductPositioning object)
      {
        return createProductPositioningAdapter();
      }
      @Override
      public Adapter caseSystem(org.eclipse.eatop.eastadl21.System object)
      {
        return createSystemAdapter();
      }
      @Override
      public Adapter caseTimingDescriptionEvent(TimingDescriptionEvent object)
      {
        return createTimingDescriptionEventAdapter();
      }
      @Override
      public Adapter caseGReferrable(GReferrable object)
      {
        return createGReferrableAdapter();
      }
      @Override
      public Adapter caseGIdentifiable(GIdentifiable object)
      {
        return createGIdentifiableAdapter();
      }
      @Override
      public Adapter caseGEAPackageableElement(GEAPackageableElement object)
      {
        return createGEAPackageableElementAdapter();
      }
      @Override
      public Adapter caseGEAPackage(GEAPackage object)
      {
        return createGEAPackageAdapter();
      }
      @Override
      public Adapter caseGEAXML(GEAXML object)
      {
        return createGEAXMLAdapter();
      }
      @Override
      public Adapter defaultCase(EObject object)
      {
        return createEObjectAdapter();
      }
    };

  /**
   * Creates an adapter for the <code>target</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param target the object to adapt.
   * @return the adapter for the <code>target</code>.
   * @generated
   */
  @Override
  public Adapter createAdapter(Notifier target)
  {
    return modelSwitch.doSwitch((EObject)target);
  }


  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VehicleLevel <em>Vehicle Level</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VehicleLevel
   * @generated
   */
  public Adapter createVehicleLevelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SystemModel <em>System Model</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SystemModel
   * @generated
   */
  public Adapter createSystemModelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AnalysisLevel <em>Analysis Level</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AnalysisLevel
   * @generated
   */
  public Adapter createAnalysisLevelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.DesignLevel <em>Design Level</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.DesignLevel
   * @generated
   */
  public Adapter createDesignLevelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ImplementationLevel <em>Implementation Level</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ImplementationLevel
   * @generated
   */
  public Adapter createImplementationLevelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BindingTime <em>Binding Time</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BindingTime
   * @generated
   */
  public Adapter createBindingTimeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Feature <em>Feature</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Feature
   * @generated
   */
  public Adapter createFeatureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureConstraint <em>Feature Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureConstraint
   * @generated
   */
  public Adapter createFeatureConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureGroup <em>Feature Group</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureGroup
   * @generated
   */
  public Adapter createFeatureGroupAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureLink <em>Feature Link</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureLink
   * @generated
   */
  public Adapter createFeatureLinkAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureModel <em>Feature Model</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureModel
   * @generated
   */
  public Adapter createFeatureModelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureTreeNode <em>Feature Tree Node</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureTreeNode
   * @generated
   */
  public Adapter createFeatureTreeNodeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.DeviationAttributeSet <em>Deviation Attribute Set</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.DeviationAttributeSet
   * @generated
   */
  public Adapter createDeviationAttributeSetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VehicleFeature <em>Vehicle Feature</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VehicleFeature
   * @generated
   */
  public Adapter createVehicleFeatureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AllocateableElement <em>Allocateable Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AllocateableElement
   * @generated
   */
  public Adapter createAllocateableElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Allocation <em>Allocation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Allocation
   * @generated
   */
  public Adapter createAllocationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype <em>Analysis Function Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype
   * @generated
   */
  public Adapter createAnalysisFunctionPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AnalysisFunctionType <em>Analysis Function Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AnalysisFunctionType
   * @generated
   */
  public Adapter createAnalysisFunctionTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType <em>Basic Software Function Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType
   * @generated
   */
  public Adapter createBasicSoftwareFunctionTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.DesignFunctionPrototype <em>Design Function Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.DesignFunctionPrototype
   * @generated
   */
  public Adapter createDesignFunctionPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.DesignFunctionType <em>Design Function Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.DesignFunctionType
   * @generated
   */
  public Adapter createDesignFunctionTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionalDevice <em>Functional Device</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionalDevice
   * @generated
   */
  public Adapter createFunctionalDeviceAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionAllocation <em>Function Allocation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionAllocation
   * @generated
   */
  public Adapter createFunctionAllocationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionClientServerInterface <em>Function Client Server Interface</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionClientServerInterface
   * @generated
   */
  public Adapter createFunctionClientServerInterfaceAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionClientServerPort <em>Function Client Server Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionClientServerPort
   * @generated
   */
  public Adapter createFunctionClientServerPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionConnector <em>Function Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionConnector
   * @generated
   */
  public Adapter createFunctionConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionFlowPort <em>Function Flow Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionFlowPort
   * @generated
   */
  public Adapter createFunctionFlowPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionPort <em>Function Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionPort
   * @generated
   */
  public Adapter createFunctionPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionPowerPort <em>Function Power Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionPowerPort
   * @generated
   */
  public Adapter createFunctionPowerPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionPrototype <em>Function Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionPrototype
   * @generated
   */
  public Adapter createFunctionPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionType <em>Function Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionType
   * @generated
   */
  public Adapter createFunctionTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwareFunctionType <em>Hardware Function Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwareFunctionType
   * @generated
   */
  public Adapter createHardwareFunctionTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.LocalDeviceManager <em>Local Device Manager</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.LocalDeviceManager
   * @generated
   */
  public Adapter createLocalDeviceManagerAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Operation <em>Operation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Operation
   * @generated
   */
  public Adapter createOperationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PortGroup <em>Port Group</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PortGroup
   * @generated
   */
  public Adapter createPortGroupAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement <em>Function Allocation allocated Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement
   * @generated
   */
  public Adapter createFunctionAllocation_allocatedElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionAllocation_target <em>Function Allocation target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionAllocation_target
   * @generated
   */
  public Adapter createFunctionAllocation_targetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionConnector_port <em>Function Connector port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionConnector_port
   * @generated
   */
  public Adapter createFunctionConnector_portAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Actuator <em>Actuator</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Actuator
   * @generated
   */
  public Adapter createActuatorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.CommunicationHardwarePin <em>Communication Hardware Pin</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.CommunicationHardwarePin
   * @generated
   */
  public Adapter createCommunicationHardwarePinAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ElectricalComponent <em>Electrical Component</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ElectricalComponent
   * @generated
   */
  public Adapter createElectricalComponentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwareComponentPrototype <em>Hardware Component Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwareComponentPrototype
   * @generated
   */
  public Adapter createHardwareComponentPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwareComponentType <em>Hardware Component Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwareComponentType
   * @generated
   */
  public Adapter createHardwareComponentTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwareConnector <em>Hardware Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwareConnector
   * @generated
   */
  public Adapter createHardwareConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwarePin <em>Hardware Pin</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwarePin
   * @generated
   */
  public Adapter createHardwarePinAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwarePort <em>Hardware Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwarePort
   * @generated
   */
  public Adapter createHardwarePortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector <em>Hardware Port Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwarePortConnector
   * @generated
   */
  public Adapter createHardwarePortConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.IOHardwarePin <em>IO Hardware Pin</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.IOHardwarePin
   * @generated
   */
  public Adapter createIOHardwarePinAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Node <em>Node</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Node
   * @generated
   */
  public Adapter createNodeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PowerHardwarePin <em>Power Hardware Pin</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PowerHardwarePin
   * @generated
   */
  public Adapter createPowerHardwarePinAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Sensor <em>Sensor</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Sensor
   * @generated
   */
  public Adapter createSensorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AllocationTarget <em>Allocation Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AllocationTarget
   * @generated
   */
  public Adapter createAllocationTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwareConnector_port <em>Hardware Connector port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwareConnector_port
   * @generated
   */
  public Adapter createHardwareConnector_portAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HardwarePortConnector_port <em>Hardware Port Connector port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HardwarePortConnector_port
   * @generated
   */
  public Adapter createHardwarePortConnector_portAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ClampConnector <em>Clamp Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ClampConnector
   * @generated
   */
  public Adapter createClampConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Environment <em>Environment</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Environment
   * @generated
   */
  public Adapter createEnvironmentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ClampConnector_port <em>Clamp Connector port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ClampConnector_port
   * @generated
   */
  public Adapter createClampConnector_portAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Behavior <em>Behavior</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Behavior
   * @generated
   */
  public Adapter createBehaviorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Mode <em>Mode</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Mode
   * @generated
   */
  public Adapter createModeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ModeGroup <em>Mode Group</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ModeGroup
   * @generated
   */
  public Adapter createModeGroupAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionBehavior <em>Function Behavior</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionBehavior
   * @generated
   */
  public Adapter createFunctionBehaviorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionTrigger <em>Function Trigger</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionTrigger
   * @generated
   */
  public Adapter createFunctionTriggerAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ConfigurableContainer <em>Configurable Container</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ConfigurableContainer
   * @generated
   */
  public Adapter createConfigurableContainerAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ConfigurationDecision <em>Configuration Decision</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ConfigurationDecision
   * @generated
   */
  public Adapter createConfigurationDecisionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder <em>Configuration Decision Folder</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder
   * @generated
   */
  public Adapter createConfigurationDecisionFolderAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ConfigurationDecisionModel <em>Configuration Decision Model</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ConfigurationDecisionModel
   * @generated
   */
  public Adapter createConfigurationDecisionModelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ConfigurationDecisionModelEntry <em>Configuration Decision Model Entry</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ConfigurationDecisionModelEntry
   * @generated
   */
  public Adapter createConfigurationDecisionModelEntryAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ContainerConfiguration <em>Container Configuration</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ContainerConfiguration
   * @generated
   */
  public Adapter createContainerConfigurationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureConfiguration <em>Feature Configuration</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureConfiguration
   * @generated
   */
  public Adapter createFeatureConfigurationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.InternalBinding <em>Internal Binding</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.InternalBinding
   * @generated
   */
  public Adapter createInternalBindingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PrivateContent <em>Private Content</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PrivateContent
   * @generated
   */
  public Adapter createPrivateContentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ReuseMetaInformation <em>Reuse Meta Information</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ReuseMetaInformation
   * @generated
   */
  public Adapter createReuseMetaInformationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SelectionCriterion <em>Selection Criterion</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SelectionCriterion
   * @generated
   */
  public Adapter createSelectionCriterionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Variability <em>Variability</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Variability
   * @generated
   */
  public Adapter createVariabilityAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VariableElement <em>Variable Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VariableElement
   * @generated
   */
  public Adapter createVariableElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VariationGroup <em>Variation Group</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VariationGroup
   * @generated
   */
  public Adapter createVariationGroupAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VehicleLevelBinding <em>Vehicle Level Binding</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VehicleLevelBinding
   * @generated
   */
  public Adapter createVehicleLevelBindingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.DeriveRequirement <em>Derive Requirement</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.DeriveRequirement
   * @generated
   */
  public Adapter createDeriveRequirementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.OperationalSituation <em>Operational Situation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.OperationalSituation
   * @generated
   */
  public Adapter createOperationalSituationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RequirementsModel <em>Requirements Model</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RequirementsModel
   * @generated
   */
  public Adapter createRequirementsModelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RequirementsRelationship <em>Requirements Relationship</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RequirementsRelationship
   * @generated
   */
  public Adapter createRequirementsRelationshipAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Requirement <em>Requirement</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Requirement
   * @generated
   */
  public Adapter createRequirementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RequirementsHierarchy <em>Requirements Hierarchy</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RequirementsHierarchy
   * @generated
   */
  public Adapter createRequirementsHierarchyAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Refine <em>Refine</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Refine
   * @generated
   */
  public Adapter createRefineAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Satisfy <em>Satisfy</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Satisfy
   * @generated
   */
  public Adapter createSatisfyAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RequirementsLink <em>Requirements Link</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RequirementsLink
   * @generated
   */
  public Adapter createRequirementsLinkAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup <em>Requirements Relationship Group</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup
   * @generated
   */
  public Adapter createRequirementsRelationshipGroupAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.QualityRequirement <em>Quality Requirement</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.QualityRequirement
   * @generated
   */
  public Adapter createQualityRequirementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Refine_refinedBy <em>Refine refined By</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Refine_refinedBy
   * @generated
   */
  public Adapter createRefine_refinedByAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy <em>Satisfy satisfied By</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy
   * @generated
   */
  public Adapter createSatisfy_satisfiedByAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Actor <em>Actor</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Actor
   * @generated
   */
  public Adapter createActorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Extend <em>Extend</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Extend
   * @generated
   */
  public Adapter createExtendAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ExtensionPoint <em>Extension Point</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ExtensionPoint
   * @generated
   */
  public Adapter createExtensionPointAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Include <em>Include</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Include
   * @generated
   */
  public Adapter createIncludeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RedefinableElement <em>Redefinable Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RedefinableElement
   * @generated
   */
  public Adapter createRedefinableElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.UseCase <em>Use Case</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.UseCase
   * @generated
   */
  public Adapter createUseCaseAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VerificationValidation <em>Verification Validation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VerificationValidation
   * @generated
   */
  public Adapter createVerificationValidationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Verify <em>Verify</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Verify
   * @generated
   */
  public Adapter createVerifyAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVActualOutcome <em>VV Actual Outcome</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVActualOutcome
   * @generated
   */
  public Adapter createVVActualOutcomeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVCase <em>VV Case</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVCase
   * @generated
   */
  public Adapter createVVCaseAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVIntendedOutcome <em>VV Intended Outcome</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVIntendedOutcome
   * @generated
   */
  public Adapter createVVIntendedOutcomeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVLog <em>VV Log</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVLog
   * @generated
   */
  public Adapter createVVLogAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVProcedure <em>VV Procedure</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVProcedure
   * @generated
   */
  public Adapter createVVProcedureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVStimuli <em>VV Stimuli</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVStimuli
   * @generated
   */
  public Adapter createVVStimuliAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVTarget <em>VV Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVTarget
   * @generated
   */
  public Adapter createVVTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVCase_vvSubject <em>VV Case vv Subject</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVCase_vvSubject
   * @generated
   */
  public Adapter createVVCase_vvSubjectAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VVTarget_element <em>VV Target element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VVTarget_element
   * @generated
   */
  public Adapter createVVTarget_elementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Event <em>Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Event
   * @generated
   */
  public Adapter createEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventChain <em>Event Chain</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventChain
   * @generated
   */
  public Adapter createEventChainAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint <em>Precedence Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PrecedenceConstraint
   * @generated
   */
  public Adapter createPrecedenceConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Timing <em>Timing</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Timing
   * @generated
   */
  public Adapter createTimingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TimingConstraint <em>Timing Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TimingConstraint
   * @generated
   */
  public Adapter createTimingConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TimingDescription <em>Timing Description</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TimingDescription
   * @generated
   */
  public Adapter createTimingDescriptionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TimingExpression <em>Timing Expression</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TimingExpression
   * @generated
   */
  public Adapter createTimingExpressionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AUTOSAREvent <em>AUTOSAR Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AUTOSAREvent
   * @generated
   */
  public Adapter createAUTOSAREventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFaultFailure <em>Event Fault Failure</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFaultFailure
   * @generated
   */
  public Adapter createEventFaultFailureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFeatureFlaw <em>Event Feature Flaw</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFeatureFlaw
   * @generated
   */
  public Adapter createEventFeatureFlawAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFunction <em>Event Function</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFunction
   * @generated
   */
  public Adapter createEventFunctionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFunctionClientServerPort <em>Event Function Client Server Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFunctionClientServerPort
   * @generated
   */
  public Adapter createEventFunctionClientServerPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort <em>Event Function Flow Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFunctionFlowPort
   * @generated
   */
  public Adapter createEventFunctionFlowPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ExternalEvent <em>External Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ExternalEvent
   * @generated
   */
  public Adapter createExternalEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ModeEvent <em>Mode Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ModeEvent
   * @generated
   */
  public Adapter createModeEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFunction_function <em>Event Function function</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFunction_function
   * @generated
   */
  public Adapter createEventFunction_functionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port <em>Event Function Client Server Port port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port
   * @generated
   */
  public Adapter createEventFunctionClientServerPort_portAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port <em>Event Function Flow Port port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port
   * @generated
   */
  public Adapter createEventFunctionFlowPort_portAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AgeConstraint <em>Age Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AgeConstraint
   * @generated
   */
  public Adapter createAgeConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ArbitraryConstraint <em>Arbitrary Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ArbitraryConstraint
   * @generated
   */
  public Adapter createArbitraryConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BurstConstraint <em>Burst Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BurstConstraint
   * @generated
   */
  public Adapter createBurstConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ComparisonConstraint <em>Comparison Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ComparisonConstraint
   * @generated
   */
  public Adapter createComparisonConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.DelayConstraint <em>Delay Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.DelayConstraint
   * @generated
   */
  public Adapter createDelayConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint <em>Execution Time Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ExecutionTimeConstraint
   * @generated
   */
  public Adapter createExecutionTimeConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.InputSynchronizationConstraint <em>Input Synchronization Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.InputSynchronizationConstraint
   * @generated
   */
  public Adapter createInputSynchronizationConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.OrderConstraint <em>Order Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.OrderConstraint
   * @generated
   */
  public Adapter createOrderConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint <em>Output Synchronization Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint
   * @generated
   */
  public Adapter createOutputSynchronizationConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PatternConstraint <em>Pattern Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PatternConstraint
   * @generated
   */
  public Adapter createPatternConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PeriodicConstraint <em>Periodic Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PeriodicConstraint
   * @generated
   */
  public Adapter createPeriodicConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ReactionConstraint <em>Reaction Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ReactionConstraint
   * @generated
   */
  public Adapter createReactionConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RepetitionConstraint <em>Repetition Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RepetitionConstraint
   * @generated
   */
  public Adapter createRepetitionConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SporadicConstraint <em>Sporadic Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SporadicConstraint
   * @generated
   */
  public Adapter createSporadicConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.StrongDelayConstraint <em>Strong Delay Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.StrongDelayConstraint
   * @generated
   */
  public Adapter createStrongDelayConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint <em>Strong Synchronization Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint
   * @generated
   */
  public Adapter createStrongSynchronizationConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SynchronizationConstraint <em>Synchronization Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SynchronizationConstraint
   * @generated
   */
  public Adapter createSynchronizationConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding <em>Precedence Constraint preceding</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding
   * @generated
   */
  public Adapter createPrecedenceConstraint_precedingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive <em>Precedence Constraint successive</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive
   * @generated
   */
  public Adapter createPrecedenceConstraint_successiveAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Dependability <em>Dependability</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Dependability
   * @generated
   */
  public Adapter createDependabilityAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FeatureFlaw <em>Feature Flaw</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FeatureFlaw
   * @generated
   */
  public Adapter createFeatureFlawAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Hazard <em>Hazard</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Hazard
   * @generated
   */
  public Adapter createHazardAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.HazardousEvent <em>Hazardous Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.HazardousEvent
   * @generated
   */
  public Adapter createHazardousEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Item <em>Item</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Item
   * @generated
   */
  public Adapter createItemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailure <em>Fault Failure</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailure
   * @generated
   */
  public Adapter createFaultFailureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint <em>Quantitative Safety Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint
   * @generated
   */
  public Adapter createQuantitativeSafetyConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SafetyConstraint <em>Safety Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SafetyConstraint
   * @generated
   */
  public Adapter createSafetyConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailure_anomaly <em>Fault Failure anomaly</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailure_anomaly
   * @generated
   */
  public Adapter createFaultFailure_anomalyAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Anomaly <em>Anomaly</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Anomaly
   * @generated
   */
  public Adapter createAnomalyAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ErrorBehavior <em>Error Behavior</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ErrorBehavior
   * @generated
   */
  public Adapter createErrorBehaviorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ErrorModelPrototype <em>Error Model Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ErrorModelPrototype
   * @generated
   */
  public Adapter createErrorModelPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ErrorModelType <em>Error Model Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ErrorModelType
   * @generated
   */
  public Adapter createErrorModelTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FailureOutPort <em>Failure Out Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FailureOutPort
   * @generated
   */
  public Adapter createFailureOutPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailurePort <em>Fault Failure Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailurePort
   * @generated
   */
  public Adapter createFaultFailurePortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink <em>Fault Failure Propagation Link</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailurePropagationLink
   * @generated
   */
  public Adapter createFaultFailurePropagationLinkAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultInPort <em>Fault In Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultInPort
   * @generated
   */
  public Adapter createFaultInPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.InternalFaultPrototype <em>Internal Fault Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.InternalFaultPrototype
   * @generated
   */
  public Adapter createInternalFaultPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ProcessFaultPrototype <em>Process Fault Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ProcessFaultPrototype
   * @generated
   */
  public Adapter createProcessFaultPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget <em>Error Model Prototype function Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget
   * @generated
   */
  public Adapter createErrorModelPrototype_functionTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget <em>Error Model Prototype hw Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget
   * @generated
   */
  public Adapter createErrorModelPrototype_hwTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget <em>Fault Failure Port function Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget
   * @generated
   */
  public Adapter createFaultFailurePort_functionTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget <em>Fault Failure Port hw Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget
   * @generated
   */
  public Adapter createFaultFailurePort_hwTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort <em>Fault Failure Propagation Link from Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort
   * @generated
   */
  public Adapter createFaultFailurePropagationLink_fromPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort <em>Fault Failure Propagation Link to Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort
   * @generated
   */
  public Adapter createFaultFailurePropagationLink_toPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.FunctionalSafetyConcept <em>Functional Safety Concept</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.FunctionalSafetyConcept
   * @generated
   */
  public Adapter createFunctionalSafetyConceptAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SafetyGoal <em>Safety Goal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SafetyGoal
   * @generated
   */
  public Adapter createSafetyGoalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TechnicalSafetyConcept <em>Technical Safety Concept</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TechnicalSafetyConcept
   * @generated
   */
  public Adapter createTechnicalSafetyConceptAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Claim <em>Claim</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Claim
   * @generated
   */
  public Adapter createClaimAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Ground <em>Ground</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Ground
   * @generated
   */
  public Adapter createGroundAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SafetyCase <em>Safety Case</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SafetyCase
   * @generated
   */
  public Adapter createSafetyCaseAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Warrant <em>Warrant</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Warrant
   * @generated
   */
  public Adapter createWarrantAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.GenericConstraint <em>Generic Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.GenericConstraint
   * @generated
   */
  public Adapter createGenericConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.GenericConstraintSet <em>Generic Constraint Set</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.GenericConstraintSet
   * @generated
   */
  public Adapter createGenericConstraintSetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TakeRateConstraint <em>Take Rate Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TakeRateConstraint
   * @generated
   */
  public Adapter createTakeRateConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Comment <em>Comment</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Comment
   * @generated
   */
  public Adapter createCommentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Context <em>Context</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Context
   * @generated
   */
  public Adapter createContextAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAConnector <em>EA Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAConnector
   * @generated
   */
  public Adapter createEAConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAElement <em>EA Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAElement
   * @generated
   */
  public Adapter createEAElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAPackage <em>EA Package</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAPackage
   * @generated
   */
  public Adapter createEAPackageAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAPackageableElement <em>EA Packageable Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAPackageableElement
   * @generated
   */
  public Adapter createEAPackageableElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAPort <em>EA Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAPort
   * @generated
   */
  public Adapter createEAPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAPrototype <em>EA Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAPrototype
   * @generated
   */
  public Adapter createEAPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAType <em>EA Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAType
   * @generated
   */
  public Adapter createEATypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAXML <em>EAXML</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAXML
   * @generated
   */
  public Adapter createEAXMLAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Rationale <em>Rationale</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Rationale
   * @generated
   */
  public Adapter createRationaleAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Realization <em>Realization</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Realization
   * @generated
   */
  public Adapter createRealizationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Referrable <em>Referrable</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Referrable
   * @generated
   */
  public Adapter createReferrableAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Relationship <em>Relationship</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Relationship
   * @generated
   */
  public Adapter createRelationshipAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TraceableSpecification <em>Traceable Specification</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TraceableSpecification
   * @generated
   */
  public Adapter createTraceableSpecificationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Identifiable <em>Identifiable</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Identifiable
   * @generated
   */
  public Adapter createIdentifiableAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Realization_realized <em>Realization realized</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Realization_realized
   * @generated
   */
  public Adapter createRealization_realizedAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Realization_realizedBy <em>Realization realized By</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Realization_realizedBy
   * @generated
   */
  public Adapter createRealization_realizedByAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ArrayDatatype <em>Array Datatype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ArrayDatatype
   * @generated
   */
  public Adapter createArrayDatatypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.CompositeDatatype <em>Composite Datatype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.CompositeDatatype
   * @generated
   */
  public Adapter createCompositeDatatypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EABoolean <em>EA Boolean</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EABoolean
   * @generated
   */
  public Adapter createEABooleanAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EADatatype <em>EA Datatype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EADatatype
   * @generated
   */
  public Adapter createEADatatypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EADatatypePrototype <em>EA Datatype Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EADatatypePrototype
   * @generated
   */
  public Adapter createEADatatypePrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EANumerical <em>EA Numerical</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EANumerical
   * @generated
   */
  public Adapter createEANumericalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAString <em>EA String</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAString
   * @generated
   */
  public Adapter createEAStringAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Enumeration <em>Enumeration</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Enumeration
   * @generated
   */
  public Adapter createEnumerationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EnumerationLiteral <em>Enumeration Literal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EnumerationLiteral
   * @generated
   */
  public Adapter createEnumerationLiteralAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Quantity <em>Quantity</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Quantity
   * @generated
   */
  public Adapter createQuantityAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.RangeableValueType <em>Rangeable Value Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.RangeableValueType
   * @generated
   */
  public Adapter createRangeableValueTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Unit <em>Unit</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Unit
   * @generated
   */
  public Adapter createUnitAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAArrayValue <em>EA Array Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAArrayValue
   * @generated
   */
  public Adapter createEAArrayValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EABooleanValue <em>EA Boolean Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EABooleanValue
   * @generated
   */
  public Adapter createEABooleanValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EACompositeValue <em>EA Composite Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EACompositeValue
   * @generated
   */
  public Adapter createEACompositeValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAEnumerationValue <em>EA Enumeration Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAEnumerationValue
   * @generated
   */
  public Adapter createEAEnumerationValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAExpression <em>EA Expression</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAExpression
   * @generated
   */
  public Adapter createEAExpressionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EANumericalValue <em>EA Numerical Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EANumericalValue
   * @generated
   */
  public Adapter createEANumericalValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAStringValue <em>EA String Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAStringValue
   * @generated
   */
  public Adapter createEAStringValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.EAValue <em>EA Value</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.EAValue
   * @generated
   */
  public Adapter createEAValueAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.UserAttributeDefinition <em>User Attribute Definition</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.UserAttributeDefinition
   * @generated
   */
  public Adapter createUserAttributeDefinitionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.UserAttributedElement <em>User Attributed Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.UserAttributedElement
   * @generated
   */
  public Adapter createUserAttributedElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.UserElementType <em>User Element Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.UserElementType
   * @generated
   */
  public Adapter createUserElementTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute <em>Behavior Constraint Binding Attribute</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute
   * @generated
   */
  public Adapter createBehaviorConstraintBindingAttributeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent <em>Behavior Constraint Binding Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent
   * @generated
   */
  public Adapter createBehaviorConstraintBindingEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding <em>Behavior Constraint Internal Binding</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding
   * @generated
   */
  public Adapter createBehaviorConstraintInternalBindingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintParameter <em>Behavior Constraint Parameter</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintParameter
   * @generated
   */
  public Adapter createBehaviorConstraintParameterAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype <em>Behavior Constraint Prototype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype
   * @generated
   */
  public Adapter createBehaviorConstraintPrototypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding <em>Behavior Constraint Target Binding</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding
   * @generated
   */
  public Adapter createBehaviorConstraintTargetBindingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintType <em>Behavior Constraint Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintType
   * @generated
   */
  public Adapter createBehaviorConstraintTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector <em>Behavior Constraint Internal Binding binding Through Function Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector
   * @generated
   */
  public Adapter createBehaviorConstraintInternalBinding_bindingThroughFunctionConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector <em>Behavior Constraint Internal Binding binding Through Hardware Connector</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector
   * @generated
   */
  public Adapter createBehaviorConstraintInternalBinding_bindingThroughHardwareConnectorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget <em>Behavior Constraint Prototype error Model Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget
   * @generated
   */
  public Adapter createBehaviorConstraintPrototype_errorModelTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget <em>Behavior Constraint Prototype function Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget
   * @generated
   */
  public Adapter createBehaviorConstraintPrototype_functionTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget <em>Behavior Constraint Prototype hardware Component Target</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget
   * @generated
   */
  public Adapter createBehaviorConstraintPrototype_hardwareComponentTargetAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Attribute <em>Attribute</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Attribute
   * @generated
   */
  public Adapter createAttributeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint <em>Attribute Quantification Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint
   * @generated
   */
  public Adapter createAttributeQuantificationConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BehaviorAttributeBinding <em>Behavior Attribute Binding</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BehaviorAttributeBinding
   * @generated
   */
  public Adapter createBehaviorAttributeBindingAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.LogicalEvent <em>Logical Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.LogicalEvent
   * @generated
   */
  public Adapter createLogicalEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Quantification <em>Quantification</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Quantification
   * @generated
   */
  public Adapter createQuantificationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ComputationConstraint <em>Computation Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ComputationConstraint
   * @generated
   */
  public Adapter createComputationConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.LogicalPath <em>Logical Path</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.LogicalPath
   * @generated
   */
  public Adapter createLogicalPathAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.LogicalTransformation <em>Logical Transformation</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.LogicalTransformation
   * @generated
   */
  public Adapter createLogicalTransformationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TransformationOccurrence <em>Transformation Occurrence</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TransformationOccurrence
   * @generated
   */
  public Adapter createTransformationOccurrenceAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.LogicalTimeCondition <em>Logical Time Condition</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.LogicalTimeCondition
   * @generated
   */
  public Adapter createLogicalTimeConditionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.State <em>State</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.State
   * @generated
   */
  public Adapter createStateAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.StateEvent <em>State Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.StateEvent
   * @generated
   */
  public Adapter createStateEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.SynchronousTransition <em>Synchronous Transition</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.SynchronousTransition
   * @generated
   */
  public Adapter createSynchronousTransitionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TemporalConstraint <em>Temporal Constraint</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TemporalConstraint
   * @generated
   */
  public Adapter createTemporalConstraintAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Transition <em>Transition</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Transition
   * @generated
   */
  public Adapter createTransitionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TransitionEvent <em>Transition Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TransitionEvent
   * @generated
   */
  public Adapter createTransitionEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ArchitecturalDescription <em>Architectural Description</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ArchitecturalDescription
   * @generated
   */
  public Adapter createArchitecturalDescriptionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ArchitecturalModel <em>Architectural Model</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ArchitecturalModel
   * @generated
   */
  public Adapter createArchitecturalModelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Architecture <em>Architecture</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Architecture
   * @generated
   */
  public Adapter createArchitectureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Concept <em>Concept</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Concept
   * @generated
   */
  public Adapter createConceptAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Mission <em>Mission</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Mission
   * @generated
   */
  public Adapter createMissionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.VehicleSystem <em>Vehicle System</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.VehicleSystem
   * @generated
   */
  public Adapter createVehicleSystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.Stakeholder <em>Stakeholder</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.Stakeholder
   * @generated
   */
  public Adapter createStakeholderAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.StakeholderNeed <em>Stakeholder Need</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.StakeholderNeed
   * @generated
   */
  public Adapter createStakeholderNeedAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.BusinessOpportunity <em>Business Opportunity</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.BusinessOpportunity
   * @generated
   */
  public Adapter createBusinessOpportunityAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ProblemStatement <em>Problem Statement</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ProblemStatement
   * @generated
   */
  public Adapter createProblemStatementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.ProductPositioning <em>Product Positioning</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.ProductPositioning
   * @generated
   */
  public Adapter createProductPositioningAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.System <em>System</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.System
   * @generated
   */
  public Adapter createSystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.eastadl21.TimingDescriptionEvent <em>Timing Description Event</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.eastadl21.TimingDescriptionEvent
   * @generated
   */
  public Adapter createTimingDescriptionEventAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.geastadl.ginfrastructure.gelements.GReferrable <em>GReferrable</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.geastadl.ginfrastructure.gelements.GReferrable
   * @generated
   */
  public Adapter createGReferrableAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.geastadl.ginfrastructure.gelements.GIdentifiable <em>GIdentifiable</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.geastadl.ginfrastructure.gelements.GIdentifiable
   * @generated
   */
  public Adapter createGIdentifiableAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackageableElement <em>GEA Packageable Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackageableElement
   * @generated
   */
  public Adapter createGEAPackageableElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackage <em>GEA Package</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackage
   * @generated
   */
  public Adapter createGEAPackageAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAXML <em>GEAXML</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAXML
   * @generated
   */
  public Adapter createGEAXMLAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for the default case.
   * <!-- begin-user-doc -->
   * This default implementation returns null.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @generated
   */
  public Adapter createEObjectAdapter()
  {
    return null;
  }

} //Eastadl21AdapterFactory
