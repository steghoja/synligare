/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Refine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Refine is a relationship metaclass, which signifies a dependency relationship between Requirements and EAElements, showing the relationship when a client EAElement refines the supplier Requirement.
 * 
 * Semantics:
 * The Refine metaclass signifies a refined requirement/refined by relationship between a Requirement and an EAElement, where the modification of the supplier Requirement may impact the refining client EAElement. The Refine metaclass implies the semantics that the refining client EAElement is not complete, without the supplier Requirement. 
 * 
 * Constraints:
 * [1] The property refinedBy must not have the types Requirement or RequirementContainer.
 * 
 * Notation:
 * A Refine relationship is shown as a dashed arrow between the Requirements and EAElement. The entity at the tail of the arrow (the refining EAElement) depends on the Requirement at the arrowhead (the refined Requirement).
 * 
 * Extension: specializes UML2 stereotype Refine, which extends Dependency.
 * 
 * Temporary change in the profile (to overcome bug in Eclipse/UML2 concerning standard stereotypes)
 * - added extension towards Dependency
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.Refine</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Refine#getRefinedRequirement <em>Refined Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Refine#getRefinedBy <em>Refined By</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRefine()
 * @model annotation="MetaData guid='{8A15BB72-E787-4520-AA1D-7BC23AC2237E}' id='173' EA\040name='Refine'"
 *        extendedMetaData="name='REFINE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REFINES'"
 * @generated
 */
public interface Refine extends RequirementsRelationship
{
  /**
   * Returns the value of the '<em><b>Refined Requirement</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Refined Requirement</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Refined Requirement</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRefine_RefinedRequirement()
   * @model required="true"
   *        annotation="MetaData guid='{A8C1CAB5-8C93-4940-86D4-732FC166C3A6}' id='97' EA\040name=''"
   *        extendedMetaData="name='REFINED-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REFINED-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getRefinedRequirement();

  /**
   * Returns the value of the '<em><b>Refined By</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Refine_refinedBy}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Refined By</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Refined By</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRefine_RefinedBy()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{5955503B-6141-4c9f-B342-C558D279DC31}' id='-1160537846' EA\040name=''"
   *        annotation="TaggedValues xml.name='REFINED-BY-IREF' xml.namePlural='REFINED-BY-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='REFINED-BY-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REFINED-BY-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Refine_refinedBy> getRefinedBy();

} // Refine
