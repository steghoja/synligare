/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget;
import org.eclipse.eatop.eastadl21.ErrorModelType;
import org.eclipse.eatop.eastadl21.Identifiable;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Error Model Prototype</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ErrorModelPrototypeImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ErrorModelPrototypeImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ErrorModelPrototypeImpl#getFunctionTarget <em>Function Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ErrorModelPrototypeImpl#getHwTarget <em>Hw Target</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ErrorModelPrototypeImpl extends EAElementImpl implements ErrorModelPrototype
{
  /**
   * The cached value of the '{@link #getTarget() <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTarget()
   * @generated
   * @ordered
   */
  protected Identifiable target;

  /**
   * The cached value of the '{@link #getType() <em>Type</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getType()
   * @generated
   * @ordered
   */
  protected ErrorModelType type;

  /**
   * The cached value of the '{@link #getFunctionTarget() <em>Function Target</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFunctionTarget()
   * @generated
   * @ordered
   */
  protected EList<ErrorModelPrototype_functionTarget> functionTarget;

  /**
   * The cached value of the '{@link #getHwTarget() <em>Hw Target</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHwTarget()
   * @generated
   * @ordered
   */
  protected EList<ErrorModelPrototype_hwTarget> hwTarget;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ErrorModelPrototypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getErrorModelPrototype();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Identifiable getTarget()
  {
    if (target != null && target.eIsProxy())
    {
      InternalEObject oldTarget = (InternalEObject)target;
      target = (Identifiable)eResolveProxy(oldTarget);
      if (target != oldTarget)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.ERROR_MODEL_PROTOTYPE__TARGET, oldTarget, target));
      }
    }
    return target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Identifiable basicGetTarget()
  {
    return target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTarget(Identifiable newTarget)
  {
    Identifiable oldTarget = target;
    target = newTarget;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.ERROR_MODEL_PROTOTYPE__TARGET, oldTarget, target));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelType getType()
  {
    if (type != null && type.eIsProxy())
    {
      InternalEObject oldType = (InternalEObject)type;
      type = (ErrorModelType)eResolveProxy(oldType);
      if (type != oldType)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.ERROR_MODEL_PROTOTYPE__TYPE, oldType, type));
      }
    }
    return type;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelType basicGetType()
  {
    return type;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setType(ErrorModelType newType)
  {
    ErrorModelType oldType = type;
    type = newType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.ERROR_MODEL_PROTOTYPE__TYPE, oldType, type));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ErrorModelPrototype_functionTarget> getFunctionTarget()
  {
    if (functionTarget == null)
    {
      functionTarget = new EObjectContainmentEList<ErrorModelPrototype_functionTarget>(ErrorModelPrototype_functionTarget.class, this, Eastadl21Package.ERROR_MODEL_PROTOTYPE__FUNCTION_TARGET);
    }
    return functionTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ErrorModelPrototype_hwTarget> getHwTarget()
  {
    if (hwTarget == null)
    {
      hwTarget = new EObjectContainmentEList<ErrorModelPrototype_hwTarget>(ErrorModelPrototype_hwTarget.class, this, Eastadl21Package.ERROR_MODEL_PROTOTYPE__HW_TARGET);
    }
    return hwTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__FUNCTION_TARGET:
        return ((InternalEList<?>)getFunctionTarget()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__HW_TARGET:
        return ((InternalEList<?>)getHwTarget()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TARGET:
        if (resolve) return getTarget();
        return basicGetTarget();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TYPE:
        if (resolve) return getType();
        return basicGetType();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__FUNCTION_TARGET:
        return getFunctionTarget();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__HW_TARGET:
        return getHwTarget();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TARGET:
   			setTarget((Identifiable)newValue);
        return;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TYPE:
   			setType((ErrorModelType)newValue);
        return;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__FUNCTION_TARGET:
        getFunctionTarget().clear();
        getFunctionTarget().addAll((Collection<? extends ErrorModelPrototype_functionTarget>)newValue);
        return;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__HW_TARGET:
        getHwTarget().clear();
        getHwTarget().addAll((Collection<? extends ErrorModelPrototype_hwTarget>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TARGET:
        	setTarget((Identifiable)null);
        return;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TYPE:
        	setType((ErrorModelType)null);
        return;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__FUNCTION_TARGET:
        getFunctionTarget().clear();
        return;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__HW_TARGET:
        getHwTarget().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TARGET:
        return target != null;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__TYPE:
        return type != null;
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__FUNCTION_TARGET:
        return functionTarget != null && !functionTarget.isEmpty();
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE__HW_TARGET:
        return hwTarget != null && !hwTarget.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ErrorModelPrototypeImpl
