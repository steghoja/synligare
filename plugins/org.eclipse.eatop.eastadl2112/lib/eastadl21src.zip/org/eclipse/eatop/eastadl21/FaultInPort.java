/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault In Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The FaultInPort represents a propagation point for faults that propagate to the containing ErrorModelType. The EADatatype of the FaultInPort defines the range of valid failures.
 * 
 * Constraints:
 * [1] The direction of the nominal port must be 'in'.
 * 
 * Semantics:
 * The value range of a FaultInPort represents faults propagated from a FailureOutPort in another ErrorModel. The value range is defined by the FaultInPort's EADatatype.
 * 
 * If nominal ports HWTarget or FunctionTarget are referenced, the faults on the FaultInPort correspond to data on these nominal ports.
 * 
 * Extension: 
 * UML::Port
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel.FaultInPort</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultInPort()
 * @model annotation="MetaData guid='{9E0DEBB3-60EB-4696-B6F4-1F3D03C80A45}' id='902884008' EA\040name='FaultInPort'"
 *        extendedMetaData="name='FAULT-IN-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-IN-PORTS'"
 * @generated
 */
public interface FaultInPort extends FaultFailurePort
{
} // FaultInPort
