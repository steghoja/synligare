/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Behavior Constraint Prototype error Model Target</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintPrototype_errorModelTargetImpl#getErrorModelPrototype_target <em>Error Model Prototype target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintPrototype_errorModelTargetImpl#getErrorModelPrototype_context <em>Error Model Prototype context</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BehaviorConstraintPrototype_errorModelTargetImpl extends ExtendedEObjectImpl implements BehaviorConstraintPrototype_errorModelTarget
{
  /**
   * The cached value of the '{@link #getErrorModelPrototype_target() <em>Error Model Prototype target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getErrorModelPrototype_target()
   * @generated
   * @ordered
   */
  protected ErrorModelPrototype errorModelPrototype_target;

  /**
   * The cached value of the '{@link #getErrorModelPrototype_context() <em>Error Model Prototype context</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getErrorModelPrototype_context()
   * @generated
   * @ordered
   */
  protected EList<ErrorModelPrototype> errorModelPrototype_context;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BehaviorConstraintPrototype_errorModelTargetImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getBehaviorConstraintPrototype_errorModelTarget();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelPrototype getErrorModelPrototype_target()
  {
    if (errorModelPrototype_target != null && errorModelPrototype_target.eIsProxy())
    {
      InternalEObject oldErrorModelPrototype_target = (InternalEObject)errorModelPrototype_target;
      errorModelPrototype_target = (ErrorModelPrototype)eResolveProxy(oldErrorModelPrototype_target);
      if (errorModelPrototype_target != oldErrorModelPrototype_target)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_TARGET, oldErrorModelPrototype_target, errorModelPrototype_target));
      }
    }
    return errorModelPrototype_target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ErrorModelPrototype basicGetErrorModelPrototype_target()
  {
    return errorModelPrototype_target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setErrorModelPrototype_target(ErrorModelPrototype newErrorModelPrototype_target)
  {
    ErrorModelPrototype oldErrorModelPrototype_target = errorModelPrototype_target;
    errorModelPrototype_target = newErrorModelPrototype_target;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_TARGET, oldErrorModelPrototype_target, errorModelPrototype_target));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ErrorModelPrototype> getErrorModelPrototype_context()
  {
    if (errorModelPrototype_context == null)
    {
      errorModelPrototype_context = new EObjectResolvingEList<ErrorModelPrototype>(ErrorModelPrototype.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_CONTEXT);
    }
    return errorModelPrototype_context;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_TARGET:
        if (resolve) return getErrorModelPrototype_target();
        return basicGetErrorModelPrototype_target();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_CONTEXT:
        return getErrorModelPrototype_context();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_TARGET:
   			setErrorModelPrototype_target((ErrorModelPrototype)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_CONTEXT:
        getErrorModelPrototype_context().clear();
        getErrorModelPrototype_context().addAll((Collection<? extends ErrorModelPrototype>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_TARGET:
        	setErrorModelPrototype_target((ErrorModelPrototype)null);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_CONTEXT:
        getErrorModelPrototype_context().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_TARGET:
        return errorModelPrototype_target != null;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET__ERROR_MODEL_PROTOTYPE_CONTEXT:
        return errorModelPrototype_context != null && !errorModelPrototype_context.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //BehaviorConstraintPrototype_errorModelTargetImpl
