/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Temporal Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Temporal constraints (TemporalConstraint) provide the language support for capturing the concerns relating to discrete behavior, which emphasizes the dependency that a behavior has in regard to its own history and other behaviors on a timeline. They are useful for precisely defining requirements or design solutions.
 * 
 * A temporal constraint consists of a set of states of discrete behavior, a set of occurrences of discrete events, a set of discrete transitions; and a set of time intervals that constitute the logical time basis of discrete behavior
 * 
 * Constraints:
 * [1] A Temporal constraint has a single initial state. 
 * 
 * Semantics:
 * The definition of temporal constraint is based on a generic definition of automata. That is, a temporal constraint is a tuple of: 1. a set of states of discrete behavior; 2. a set of occurrences of discrete events; 3. a set of discrete transitions; and 4.  a set of time intervals that constitute the logical time basis of discrete behavior.
 * 
 * The execution has the following pattern: In one state, read certain parameter, upon certain parameter condition(s) and event occurrence(s), do certain transitions(s) to go to another state. Only one state is active during the operation.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.TemporalConstraint.TemporalConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getAssertion <em>Assertion</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getTimeCondition <em>Time Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getTransitionEvent <em>Transition Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getTransition <em>Transition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getInitState <em>Init State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getState <em>State</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint()
 * @model annotation="MetaData guid='{B8757AB8-DF54-49dc-98D3-4721432645EB}' id='-611526347' EA\040name='TemporalConstraint'"
 *        extendedMetaData="name='TEMPORAL-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TEMPORAL-CONSTRAINTS'"
 * @generated
 */
public interface TemporalConstraint extends EAElement
{
  /**
   * Returns the value of the '<em><b>Assertion</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Assertion</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Assertion</em>' containment reference.
   * @see #setAssertion(EAExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint_Assertion()
   * @model containment="true"
   *        annotation="MetaData guid='{4F7D45CF-C1F9-4b20-8EAC-2003987B5B74}' id='-1312438259' EA\040name=''"
   *        extendedMetaData="name='ASSERTION' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ASSERTIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EAExpression getAssertion();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getAssertion <em>Assertion</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Assertion</em>' containment reference.
   * @see #getAssertion()
   * @generated
   */
  void setAssertion(EAExpression value);

  /**
   * Returns the value of the '<em><b>Time Condition</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.LogicalTimeCondition}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Time Condition</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Time Condition</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint_TimeCondition()
   * @model containment="true"
   *        annotation="MetaData guid='{2BDCE2B3-91BF-41d1-884A-D18D8D104E4F}' id='781115437' EA\040name=''"
   *        extendedMetaData="name='TIME-CONDITION' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIME-CONDITIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<LogicalTimeCondition> getTimeCondition();

  /**
   * Returns the value of the '<em><b>Transition Event</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.TransitionEvent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transition Event</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transition Event</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint_TransitionEvent()
   * @model containment="true"
   *        annotation="MetaData guid='{BFC3B83F-2DD7-47c7-A488-432D01F5188E}' id='-467033947' EA\040name=''"
   *        extendedMetaData="name='TRANSITION-EVENT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRANSITION-EVENTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<TransitionEvent> getTransitionEvent();

  /**
   * Returns the value of the '<em><b>Transition</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Transition}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transition</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transition</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint_Transition()
   * @model containment="true"
   *        annotation="MetaData guid='{AE32075F-AAF0-4b18-8F5D-959BE8C94090}' id='228370613' EA\040name=''"
   *        extendedMetaData="name='TRANSITION' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRANSITIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Transition> getTransition();

  /**
   * Returns the value of the '<em><b>Init State</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Init State</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Init State</em>' reference.
   * @see #setInitState(State)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint_InitState()
   * @model required="true"
   *        annotation="MetaData guid='{9CB945C3-D415-4078-B830-1DC5901D9B04}' id='423055364' EA\040name=''"
   *        extendedMetaData="name='INIT-STATE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INIT-STATE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  State getInitState();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.TemporalConstraint#getInitState <em>Init State</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Init State</em>' reference.
   * @see #getInitState()
   * @generated
   */
  void setInitState(State value);

  /**
   * Returns the value of the '<em><b>State</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.State}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>State</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>State</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTemporalConstraint_State()
   * @model containment="true"
   *        annotation="MetaData guid='{F32B0F7C-818D-4bc5-AFE2-563CC70A43DA}' id='1231872870' EA\040name=''"
   *        extendedMetaData="name='STATE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STATES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<State> getState();

} // TemporalConstraint
