/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.SynchronousTransition;
import org.eclipse.eatop.eastadl21.TransitionEvent;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Synchronous Transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.SynchronousTransitionImpl#getWriteTransitionEvent <em>Write Transition Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.SynchronousTransitionImpl#getReadTransitionEvent <em>Read Transition Event</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SynchronousTransitionImpl extends TransitionImpl implements SynchronousTransition
{
  /**
   * The cached value of the '{@link #getWriteTransitionEvent() <em>Write Transition Event</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWriteTransitionEvent()
   * @generated
   * @ordered
   */
  protected TransitionEvent writeTransitionEvent;

  /**
   * The cached value of the '{@link #getReadTransitionEvent() <em>Read Transition Event</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReadTransitionEvent()
   * @generated
   * @ordered
   */
  protected TransitionEvent readTransitionEvent;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SynchronousTransitionImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getSynchronousTransition();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent getWriteTransitionEvent()
  {
    if (writeTransitionEvent != null && writeTransitionEvent.eIsProxy())
    {
      InternalEObject oldWriteTransitionEvent = (InternalEObject)writeTransitionEvent;
      writeTransitionEvent = (TransitionEvent)eResolveProxy(oldWriteTransitionEvent);
      if (writeTransitionEvent != oldWriteTransitionEvent)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.SYNCHRONOUS_TRANSITION__WRITE_TRANSITION_EVENT, oldWriteTransitionEvent, writeTransitionEvent));
      }
    }
    return writeTransitionEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent basicGetWriteTransitionEvent()
  {
    return writeTransitionEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWriteTransitionEvent(TransitionEvent newWriteTransitionEvent)
  {
    TransitionEvent oldWriteTransitionEvent = writeTransitionEvent;
    writeTransitionEvent = newWriteTransitionEvent;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYNCHRONOUS_TRANSITION__WRITE_TRANSITION_EVENT, oldWriteTransitionEvent, writeTransitionEvent));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent getReadTransitionEvent()
  {
    if (readTransitionEvent != null && readTransitionEvent.eIsProxy())
    {
      InternalEObject oldReadTransitionEvent = (InternalEObject)readTransitionEvent;
      readTransitionEvent = (TransitionEvent)eResolveProxy(oldReadTransitionEvent);
      if (readTransitionEvent != oldReadTransitionEvent)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.SYNCHRONOUS_TRANSITION__READ_TRANSITION_EVENT, oldReadTransitionEvent, readTransitionEvent));
      }
    }
    return readTransitionEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent basicGetReadTransitionEvent()
  {
    return readTransitionEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setReadTransitionEvent(TransitionEvent newReadTransitionEvent)
  {
    TransitionEvent oldReadTransitionEvent = readTransitionEvent;
    readTransitionEvent = newReadTransitionEvent;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYNCHRONOUS_TRANSITION__READ_TRANSITION_EVENT, oldReadTransitionEvent, readTransitionEvent));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__WRITE_TRANSITION_EVENT:
        if (resolve) return getWriteTransitionEvent();
        return basicGetWriteTransitionEvent();
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__READ_TRANSITION_EVENT:
        if (resolve) return getReadTransitionEvent();
        return basicGetReadTransitionEvent();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__WRITE_TRANSITION_EVENT:
   			setWriteTransitionEvent((TransitionEvent)newValue);
        return;
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__READ_TRANSITION_EVENT:
   			setReadTransitionEvent((TransitionEvent)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__WRITE_TRANSITION_EVENT:
        	setWriteTransitionEvent((TransitionEvent)null);
        return;
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__READ_TRANSITION_EVENT:
        	setReadTransitionEvent((TransitionEvent)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__WRITE_TRANSITION_EVENT:
        return writeTransitionEvent != null;
      case Eastadl21Package.SYNCHRONOUS_TRANSITION__READ_TRANSITION_EVENT:
        return readTransitionEvent != null;
    }
    return super.eIsSet(featureID);
  }

} //SynchronousTransitionImpl
