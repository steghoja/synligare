/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Satisfy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Satisfy is a relationship metaclass, which signifies the relationship between a Requirement and an element intended to satisfy the Requirement.
 * 
 * Semantics:
 * The Satisfy metaclass signifies a satisfied requirement/satisfied by relationship between a set of Requirements and a set of satisfying entities, where the modification of the supplier Requirements may impact the satisfying client entities. The Satisfy metaclass implies the semantics that the satisfying client entities are not complete without the supplier Requirement.
 * 
 * Constraints:
 * [1] The EAElement in the association satisfiedBy may not be a Requirement or RequirementContainer.
 * [2] An element of type Satisfy is only allowed to have associations to either elements of type UseCase (see satisfiedUseCase) or elements of type Requirement (see satisfiedRequirement). Not both at the same time!
 * 
 * Notation:
 * A Satisfy relationship is shown as a dashed line with an arrowhead at the end that corresponds to the satisfied Requirement or UseCaseUseCase. The entity at the tail of the arrow (the satisfying EAElement or the satisfying ARElement) depends on the entity at the arrowhead (the satisfied Requirement or UseCaseUseCase).
 * 
 * Extension:
 * To specialize SysML::Satisfy, which extends Realization.
 * 
 * Temporary change in the profile (to overcome Papyrus current limitation):
 * - added extension towards Dependency
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.Satisfy</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Satisfy#getSatisfiedRequirement <em>Satisfied Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Satisfy#getSatisfiedUseCase <em>Satisfied Use Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Satisfy#getSatisfiedBy <em>Satisfied By</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSatisfy()
 * @model annotation="MetaData guid='{C0E72585-F720-4d46-AAC5-616721B3F5D6}' id='174' EA\040name='Satisfy'"
 *        extendedMetaData="name='SATISFY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SATISFYS'"
 * @generated
 */
public interface Satisfy extends RequirementsRelationship
{
  /**
   * Returns the value of the '<em><b>Satisfied Requirement</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Satisfied Requirement</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Satisfied Requirement</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSatisfy_SatisfiedRequirement()
   * @model annotation="MetaData guid='{27E83126-D845-4839-A582-E24E45E45A08}' id='98' EA\040name=''"
   *        extendedMetaData="name='SATISFIED-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SATISFIED-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getSatisfiedRequirement();

  /**
   * Returns the value of the '<em><b>Satisfied Use Case</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.UseCase}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Satisfied Use Case</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Satisfied Use Case</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSatisfy_SatisfiedUseCase()
   * @model annotation="MetaData guid='{76874C9D-BBE3-4098-A17A-D8736C3C81E7}' id='70100593' EA\040name=''"
   *        extendedMetaData="name='SATISFIED-USE-CASE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SATISFIED-USE-CASE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<UseCase> getSatisfiedUseCase();

  /**
   * Returns the value of the '<em><b>Satisfied By</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Satisfied By</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Satisfied By</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSatisfy_SatisfiedBy()
   * @model containment="true"
   *        annotation="MetaData guid='{E4A3C974-22AA-4bda-977F-0086E59B2509}' id='-1624586411' EA\040name=''"
   *        annotation="TaggedValues xml.name='SATISFIED-BY-IREF' xml.namePlural='SATISFIED-BY-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='SATISFIED-BY-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SATISFIED-BY-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Satisfy_satisfiedBy> getSatisfiedBy();

} // Satisfy
