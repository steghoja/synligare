/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirements Link</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * RequirementsLink represents a relation between two or more Requirements. Source and target Requirements of the relation are distinguished, which means that the relation is directed (from source to target). If such a distinction does not make sense, then use a RequirementsRelationGroup instead.
 * 
 * The standard case will be a relation with one source and one target Requirement. However, it is possible to have several source and/or several target Requirements so that general relations can be expressed with instances of this metaclass.
 * 
 * The semantic of a concrete Requirement relation can be provided by the modeler. In particular, three ways are conceivable:
 * 
 * (1) The user attributes of the relation can be used to specify its meaning, for example with a user attribute called "relationType" which is set to values such as "needs" or "excludes".
 * 
 * (2) The UserAttributeElementType can be used. Certain types will be used for certain relation semantics.
 * 
 * (3) RequirementsRelationGroups can be used, i.e. all relations with an "excludes" meaning are put in one relation group and all with a "needs" meaning are put in another.
 * 
 * Semantics:
 * The RequirementsLink defines a relation from a set of source and target requirements. The isBidirectional attribute defines whether the relation is bidirectional. The semantics of the relation is user-defined.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.RequirementsLink</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsLink#getIsBidirectional <em>Is Bidirectional</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsLink#getSource <em>Source</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsLink#getTarget <em>Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsLink()
 * @model annotation="MetaData guid='{A089F8C8-0E6D-428b-9E7E-13F62E85F145}' id='-1485011854' EA\040name='RequirementsLink'"
 *        extendedMetaData="name='REQUIREMENTS-LINK' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-LINKS'"
 * @generated
 */
public interface RequirementsLink extends RequirementsRelationship
{
  /**
   * Returns the value of the '<em><b>Is Bidirectional</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * When set to true, the semantic relation represented by this instance of RequirementRelation does not only apply to the direction from source to target (as always) but also in the opposite direction.
   * 
   * Note that this means that the relation becomes directed in both directions but NOT undirected. To express an undirected association use a RequirementsRelationGroup.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Is Bidirectional</em>' attribute.
   * @see #isSetIsBidirectional()
   * @see #unsetIsBidirectional()
   * @see #setIsBidirectional(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsLink_IsBidirectional()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{0160F6E0-F6F4-433b-BC23-07ECCE9EF0FB}' id='783190000' EA\040name='isBidirectional'"
   *        extendedMetaData="name='IS-BIDIRECTIONAL' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-BIDIRECTIONALS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsBidirectional();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.RequirementsLink#getIsBidirectional <em>Is Bidirectional</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Bidirectional</em>' attribute.
   * @see #isSetIsBidirectional()
   * @see #IsBidirectional()
   * @see #getIsBidirectional()
   * @generated
   */
  void setIsBidirectional(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.RequirementsLink#getIsBidirectional <em>Is Bidirectional</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsBidirectional()
   * @see #getIsBidirectional()
   * @see #setIsBidirectional(Boolean)
   * @generated
   */
  void unsetIsBidirectional();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.RequirementsLink#getIsBidirectional <em>Is Bidirectional</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Bidirectional</em>' attribute is set.
   * @see #IsBidirectional()
   * @see #getIsBidirectional()
   * @see #setIsBidirectional(Boolean)
   * @generated
   */
  boolean isSetIsBidirectional();

  /**
   * Returns the value of the '<em><b>Source</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsLink_Source()
   * @model required="true"
   *        annotation="MetaData guid='{997C8D37-BDBE-47fb-9517-A795C97B05DE}' id='1322222897' EA\040name=''"
   *        extendedMetaData="name='SOURCE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getSource();

  /**
   * Returns the value of the '<em><b>Target</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsLink_Target()
   * @model required="true"
   *        annotation="MetaData guid='{8FF70C9B-DC92-4e30-B5B3-F3C418C926F3}' id='1667526558' EA\040name=''"
   *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getTarget();

} // RequirementsLink
