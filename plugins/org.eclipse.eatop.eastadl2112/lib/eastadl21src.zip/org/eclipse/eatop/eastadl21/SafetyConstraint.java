/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Safety Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The SafetyConstraint metaclass represents the qualitative integrity constraints on a fault or failure. Thus, the system has the same or better performance with respect to the constrained fault or failure, and depending on the role this is either a requirement or a property.
 * 
 * Semantics:
 * A SafetyConstraint defines qualitative bounds on the constrainedFaultFailure in terms of safety integrity level, asilValue.
 * 
 * Depending on role, the SafetyConstraint may define a required or an actual safety integrity level. 
 * 
 * 
 * Extension:
 * (see ADLTraceableSpecification)
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.SafetyConstraints.SafetyConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyConstraint#getAsilValue <em>Asil Value</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyConstraint#getConstrainedFaultFailure <em>Constrained Fault Failure</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyConstraint()
 * @model annotation="MetaData guid='{64159918-9D0B-494e-91EE-4D5B22FCBEEB}' id='-463822280' EA\040name='SafetyConstraint'"
 *        extendedMetaData="name='SAFETY-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-CONSTRAINTS'"
 * @generated
 */
public interface SafetyConstraint extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Asil Value</b></em>' attribute.
   * The default value is <code>"ASIL_A"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.ASILKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The ASIL level of the target fault or failure.
   * 
   * <!-- end-model-doc -->
   * @return the value of the '<em>Asil Value</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ASILKind
   * @see #isSetAsilValue()
   * @see #unsetAsilValue()
   * @see #setAsilValue(ASILKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyConstraint_AsilValue()
   * @model default="ASIL_A" unsettable="true" required="true"
   *        annotation="MetaData guid='{1E6D09DA-4D9C-4523-84A0-3E61C1EC09F9}' id='418788134' EA\040name='asilValue'"
   *        extendedMetaData="name='ASIL-VALUE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ASIL-VALUES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ASILKind getAsilValue();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyConstraint#getAsilValue <em>Asil Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Asil Value</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ASILKind
   * @see #isSetAsilValue()
   * @see #AsilValue()
   * @see #getAsilValue()
   * @generated
   */
  void setAsilValue(ASILKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyConstraint#getAsilValue <em>Asil Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetAsilValue()
   * @see #getAsilValue()
   * @see #setAsilValue(ASILKind)
   * @generated
   */
  void unsetAsilValue();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.SafetyConstraint#getAsilValue <em>Asil Value</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Asil Value</em>' attribute is set.
   * @see #AsilValue()
   * @see #getAsilValue()
   * @see #setAsilValue(ASILKind)
   * @generated
   */
  boolean isSetAsilValue();

  /**
   * Returns the value of the '<em><b>Constrained Fault Failure</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FaultFailure}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Constrained Fault Failure</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Constrained Fault Failure</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyConstraint_ConstrainedFaultFailure()
   * @model required="true"
   *        annotation="MetaData guid='{AE749985-EFF7-4682-A1EE-79D5C68F1A47}' id='616348533' EA\040name=''"
   *        extendedMetaData="name='CONSTRAINED-FAULT-FAILURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINED-FAULT-FAILURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FaultFailure> getConstrainedFaultFailure();

} // SafetyConstraint
