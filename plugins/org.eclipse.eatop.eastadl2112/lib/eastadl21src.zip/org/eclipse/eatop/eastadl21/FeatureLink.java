/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Link</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A FeatureLink resembles a Relationship between two Features referred to as 'start' and 'end' feature (such as "feature S requires feature E" or "S excludes E").
 * 
 * The type of the FeatureLink specifies the precise semantics of the relationship. There are several predefined types, for example "needs" states that S requires E. In addition, user-defined types are allowed as well. For user-defined types, attribute 'customType' provides a unique identifier of the custom link type and attribute 'isBidirectional' states whether the link is uni- or bidirectional.
 * 
 * FeatureLinks are similar to FeatureConstraints but much more restricted. The rationale for having FeatureLinks in addition to FeatureConstraints is that in many cases FeatureLinks are sufficient and tools can deal with them more easily and appropriately (e.g. they can easily be presented visually as arrows in a diagram).
 * 
 * 
 * Semantics:
 * The FeatureLink is a relationship between Features that may constrain the selection of Features involved in the relationship.
 * 
 * 
 * Constraints:
 * [1] The start and end Features of a FeatureLink must be contained in the FeatureModel that contains the FeatureLink.
 * 
 * Extension:
 * AssociationClass
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Structure.FeatureModeling.FeatureLink</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureLink#getCustomType <em>Custom Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureLink#getIsBidirectional <em>Is Bidirectional</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureLink#getKind <em>Kind</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureLink#getEnd <em>End</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureLink#getStart <em>Start</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureLink()
 * @model annotation="MetaData guid='{897045CC-A984-47f5-A3E0-1E4FFDD1A6D5}' id='45' EA\040name='FeatureLink'"
 *        extendedMetaData="name='FEATURE-LINK' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-LINKS'"
 * @generated
 */
public interface FeatureLink extends Relationship
{
  /**
   * Returns the value of the '<em><b>Custom Type</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The custom type of this FeatureLink identified by a String value. This attribute's value is ignored if attribute 'kind' is set to some other value than 'custom'.
   * 
   * Each company or project can decide to use additional link types by defining unique key-words for them. In cases where FeatureModels are shared with third parties (other departments, companies, etc.) a globally unique type string must be used. Follow the instructions for finding globally unique keys for user attributes (cf. documentation of metaclass UserAttributeValue).
   * <!-- end-model-doc -->
   * @return the value of the '<em>Custom Type</em>' attribute.
   * @see #isSetCustomType()
   * @see #unsetCustomType()
   * @see #setCustomType(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureLink_CustomType()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{DBE27DDD-2266-4466-A357-E380E7A6A226}' id='41' EA\040name='customType'"
   *        extendedMetaData="name='CUSTOM-TYPE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CUSTOM-TYPES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getCustomType();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getCustomType <em>Custom Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Custom Type</em>' attribute.
   * @see #isSetCustomType()
   * @see #CustomType()
   * @see #getCustomType()
   * @generated
   */
  void setCustomType(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getCustomType <em>Custom Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetCustomType()
   * @see #getCustomType()
   * @see #setCustomType(String)
   * @generated
   */
  void unsetCustomType();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getCustomType <em>Custom Type</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Custom Type</em>' attribute is set.
   * @see #CustomType()
   * @see #getCustomType()
   * @see #setCustomType(String)
   * @generated
   */
  boolean isSetCustomType();

  /**
   * Returns the value of the '<em><b>Is Bidirectional</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Tells whether the FeatureLink is bidirectional or unidirectional. For predefined kinds, such as "needs", "mandatoryAlternative", etc., this attribute will be ignored and the kind determines whether the link is bidirectional or not (as defined in the documentation of attribute 'type', below). For custom kinds, this attribute may be provided to explicitly state the link's direction. If this attribute is not provided in case of a custom link type, then the link is assumed to be unidirectional.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Is Bidirectional</em>' attribute.
   * @see #isSetIsBidirectional()
   * @see #unsetIsBidirectional()
   * @see #setIsBidirectional(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureLink_IsBidirectional()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean"
   *        annotation="MetaData guid='{EB717DAC-EA54-4ac6-B0D6-9CC3DB328331}' id='39' EA\040name='isBidirectional'"
   *        extendedMetaData="name='IS-BIDIRECTIONAL' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-BIDIRECTIONALS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsBidirectional();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getIsBidirectional <em>Is Bidirectional</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Bidirectional</em>' attribute.
   * @see #isSetIsBidirectional()
   * @see #IsBidirectional()
   * @see #getIsBidirectional()
   * @generated
   */
  void setIsBidirectional(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getIsBidirectional <em>Is Bidirectional</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsBidirectional()
   * @see #getIsBidirectional()
   * @see #setIsBidirectional(Boolean)
   * @generated
   */
  void unsetIsBidirectional();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getIsBidirectional <em>Is Bidirectional</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Bidirectional</em>' attribute is set.
   * @see #IsBidirectional()
   * @see #getIsBidirectional()
   * @see #setIsBidirectional(Boolean)
   * @generated
   */
  boolean isSetIsBidirectional();

  /**
   * Returns the value of the '<em><b>Kind</b></em>' attribute.
   * The default value is <code>"NEEDS"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.VariabilityDependencyKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The kind determines the precise semantics of the relation between the FeatureLink's start and end feature. There are 5 predefined kinds as defined by enumeration VariabilityDependencyKind and in the case of kind 'custom' the attribute customType can be used to define a custom feature link type.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Kind</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.VariabilityDependencyKind
   * @see #isSetKind()
   * @see #unsetKind()
   * @see #setKind(VariabilityDependencyKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureLink_Kind()
   * @model default="NEEDS" unsettable="true" required="true"
   *        annotation="MetaData guid='{114F4EB3-DEDA-45d7-B3B4-1BA0C20AA729}' id='1073905310' EA\040name='kind'"
   *        extendedMetaData="name='KIND' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='KINDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  VariabilityDependencyKind getKind();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getKind <em>Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Kind</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.VariabilityDependencyKind
   * @see #isSetKind()
   * @see #Kind()
   * @see #getKind()
   * @generated
   */
  void setKind(VariabilityDependencyKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getKind <em>Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetKind()
   * @see #getKind()
   * @see #setKind(VariabilityDependencyKind)
   * @generated
   */
  void unsetKind();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getKind <em>Kind</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Kind</em>' attribute is set.
   * @see #Kind()
   * @see #getKind()
   * @see #setKind(VariabilityDependencyKind)
   * @generated
   */
  boolean isSetKind();

  /**
   * Returns the value of the '<em><b>End</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>End</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>End</em>' reference.
   * @see #setEnd(Feature)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureLink_End()
   * @model required="true"
   *        annotation="MetaData guid='{9DAEA9C0-5D89-4a0e-AF26-9F1360711AD4}' id='245' EA\040name=''"
   *        extendedMetaData="name='END-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='END-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Feature getEnd();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getEnd <em>End</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>End</em>' reference.
   * @see #getEnd()
   * @generated
   */
  void setEnd(Feature value);

  /**
   * Returns the value of the '<em><b>Start</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Start</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Start</em>' reference.
   * @see #setStart(Feature)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureLink_Start()
   * @model required="true"
   *        annotation="MetaData guid='{8C4CB765-BD7C-43ed-BAC1-5B91E2A2C904}' id='247' EA\040name=''"
   *        extendedMetaData="name='START-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='START-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Feature getStart();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FeatureLink#getStart <em>Start</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Start</em>' reference.
   * @see #getStart()
   * @generated
   */
  void setStart(Feature value);

} // FeatureLink
