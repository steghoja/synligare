/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.VVActualOutcome;
import org.eclipse.eatop.eastadl21.VVIntendedOutcome;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VV Actual Outcome</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVActualOutcomeImpl#getIntendedOutcome <em>Intended Outcome</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VVActualOutcomeImpl extends TraceableSpecificationImpl implements VVActualOutcome
{
  /**
   * The cached value of the '{@link #getIntendedOutcome() <em>Intended Outcome</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIntendedOutcome()
   * @generated
   * @ordered
   */
  protected VVIntendedOutcome intendedOutcome;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VVActualOutcomeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getVVActualOutcome();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVIntendedOutcome getIntendedOutcome()
  {
    if (intendedOutcome != null && intendedOutcome.eIsProxy())
    {
      InternalEObject oldIntendedOutcome = (InternalEObject)intendedOutcome;
      intendedOutcome = (VVIntendedOutcome)eResolveProxy(oldIntendedOutcome);
      if (intendedOutcome != oldIntendedOutcome)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.VV_ACTUAL_OUTCOME__INTENDED_OUTCOME, oldIntendedOutcome, intendedOutcome));
      }
    }
    return intendedOutcome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVIntendedOutcome basicGetIntendedOutcome()
  {
    return intendedOutcome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIntendedOutcome(VVIntendedOutcome newIntendedOutcome)
  {
    VVIntendedOutcome oldIntendedOutcome = intendedOutcome;
    intendedOutcome = newIntendedOutcome;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.VV_ACTUAL_OUTCOME__INTENDED_OUTCOME, oldIntendedOutcome, intendedOutcome));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_ACTUAL_OUTCOME__INTENDED_OUTCOME:
        if (resolve) return getIntendedOutcome();
        return basicGetIntendedOutcome();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_ACTUAL_OUTCOME__INTENDED_OUTCOME:
   			setIntendedOutcome((VVIntendedOutcome)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_ACTUAL_OUTCOME__INTENDED_OUTCOME:
        	setIntendedOutcome((VVIntendedOutcome)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_ACTUAL_OUTCOME__INTENDED_OUTCOME:
        return intendedOutcome != null;
    }
    return super.eIsSet(featureID);
  }

} //VVActualOutcomeImpl
