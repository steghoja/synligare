/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Fault Failure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Events.EventFaultFailure</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventFaultFailure#getFaultFailure <em>Fault Failure</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFaultFailure()
 * @model annotation="MetaData guid='{407E83C7-E399-4bf8-A6D6-91C2D6896C97}' id='-368329119' EA\040name='EventFaultFailure'"
 *        extendedMetaData="name='EVENT-FAULT-FAILURE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FAULT-FAILURES'"
 * @generated
 */
public interface EventFaultFailure extends Event
{
  /**
   * Returns the value of the '<em><b>Fault Failure</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Fault Failure</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Fault Failure</em>' reference.
   * @see #setFaultFailure(FaultFailure)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFaultFailure_FaultFailure()
   * @model required="true"
   *        annotation="MetaData guid='{90834A9F-A5B3-4d21-92AC-3411CB737492}' id='1184135727' EA\040name=''"
   *        extendedMetaData="name='FAULT-FAILURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FaultFailure getFaultFailure();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.EventFaultFailure#getFaultFailure <em>Fault Failure</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Fault Failure</em>' reference.
   * @see #getFaultFailure()
   * @generated
   */
  void setFaultFailure(FaultFailure value);

} // EventFaultFailure
