/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Feature Flaw</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Events.EventFeatureFlaw</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventFeatureFlaw#getFeatureFlaw <em>Feature Flaw</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFeatureFlaw()
 * @model annotation="MetaData guid='{1D6033F4-A50B-4629-A8E8-E5B6EA1EF8F4}' id='817180535' EA\040name='EventFeatureFlaw'"
 *        extendedMetaData="name='EVENT-FEATURE-FLAW' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FEATURE-FLAWS'"
 * @generated
 */
public interface EventFeatureFlaw extends Event
{
  /**
   * Returns the value of the '<em><b>Feature Flaw</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Feature Flaw</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Feature Flaw</em>' reference.
   * @see #setFeatureFlaw(FeatureFlaw)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFeatureFlaw_FeatureFlaw()
   * @model required="true"
   *        annotation="MetaData guid='{29E2A8E6-092A-4906-821F-BF36C366CD99}' id='-1365265340' EA\040name=''"
   *        extendedMetaData="name='FEATURE-FLAW-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-FLAW-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FeatureFlaw getFeatureFlaw();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.EventFeatureFlaw#getFeatureFlaw <em>Feature Flaw</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Feature Flaw</em>' reference.
   * @see #getFeatureFlaw()
   * @generated
   */
  void setFeatureFlaw(FeatureFlaw value);

} // EventFeatureFlaw
