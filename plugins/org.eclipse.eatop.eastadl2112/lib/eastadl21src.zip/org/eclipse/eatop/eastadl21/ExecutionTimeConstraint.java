/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Execution Time Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An ExecutionTimeConstraint limits the time between the starting and stopping of an executable entity (function), not counting the intervals when the execution of such an executable entity (function) has been interrupted.
 * 
 * Semantics:
 * A system behavior satisfies an ExecutionTimeConstraint c if and only if
 * for each occurrence x of event c.start,
 * 		E is the set of times between x and the next c.stop
 * 		occurrence, excluding the times between any c.preempt
 * 		occurrence and its next c.resume occurrence,
 * and
 * 		c.lower &lt;= length of all continuous intervals in E &lt;= c.upper
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingConstraints.ExecutionTimeConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getResume <em>Resume</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getStart <em>Start</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getPreemption <em>Preemption</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getStop <em>Stop</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint()
 * @model annotation="MetaData guid='{7EA7C40F-0684-4114-9D73-E23A436F02EF}' id='-1194997585' EA\040name='ExecutionTimeConstraint'"
 *        extendedMetaData="name='EXECUTION-TIME-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXECUTION-TIME-CONSTRAINTS'"
 * @generated
 */
public interface ExecutionTimeConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Lower</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lower</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lower</em>' containment reference.
   * @see #setLower(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint_Lower()
   * @model containment="true"
   *        annotation="MetaData guid='{BDF2ABC5-82EE-462d-A5A0-47BB36D324D9}' id='776309340' EA\040name=''"
   *        extendedMetaData="name='LOWER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOWERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getLower();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getLower <em>Lower</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lower</em>' containment reference.
   * @see #getLower()
   * @generated
   */
  void setLower(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Upper</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Upper</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Upper</em>' containment reference.
   * @see #setUpper(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint_Upper()
   * @model containment="true"
   *        annotation="MetaData guid='{7DCB151D-4091-4ba5-BE76-EE443162D7C4}' id='1736964653' EA\040name=''"
   *        extendedMetaData="name='UPPER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='UPPERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getUpper();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getUpper <em>Upper</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Upper</em>' containment reference.
   * @see #getUpper()
   * @generated
   */
  void setUpper(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Resume</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Event}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Resume</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Resume</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint_Resume()
   * @model annotation="MetaData guid='{E9246572-1B57-4a06-873A-20FAC3883828}' id='-2012965641' EA\040name=''"
   *        extendedMetaData="name='RESUME-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='RESUME-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Event> getResume();

  /**
   * Returns the value of the '<em><b>Start</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Start</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Start</em>' reference.
   * @see #setStart(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint_Start()
   * @model required="true"
   *        annotation="MetaData guid='{D7B104D8-C646-4a11-A9D8-3809989297BD}' id='-1318839956' EA\040name=''"
   *        extendedMetaData="name='START-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='START-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getStart();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getStart <em>Start</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Start</em>' reference.
   * @see #getStart()
   * @generated
   */
  void setStart(Event value);

  /**
   * Returns the value of the '<em><b>Preemption</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Event}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Preemption</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Preemption</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint_Preemption()
   * @model annotation="MetaData guid='{39D14CA8-B051-447d-83DE-FB3C7FB38BC4}' id='3912401' EA\040name=''"
   *        extendedMetaData="name='PREEMPTION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PREEMPTION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Event> getPreemption();

  /**
   * Returns the value of the '<em><b>Stop</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Stop</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Stop</em>' reference.
   * @see #setStop(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getExecutionTimeConstraint_Stop()
   * @model required="true"
   *        annotation="MetaData guid='{47BB459C-136C-419c-A684-5006CB0C246C}' id='730453906' EA\040name=''"
   *        extendedMetaData="name='STOP-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STOP-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getStop();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ExecutionTimeConstraint#getStop <em>Stop</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Stop</em>' reference.
   * @see #getStop()
   * @generated
   */
  void setStop(Event value);

} // ExecutionTimeConstraint
