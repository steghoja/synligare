/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The mixed string EAExpression allow for modeling of expressions with references to elements in the model. Specializations within the metamodel define their syntax and the referred metaclasses used in the expressions.
 * 
 * Semantics:
 * Used for modeling of expressions with references to model elements. Different typing of the expression is possible, if e.g. typed by an EABooleanDatatype the evaluated expression results in a boolean value.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Infrastructure.Values.EAExpression</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEAExpression()
 * @model annotation="MetaData guid='{2FCEE92E-A893-4601-AA4D-52CE3A301564}' id='1353499236' EA\040name='EAExpression'"
 *        annotation="Stereotype Stereotype='atpMixedString'"
 *        extendedMetaData="name='EA-EXPRESSION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-EXPRESSIONS'"
 * @generated
 */
public interface EAExpression extends EAValue
{
} // EAExpression
