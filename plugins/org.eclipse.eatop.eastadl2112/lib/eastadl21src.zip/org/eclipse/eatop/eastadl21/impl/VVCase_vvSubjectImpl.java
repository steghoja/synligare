/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Identifiable;
import org.eclipse.eatop.eastadl21.VVCase_vvSubject;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VV Case vv Subject</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCase_vvSubjectImpl#getIdentifiable_context <em>Identifiable context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCase_vvSubjectImpl#getIdentifiable_target <em>Identifiable target</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VVCase_vvSubjectImpl extends ExtendedEObjectImpl implements VVCase_vvSubject
{
  /**
   * The cached value of the '{@link #getIdentifiable_context() <em>Identifiable context</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIdentifiable_context()
   * @generated
   * @ordered
   */
  protected EList<Identifiable> identifiable_context;

  /**
   * The cached value of the '{@link #getIdentifiable_target() <em>Identifiable target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIdentifiable_target()
   * @generated
   * @ordered
   */
  protected Identifiable identifiable_target;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VVCase_vvSubjectImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getVVCase_vvSubject();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Identifiable> getIdentifiable_context()
  {
    if (identifiable_context == null)
    {
      identifiable_context = new EObjectResolvingEList<Identifiable>(Identifiable.class, this, Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_CONTEXT);
    }
    return identifiable_context;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Identifiable getIdentifiable_target()
  {
    if (identifiable_target != null && identifiable_target.eIsProxy())
    {
      InternalEObject oldIdentifiable_target = (InternalEObject)identifiable_target;
      identifiable_target = (Identifiable)eResolveProxy(oldIdentifiable_target);
      if (identifiable_target != oldIdentifiable_target)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_TARGET, oldIdentifiable_target, identifiable_target));
      }
    }
    return identifiable_target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Identifiable basicGetIdentifiable_target()
  {
    return identifiable_target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIdentifiable_target(Identifiable newIdentifiable_target)
  {
    Identifiable oldIdentifiable_target = identifiable_target;
    identifiable_target = newIdentifiable_target;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_TARGET, oldIdentifiable_target, identifiable_target));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_CONTEXT:
        return getIdentifiable_context();
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_TARGET:
        if (resolve) return getIdentifiable_target();
        return basicGetIdentifiable_target();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_CONTEXT:
        getIdentifiable_context().clear();
        getIdentifiable_context().addAll((Collection<? extends Identifiable>)newValue);
        return;
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_TARGET:
   			setIdentifiable_target((Identifiable)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_CONTEXT:
        getIdentifiable_context().clear();
        return;
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_TARGET:
        	setIdentifiable_target((Identifiable)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_CONTEXT:
        return identifiable_context != null && !identifiable_context.isEmpty();
      case Eastadl21Package.VV_CASE_VV_SUBJECT__IDENTIFIABLE_TARGET:
        return identifiable_target != null;
    }
    return super.eIsSet(featureID);
  }

} //VVCase_vvSubjectImpl
