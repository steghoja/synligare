/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Attribute;
import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.LogicalTransformation;
import org.eclipse.eatop.eastadl21.Operation;
import org.eclipse.eatop.eastadl21.Quantification;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Logical Transformation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getIsClientServerInterface <em>Is Client Server Interface</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getExpression <em>Expression</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getIn <em>In</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getClientServerInterfaceOperation <em>Client Server Interface Operation</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getTimeInvariant <em>Time Invariant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getPostCondition <em>Post Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getPreCondition <em>Pre Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getOut <em>Out</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getQuantificationInvariant <em>Quantification Invariant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTransformationImpl#getContained <em>Contained</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class LogicalTransformationImpl extends EAElementImpl implements LogicalTransformation
{
  /**
   * The default value of the '{@link #getIsClientServerInterface() <em>Is Client Server Interface</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsClientServerInterface()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_CLIENT_SERVER_INTERFACE_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsClientServerInterface() <em>Is Client Server Interface</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsClientServerInterface()
   * @generated
   * @ordered
   */
  protected Boolean isClientServerInterface = IS_CLIENT_SERVER_INTERFACE_EDEFAULT;

  /**
   * This is true if the Is Client Server Interface attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isClientServerInterfaceESet;

  /**
   * The cached value of the '{@link #getExpression() <em>Expression</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExpression()
   * @generated
   * @ordered
   */
  protected EAExpression expression;

  /**
   * The cached value of the '{@link #getIn() <em>In</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIn()
   * @generated
   * @ordered
   */
  protected EList<Attribute> in;

  /**
   * The cached value of the '{@link #getClientServerInterfaceOperation() <em>Client Server Interface Operation</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getClientServerInterfaceOperation()
   * @generated
   * @ordered
   */
  protected EList<Operation> clientServerInterfaceOperation;

  /**
   * The cached value of the '{@link #getTimeInvariant() <em>Time Invariant</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTimeInvariant()
   * @generated
   * @ordered
   */
  protected LogicalTimeCondition timeInvariant;

  /**
   * The cached value of the '{@link #getPostCondition() <em>Post Condition</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPostCondition()
   * @generated
   * @ordered
   */
  protected EList<Quantification> postCondition;

  /**
   * The cached value of the '{@link #getPreCondition() <em>Pre Condition</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPreCondition()
   * @generated
   * @ordered
   */
  protected EList<Quantification> preCondition;

  /**
   * The cached value of the '{@link #getOut() <em>Out</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOut()
   * @generated
   * @ordered
   */
  protected EList<Attribute> out;

  /**
   * The cached value of the '{@link #getQuantificationInvariant() <em>Quantification Invariant</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getQuantificationInvariant()
   * @generated
   * @ordered
   */
  protected EList<Quantification> quantificationInvariant;

  /**
   * The cached value of the '{@link #getContained() <em>Contained</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getContained()
   * @generated
   * @ordered
   */
  protected EList<Attribute> contained;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected LogicalTransformationImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getLogicalTransformation();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsClientServerInterface()
  {
    return isClientServerInterface;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsClientServerInterface(Boolean newIsClientServerInterface)
  {
    Boolean oldIsClientServerInterface = isClientServerInterface;
    isClientServerInterface = newIsClientServerInterface;
    boolean oldIsClientServerInterfaceESet = isClientServerInterfaceESet;
    isClientServerInterfaceESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TRANSFORMATION__IS_CLIENT_SERVER_INTERFACE, oldIsClientServerInterface, isClientServerInterface, !oldIsClientServerInterfaceESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsClientServerInterface()
  {
    Boolean oldIsClientServerInterface = isClientServerInterface;
    boolean oldIsClientServerInterfaceESet = isClientServerInterfaceESet;
    isClientServerInterface = IS_CLIENT_SERVER_INTERFACE_EDEFAULT;
    isClientServerInterfaceESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.LOGICAL_TRANSFORMATION__IS_CLIENT_SERVER_INTERFACE, oldIsClientServerInterface, IS_CLIENT_SERVER_INTERFACE_EDEFAULT, oldIsClientServerInterfaceESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsClientServerInterface()
  {
    return isClientServerInterfaceESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAExpression getExpression()
  {
    return expression;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetExpression(EAExpression newExpression, NotificationChain msgs)
  {
    EAExpression oldExpression = expression;
    expression = newExpression;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION, oldExpression, newExpression);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setExpression(EAExpression newExpression)
  {
    if (newExpression != expression)
    {
      NotificationChain msgs = null;
      if (expression != null)
        msgs = ((InternalEObject)expression).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION, null, msgs);
      if (newExpression != null)
        msgs = ((InternalEObject)newExpression).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION, null, msgs);
      msgs = basicSetExpression(newExpression, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION, newExpression, newExpression));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Attribute> getIn()
  {
    if (in == null)
    {
      in = new EObjectResolvingEList<Attribute>(Attribute.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__IN);
    }
    return in;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Operation> getClientServerInterfaceOperation()
  {
    if (clientServerInterfaceOperation == null)
    {
      clientServerInterfaceOperation = new EObjectResolvingEList<Operation>(Operation.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__CLIENT_SERVER_INTERFACE_OPERATION);
    }
    return clientServerInterfaceOperation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition getTimeInvariant()
  {
    if (timeInvariant != null && timeInvariant.eIsProxy())
    {
      InternalEObject oldTimeInvariant = (InternalEObject)timeInvariant;
      timeInvariant = (LogicalTimeCondition)eResolveProxy(oldTimeInvariant);
      if (timeInvariant != oldTimeInvariant)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.LOGICAL_TRANSFORMATION__TIME_INVARIANT, oldTimeInvariant, timeInvariant));
      }
    }
    return timeInvariant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition basicGetTimeInvariant()
  {
    return timeInvariant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTimeInvariant(LogicalTimeCondition newTimeInvariant)
  {
    LogicalTimeCondition oldTimeInvariant = timeInvariant;
    timeInvariant = newTimeInvariant;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TRANSFORMATION__TIME_INVARIANT, oldTimeInvariant, timeInvariant));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Quantification> getPostCondition()
  {
    if (postCondition == null)
    {
      postCondition = new EObjectResolvingEList<Quantification>(Quantification.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__POST_CONDITION);
    }
    return postCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Quantification> getPreCondition()
  {
    if (preCondition == null)
    {
      preCondition = new EObjectResolvingEList<Quantification>(Quantification.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__PRE_CONDITION);
    }
    return preCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Attribute> getOut()
  {
    if (out == null)
    {
      out = new EObjectResolvingEList<Attribute>(Attribute.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__OUT);
    }
    return out;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Quantification> getQuantificationInvariant()
  {
    if (quantificationInvariant == null)
    {
      quantificationInvariant = new EObjectResolvingEList<Quantification>(Quantification.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__QUANTIFICATION_INVARIANT);
    }
    return quantificationInvariant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Attribute> getContained()
  {
    if (contained == null)
    {
      contained = new EObjectResolvingEList<Attribute>(Attribute.class, this, Eastadl21Package.LOGICAL_TRANSFORMATION__CONTAINED);
    }
    return contained;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION:
        return basicSetExpression(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IS_CLIENT_SERVER_INTERFACE:
        return getIsClientServerInterface();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION:
        return getExpression();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IN:
        return getIn();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CLIENT_SERVER_INTERFACE_OPERATION:
        return getClientServerInterfaceOperation();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__TIME_INVARIANT:
        if (resolve) return getTimeInvariant();
        return basicGetTimeInvariant();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__POST_CONDITION:
        return getPostCondition();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__PRE_CONDITION:
        return getPreCondition();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__OUT:
        return getOut();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__QUANTIFICATION_INVARIANT:
        return getQuantificationInvariant();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CONTAINED:
        return getContained();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IS_CLIENT_SERVER_INTERFACE:
   			setIsClientServerInterface((Boolean)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION:
   			setExpression((EAExpression)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IN:
        getIn().clear();
        getIn().addAll((Collection<? extends Attribute>)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CLIENT_SERVER_INTERFACE_OPERATION:
        getClientServerInterfaceOperation().clear();
        getClientServerInterfaceOperation().addAll((Collection<? extends Operation>)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__TIME_INVARIANT:
   			setTimeInvariant((LogicalTimeCondition)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__POST_CONDITION:
        getPostCondition().clear();
        getPostCondition().addAll((Collection<? extends Quantification>)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__PRE_CONDITION:
        getPreCondition().clear();
        getPreCondition().addAll((Collection<? extends Quantification>)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__OUT:
        getOut().clear();
        getOut().addAll((Collection<? extends Attribute>)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__QUANTIFICATION_INVARIANT:
        getQuantificationInvariant().clear();
        getQuantificationInvariant().addAll((Collection<? extends Quantification>)newValue);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CONTAINED:
        getContained().clear();
        getContained().addAll((Collection<? extends Attribute>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IS_CLIENT_SERVER_INTERFACE:
        unsetIsClientServerInterface();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION:
        	setExpression((EAExpression)null);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IN:
        getIn().clear();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CLIENT_SERVER_INTERFACE_OPERATION:
        getClientServerInterfaceOperation().clear();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__TIME_INVARIANT:
        	setTimeInvariant((LogicalTimeCondition)null);
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__POST_CONDITION:
        getPostCondition().clear();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__PRE_CONDITION:
        getPreCondition().clear();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__OUT:
        getOut().clear();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__QUANTIFICATION_INVARIANT:
        getQuantificationInvariant().clear();
        return;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CONTAINED:
        getContained().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IS_CLIENT_SERVER_INTERFACE:
        return isSetIsClientServerInterface();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__EXPRESSION:
        return expression != null;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__IN:
        return in != null && !in.isEmpty();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CLIENT_SERVER_INTERFACE_OPERATION:
        return clientServerInterfaceOperation != null && !clientServerInterfaceOperation.isEmpty();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__TIME_INVARIANT:
        return timeInvariant != null;
      case Eastadl21Package.LOGICAL_TRANSFORMATION__POST_CONDITION:
        return postCondition != null && !postCondition.isEmpty();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__PRE_CONDITION:
        return preCondition != null && !preCondition.isEmpty();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__OUT:
        return out != null && !out.isEmpty();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__QUANTIFICATION_INVARIANT:
        return quantificationInvariant != null && !quantificationInvariant.isEmpty();
      case Eastadl21Package.LOGICAL_TRANSFORMATION__CONTAINED:
        return contained != null && !contained.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (isClientServerInterface: ");
    if (isClientServerInterfaceESet) result.append(isClientServerInterface); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //LogicalTransformationImpl
