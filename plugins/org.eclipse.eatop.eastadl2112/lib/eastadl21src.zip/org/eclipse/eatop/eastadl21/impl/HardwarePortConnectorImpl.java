/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.HardwareBusKind;
import org.eclipse.eatop.eastadl21.HardwareConnector;
import org.eclipse.eatop.eastadl21.HardwarePortConnector;
import org.eclipse.eatop.eastadl21.HardwarePortConnector_port;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hardware Port Connector</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortConnectorImpl#getBusType <em>Bus Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortConnectorImpl#getBusSpeed <em>Bus Speed</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortConnectorImpl#getConnector <em>Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortConnectorImpl#getPort <em>Port</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class HardwarePortConnectorImpl extends AllocationTargetImpl implements HardwarePortConnector
{
  /**
   * The default value of the '{@link #getBusType() <em>Bus Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBusType()
   * @generated
   * @ordered
   */
  protected static final HardwareBusKind BUS_TYPE_EDEFAULT = HardwareBusKind.TIME_TRIGGERED;

  /**
   * The cached value of the '{@link #getBusType() <em>Bus Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBusType()
   * @generated
   * @ordered
   */
  protected HardwareBusKind busType = BUS_TYPE_EDEFAULT;

  /**
   * This is true if the Bus Type attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean busTypeESet;

  /**
   * The default value of the '{@link #getBusSpeed() <em>Bus Speed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBusSpeed()
   * @generated
   * @ordered
   */
  protected static final Double BUS_SPEED_EDEFAULT = new Double(0.0);

  /**
   * The cached value of the '{@link #getBusSpeed() <em>Bus Speed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBusSpeed()
   * @generated
   * @ordered
   */
  protected Double busSpeed = BUS_SPEED_EDEFAULT;

  /**
   * This is true if the Bus Speed attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean busSpeedESet;

  /**
   * The cached value of the '{@link #getConnector() <em>Connector</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConnector()
   * @generated
   * @ordered
   */
  protected EList<HardwareConnector> connector;

  /**
   * The cached value of the '{@link #getPort() <em>Port</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPort()
   * @generated
   * @ordered
   */
  protected EList<HardwarePortConnector_port> port;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected HardwarePortConnectorImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getHardwarePortConnector();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HardwareBusKind getBusType()
  {
    return busType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBusType(HardwareBusKind newBusType)
  {
    HardwareBusKind oldBusType = busType;
    busType = newBusType == null ? BUS_TYPE_EDEFAULT : newBusType;
    boolean oldBusTypeESet = busTypeESet;
    busTypeESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_TYPE, oldBusType, busType, !oldBusTypeESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetBusType()
  {
    HardwareBusKind oldBusType = busType;
    boolean oldBusTypeESet = busTypeESet;
    busType = BUS_TYPE_EDEFAULT;
    busTypeESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_TYPE, oldBusType, BUS_TYPE_EDEFAULT, oldBusTypeESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetBusType()
  {
    return busTypeESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Double getBusSpeed()
  {
    return busSpeed;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBusSpeed(Double newBusSpeed)
  {
    Double oldBusSpeed = busSpeed;
    busSpeed = newBusSpeed;
    boolean oldBusSpeedESet = busSpeedESet;
    busSpeedESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_SPEED, oldBusSpeed, busSpeed, !oldBusSpeedESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetBusSpeed()
  {
    Double oldBusSpeed = busSpeed;
    boolean oldBusSpeedESet = busSpeedESet;
    busSpeed = BUS_SPEED_EDEFAULT;
    busSpeedESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_SPEED, oldBusSpeed, BUS_SPEED_EDEFAULT, oldBusSpeedESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetBusSpeed()
  {
    return busSpeedESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<HardwareConnector> getConnector()
  {
    if (connector == null)
    {
      connector = new EObjectContainmentEList<HardwareConnector>(HardwareConnector.class, this, Eastadl21Package.HARDWARE_PORT_CONNECTOR__CONNECTOR);
    }
    return connector;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<HardwarePortConnector_port> getPort()
  {
    if (port == null)
    {
      port = new EObjectContainmentEList<HardwarePortConnector_port>(HardwarePortConnector_port.class, this, Eastadl21Package.HARDWARE_PORT_CONNECTOR__PORT);
    }
    return port;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__CONNECTOR:
        return ((InternalEList<?>)getConnector()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__PORT:
        return ((InternalEList<?>)getPort()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_TYPE:
        return getBusType();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_SPEED:
        return getBusSpeed();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__CONNECTOR:
        return getConnector();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__PORT:
        return getPort();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_TYPE:
   			setBusType((HardwareBusKind)newValue);
        return;
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_SPEED:
   			setBusSpeed((Double)newValue);
        return;
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__CONNECTOR:
        getConnector().clear();
        getConnector().addAll((Collection<? extends HardwareConnector>)newValue);
        return;
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__PORT:
        getPort().clear();
        getPort().addAll((Collection<? extends HardwarePortConnector_port>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_TYPE:
        unsetBusType();
        return;
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_SPEED:
        unsetBusSpeed();
        return;
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__CONNECTOR:
        getConnector().clear();
        return;
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__PORT:
        getPort().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_TYPE:
        return isSetBusType();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__BUS_SPEED:
        return isSetBusSpeed();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__CONNECTOR:
        return connector != null && !connector.isEmpty();
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR__PORT:
        return port != null && !port.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (busType: ");
    if (busTypeESet) result.append(busType); else result.append("<unset>");
    result.append(", busSpeed: ");
    if (busSpeedESet) result.append(busSpeed); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //HardwarePortConnectorImpl
