/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Synchronous Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * SynchronousTransition denotes a specialization of discrete transitions (Transition) of which the firing can be synchronized by explicit rendezvous events.  
 * 
 * Constraints:
 * [1] For behavior constraint descriptions that target application software functions, SynchronousTransition should not be applied.
 * 
 * Semantics:
 * When all the given guard conditions are met, a transition will be fired to respond to the occurrence of an event (which is indicated by the role readEventOccurrences?) or to signal the occurrence of an event (which is indicated by the role writeEventOccurrance!). A transition, when fired, will lead to the exit of the associated "from" state and an entrance to the associated "to" state, while invoking one or more logical transformations (TransformationOccurrance!) as the effects of the transition.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.TemporalConstraint.SynchronousTransition</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.SynchronousTransition#getWriteTransitionEvent <em>Write Transition Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SynchronousTransition#getReadTransitionEvent <em>Read Transition Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSynchronousTransition()
 * @model annotation="MetaData guid='{A0305E5C-6002-4896-BE2C-1F732C886B9E}' id='1598323055' EA\040name='SynchronousTransition'"
 *        extendedMetaData="name='SYNCHRONOUS-TRANSITION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SYNCHRONOUS-TRANSITIONS'"
 * @generated
 */
public interface SynchronousTransition extends Transition
{
  /**
   * Returns the value of the '<em><b>Write Transition Event</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Write Transition Event</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Write Transition Event</em>' reference.
   * @see #setWriteTransitionEvent(TransitionEvent)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSynchronousTransition_WriteTransitionEvent()
   * @model annotation="MetaData guid='{C99EB391-88B9-4aa9-A693-82A33ACA18BE}' id='-2066641057' EA\040name=''"
   *        extendedMetaData="name='WRITE-TRANSITION-EVENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='WRITE-TRANSITION-EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TransitionEvent getWriteTransitionEvent();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SynchronousTransition#getWriteTransitionEvent <em>Write Transition Event</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Write Transition Event</em>' reference.
   * @see #getWriteTransitionEvent()
   * @generated
   */
  void setWriteTransitionEvent(TransitionEvent value);

  /**
   * Returns the value of the '<em><b>Read Transition Event</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Read Transition Event</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Read Transition Event</em>' reference.
   * @see #setReadTransitionEvent(TransitionEvent)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSynchronousTransition_ReadTransitionEvent()
   * @model annotation="MetaData guid='{FAEDB464-0678-4948-9B36-EC0DF82A29E4}' id='-370821623' EA\040name=''"
   *        extendedMetaData="name='READ-TRANSITION-EVENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='READ-TRANSITION-EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TransitionEvent getReadTransitionEvent();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SynchronousTransition#getReadTransitionEvent <em>Read Transition Event</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Read Transition Event</em>' reference.
   * @see #getReadTransitionEvent()
   * @generated
   */
  void setReadTransitionEvent(TransitionEvent value);

} // SynchronousTransition
