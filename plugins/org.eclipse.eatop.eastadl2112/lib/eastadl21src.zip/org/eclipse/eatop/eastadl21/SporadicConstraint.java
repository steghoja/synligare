/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sporadic Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A SporadicConstraint describes an event that occurs sporadically.
 * 
 * The SporadicConstraint is just an application of the RepetitionConstraint with a default span attribute of 1, combined with an additional requirement that the effective minimum distance between any two occurrences must be at least the value given by minimum (even if lower-jitter would suggest a smaller value).
 * 
 * Semantics:
 * A system behavior satisfies a SporadicConstraint c if and only if
 * the same system behavior concurrently satisfies
 * 
 * RepetitionConstraint { event = c.event,
 * lower = c.lower,
 * upper = c.upper,
 * jitter = c.jitter }
 * 
 * and
 * 
 * RepeatConstraint { event = c.event,
 * lower = c.minimum }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingConstraints.SporadicConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getEvent <em>Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getJitter <em>Jitter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getMinimum <em>Minimum</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSporadicConstraint()
 * @model annotation="MetaData guid='{CB6BAD6B-242F-4022-BF76-458994B55BF1}' id='-1317269058' EA\040name='SporadicConstraint'"
 *        extendedMetaData="name='SPORADIC-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SPORADIC-CONSTRAINTS'"
 * @generated
 */
public interface SporadicConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Event</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Event</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Event</em>' reference.
   * @see #setEvent(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSporadicConstraint_Event()
   * @model required="true"
   *        annotation="MetaData guid='{65004388-E517-4dce-BF98-6DB9217C4372}' id='-1910023819' EA\040name=''"
   *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getEvent();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getEvent <em>Event</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Event</em>' reference.
   * @see #getEvent()
   * @generated
   */
  void setEvent(Event value);

  /**
   * Returns the value of the '<em><b>Jitter</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Jitter</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Jitter</em>' containment reference.
   * @see #setJitter(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSporadicConstraint_Jitter()
   * @model containment="true"
   *        annotation="MetaData guid='{D7B13CD6-CDE9-4914-A466-12CBF7031410}' id='-564613059' EA\040name=''"
   *        extendedMetaData="name='JITTER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='JITTERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getJitter();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getJitter <em>Jitter</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Jitter</em>' containment reference.
   * @see #getJitter()
   * @generated
   */
  void setJitter(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Lower</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lower</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lower</em>' containment reference.
   * @see #setLower(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSporadicConstraint_Lower()
   * @model containment="true"
   *        annotation="MetaData guid='{1D1A3683-32AC-4cad-AD2D-D7147D45F678}' id='305235320' EA\040name=''"
   *        extendedMetaData="name='LOWER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOWERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getLower();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getLower <em>Lower</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lower</em>' containment reference.
   * @see #getLower()
   * @generated
   */
  void setLower(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Upper</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Upper</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Upper</em>' containment reference.
   * @see #setUpper(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSporadicConstraint_Upper()
   * @model containment="true"
   *        annotation="MetaData guid='{860627AA-85AF-4fdc-9848-445242700B06}' id='1647167674' EA\040name=''"
   *        extendedMetaData="name='UPPER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='UPPERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getUpper();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getUpper <em>Upper</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Upper</em>' containment reference.
   * @see #getUpper()
   * @generated
   */
  void setUpper(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Minimum</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Minimum</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Minimum</em>' containment reference.
   * @see #setMinimum(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSporadicConstraint_Minimum()
   * @model containment="true"
   *        annotation="MetaData guid='{578B7BD3-1FFB-4b08-87A5-EBEB33DD5200}' id='1893950643' EA\040name=''"
   *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getMinimum();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SporadicConstraint#getMinimum <em>Minimum</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Minimum</em>' containment reference.
   * @see #getMinimum()
   * @generated
   */
  void setMinimum(TimingExpression value);

} // SporadicConstraint
