/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import org.eclipse.eatop.eastadl21.Eastadl21Package;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 */
public class Eastadl21Factory extends EFactoryImpl implements EFactory {

    public static final Eastadl21Factory eINSTANCE = new Eastadl21Factory();

    /**
    * Returns the value of the '<em><b>EPackage</b></em>' reference.
    */
    @Override
    public EPackage getEPackage()
    {
        if (ePackage == null)
        {
            ePackage = Eastadl21Package.eINSTANCE;
        }
        return ePackage;
    }
  
    /**
    * <!-- begin-user-doc -->
    * Creates a new instance of the class and returns it.
    * Ask the package the list of its classifiers. Given these classifiers, ask their packages what their factories are.
    * @param eClass the class of the new instance.
    * @return a new instance of the class.
    * <!-- end-user-doc -->
    */
    @Override
    public EObject create(EClass eClass)
    {
        EObject result = null;

        if (eClass.eContainer() instanceof EPackage)
        {
            result = ((EPackage) eClass.eContainer()).getEFactoryInstance().create(eClass);
        }
        return result;
    }
  
    public org.eclipse.eatop.eastadl21.VehicleLevel createVehicleLevel() {
        org.eclipse.eatop.eastadl21.VehicleLevel vehicleLevel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVehicleLevel();
        vehicleLevel.setUuid(java.util.UUID.randomUUID().toString());
        return vehicleLevel;
    }
    
    public org.eclipse.eatop.eastadl21.SystemModel createSystemModel() {
        org.eclipse.eatop.eastadl21.SystemModel systemModel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSystemModel();
        systemModel.setUuid(java.util.UUID.randomUUID().toString());
        return systemModel;
    }
    
    public org.eclipse.eatop.eastadl21.AnalysisLevel createAnalysisLevel() {
        org.eclipse.eatop.eastadl21.AnalysisLevel analysisLevel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAnalysisLevel();
        analysisLevel.setUuid(java.util.UUID.randomUUID().toString());
        return analysisLevel;
    }
    
    public org.eclipse.eatop.eastadl21.DesignLevel createDesignLevel() {
        org.eclipse.eatop.eastadl21.DesignLevel designLevel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDesignLevel();
        designLevel.setUuid(java.util.UUID.randomUUID().toString());
        return designLevel;
    }
    
    public org.eclipse.eatop.eastadl21.ImplementationLevel createImplementationLevel() {
        org.eclipse.eatop.eastadl21.ImplementationLevel implementationLevel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createImplementationLevel();
        implementationLevel.setUuid(java.util.UUID.randomUUID().toString());
        return implementationLevel;
    }
    
    public org.eclipse.eatop.eastadl21.BindingTime createBindingTime() {
        org.eclipse.eatop.eastadl21.BindingTime bindingTime = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBindingTime();
        bindingTime.setUuid(java.util.UUID.randomUUID().toString());
        return bindingTime;
    }
    
    public org.eclipse.eatop.eastadl21.Feature createFeature() {
        org.eclipse.eatop.eastadl21.Feature feature = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeature();
        feature.setUuid(java.util.UUID.randomUUID().toString());
        return feature;
    }
    
    public org.eclipse.eatop.eastadl21.FeatureConstraint createFeatureConstraint() {
        org.eclipse.eatop.eastadl21.FeatureConstraint featureConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeatureConstraint();
        featureConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return featureConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.FeatureGroup createFeatureGroup() {
        org.eclipse.eatop.eastadl21.FeatureGroup featureGroup = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeatureGroup();
        featureGroup.setUuid(java.util.UUID.randomUUID().toString());
        return featureGroup;
    }
    
    public org.eclipse.eatop.eastadl21.FeatureLink createFeatureLink() {
        org.eclipse.eatop.eastadl21.FeatureLink featureLink = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeatureLink();
        featureLink.setUuid(java.util.UUID.randomUUID().toString());
        return featureLink;
    }
    
    public org.eclipse.eatop.eastadl21.FeatureModel createFeatureModel() {
        org.eclipse.eatop.eastadl21.FeatureModel featureModel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeatureModel();
        featureModel.setUuid(java.util.UUID.randomUUID().toString());
        return featureModel;
    }
    
    public org.eclipse.eatop.eastadl21.DeviationAttributeSet createDeviationAttributeSet() {
        org.eclipse.eatop.eastadl21.DeviationAttributeSet deviationAttributeSet = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDeviationAttributeSet();
        deviationAttributeSet.setUuid(java.util.UUID.randomUUID().toString());
        return deviationAttributeSet;
    }
    
    public org.eclipse.eatop.eastadl21.VehicleFeature createVehicleFeature() {
        org.eclipse.eatop.eastadl21.VehicleFeature vehicleFeature = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVehicleFeature();
        vehicleFeature.setUuid(java.util.UUID.randomUUID().toString());
        return vehicleFeature;
    }
    
    public org.eclipse.eatop.eastadl21.Allocation createAllocation() {
        org.eclipse.eatop.eastadl21.Allocation allocation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAllocation();
        allocation.setUuid(java.util.UUID.randomUUID().toString());
        return allocation;
    }
    
    public org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype createAnalysisFunctionPrototype() {
        org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype analysisFunctionPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAnalysisFunctionPrototype();
        analysisFunctionPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return analysisFunctionPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.AnalysisFunctionType createAnalysisFunctionType() {
        org.eclipse.eatop.eastadl21.AnalysisFunctionType analysisFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAnalysisFunctionType();
        analysisFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return analysisFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType createBasicSoftwareFunctionType() {
        org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType basicSoftwareFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBasicSoftwareFunctionType();
        basicSoftwareFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return basicSoftwareFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.DesignFunctionPrototype createDesignFunctionPrototype() {
        org.eclipse.eatop.eastadl21.DesignFunctionPrototype designFunctionPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDesignFunctionPrototype();
        designFunctionPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return designFunctionPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.DesignFunctionType createDesignFunctionType() {
        org.eclipse.eatop.eastadl21.DesignFunctionType designFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDesignFunctionType();
        designFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return designFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionalDevice createFunctionalDevice() {
        org.eclipse.eatop.eastadl21.FunctionalDevice functionalDevice = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionalDevice();
        functionalDevice.setUuid(java.util.UUID.randomUUID().toString());
        return functionalDevice;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionAllocation createFunctionAllocation() {
        org.eclipse.eatop.eastadl21.FunctionAllocation functionAllocation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionAllocation();
        functionAllocation.setUuid(java.util.UUID.randomUUID().toString());
        return functionAllocation;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionClientServerInterface createFunctionClientServerInterface() {
        org.eclipse.eatop.eastadl21.FunctionClientServerInterface functionClientServerInterface = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionClientServerInterface();
        functionClientServerInterface.setUuid(java.util.UUID.randomUUID().toString());
        return functionClientServerInterface;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionClientServerPort createFunctionClientServerPort() {
        org.eclipse.eatop.eastadl21.FunctionClientServerPort functionClientServerPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionClientServerPort();
        functionClientServerPort.setUuid(java.util.UUID.randomUUID().toString());
        return functionClientServerPort;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionConnector createFunctionConnector() {
        org.eclipse.eatop.eastadl21.FunctionConnector functionConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionConnector();
        functionConnector.setUuid(java.util.UUID.randomUUID().toString());
        return functionConnector;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionFlowPort createFunctionFlowPort() {
        org.eclipse.eatop.eastadl21.FunctionFlowPort functionFlowPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionFlowPort();
        functionFlowPort.setUuid(java.util.UUID.randomUUID().toString());
        return functionFlowPort;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionPowerPort createFunctionPowerPort() {
        org.eclipse.eatop.eastadl21.FunctionPowerPort functionPowerPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionPowerPort();
        functionPowerPort.setUuid(java.util.UUID.randomUUID().toString());
        return functionPowerPort;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareFunctionType createHardwareFunctionType() {
        org.eclipse.eatop.eastadl21.HardwareFunctionType hardwareFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareFunctionType();
        hardwareFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.LocalDeviceManager createLocalDeviceManager() {
        org.eclipse.eatop.eastadl21.LocalDeviceManager localDeviceManager = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLocalDeviceManager();
        localDeviceManager.setUuid(java.util.UUID.randomUUID().toString());
        return localDeviceManager;
    }
    
    public org.eclipse.eatop.eastadl21.Operation createOperation() {
        org.eclipse.eatop.eastadl21.Operation operation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createOperation();
        operation.setUuid(java.util.UUID.randomUUID().toString());
        return operation;
    }
    
    public org.eclipse.eatop.eastadl21.PortGroup createPortGroup() {
        org.eclipse.eatop.eastadl21.PortGroup portGroup = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPortGroup();
        portGroup.setUuid(java.util.UUID.randomUUID().toString());
        return portGroup;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement createFunctionAllocation_allocatedElement() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionAllocation_allocatedElement();
    }
    
    public org.eclipse.eatop.eastadl21.FunctionAllocation_target createFunctionAllocation_target() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionAllocation_target();
    }
    
    public org.eclipse.eatop.eastadl21.FunctionConnector_port createFunctionConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.Actuator createActuator() {
        org.eclipse.eatop.eastadl21.Actuator actuator = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createActuator();
        actuator.setUuid(java.util.UUID.randomUUID().toString());
        return actuator;
    }
    
    public org.eclipse.eatop.eastadl21.CommunicationHardwarePin createCommunicationHardwarePin() {
        org.eclipse.eatop.eastadl21.CommunicationHardwarePin communicationHardwarePin = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createCommunicationHardwarePin();
        communicationHardwarePin.setUuid(java.util.UUID.randomUUID().toString());
        return communicationHardwarePin;
    }
    
    public org.eclipse.eatop.eastadl21.ElectricalComponent createElectricalComponent() {
        org.eclipse.eatop.eastadl21.ElectricalComponent electricalComponent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createElectricalComponent();
        electricalComponent.setUuid(java.util.UUID.randomUUID().toString());
        return electricalComponent;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareComponentPrototype createHardwareComponentPrototype() {
        org.eclipse.eatop.eastadl21.HardwareComponentPrototype hardwareComponentPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareComponentPrototype();
        hardwareComponentPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareComponentPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareComponentType createHardwareComponentType() {
        org.eclipse.eatop.eastadl21.HardwareComponentType hardwareComponentType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareComponentType();
        hardwareComponentType.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareComponentType;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareConnector createHardwareConnector() {
        org.eclipse.eatop.eastadl21.HardwareConnector hardwareConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareConnector();
        hardwareConnector.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareConnector;
    }
    
    public org.eclipse.eatop.eastadl21.HardwarePort createHardwarePort() {
        org.eclipse.eatop.eastadl21.HardwarePort hardwarePort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwarePort();
        hardwarePort.setUuid(java.util.UUID.randomUUID().toString());
        return hardwarePort;
    }
    
    public org.eclipse.eatop.eastadl21.HardwarePortConnector createHardwarePortConnector() {
        org.eclipse.eatop.eastadl21.HardwarePortConnector hardwarePortConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwarePortConnector();
        hardwarePortConnector.setUuid(java.util.UUID.randomUUID().toString());
        return hardwarePortConnector;
    }
    
    public org.eclipse.eatop.eastadl21.IOHardwarePin createIOHardwarePin() {
        org.eclipse.eatop.eastadl21.IOHardwarePin iOHardwarePin = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createIOHardwarePin();
        iOHardwarePin.setUuid(java.util.UUID.randomUUID().toString());
        return iOHardwarePin;
    }
    
    public org.eclipse.eatop.eastadl21.Node createNode() {
        org.eclipse.eatop.eastadl21.Node node = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createNode();
        node.setUuid(java.util.UUID.randomUUID().toString());
        return node;
    }
    
    public org.eclipse.eatop.eastadl21.PowerHardwarePin createPowerHardwarePin() {
        org.eclipse.eatop.eastadl21.PowerHardwarePin powerHardwarePin = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPowerHardwarePin();
        powerHardwarePin.setUuid(java.util.UUID.randomUUID().toString());
        return powerHardwarePin;
    }
    
    public org.eclipse.eatop.eastadl21.Sensor createSensor() {
        org.eclipse.eatop.eastadl21.Sensor sensor = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSensor();
        sensor.setUuid(java.util.UUID.randomUUID().toString());
        return sensor;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareConnector_port createHardwareConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.HardwarePortConnector_port createHardwarePortConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwarePortConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.ClampConnector createClampConnector() {
        org.eclipse.eatop.eastadl21.ClampConnector clampConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createClampConnector();
        clampConnector.setUuid(java.util.UUID.randomUUID().toString());
        return clampConnector;
    }
    
    public org.eclipse.eatop.eastadl21.Environment createEnvironment() {
        org.eclipse.eatop.eastadl21.Environment environment = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEnvironment();
        environment.setUuid(java.util.UUID.randomUUID().toString());
        return environment;
    }
    
    public org.eclipse.eatop.eastadl21.ClampConnector_port createClampConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createClampConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.Behavior createBehavior() {
        org.eclipse.eatop.eastadl21.Behavior behavior = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehavior();
        behavior.setUuid(java.util.UUID.randomUUID().toString());
        return behavior;
    }
    
    public org.eclipse.eatop.eastadl21.Mode createMode() {
        org.eclipse.eatop.eastadl21.Mode mode = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createMode();
        mode.setUuid(java.util.UUID.randomUUID().toString());
        return mode;
    }
    
    public org.eclipse.eatop.eastadl21.ModeGroup createModeGroup() {
        org.eclipse.eatop.eastadl21.ModeGroup modeGroup = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createModeGroup();
        modeGroup.setUuid(java.util.UUID.randomUUID().toString());
        return modeGroup;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionBehavior createFunctionBehavior() {
        org.eclipse.eatop.eastadl21.FunctionBehavior functionBehavior = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionBehavior();
        functionBehavior.setUuid(java.util.UUID.randomUUID().toString());
        return functionBehavior;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionTrigger createFunctionTrigger() {
        org.eclipse.eatop.eastadl21.FunctionTrigger functionTrigger = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionTrigger();
        functionTrigger.setUuid(java.util.UUID.randomUUID().toString());
        return functionTrigger;
    }
    
    public org.eclipse.eatop.eastadl21.ConfigurableContainer createConfigurableContainer() {
        org.eclipse.eatop.eastadl21.ConfigurableContainer configurableContainer = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createConfigurableContainer();
        configurableContainer.setUuid(java.util.UUID.randomUUID().toString());
        return configurableContainer;
    }
    
    public org.eclipse.eatop.eastadl21.ConfigurationDecision createConfigurationDecision() {
        org.eclipse.eatop.eastadl21.ConfigurationDecision configurationDecision = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createConfigurationDecision();
        configurationDecision.setUuid(java.util.UUID.randomUUID().toString());
        return configurationDecision;
    }
    
    public org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder createConfigurationDecisionFolder() {
        org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder configurationDecisionFolder = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createConfigurationDecisionFolder();
        configurationDecisionFolder.setUuid(java.util.UUID.randomUUID().toString());
        return configurationDecisionFolder;
    }
    
    public org.eclipse.eatop.eastadl21.ContainerConfiguration createContainerConfiguration() {
        org.eclipse.eatop.eastadl21.ContainerConfiguration containerConfiguration = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createContainerConfiguration();
        containerConfiguration.setUuid(java.util.UUID.randomUUID().toString());
        return containerConfiguration;
    }
    
    public org.eclipse.eatop.eastadl21.FeatureConfiguration createFeatureConfiguration() {
        org.eclipse.eatop.eastadl21.FeatureConfiguration featureConfiguration = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeatureConfiguration();
        featureConfiguration.setUuid(java.util.UUID.randomUUID().toString());
        return featureConfiguration;
    }
    
    public org.eclipse.eatop.eastadl21.InternalBinding createInternalBinding() {
        org.eclipse.eatop.eastadl21.InternalBinding internalBinding = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createInternalBinding();
        internalBinding.setUuid(java.util.UUID.randomUUID().toString());
        return internalBinding;
    }
    
    public org.eclipse.eatop.eastadl21.PrivateContent createPrivateContent() {
        org.eclipse.eatop.eastadl21.PrivateContent privateContent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPrivateContent();
        privateContent.setUuid(java.util.UUID.randomUUID().toString());
        return privateContent;
    }
    
    public org.eclipse.eatop.eastadl21.ReuseMetaInformation createReuseMetaInformation() {
        org.eclipse.eatop.eastadl21.ReuseMetaInformation reuseMetaInformation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createReuseMetaInformation();
        reuseMetaInformation.setUuid(java.util.UUID.randomUUID().toString());
        return reuseMetaInformation;
    }
    
    public org.eclipse.eatop.eastadl21.SelectionCriterion createSelectionCriterion() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSelectionCriterion();
    }
    
    public org.eclipse.eatop.eastadl21.Variability createVariability() {
        org.eclipse.eatop.eastadl21.Variability variability = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVariability();
        variability.setUuid(java.util.UUID.randomUUID().toString());
        return variability;
    }
    
    public org.eclipse.eatop.eastadl21.VariableElement createVariableElement() {
        org.eclipse.eatop.eastadl21.VariableElement variableElement = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVariableElement();
        variableElement.setUuid(java.util.UUID.randomUUID().toString());
        return variableElement;
    }
    
    public org.eclipse.eatop.eastadl21.VariationGroup createVariationGroup() {
        org.eclipse.eatop.eastadl21.VariationGroup variationGroup = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVariationGroup();
        variationGroup.setUuid(java.util.UUID.randomUUID().toString());
        return variationGroup;
    }
    
    public org.eclipse.eatop.eastadl21.VehicleLevelBinding createVehicleLevelBinding() {
        org.eclipse.eatop.eastadl21.VehicleLevelBinding vehicleLevelBinding = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVehicleLevelBinding();
        vehicleLevelBinding.setUuid(java.util.UUID.randomUUID().toString());
        return vehicleLevelBinding;
    }
    
    public org.eclipse.eatop.eastadl21.DeriveRequirement createDeriveRequirement() {
        org.eclipse.eatop.eastadl21.DeriveRequirement deriveRequirement = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDeriveRequirement();
        deriveRequirement.setUuid(java.util.UUID.randomUUID().toString());
        return deriveRequirement;
    }
    
    public org.eclipse.eatop.eastadl21.OperationalSituation createOperationalSituation() {
        org.eclipse.eatop.eastadl21.OperationalSituation operationalSituation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createOperationalSituation();
        operationalSituation.setUuid(java.util.UUID.randomUUID().toString());
        return operationalSituation;
    }
    
    public org.eclipse.eatop.eastadl21.RequirementsModel createRequirementsModel() {
        org.eclipse.eatop.eastadl21.RequirementsModel requirementsModel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRequirementsModel();
        requirementsModel.setUuid(java.util.UUID.randomUUID().toString());
        return requirementsModel;
    }
    
    public org.eclipse.eatop.eastadl21.Requirement createRequirement() {
        org.eclipse.eatop.eastadl21.Requirement requirement = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRequirement();
        requirement.setUuid(java.util.UUID.randomUUID().toString());
        return requirement;
    }
    
    public org.eclipse.eatop.eastadl21.RequirementsHierarchy createRequirementsHierarchy() {
        org.eclipse.eatop.eastadl21.RequirementsHierarchy requirementsHierarchy = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRequirementsHierarchy();
        requirementsHierarchy.setUuid(java.util.UUID.randomUUID().toString());
        return requirementsHierarchy;
    }
    
    public org.eclipse.eatop.eastadl21.Refine createRefine() {
        org.eclipse.eatop.eastadl21.Refine refine = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRefine();
        refine.setUuid(java.util.UUID.randomUUID().toString());
        return refine;
    }
    
    public org.eclipse.eatop.eastadl21.Satisfy createSatisfy() {
        org.eclipse.eatop.eastadl21.Satisfy satisfy = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSatisfy();
        satisfy.setUuid(java.util.UUID.randomUUID().toString());
        return satisfy;
    }
    
    public org.eclipse.eatop.eastadl21.RequirementsLink createRequirementsLink() {
        org.eclipse.eatop.eastadl21.RequirementsLink requirementsLink = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRequirementsLink();
        requirementsLink.setUuid(java.util.UUID.randomUUID().toString());
        return requirementsLink;
    }
    
    public org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup createRequirementsRelationshipGroup() {
        org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup requirementsRelationshipGroup = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRequirementsRelationshipGroup();
        requirementsRelationshipGroup.setUuid(java.util.UUID.randomUUID().toString());
        return requirementsRelationshipGroup;
    }
    
    public org.eclipse.eatop.eastadl21.QualityRequirement createQualityRequirement() {
        org.eclipse.eatop.eastadl21.QualityRequirement qualityRequirement = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createQualityRequirement();
        qualityRequirement.setUuid(java.util.UUID.randomUUID().toString());
        return qualityRequirement;
    }
    
    public org.eclipse.eatop.eastadl21.Refine_refinedBy createRefine_refinedBy() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRefine_refinedBy();
    }
    
    public org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy createSatisfy_satisfiedBy() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSatisfy_satisfiedBy();
    }
    
    public org.eclipse.eatop.eastadl21.Actor createActor() {
        org.eclipse.eatop.eastadl21.Actor actor = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createActor();
        actor.setUuid(java.util.UUID.randomUUID().toString());
        return actor;
    }
    
    public org.eclipse.eatop.eastadl21.Extend createExtend() {
        org.eclipse.eatop.eastadl21.Extend extend = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createExtend();
        extend.setUuid(java.util.UUID.randomUUID().toString());
        return extend;
    }
    
    public org.eclipse.eatop.eastadl21.ExtensionPoint createExtensionPoint() {
        org.eclipse.eatop.eastadl21.ExtensionPoint extensionPoint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createExtensionPoint();
        extensionPoint.setUuid(java.util.UUID.randomUUID().toString());
        return extensionPoint;
    }
    
    public org.eclipse.eatop.eastadl21.Include createInclude() {
        org.eclipse.eatop.eastadl21.Include include = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createInclude();
        include.setUuid(java.util.UUID.randomUUID().toString());
        return include;
    }
    
    public org.eclipse.eatop.eastadl21.UseCase createUseCase() {
        org.eclipse.eatop.eastadl21.UseCase useCase = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createUseCase();
        useCase.setUuid(java.util.UUID.randomUUID().toString());
        return useCase;
    }
    
    public org.eclipse.eatop.eastadl21.VerificationValidation createVerificationValidation() {
        org.eclipse.eatop.eastadl21.VerificationValidation verificationValidation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVerificationValidation();
        verificationValidation.setUuid(java.util.UUID.randomUUID().toString());
        return verificationValidation;
    }
    
    public org.eclipse.eatop.eastadl21.Verify createVerify() {
        org.eclipse.eatop.eastadl21.Verify verify = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVerify();
        verify.setUuid(java.util.UUID.randomUUID().toString());
        return verify;
    }
    
    public org.eclipse.eatop.eastadl21.VVActualOutcome createVVActualOutcome() {
        org.eclipse.eatop.eastadl21.VVActualOutcome vVActualOutcome = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVActualOutcome();
        vVActualOutcome.setUuid(java.util.UUID.randomUUID().toString());
        return vVActualOutcome;
    }
    
    public org.eclipse.eatop.eastadl21.VVCase createVVCase() {
        org.eclipse.eatop.eastadl21.VVCase vVCase = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVCase();
        vVCase.setUuid(java.util.UUID.randomUUID().toString());
        return vVCase;
    }
    
    public org.eclipse.eatop.eastadl21.VVIntendedOutcome createVVIntendedOutcome() {
        org.eclipse.eatop.eastadl21.VVIntendedOutcome vVIntendedOutcome = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVIntendedOutcome();
        vVIntendedOutcome.setUuid(java.util.UUID.randomUUID().toString());
        return vVIntendedOutcome;
    }
    
    public org.eclipse.eatop.eastadl21.VVLog createVVLog() {
        org.eclipse.eatop.eastadl21.VVLog vVLog = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVLog();
        vVLog.setUuid(java.util.UUID.randomUUID().toString());
        return vVLog;
    }
    
    public org.eclipse.eatop.eastadl21.VVProcedure createVVProcedure() {
        org.eclipse.eatop.eastadl21.VVProcedure vVProcedure = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVProcedure();
        vVProcedure.setUuid(java.util.UUID.randomUUID().toString());
        return vVProcedure;
    }
    
    public org.eclipse.eatop.eastadl21.VVStimuli createVVStimuli() {
        org.eclipse.eatop.eastadl21.VVStimuli vVStimuli = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVStimuli();
        vVStimuli.setUuid(java.util.UUID.randomUUID().toString());
        return vVStimuli;
    }
    
    public org.eclipse.eatop.eastadl21.VVTarget createVVTarget() {
        org.eclipse.eatop.eastadl21.VVTarget vVTarget = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVTarget();
        vVTarget.setUuid(java.util.UUID.randomUUID().toString());
        return vVTarget;
    }
    
    public org.eclipse.eatop.eastadl21.VVCase_vvSubject createVVCase_vvSubject() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVCase_vvSubject();
    }
    
    public org.eclipse.eatop.eastadl21.VVTarget_element createVVTarget_element() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVVTarget_element();
    }
    
    public org.eclipse.eatop.eastadl21.EventChain createEventChain() {
        org.eclipse.eatop.eastadl21.EventChain eventChain = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventChain();
        eventChain.setUuid(java.util.UUID.randomUUID().toString());
        return eventChain;
    }
    
    public org.eclipse.eatop.eastadl21.PrecedenceConstraint createPrecedenceConstraint() {
        org.eclipse.eatop.eastadl21.PrecedenceConstraint precedenceConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPrecedenceConstraint();
        precedenceConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return precedenceConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.Timing createTiming() {
        org.eclipse.eatop.eastadl21.Timing timing = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTiming();
        timing.setUuid(java.util.UUID.randomUUID().toString());
        return timing;
    }
    
    public org.eclipse.eatop.eastadl21.TimingExpression createTimingExpression() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTimingExpression();
    }
    
    public org.eclipse.eatop.eastadl21.AUTOSAREvent createAUTOSAREvent() {
        org.eclipse.eatop.eastadl21.AUTOSAREvent aUTOSAREvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAUTOSAREvent();
        aUTOSAREvent.setUuid(java.util.UUID.randomUUID().toString());
        return aUTOSAREvent;
    }
    
    public org.eclipse.eatop.eastadl21.EventFaultFailure createEventFaultFailure() {
        org.eclipse.eatop.eastadl21.EventFaultFailure eventFaultFailure = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFaultFailure();
        eventFaultFailure.setUuid(java.util.UUID.randomUUID().toString());
        return eventFaultFailure;
    }
    
    public org.eclipse.eatop.eastadl21.EventFeatureFlaw createEventFeatureFlaw() {
        org.eclipse.eatop.eastadl21.EventFeatureFlaw eventFeatureFlaw = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFeatureFlaw();
        eventFeatureFlaw.setUuid(java.util.UUID.randomUUID().toString());
        return eventFeatureFlaw;
    }
    
    public org.eclipse.eatop.eastadl21.EventFunction createEventFunction() {
        org.eclipse.eatop.eastadl21.EventFunction eventFunction = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFunction();
        eventFunction.setUuid(java.util.UUID.randomUUID().toString());
        return eventFunction;
    }
    
    public org.eclipse.eatop.eastadl21.EventFunctionClientServerPort createEventFunctionClientServerPort() {
        org.eclipse.eatop.eastadl21.EventFunctionClientServerPort eventFunctionClientServerPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFunctionClientServerPort();
        eventFunctionClientServerPort.setUuid(java.util.UUID.randomUUID().toString());
        return eventFunctionClientServerPort;
    }
    
    public org.eclipse.eatop.eastadl21.EventFunctionFlowPort createEventFunctionFlowPort() {
        org.eclipse.eatop.eastadl21.EventFunctionFlowPort eventFunctionFlowPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFunctionFlowPort();
        eventFunctionFlowPort.setUuid(java.util.UUID.randomUUID().toString());
        return eventFunctionFlowPort;
    }
    
    public org.eclipse.eatop.eastadl21.ExternalEvent createExternalEvent() {
        org.eclipse.eatop.eastadl21.ExternalEvent externalEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createExternalEvent();
        externalEvent.setUuid(java.util.UUID.randomUUID().toString());
        return externalEvent;
    }
    
    public org.eclipse.eatop.eastadl21.ModeEvent createModeEvent() {
        org.eclipse.eatop.eastadl21.ModeEvent modeEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createModeEvent();
        modeEvent.setUuid(java.util.UUID.randomUUID().toString());
        return modeEvent;
    }
    
    public org.eclipse.eatop.eastadl21.EventFunction_function createEventFunction_function() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFunction_function();
    }
    
    public org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port createEventFunctionClientServerPort_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFunctionClientServerPort_port();
    }
    
    public org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port createEventFunctionFlowPort_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEventFunctionFlowPort_port();
    }
    
    public org.eclipse.eatop.eastadl21.AgeConstraint createAgeConstraint() {
        org.eclipse.eatop.eastadl21.AgeConstraint ageConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAgeConstraint();
        ageConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return ageConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.ArbitraryConstraint createArbitraryConstraint() {
        org.eclipse.eatop.eastadl21.ArbitraryConstraint arbitraryConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createArbitraryConstraint();
        arbitraryConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return arbitraryConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.BurstConstraint createBurstConstraint() {
        org.eclipse.eatop.eastadl21.BurstConstraint burstConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBurstConstraint();
        burstConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return burstConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.ComparisonConstraint createComparisonConstraint() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createComparisonConstraint();
    }
    
    public org.eclipse.eatop.eastadl21.DelayConstraint createDelayConstraint() {
        org.eclipse.eatop.eastadl21.DelayConstraint delayConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDelayConstraint();
        delayConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return delayConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.ExecutionTimeConstraint createExecutionTimeConstraint() {
        org.eclipse.eatop.eastadl21.ExecutionTimeConstraint executionTimeConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createExecutionTimeConstraint();
        executionTimeConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return executionTimeConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.InputSynchronizationConstraint createInputSynchronizationConstraint() {
        org.eclipse.eatop.eastadl21.InputSynchronizationConstraint inputSynchronizationConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createInputSynchronizationConstraint();
        inputSynchronizationConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return inputSynchronizationConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.OrderConstraint createOrderConstraint() {
        org.eclipse.eatop.eastadl21.OrderConstraint orderConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createOrderConstraint();
        orderConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return orderConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint createOutputSynchronizationConstraint() {
        org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint outputSynchronizationConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createOutputSynchronizationConstraint();
        outputSynchronizationConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return outputSynchronizationConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.PatternConstraint createPatternConstraint() {
        org.eclipse.eatop.eastadl21.PatternConstraint patternConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPatternConstraint();
        patternConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return patternConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.PeriodicConstraint createPeriodicConstraint() {
        org.eclipse.eatop.eastadl21.PeriodicConstraint periodicConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPeriodicConstraint();
        periodicConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return periodicConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.ReactionConstraint createReactionConstraint() {
        org.eclipse.eatop.eastadl21.ReactionConstraint reactionConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createReactionConstraint();
        reactionConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return reactionConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.RepetitionConstraint createRepetitionConstraint() {
        org.eclipse.eatop.eastadl21.RepetitionConstraint repetitionConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRepetitionConstraint();
        repetitionConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return repetitionConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.SporadicConstraint createSporadicConstraint() {
        org.eclipse.eatop.eastadl21.SporadicConstraint sporadicConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSporadicConstraint();
        sporadicConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return sporadicConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.StrongDelayConstraint createStrongDelayConstraint() {
        org.eclipse.eatop.eastadl21.StrongDelayConstraint strongDelayConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createStrongDelayConstraint();
        strongDelayConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return strongDelayConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint createStrongSynchronizationConstraint() {
        org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint strongSynchronizationConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createStrongSynchronizationConstraint();
        strongSynchronizationConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return strongSynchronizationConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.SynchronizationConstraint createSynchronizationConstraint() {
        org.eclipse.eatop.eastadl21.SynchronizationConstraint synchronizationConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSynchronizationConstraint();
        synchronizationConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return synchronizationConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding createPrecedenceConstraint_preceding() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPrecedenceConstraint_preceding();
    }
    
    public org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive createPrecedenceConstraint_successive() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPrecedenceConstraint_successive();
    }
    
    public org.eclipse.eatop.eastadl21.Dependability createDependability() {
        org.eclipse.eatop.eastadl21.Dependability dependability = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDependability();
        dependability.setUuid(java.util.UUID.randomUUID().toString());
        return dependability;
    }
    
    public org.eclipse.eatop.eastadl21.FeatureFlaw createFeatureFlaw() {
        org.eclipse.eatop.eastadl21.FeatureFlaw featureFlaw = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFeatureFlaw();
        featureFlaw.setUuid(java.util.UUID.randomUUID().toString());
        return featureFlaw;
    }
    
    public org.eclipse.eatop.eastadl21.Hazard createHazard() {
        org.eclipse.eatop.eastadl21.Hazard hazard = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHazard();
        hazard.setUuid(java.util.UUID.randomUUID().toString());
        return hazard;
    }
    
    public org.eclipse.eatop.eastadl21.HazardousEvent createHazardousEvent() {
        org.eclipse.eatop.eastadl21.HazardousEvent hazardousEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHazardousEvent();
        hazardousEvent.setUuid(java.util.UUID.randomUUID().toString());
        return hazardousEvent;
    }
    
    public org.eclipse.eatop.eastadl21.Item createItem() {
        org.eclipse.eatop.eastadl21.Item item = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createItem();
        item.setUuid(java.util.UUID.randomUUID().toString());
        return item;
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailure createFaultFailure() {
        org.eclipse.eatop.eastadl21.FaultFailure faultFailure = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailure();
        faultFailure.setUuid(java.util.UUID.randomUUID().toString());
        return faultFailure;
    }
    
    public org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint createQuantitativeSafetyConstraint() {
        org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint quantitativeSafetyConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createQuantitativeSafetyConstraint();
        quantitativeSafetyConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return quantitativeSafetyConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.SafetyConstraint createSafetyConstraint() {
        org.eclipse.eatop.eastadl21.SafetyConstraint safetyConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSafetyConstraint();
        safetyConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return safetyConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailure_anomaly createFaultFailure_anomaly() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailure_anomaly();
    }
    
    public org.eclipse.eatop.eastadl21.ErrorBehavior createErrorBehavior() {
        org.eclipse.eatop.eastadl21.ErrorBehavior errorBehavior = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createErrorBehavior();
        errorBehavior.setUuid(java.util.UUID.randomUUID().toString());
        return errorBehavior;
    }
    
    public org.eclipse.eatop.eastadl21.ErrorModelPrototype createErrorModelPrototype() {
        org.eclipse.eatop.eastadl21.ErrorModelPrototype errorModelPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createErrorModelPrototype();
        errorModelPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return errorModelPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.ErrorModelType createErrorModelType() {
        org.eclipse.eatop.eastadl21.ErrorModelType errorModelType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createErrorModelType();
        errorModelType.setUuid(java.util.UUID.randomUUID().toString());
        return errorModelType;
    }
    
    public org.eclipse.eatop.eastadl21.FailureOutPort createFailureOutPort() {
        org.eclipse.eatop.eastadl21.FailureOutPort failureOutPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFailureOutPort();
        failureOutPort.setUuid(java.util.UUID.randomUUID().toString());
        return failureOutPort;
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailurePropagationLink createFaultFailurePropagationLink() {
        org.eclipse.eatop.eastadl21.FaultFailurePropagationLink faultFailurePropagationLink = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailurePropagationLink();
        faultFailurePropagationLink.setUuid(java.util.UUID.randomUUID().toString());
        return faultFailurePropagationLink;
    }
    
    public org.eclipse.eatop.eastadl21.FaultInPort createFaultInPort() {
        org.eclipse.eatop.eastadl21.FaultInPort faultInPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultInPort();
        faultInPort.setUuid(java.util.UUID.randomUUID().toString());
        return faultInPort;
    }
    
    public org.eclipse.eatop.eastadl21.InternalFaultPrototype createInternalFaultPrototype() {
        org.eclipse.eatop.eastadl21.InternalFaultPrototype internalFaultPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createInternalFaultPrototype();
        internalFaultPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return internalFaultPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.ProcessFaultPrototype createProcessFaultPrototype() {
        org.eclipse.eatop.eastadl21.ProcessFaultPrototype processFaultPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createProcessFaultPrototype();
        processFaultPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return processFaultPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget createErrorModelPrototype_functionTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createErrorModelPrototype_functionTarget();
    }
    
    public org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget createErrorModelPrototype_hwTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createErrorModelPrototype_hwTarget();
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget createFaultFailurePort_functionTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailurePort_functionTarget();
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget createFaultFailurePort_hwTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailurePort_hwTarget();
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort createFaultFailurePropagationLink_fromPort() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailurePropagationLink_fromPort();
    }
    
    public org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort createFaultFailurePropagationLink_toPort() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFaultFailurePropagationLink_toPort();
    }
    
    public org.eclipse.eatop.eastadl21.FunctionalSafetyConcept createFunctionalSafetyConcept() {
        org.eclipse.eatop.eastadl21.FunctionalSafetyConcept functionalSafetyConcept = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionalSafetyConcept();
        functionalSafetyConcept.setUuid(java.util.UUID.randomUUID().toString());
        return functionalSafetyConcept;
    }
    
    public org.eclipse.eatop.eastadl21.SafetyGoal createSafetyGoal() {
        org.eclipse.eatop.eastadl21.SafetyGoal safetyGoal = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSafetyGoal();
        safetyGoal.setUuid(java.util.UUID.randomUUID().toString());
        return safetyGoal;
    }
    
    public org.eclipse.eatop.eastadl21.TechnicalSafetyConcept createTechnicalSafetyConcept() {
        org.eclipse.eatop.eastadl21.TechnicalSafetyConcept technicalSafetyConcept = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTechnicalSafetyConcept();
        technicalSafetyConcept.setUuid(java.util.UUID.randomUUID().toString());
        return technicalSafetyConcept;
    }
    
    public org.eclipse.eatop.eastadl21.Claim createClaim() {
        org.eclipse.eatop.eastadl21.Claim claim = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createClaim();
        claim.setUuid(java.util.UUID.randomUUID().toString());
        return claim;
    }
    
    public org.eclipse.eatop.eastadl21.Ground createGround() {
        org.eclipse.eatop.eastadl21.Ground ground = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createGround();
        ground.setUuid(java.util.UUID.randomUUID().toString());
        return ground;
    }
    
    public org.eclipse.eatop.eastadl21.SafetyCase createSafetyCase() {
        org.eclipse.eatop.eastadl21.SafetyCase safetyCase = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSafetyCase();
        safetyCase.setUuid(java.util.UUID.randomUUID().toString());
        return safetyCase;
    }
    
    public org.eclipse.eatop.eastadl21.Warrant createWarrant() {
        org.eclipse.eatop.eastadl21.Warrant warrant = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createWarrant();
        warrant.setUuid(java.util.UUID.randomUUID().toString());
        return warrant;
    }
    
    public org.eclipse.eatop.eastadl21.GenericConstraint createGenericConstraint() {
        org.eclipse.eatop.eastadl21.GenericConstraint genericConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createGenericConstraint();
        genericConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return genericConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.GenericConstraintSet createGenericConstraintSet() {
        org.eclipse.eatop.eastadl21.GenericConstraintSet genericConstraintSet = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createGenericConstraintSet();
        genericConstraintSet.setUuid(java.util.UUID.randomUUID().toString());
        return genericConstraintSet;
    }
    
    public org.eclipse.eatop.eastadl21.TakeRateConstraint createTakeRateConstraint() {
        org.eclipse.eatop.eastadl21.TakeRateConstraint takeRateConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTakeRateConstraint();
        takeRateConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return takeRateConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.Comment createComment() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createComment();
    }
    
    public org.eclipse.eatop.eastadl21.EAPackage createEAPackage() {
        org.eclipse.eatop.eastadl21.EAPackage eAPackage = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAPackage();
        eAPackage.setUuid(java.util.UUID.randomUUID().toString());
        return eAPackage;
    }
    
    public org.eclipse.eatop.eastadl21.EAXML createEAXML() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAXML();
    }
    
    public org.eclipse.eatop.eastadl21.Rationale createRationale() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRationale();
    }
    
    public org.eclipse.eatop.eastadl21.Realization createRealization() {
        org.eclipse.eatop.eastadl21.Realization realization = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRealization();
        realization.setUuid(java.util.UUID.randomUUID().toString());
        return realization;
    }
    
    public org.eclipse.eatop.eastadl21.Realization_realized createRealization_realized() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRealization_realized();
    }
    
    public org.eclipse.eatop.eastadl21.Realization_realizedBy createRealization_realizedBy() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRealization_realizedBy();
    }
    
    public org.eclipse.eatop.eastadl21.ArrayDatatype createArrayDatatype() {
        org.eclipse.eatop.eastadl21.ArrayDatatype arrayDatatype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createArrayDatatype();
        arrayDatatype.setUuid(java.util.UUID.randomUUID().toString());
        return arrayDatatype;
    }
    
    public org.eclipse.eatop.eastadl21.CompositeDatatype createCompositeDatatype() {
        org.eclipse.eatop.eastadl21.CompositeDatatype compositeDatatype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createCompositeDatatype();
        compositeDatatype.setUuid(java.util.UUID.randomUUID().toString());
        return compositeDatatype;
    }
    
    public org.eclipse.eatop.eastadl21.EABoolean createEABoolean() {
        org.eclipse.eatop.eastadl21.EABoolean eABoolean = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEABoolean();
        eABoolean.setUuid(java.util.UUID.randomUUID().toString());
        return eABoolean;
    }
    
    public org.eclipse.eatop.eastadl21.EADatatypePrototype createEADatatypePrototype() {
        org.eclipse.eatop.eastadl21.EADatatypePrototype eADatatypePrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEADatatypePrototype();
        eADatatypePrototype.setUuid(java.util.UUID.randomUUID().toString());
        return eADatatypePrototype;
    }
    
    public org.eclipse.eatop.eastadl21.EANumerical createEANumerical() {
        org.eclipse.eatop.eastadl21.EANumerical eANumerical = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEANumerical();
        eANumerical.setUuid(java.util.UUID.randomUUID().toString());
        return eANumerical;
    }
    
    public org.eclipse.eatop.eastadl21.EAString createEAString() {
        org.eclipse.eatop.eastadl21.EAString eAString = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAString();
        eAString.setUuid(java.util.UUID.randomUUID().toString());
        return eAString;
    }
    
    public org.eclipse.eatop.eastadl21.Enumeration createEnumeration() {
        org.eclipse.eatop.eastadl21.Enumeration enumeration = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEnumeration();
        enumeration.setUuid(java.util.UUID.randomUUID().toString());
        return enumeration;
    }
    
    public org.eclipse.eatop.eastadl21.EnumerationLiteral createEnumerationLiteral() {
        org.eclipse.eatop.eastadl21.EnumerationLiteral enumerationLiteral = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEnumerationLiteral();
        enumerationLiteral.setUuid(java.util.UUID.randomUUID().toString());
        return enumerationLiteral;
    }
    
    public org.eclipse.eatop.eastadl21.Quantity createQuantity() {
        org.eclipse.eatop.eastadl21.Quantity quantity = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createQuantity();
        quantity.setUuid(java.util.UUID.randomUUID().toString());
        return quantity;
    }
    
    public org.eclipse.eatop.eastadl21.RangeableValueType createRangeableValueType() {
        org.eclipse.eatop.eastadl21.RangeableValueType rangeableValueType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRangeableValueType();
        rangeableValueType.setUuid(java.util.UUID.randomUUID().toString());
        return rangeableValueType;
    }
    
    public org.eclipse.eatop.eastadl21.Unit createUnit() {
        org.eclipse.eatop.eastadl21.Unit unit = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createUnit();
        unit.setUuid(java.util.UUID.randomUUID().toString());
        return unit;
    }
    
    public org.eclipse.eatop.eastadl21.EAArrayValue createEAArrayValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAArrayValue();
    }
    
    public org.eclipse.eatop.eastadl21.EABooleanValue createEABooleanValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEABooleanValue();
    }
    
    public org.eclipse.eatop.eastadl21.EACompositeValue createEACompositeValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEACompositeValue();
    }
    
    public org.eclipse.eatop.eastadl21.EAEnumerationValue createEAEnumerationValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAEnumerationValue();
    }
    
    public org.eclipse.eatop.eastadl21.EAExpression createEAExpression() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAExpression();
    }
    
    public org.eclipse.eatop.eastadl21.EANumericalValue createEANumericalValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEANumericalValue();
    }
    
    public org.eclipse.eatop.eastadl21.EAStringValue createEAStringValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAStringValue();
    }
    
    public org.eclipse.eatop.eastadl21.UserAttributeDefinition createUserAttributeDefinition() {
        org.eclipse.eatop.eastadl21.UserAttributeDefinition userAttributeDefinition = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createUserAttributeDefinition();
        userAttributeDefinition.setUuid(java.util.UUID.randomUUID().toString());
        return userAttributeDefinition;
    }
    
    public org.eclipse.eatop.eastadl21.UserAttributedElement createUserAttributedElement() {
        org.eclipse.eatop.eastadl21.UserAttributedElement userAttributedElement = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createUserAttributedElement();
        userAttributedElement.setUuid(java.util.UUID.randomUUID().toString());
        return userAttributedElement;
    }
    
    public org.eclipse.eatop.eastadl21.UserElementType createUserElementType() {
        org.eclipse.eatop.eastadl21.UserElementType userElementType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createUserElementType();
        userElementType.setUuid(java.util.UUID.randomUUID().toString());
        return userElementType;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute createBehaviorConstraintBindingAttribute() {
        org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute behaviorConstraintBindingAttribute = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintBindingAttribute();
        behaviorConstraintBindingAttribute.setUuid(java.util.UUID.randomUUID().toString());
        return behaviorConstraintBindingAttribute;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent createBehaviorConstraintBindingEvent() {
        org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent behaviorConstraintBindingEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintBindingEvent();
        behaviorConstraintBindingEvent.setUuid(java.util.UUID.randomUUID().toString());
        return behaviorConstraintBindingEvent;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype createBehaviorConstraintPrototype() {
        org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype behaviorConstraintPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintPrototype();
        behaviorConstraintPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return behaviorConstraintPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding createBehaviorConstraintTargetBinding() {
        org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding behaviorConstraintTargetBinding = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintTargetBinding();
        behaviorConstraintTargetBinding.setUuid(java.util.UUID.randomUUID().toString());
        return behaviorConstraintTargetBinding;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintType createBehaviorConstraintType() {
        org.eclipse.eatop.eastadl21.BehaviorConstraintType behaviorConstraintType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintType();
        behaviorConstraintType.setUuid(java.util.UUID.randomUUID().toString());
        return behaviorConstraintType;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector();
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector();
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget createBehaviorConstraintPrototype_errorModelTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintPrototype_errorModelTarget();
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget createBehaviorConstraintPrototype_functionTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintPrototype_functionTarget();
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget createBehaviorConstraintPrototype_hardwareComponentTarget() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorConstraintPrototype_hardwareComponentTarget();
    }
    
    public org.eclipse.eatop.eastadl21.Attribute createAttribute() {
        org.eclipse.eatop.eastadl21.Attribute attribute = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAttribute();
        attribute.setUuid(java.util.UUID.randomUUID().toString());
        return attribute;
    }
    
    public org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint createAttributeQuantificationConstraint() {
        org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint attributeQuantificationConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAttributeQuantificationConstraint();
        attributeQuantificationConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return attributeQuantificationConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.BehaviorAttributeBinding createBehaviorAttributeBinding() {
        org.eclipse.eatop.eastadl21.BehaviorAttributeBinding behaviorAttributeBinding = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBehaviorAttributeBinding();
        behaviorAttributeBinding.setUuid(java.util.UUID.randomUUID().toString());
        return behaviorAttributeBinding;
    }
    
    public org.eclipse.eatop.eastadl21.LogicalEvent createLogicalEvent() {
        org.eclipse.eatop.eastadl21.LogicalEvent logicalEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLogicalEvent();
        logicalEvent.setUuid(java.util.UUID.randomUUID().toString());
        return logicalEvent;
    }
    
    public org.eclipse.eatop.eastadl21.Quantification createQuantification() {
        org.eclipse.eatop.eastadl21.Quantification quantification = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createQuantification();
        quantification.setUuid(java.util.UUID.randomUUID().toString());
        return quantification;
    }
    
    public org.eclipse.eatop.eastadl21.ComputationConstraint createComputationConstraint() {
        org.eclipse.eatop.eastadl21.ComputationConstraint computationConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createComputationConstraint();
        computationConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return computationConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.LogicalPath createLogicalPath() {
        org.eclipse.eatop.eastadl21.LogicalPath logicalPath = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLogicalPath();
        logicalPath.setUuid(java.util.UUID.randomUUID().toString());
        return logicalPath;
    }
    
    public org.eclipse.eatop.eastadl21.LogicalTransformation createLogicalTransformation() {
        org.eclipse.eatop.eastadl21.LogicalTransformation logicalTransformation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLogicalTransformation();
        logicalTransformation.setUuid(java.util.UUID.randomUUID().toString());
        return logicalTransformation;
    }
    
    public org.eclipse.eatop.eastadl21.TransformationOccurrence createTransformationOccurrence() {
        org.eclipse.eatop.eastadl21.TransformationOccurrence transformationOccurrence = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTransformationOccurrence();
        transformationOccurrence.setUuid(java.util.UUID.randomUUID().toString());
        return transformationOccurrence;
    }
    
    public org.eclipse.eatop.eastadl21.LogicalTimeCondition createLogicalTimeCondition() {
        org.eclipse.eatop.eastadl21.LogicalTimeCondition logicalTimeCondition = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLogicalTimeCondition();
        logicalTimeCondition.setUuid(java.util.UUID.randomUUID().toString());
        return logicalTimeCondition;
    }
    
    public org.eclipse.eatop.eastadl21.State createState() {
        org.eclipse.eatop.eastadl21.State state = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createState();
        state.setUuid(java.util.UUID.randomUUID().toString());
        return state;
    }
    
    public org.eclipse.eatop.eastadl21.StateEvent createStateEvent() {
        org.eclipse.eatop.eastadl21.StateEvent stateEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createStateEvent();
        stateEvent.setUuid(java.util.UUID.randomUUID().toString());
        return stateEvent;
    }
    
    public org.eclipse.eatop.eastadl21.SynchronousTransition createSynchronousTransition() {
        org.eclipse.eatop.eastadl21.SynchronousTransition synchronousTransition = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSynchronousTransition();
        synchronousTransition.setUuid(java.util.UUID.randomUUID().toString());
        return synchronousTransition;
    }
    
    public org.eclipse.eatop.eastadl21.TemporalConstraint createTemporalConstraint() {
        org.eclipse.eatop.eastadl21.TemporalConstraint temporalConstraint = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTemporalConstraint();
        temporalConstraint.setUuid(java.util.UUID.randomUUID().toString());
        return temporalConstraint;
    }
    
    public org.eclipse.eatop.eastadl21.Transition createTransition() {
        org.eclipse.eatop.eastadl21.Transition transition = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTransition();
        transition.setUuid(java.util.UUID.randomUUID().toString());
        return transition;
    }
    
    public org.eclipse.eatop.eastadl21.TransitionEvent createTransitionEvent() {
        org.eclipse.eatop.eastadl21.TransitionEvent transitionEvent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createTransitionEvent();
        transitionEvent.setUuid(java.util.UUID.randomUUID().toString());
        return transitionEvent;
    }
    
    public org.eclipse.eatop.eastadl21.ArchitecturalDescription createArchitecturalDescription() {
        org.eclipse.eatop.eastadl21.ArchitecturalDescription architecturalDescription = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createArchitecturalDescription();
        architecturalDescription.setUuid(java.util.UUID.randomUUID().toString());
        return architecturalDescription;
    }
    
    public org.eclipse.eatop.eastadl21.ArchitecturalModel createArchitecturalModel() {
        org.eclipse.eatop.eastadl21.ArchitecturalModel architecturalModel = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createArchitecturalModel();
        architecturalModel.setUuid(java.util.UUID.randomUUID().toString());
        return architecturalModel;
    }
    
    public org.eclipse.eatop.eastadl21.Architecture createArchitecture() {
        org.eclipse.eatop.eastadl21.Architecture architecture = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createArchitecture();
        architecture.setUuid(java.util.UUID.randomUUID().toString());
        return architecture;
    }
    
    public org.eclipse.eatop.eastadl21.Mission createMission() {
        org.eclipse.eatop.eastadl21.Mission mission = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createMission();
        mission.setUuid(java.util.UUID.randomUUID().toString());
        return mission;
    }
    
    public org.eclipse.eatop.eastadl21.VehicleSystem createVehicleSystem() {
        org.eclipse.eatop.eastadl21.VehicleSystem vehicleSystem = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createVehicleSystem();
        vehicleSystem.setUuid(java.util.UUID.randomUUID().toString());
        return vehicleSystem;
    }
    
    public org.eclipse.eatop.eastadl21.Stakeholder createStakeholder() {
        org.eclipse.eatop.eastadl21.Stakeholder stakeholder = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createStakeholder();
        stakeholder.setUuid(java.util.UUID.randomUUID().toString());
        return stakeholder;
    }
    
    public org.eclipse.eatop.eastadl21.StakeholderNeed createStakeholderNeed() {
        org.eclipse.eatop.eastadl21.StakeholderNeed stakeholderNeed = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createStakeholderNeed();
        stakeholderNeed.setUuid(java.util.UUID.randomUUID().toString());
        return stakeholderNeed;
    }
    
    public org.eclipse.eatop.eastadl21.BusinessOpportunity createBusinessOpportunity() {
        org.eclipse.eatop.eastadl21.BusinessOpportunity businessOpportunity = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBusinessOpportunity();
        businessOpportunity.setUuid(java.util.UUID.randomUUID().toString());
        return businessOpportunity;
    }
    
    public org.eclipse.eatop.eastadl21.ProblemStatement createProblemStatement() {
        org.eclipse.eatop.eastadl21.ProblemStatement problemStatement = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createProblemStatement();
        problemStatement.setUuid(java.util.UUID.randomUUID().toString());
        return problemStatement;
    }
    
    public org.eclipse.eatop.eastadl21.ProductPositioning createProductPositioning() {
        org.eclipse.eatop.eastadl21.ProductPositioning productPositioning = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createProductPositioning();
        productPositioning.setUuid(java.util.UUID.randomUUID().toString());
        return productPositioning;
    }
    
    public org.eclipse.eatop.eastadl21.System createSystem() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSystem();
    }
    
}