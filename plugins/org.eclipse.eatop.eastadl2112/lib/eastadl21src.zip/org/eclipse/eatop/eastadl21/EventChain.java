/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Chain</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An EventChain is a container for a pair of events that must be causally related.
 * 
 * Semantics:
 * A system behavior is consistent with respect to an event chain ec if and only if
 * for each occurrence x in ec.stimulus,
 * 		for each occurrence y in ec.response,
 * 			if x.color = y.color then x &lt; y
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.EventChain</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventChain#getSegment <em>Segment</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventChain#getStimulus <em>Stimulus</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventChain#getResponse <em>Response</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventChain()
 * @model annotation="MetaData guid='{32948665-DA74-417b-A9D9-EF33B768A1C5}' id='-1637507082' EA\040name='EventChain'"
 *        extendedMetaData="name='EVENT-CHAIN' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-CHAINS'"
 * @generated
 */
public interface EventChain extends TimingDescription
{
  /**
   * Returns the value of the '<em><b>Segment</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.EventChain}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Segment</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Segment</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventChain_Segment()
   * @model annotation="MetaData guid='{72BA3227-9BA3-4b44-B322-C3C1C3937ADB}' id='-2014890775' EA\040name=''"
   *        extendedMetaData="name='SEGMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SEGMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<EventChain> getSegment();

  /**
   * Returns the value of the '<em><b>Stimulus</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Stimulus</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Stimulus</em>' reference.
   * @see #setStimulus(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventChain_Stimulus()
   * @model required="true"
   *        annotation="MetaData guid='{2419A89A-AA86-43bc-8FEF-5340CF382F78}' id='-86378137' EA\040name=''"
   *        extendedMetaData="name='STIMULUS-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STIMULUS-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getStimulus();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.EventChain#getStimulus <em>Stimulus</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Stimulus</em>' reference.
   * @see #getStimulus()
   * @generated
   */
  void setStimulus(Event value);

  /**
   * Returns the value of the '<em><b>Response</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Response</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Response</em>' reference.
   * @see #setResponse(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventChain_Response()
   * @model required="true"
   *        annotation="MetaData guid='{343DB3F7-D96F-40f2-A552-92D564BACE40}' id='208024766' EA\040name=''"
   *        extendedMetaData="name='RESPONSE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='RESPONSE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getResponse();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.EventChain#getResponse <em>Response</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Response</em>' reference.
   * @see #getResponse()
   * @generated
   */
  void setResponse(Event value);

} // EventChain
