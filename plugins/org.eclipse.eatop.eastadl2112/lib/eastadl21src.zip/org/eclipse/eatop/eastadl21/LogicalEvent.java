/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Logical Event is the modeling construct for the declarations of the value conditions that, when fulfilled, may trigger state transitions. If a logical event is externally visible (isExternVisible == true), it is disseminated through function ports.
 * 
 * Constraints:
 * see Quantification.
 * 
 * Semantics:
 * see Quantification.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.AttributeQuantificationConstraint.LogicalEvent</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.LogicalEvent#getIsExternVisible <em>Is Extern Visible</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.LogicalEvent#getVisibleThroughFunctionPort <em>Visible Through Function Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getLogicalEvent()
 * @model annotation="MetaData guid='{92B0F679-108F-447a-B0A0-344AC902E290}' id='-1883649853' EA\040name='LogicalEvent'"
 *        extendedMetaData="name='LOGICAL-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-EVENTS'"
 * @generated
 */
public interface LogicalEvent extends Quantification
{
  /**
   * Returns the value of the '<em><b>Is Extern Visible</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Is Extern Visible</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Is Extern Visible</em>' attribute.
   * @see #isSetIsExternVisible()
   * @see #unsetIsExternVisible()
   * @see #setIsExternVisible(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getLogicalEvent_IsExternVisible()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{CC14EF6B-71D3-45fe-B8BA-072581656585}' id='-809010104' EA\040name='isExternVisible'"
   *        extendedMetaData="name='IS-EXTERN-VISIBLE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-EXTERN-VISIBLES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsExternVisible();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.LogicalEvent#getIsExternVisible <em>Is Extern Visible</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Extern Visible</em>' attribute.
   * @see #isSetIsExternVisible()
   * @see #IsExternVisible()
   * @see #getIsExternVisible()
   * @generated
   */
  void setIsExternVisible(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.LogicalEvent#getIsExternVisible <em>Is Extern Visible</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsExternVisible()
   * @see #getIsExternVisible()
   * @see #setIsExternVisible(Boolean)
   * @generated
   */
  void unsetIsExternVisible();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.LogicalEvent#getIsExternVisible <em>Is Extern Visible</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Extern Visible</em>' attribute is set.
   * @see #IsExternVisible()
   * @see #getIsExternVisible()
   * @see #setIsExternVisible(Boolean)
   * @generated
   */
  boolean isSetIsExternVisible();

  /**
   * Returns the value of the '<em><b>Visible Through Function Port</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FunctionPort}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Visible Through Function Port</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Visible Through Function Port</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getLogicalEvent_VisibleThroughFunctionPort()
   * @model annotation="MetaData guid='{C88EB0F7-AE8C-4679-8113-8F26998E5565}' id='1591933145' EA\040name=''"
   *        extendedMetaData="name='VISIBLE-THROUGH-FUNCTION-PORT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VISIBLE-THROUGH-FUNCTION-PORT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FunctionPort> getVisibleThroughFunctionPort();

} // LogicalEvent
