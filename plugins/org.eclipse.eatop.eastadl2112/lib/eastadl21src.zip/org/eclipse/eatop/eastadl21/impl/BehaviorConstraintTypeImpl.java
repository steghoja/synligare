/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintParameter;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype;
import org.eclipse.eatop.eastadl21.BehaviorConstraintType;
import org.eclipse.eatop.eastadl21.ComputationConstraint;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.TemporalConstraint;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Behavior Constraint Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTypeImpl#getInterfaceVariable <em>Interface Variable</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTypeImpl#getSharedVariable <em>Shared Variable</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTypeImpl#getPart <em>Part</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTypeImpl#getAttributeQuantificationConstraint <em>Attribute Quantification Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTypeImpl#getComputationConstraint <em>Computation Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTypeImpl#getTemporalConstraint <em>Temporal Constraint</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BehaviorConstraintTypeImpl extends ContextImpl implements BehaviorConstraintType
{
  /**
   * The cached value of the '{@link #getInterfaceVariable() <em>Interface Variable</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInterfaceVariable()
   * @generated
   * @ordered
   */
  protected EList<BehaviorConstraintParameter> interfaceVariable;

  /**
   * The cached value of the '{@link #getSharedVariable() <em>Shared Variable</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSharedVariable()
   * @generated
   * @ordered
   */
  protected EList<BehaviorConstraintInternalBinding> sharedVariable;

  /**
   * The cached value of the '{@link #getPart() <em>Part</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPart()
   * @generated
   * @ordered
   */
  protected EList<BehaviorConstraintPrototype> part;

  /**
   * The cached value of the '{@link #getAttributeQuantificationConstraint() <em>Attribute Quantification Constraint</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAttributeQuantificationConstraint()
   * @generated
   * @ordered
   */
  protected EList<AttributeQuantificationConstraint> attributeQuantificationConstraint;

  /**
   * The cached value of the '{@link #getComputationConstraint() <em>Computation Constraint</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getComputationConstraint()
   * @generated
   * @ordered
   */
  protected EList<ComputationConstraint> computationConstraint;

  /**
   * The cached value of the '{@link #getTemporalConstraint() <em>Temporal Constraint</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTemporalConstraint()
   * @generated
   * @ordered
   */
  protected EList<TemporalConstraint> temporalConstraint;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BehaviorConstraintTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getBehaviorConstraintType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<BehaviorConstraintParameter> getInterfaceVariable()
  {
    if (interfaceVariable == null)
    {
      interfaceVariable = new EObjectResolvingEList<BehaviorConstraintParameter>(BehaviorConstraintParameter.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__INTERFACE_VARIABLE);
    }
    return interfaceVariable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<BehaviorConstraintInternalBinding> getSharedVariable()
  {
    if (sharedVariable == null)
    {
      sharedVariable = new EObjectResolvingEList<BehaviorConstraintInternalBinding>(BehaviorConstraintInternalBinding.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__SHARED_VARIABLE);
    }
    return sharedVariable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<BehaviorConstraintPrototype> getPart()
  {
    if (part == null)
    {
      part = new EObjectContainmentEList<BehaviorConstraintPrototype>(BehaviorConstraintPrototype.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__PART);
    }
    return part;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<AttributeQuantificationConstraint> getAttributeQuantificationConstraint()
  {
    if (attributeQuantificationConstraint == null)
    {
      attributeQuantificationConstraint = new EObjectContainmentEList<AttributeQuantificationConstraint>(AttributeQuantificationConstraint.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__ATTRIBUTE_QUANTIFICATION_CONSTRAINT);
    }
    return attributeQuantificationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ComputationConstraint> getComputationConstraint()
  {
    if (computationConstraint == null)
    {
      computationConstraint = new EObjectContainmentEList<ComputationConstraint>(ComputationConstraint.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__COMPUTATION_CONSTRAINT);
    }
    return computationConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<TemporalConstraint> getTemporalConstraint()
  {
    if (temporalConstraint == null)
    {
      temporalConstraint = new EObjectContainmentEList<TemporalConstraint>(TemporalConstraint.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__TEMPORAL_CONSTRAINT);
    }
    return temporalConstraint;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__PART:
        return ((InternalEList<?>)getPart()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
        return ((InternalEList<?>)getAttributeQuantificationConstraint()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__COMPUTATION_CONSTRAINT:
        return ((InternalEList<?>)getComputationConstraint()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__TEMPORAL_CONSTRAINT:
        return ((InternalEList<?>)getTemporalConstraint()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__INTERFACE_VARIABLE:
        return getInterfaceVariable();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__SHARED_VARIABLE:
        return getSharedVariable();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__PART:
        return getPart();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
        return getAttributeQuantificationConstraint();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__COMPUTATION_CONSTRAINT:
        return getComputationConstraint();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__TEMPORAL_CONSTRAINT:
        return getTemporalConstraint();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__INTERFACE_VARIABLE:
        getInterfaceVariable().clear();
        getInterfaceVariable().addAll((Collection<? extends BehaviorConstraintParameter>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__SHARED_VARIABLE:
        getSharedVariable().clear();
        getSharedVariable().addAll((Collection<? extends BehaviorConstraintInternalBinding>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__PART:
        getPart().clear();
        getPart().addAll((Collection<? extends BehaviorConstraintPrototype>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
        getAttributeQuantificationConstraint().clear();
        getAttributeQuantificationConstraint().addAll((Collection<? extends AttributeQuantificationConstraint>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__COMPUTATION_CONSTRAINT:
        getComputationConstraint().clear();
        getComputationConstraint().addAll((Collection<? extends ComputationConstraint>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__TEMPORAL_CONSTRAINT:
        getTemporalConstraint().clear();
        getTemporalConstraint().addAll((Collection<? extends TemporalConstraint>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__INTERFACE_VARIABLE:
        getInterfaceVariable().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__SHARED_VARIABLE:
        getSharedVariable().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__PART:
        getPart().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
        getAttributeQuantificationConstraint().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__COMPUTATION_CONSTRAINT:
        getComputationConstraint().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__TEMPORAL_CONSTRAINT:
        getTemporalConstraint().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__INTERFACE_VARIABLE:
        return interfaceVariable != null && !interfaceVariable.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__SHARED_VARIABLE:
        return sharedVariable != null && !sharedVariable.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__PART:
        return part != null && !part.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
        return attributeQuantificationConstraint != null && !attributeQuantificationConstraint.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__COMPUTATION_CONSTRAINT:
        return computationConstraint != null && !computationConstraint.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE__TEMPORAL_CONSTRAINT:
        return temporalConstraint != null && !temporalConstraint.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //BehaviorConstraintTypeImpl
