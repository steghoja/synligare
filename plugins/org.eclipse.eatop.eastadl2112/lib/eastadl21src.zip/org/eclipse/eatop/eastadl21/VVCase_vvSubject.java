/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Case vv Subject</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.VerificationValidation._instanceRef.VVCase_vvSubject</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVCase_vvSubject#getIdentifiable_context <em>Identifiable context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVCase_vvSubject#getIdentifiable_target <em>Identifiable target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVCase_vvSubject()
 * @model annotation="MetaData guid='{4CF20534-86B0-4c1c-AA59-C01BFAF4027D}' id='1991726003' EA\040name='VVCase_vvSubject'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='VV-CASE--VV-SUBJECT-IREF'"
 *        extendedMetaData="name='VV-CASE--VV-SUBJECT-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-CASE--VV-SUBJECT-IREFS'"
 * @generated
 */
public interface VVCase_vvSubject extends EObject
{
  /**
   * Returns the value of the '<em><b>Identifiable context</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Identifiable}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Identifiable context</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Identifiable context</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVCase_vvSubject_Identifiable_context()
   * @model annotation="MetaData guid='{5A62BF84-BD0D-4fac-8029-88BD9BF5D666}' id='-1556890385' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='IDENTIFIABLE-CONTEXT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIABLE-CONTEXT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Identifiable> getIdentifiable_context();

  /**
   * Returns the value of the '<em><b>Identifiable target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Identifiable target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Identifiable target</em>' reference.
   * @see #setIdentifiable_target(Identifiable)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVCase_vvSubject_Identifiable_target()
   * @model required="true"
   *        annotation="MetaData guid='{FC1B2B44-48BA-4a0c-904F-64C692B77BE5}' id='-57217020' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='IDENTIFIABLE-TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIABLE-TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Identifiable getIdentifiable_target();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VVCase_vvSubject#getIdentifiable_target <em>Identifiable target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Identifiable target</em>' reference.
   * @see #getIdentifiable_target()
   * @generated
   */
  void setIdentifiable_target(Identifiable value);

} // VVCase_vvSubject
