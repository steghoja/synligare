/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Timing Description Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A timing event is the abstract representation of a specific system behavior -- that can be observed at runtime -- in the AUTOSAR specification. Timing events are used to define the scope for timing constraints. Depending on the specific scope, the view on the system, and the level of abstraction different types of events are defined.
 * 
 * In order to avoid confusion with existing event descriptions in the AUTOSAR templates the timing specific event types use the prefix TD.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.AUTOSAR.CommonStructure.Timing.TimingDescription.TimingDescriptionEvent</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTimingDescriptionEvent()
 * @model abstract="true"
 *        annotation="MetaData guid='{6F625D0C-5CC5-49e7-ACEE-3D22AB5DFB29}' id='-1805098687' EA\040name='TimingDescriptionEvent'"
 *        extendedMetaData="name='TIMING-DESCRIPTION-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIMING-DESCRIPTION-EVENTS'"
 * @generated
 */
public interface TimingDescriptionEvent extends EObject
{
} // TimingDescriptionEvent
