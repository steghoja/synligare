/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.EventChain;
import org.eclipse.eatop.eastadl21.InputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.TimingExpression;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Synchronization Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.InputSynchronizationConstraintImpl#getTolerance <em>Tolerance</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.InputSynchronizationConstraintImpl#getScope <em>Scope</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class InputSynchronizationConstraintImpl extends TimingConstraintImpl implements InputSynchronizationConstraint
{
  /**
   * The cached value of the '{@link #getTolerance() <em>Tolerance</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTolerance()
   * @generated
   * @ordered
   */
  protected TimingExpression tolerance;

  /**
   * The cached value of the '{@link #getScope() <em>Scope</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getScope()
   * @generated
   * @ordered
   */
  protected EList<EventChain> scope;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputSynchronizationConstraintImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getInputSynchronizationConstraint();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression getTolerance()
  {
    return tolerance;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTolerance(TimingExpression newTolerance, NotificationChain msgs)
  {
    TimingExpression oldTolerance = tolerance;
    tolerance = newTolerance;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE, oldTolerance, newTolerance);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTolerance(TimingExpression newTolerance)
  {
    if (newTolerance != tolerance)
    {
      NotificationChain msgs = null;
      if (tolerance != null)
        msgs = ((InternalEObject)tolerance).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE, null, msgs);
      if (newTolerance != null)
        msgs = ((InternalEObject)newTolerance).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE, null, msgs);
      msgs = basicSetTolerance(newTolerance, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE, newTolerance, newTolerance));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<EventChain> getScope()
  {
    if (scope == null)
    {
      scope = new EObjectResolvingEList<EventChain>(EventChain.class, this, Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__SCOPE);
    }
    return scope;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE:
        return basicSetTolerance(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE:
        return getTolerance();
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__SCOPE:
        return getScope();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE:
   			setTolerance((TimingExpression)newValue);
        return;
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__SCOPE:
        getScope().clear();
        getScope().addAll((Collection<? extends EventChain>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE:
        	setTolerance((TimingExpression)null);
        return;
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__SCOPE:
        getScope().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__TOLERANCE:
        return tolerance != null;
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT__SCOPE:
        return scope != null && !scope.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //InputSynchronizationConstraintImpl
