/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import java.util.Map;

import org.eclipse.eatop.eastadl21.ASILKind;
import org.eclipse.eatop.eastadl21.AUTOSAREvent;
import org.eclipse.eatop.eastadl21.Activator;
import org.eclipse.eatop.eastadl21.Actor;
import org.eclipse.eatop.eastadl21.Actuator;
import org.eclipse.eatop.eastadl21.AgeConstraint;
import org.eclipse.eatop.eastadl21.AllocateableElement;
import org.eclipse.eatop.eastadl21.Allocation;
import org.eclipse.eatop.eastadl21.AllocationTarget;
import org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype;
import org.eclipse.eatop.eastadl21.AnalysisFunctionType;
import org.eclipse.eatop.eastadl21.AnalysisLevel;
import org.eclipse.eatop.eastadl21.Anomaly;
import org.eclipse.eatop.eastadl21.ArbitraryConstraint;
import org.eclipse.eatop.eastadl21.ArchitecturalDescription;
import org.eclipse.eatop.eastadl21.ArchitecturalModel;
import org.eclipse.eatop.eastadl21.Architecture;
import org.eclipse.eatop.eastadl21.ArrayDatatype;
import org.eclipse.eatop.eastadl21.Attribute;
import org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint;
import org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType;
import org.eclipse.eatop.eastadl21.Behavior;
import org.eclipse.eatop.eastadl21.BehaviorAttributeBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintParameter;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintType;
import org.eclipse.eatop.eastadl21.BindingTime;
import org.eclipse.eatop.eastadl21.BindingTimeKind;
import org.eclipse.eatop.eastadl21.BurstConstraint;
import org.eclipse.eatop.eastadl21.BusinessOpportunity;
import org.eclipse.eatop.eastadl21.Claim;
import org.eclipse.eatop.eastadl21.ClampConnector;
import org.eclipse.eatop.eastadl21.ClampConnector_port;
import org.eclipse.eatop.eastadl21.ClientServerKind;
import org.eclipse.eatop.eastadl21.Comment;
import org.eclipse.eatop.eastadl21.CommunicationHardwarePin;
import org.eclipse.eatop.eastadl21.ComparisonConstraint;
import org.eclipse.eatop.eastadl21.ComparisonKind;
import org.eclipse.eatop.eastadl21.CompositeDatatype;
import org.eclipse.eatop.eastadl21.ComputationConstraint;
import org.eclipse.eatop.eastadl21.Concept;
import org.eclipse.eatop.eastadl21.ConfigurableContainer;
import org.eclipse.eatop.eastadl21.ConfigurationDecision;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionModel;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionModelEntry;
import org.eclipse.eatop.eastadl21.ContainerConfiguration;
import org.eclipse.eatop.eastadl21.Context;
import org.eclipse.eatop.eastadl21.ControllabilityClassKind;
import org.eclipse.eatop.eastadl21.DelayConstraint;
import org.eclipse.eatop.eastadl21.Dependability;
import org.eclipse.eatop.eastadl21.DeriveRequirement;
import org.eclipse.eatop.eastadl21.DesignFunctionPrototype;
import org.eclipse.eatop.eastadl21.DesignFunctionType;
import org.eclipse.eatop.eastadl21.DesignLevel;
import org.eclipse.eatop.eastadl21.DevelopmentCategoryKind;
import org.eclipse.eatop.eastadl21.DeviationAttributeSet;
import org.eclipse.eatop.eastadl21.DeviationPermissionKind;
import org.eclipse.eatop.eastadl21.EAArrayValue;
import org.eclipse.eatop.eastadl21.EABoolean;
import org.eclipse.eatop.eastadl21.EABooleanValue;
import org.eclipse.eatop.eastadl21.EACompositeValue;
import org.eclipse.eatop.eastadl21.EAConnector;
import org.eclipse.eatop.eastadl21.EADatatype;
import org.eclipse.eatop.eastadl21.EADatatypePrototype;
import org.eclipse.eatop.eastadl21.EADirectionKind;
import org.eclipse.eatop.eastadl21.EAElement;
import org.eclipse.eatop.eastadl21.EAEnumerationValue;
import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.EANumerical;
import org.eclipse.eatop.eastadl21.EANumericalValue;
import org.eclipse.eatop.eastadl21.EAPackage;
import org.eclipse.eatop.eastadl21.EAPackageableElement;
import org.eclipse.eatop.eastadl21.EAPort;
import org.eclipse.eatop.eastadl21.EAPrototype;
import org.eclipse.eatop.eastadl21.EAString;
import org.eclipse.eatop.eastadl21.EAStringValue;
import org.eclipse.eatop.eastadl21.EAType;
import org.eclipse.eatop.eastadl21.EAValue;
import org.eclipse.eatop.eastadl21.EAXML;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ElectricalComponent;
import org.eclipse.eatop.eastadl21.Enumeration;
import org.eclipse.eatop.eastadl21.EnumerationLiteral;
import org.eclipse.eatop.eastadl21.Environment;
import org.eclipse.eatop.eastadl21.ErrorBehavior;
import org.eclipse.eatop.eastadl21.ErrorBehaviorKind;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget;
import org.eclipse.eatop.eastadl21.ErrorModelType;
import org.eclipse.eatop.eastadl21.Event;
import org.eclipse.eatop.eastadl21.EventChain;
import org.eclipse.eatop.eastadl21.EventFaultFailure;
import org.eclipse.eatop.eastadl21.EventFeatureFlaw;
import org.eclipse.eatop.eastadl21.EventFunction;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPortKind;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port;
import org.eclipse.eatop.eastadl21.EventFunction_function;
import org.eclipse.eatop.eastadl21.ExecutionTimeConstraint;
import org.eclipse.eatop.eastadl21.ExposureClassKind;
import org.eclipse.eatop.eastadl21.Extend;
import org.eclipse.eatop.eastadl21.ExtensionPoint;
import org.eclipse.eatop.eastadl21.ExternalEvent;
import org.eclipse.eatop.eastadl21.FailureOutPort;
import org.eclipse.eatop.eastadl21.FaultFailure;
import org.eclipse.eatop.eastadl21.FaultFailurePort;
import org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort;
import org.eclipse.eatop.eastadl21.FaultFailure_anomaly;
import org.eclipse.eatop.eastadl21.FaultInPort;
import org.eclipse.eatop.eastadl21.Feature;
import org.eclipse.eatop.eastadl21.FeatureConfiguration;
import org.eclipse.eatop.eastadl21.FeatureConstraint;
import org.eclipse.eatop.eastadl21.FeatureFlaw;
import org.eclipse.eatop.eastadl21.FeatureGroup;
import org.eclipse.eatop.eastadl21.FeatureLink;
import org.eclipse.eatop.eastadl21.FeatureModel;
import org.eclipse.eatop.eastadl21.FeatureTreeNode;
import org.eclipse.eatop.eastadl21.FunctionAllocation;
import org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement;
import org.eclipse.eatop.eastadl21.FunctionAllocation_target;
import org.eclipse.eatop.eastadl21.FunctionBehavior;
import org.eclipse.eatop.eastadl21.FunctionBehaviorKind;
import org.eclipse.eatop.eastadl21.FunctionClientServerInterface;
import org.eclipse.eatop.eastadl21.FunctionClientServerPort;
import org.eclipse.eatop.eastadl21.FunctionConnector;
import org.eclipse.eatop.eastadl21.FunctionConnector_port;
import org.eclipse.eatop.eastadl21.FunctionFlowPort;
import org.eclipse.eatop.eastadl21.FunctionPort;
import org.eclipse.eatop.eastadl21.FunctionPowerPort;
import org.eclipse.eatop.eastadl21.FunctionPrototype;
import org.eclipse.eatop.eastadl21.FunctionTrigger;
import org.eclipse.eatop.eastadl21.FunctionType;
import org.eclipse.eatop.eastadl21.FunctionalDevice;
import org.eclipse.eatop.eastadl21.FunctionalSafetyConcept;
import org.eclipse.eatop.eastadl21.GenericConstraint;
import org.eclipse.eatop.eastadl21.GenericConstraintKind;
import org.eclipse.eatop.eastadl21.GenericConstraintSet;
import org.eclipse.eatop.eastadl21.Ground;
import org.eclipse.eatop.eastadl21.HardwareBusKind;
import org.eclipse.eatop.eastadl21.HardwareComponentPrototype;
import org.eclipse.eatop.eastadl21.HardwareComponentType;
import org.eclipse.eatop.eastadl21.HardwareConnector;
import org.eclipse.eatop.eastadl21.HardwareConnector_port;
import org.eclipse.eatop.eastadl21.HardwareFunctionType;
import org.eclipse.eatop.eastadl21.HardwarePin;
import org.eclipse.eatop.eastadl21.HardwarePort;
import org.eclipse.eatop.eastadl21.HardwarePortConnector;
import org.eclipse.eatop.eastadl21.HardwarePortConnector_port;
import org.eclipse.eatop.eastadl21.Hazard;
import org.eclipse.eatop.eastadl21.HazardousEvent;
import org.eclipse.eatop.eastadl21.IOHardwarePin;
import org.eclipse.eatop.eastadl21.IOHardwarePinKind;
import org.eclipse.eatop.eastadl21.Identifiable;
import org.eclipse.eatop.eastadl21.ImplementationLevel;
import org.eclipse.eatop.eastadl21.Include;
import org.eclipse.eatop.eastadl21.InputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.InternalBinding;
import org.eclipse.eatop.eastadl21.InternalFaultPrototype;
import org.eclipse.eatop.eastadl21.Item;
import org.eclipse.eatop.eastadl21.LifecycleStageKind;
import org.eclipse.eatop.eastadl21.LocalDeviceManager;
import org.eclipse.eatop.eastadl21.LogicalEvent;
import org.eclipse.eatop.eastadl21.LogicalPath;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.LogicalTransformation;
import org.eclipse.eatop.eastadl21.Mission;
import org.eclipse.eatop.eastadl21.Mode;
import org.eclipse.eatop.eastadl21.ModeEvent;
import org.eclipse.eatop.eastadl21.ModeGroup;
import org.eclipse.eatop.eastadl21.Node;
import org.eclipse.eatop.eastadl21.Operation;
import org.eclipse.eatop.eastadl21.OperationalSituation;
import org.eclipse.eatop.eastadl21.OrderConstraint;
import org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.PatternConstraint;
import org.eclipse.eatop.eastadl21.PeriodicConstraint;
import org.eclipse.eatop.eastadl21.PortGroup;
import org.eclipse.eatop.eastadl21.PowerHardwarePin;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive;
import org.eclipse.eatop.eastadl21.PrivateContent;
import org.eclipse.eatop.eastadl21.ProblemStatement;
import org.eclipse.eatop.eastadl21.ProcessFaultPrototype;
import org.eclipse.eatop.eastadl21.ProductPositioning;
import org.eclipse.eatop.eastadl21.QualityRequirement;
import org.eclipse.eatop.eastadl21.QualityRequirementKind;
import org.eclipse.eatop.eastadl21.Quantification;
import org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint;
import org.eclipse.eatop.eastadl21.Quantity;
import org.eclipse.eatop.eastadl21.RangeableValueType;
import org.eclipse.eatop.eastadl21.Rationale;
import org.eclipse.eatop.eastadl21.ReactionConstraint;
import org.eclipse.eatop.eastadl21.Realization;
import org.eclipse.eatop.eastadl21.Realization_realized;
import org.eclipse.eatop.eastadl21.Realization_realizedBy;
import org.eclipse.eatop.eastadl21.RedefinableElement;
import org.eclipse.eatop.eastadl21.Referrable;
import org.eclipse.eatop.eastadl21.Refine;
import org.eclipse.eatop.eastadl21.Refine_refinedBy;
import org.eclipse.eatop.eastadl21.Relationship;
import org.eclipse.eatop.eastadl21.RepetitionConstraint;
import org.eclipse.eatop.eastadl21.Requirement;
import org.eclipse.eatop.eastadl21.RequirementsHierarchy;
import org.eclipse.eatop.eastadl21.RequirementsLink;
import org.eclipse.eatop.eastadl21.RequirementsModel;
import org.eclipse.eatop.eastadl21.RequirementsRelationship;
import org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup;
import org.eclipse.eatop.eastadl21.ReuseMetaInformation;
import org.eclipse.eatop.eastadl21.SafetyCase;
import org.eclipse.eatop.eastadl21.SafetyConstraint;
import org.eclipse.eatop.eastadl21.SafetyGoal;
import org.eclipse.eatop.eastadl21.Satisfy;
import org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy;
import org.eclipse.eatop.eastadl21.SelectionCriterion;
import org.eclipse.eatop.eastadl21.Sensor;
import org.eclipse.eatop.eastadl21.SeverityClassKind;
import org.eclipse.eatop.eastadl21.SporadicConstraint;
import org.eclipse.eatop.eastadl21.Stakeholder;
import org.eclipse.eatop.eastadl21.StakeholderNeed;
import org.eclipse.eatop.eastadl21.State;
import org.eclipse.eatop.eastadl21.StateEvent;
import org.eclipse.eatop.eastadl21.StrongDelayConstraint;
import org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronousTransition;
import org.eclipse.eatop.eastadl21.SystemModel;
import org.eclipse.eatop.eastadl21.TakeRateConstraint;
import org.eclipse.eatop.eastadl21.TechnicalSafetyConcept;
import org.eclipse.eatop.eastadl21.TemporalConstraint;
import org.eclipse.eatop.eastadl21.Timing;
import org.eclipse.eatop.eastadl21.TimingConstraint;
import org.eclipse.eatop.eastadl21.TimingDescription;
import org.eclipse.eatop.eastadl21.TimingDescriptionEvent;
import org.eclipse.eatop.eastadl21.TimingExpression;
import org.eclipse.eatop.eastadl21.TraceableSpecification;
import org.eclipse.eatop.eastadl21.TransformationOccurrence;
import org.eclipse.eatop.eastadl21.Transition;
import org.eclipse.eatop.eastadl21.TransitionEvent;
import org.eclipse.eatop.eastadl21.TriggerPolicyKind;
import org.eclipse.eatop.eastadl21.Unit;
import org.eclipse.eatop.eastadl21.UseCase;
import org.eclipse.eatop.eastadl21.UserAttributeDefinition;
import org.eclipse.eatop.eastadl21.UserAttributedElement;
import org.eclipse.eatop.eastadl21.UserElementType;
import org.eclipse.eatop.eastadl21.VVActualOutcome;
import org.eclipse.eatop.eastadl21.VVCase;
import org.eclipse.eatop.eastadl21.VVCase_vvSubject;
import org.eclipse.eatop.eastadl21.VVIntendedOutcome;
import org.eclipse.eatop.eastadl21.VVLog;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.VVStimuli;
import org.eclipse.eatop.eastadl21.VVTarget;
import org.eclipse.eatop.eastadl21.VVTarget_element;
import org.eclipse.eatop.eastadl21.Variability;
import org.eclipse.eatop.eastadl21.VariabilityDependencyKind;
import org.eclipse.eatop.eastadl21.VariableElement;
import org.eclipse.eatop.eastadl21.VariationGroup;
import org.eclipse.eatop.eastadl21.VehicleFeature;
import org.eclipse.eatop.eastadl21.VehicleLevel;
import org.eclipse.eatop.eastadl21.VehicleLevelBinding;
import org.eclipse.eatop.eastadl21.VehicleSystem;
import org.eclipse.eatop.eastadl21.VerificationValidation;
import org.eclipse.eatop.eastadl21.Verify;
import org.eclipse.eatop.eastadl21.Warrant;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import org.eclipse.emf.ecore.xml.type.util.XMLTypeUtil;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package
 * @generated
 */
public class Eastadl21Validator extends EObjectValidator
{
  /**
   * The cached model package
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final Eastadl21Validator INSTANCE = new Eastadl21Validator();

  /**
   * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.common.util.Diagnostic#getSource()
   * @see org.eclipse.emf.common.util.Diagnostic#getCode()
   * @generated
   */
  public static final String DIAGNOSTIC_SOURCE = "org.eclipse.eatop.eastadl21";

  /**
   * A constant with a fixed name that can be used as the base value for additional hand written constants.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

  /**
   * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

  /**
   * Creates an instance of the switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eastadl21Validator()
  {
    super();
  }

  /**
   * Returns the package of this validator switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EPackage getEPackage()
  {
    return Eastadl21Package.eINSTANCE;
  }

  /**
   * Calls <code>validateXXX</code> for the corresponding classifier of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    switch (classifierID)
    {
      case Eastadl21Package.VEHICLE_LEVEL:
        return validateVehicleLevel((VehicleLevel)value, diagnostics, context);
      case Eastadl21Package.SYSTEM_MODEL:
        return validateSystemModel((SystemModel)value, diagnostics, context);
      case Eastadl21Package.ANALYSIS_LEVEL:
        return validateAnalysisLevel((AnalysisLevel)value, diagnostics, context);
      case Eastadl21Package.DESIGN_LEVEL:
        return validateDesignLevel((DesignLevel)value, diagnostics, context);
      case Eastadl21Package.IMPLEMENTATION_LEVEL:
        return validateImplementationLevel((ImplementationLevel)value, diagnostics, context);
      case Eastadl21Package.BINDING_TIME:
        return validateBindingTime((BindingTime)value, diagnostics, context);
      case Eastadl21Package.FEATURE:
        return validateFeature((Feature)value, diagnostics, context);
      case Eastadl21Package.FEATURE_CONSTRAINT:
        return validateFeatureConstraint((FeatureConstraint)value, diagnostics, context);
      case Eastadl21Package.FEATURE_GROUP:
        return validateFeatureGroup((FeatureGroup)value, diagnostics, context);
      case Eastadl21Package.FEATURE_LINK:
        return validateFeatureLink((FeatureLink)value, diagnostics, context);
      case Eastadl21Package.FEATURE_MODEL:
        return validateFeatureModel((FeatureModel)value, diagnostics, context);
      case Eastadl21Package.FEATURE_TREE_NODE:
        return validateFeatureTreeNode((FeatureTreeNode)value, diagnostics, context);
      case Eastadl21Package.DEVIATION_ATTRIBUTE_SET:
        return validateDeviationAttributeSet((DeviationAttributeSet)value, diagnostics, context);
      case Eastadl21Package.VEHICLE_FEATURE:
        return validateVehicleFeature((VehicleFeature)value, diagnostics, context);
      case Eastadl21Package.ALLOCATEABLE_ELEMENT:
        return validateAllocateableElement((AllocateableElement)value, diagnostics, context);
      case Eastadl21Package.ALLOCATION:
        return validateAllocation((Allocation)value, diagnostics, context);
      case Eastadl21Package.ANALYSIS_FUNCTION_PROTOTYPE:
        return validateAnalysisFunctionPrototype((AnalysisFunctionPrototype)value, diagnostics, context);
      case Eastadl21Package.ANALYSIS_FUNCTION_TYPE:
        return validateAnalysisFunctionType((AnalysisFunctionType)value, diagnostics, context);
      case Eastadl21Package.BASIC_SOFTWARE_FUNCTION_TYPE:
        return validateBasicSoftwareFunctionType((BasicSoftwareFunctionType)value, diagnostics, context);
      case Eastadl21Package.DESIGN_FUNCTION_PROTOTYPE:
        return validateDesignFunctionPrototype((DesignFunctionPrototype)value, diagnostics, context);
      case Eastadl21Package.DESIGN_FUNCTION_TYPE:
        return validateDesignFunctionType((DesignFunctionType)value, diagnostics, context);
      case Eastadl21Package.FUNCTIONAL_DEVICE:
        return validateFunctionalDevice((FunctionalDevice)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_ALLOCATION:
        return validateFunctionAllocation((FunctionAllocation)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_CLIENT_SERVER_INTERFACE:
        return validateFunctionClientServerInterface((FunctionClientServerInterface)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_CLIENT_SERVER_PORT:
        return validateFunctionClientServerPort((FunctionClientServerPort)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_CONNECTOR:
        return validateFunctionConnector((FunctionConnector)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_FLOW_PORT:
        return validateFunctionFlowPort((FunctionFlowPort)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_PORT:
        return validateFunctionPort((FunctionPort)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_POWER_PORT:
        return validateFunctionPowerPort((FunctionPowerPort)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_PROTOTYPE:
        return validateFunctionPrototype((FunctionPrototype)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_TYPE:
        return validateFunctionType((FunctionType)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_FUNCTION_TYPE:
        return validateHardwareFunctionType((HardwareFunctionType)value, diagnostics, context);
      case Eastadl21Package.LOCAL_DEVICE_MANAGER:
        return validateLocalDeviceManager((LocalDeviceManager)value, diagnostics, context);
      case Eastadl21Package.OPERATION:
        return validateOperation((Operation)value, diagnostics, context);
      case Eastadl21Package.PORT_GROUP:
        return validatePortGroup((PortGroup)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_ALLOCATION_ALLOCATED_ELEMENT:
        return validateFunctionAllocation_allocatedElement((FunctionAllocation_allocatedElement)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_ALLOCATION_TARGET:
        return validateFunctionAllocation_target((FunctionAllocation_target)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_CONNECTOR_PORT:
        return validateFunctionConnector_port((FunctionConnector_port)value, diagnostics, context);
      case Eastadl21Package.ACTUATOR:
        return validateActuator((Actuator)value, diagnostics, context);
      case Eastadl21Package.COMMUNICATION_HARDWARE_PIN:
        return validateCommunicationHardwarePin((CommunicationHardwarePin)value, diagnostics, context);
      case Eastadl21Package.ELECTRICAL_COMPONENT:
        return validateElectricalComponent((ElectricalComponent)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_COMPONENT_PROTOTYPE:
        return validateHardwareComponentPrototype((HardwareComponentPrototype)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_COMPONENT_TYPE:
        return validateHardwareComponentType((HardwareComponentType)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_CONNECTOR:
        return validateHardwareConnector((HardwareConnector)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_PIN:
        return validateHardwarePin((HardwarePin)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_PORT:
        return validateHardwarePort((HardwarePort)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR:
        return validateHardwarePortConnector((HardwarePortConnector)value, diagnostics, context);
      case Eastadl21Package.IO_HARDWARE_PIN:
        return validateIOHardwarePin((IOHardwarePin)value, diagnostics, context);
      case Eastadl21Package.NODE:
        return validateNode((Node)value, diagnostics, context);
      case Eastadl21Package.POWER_HARDWARE_PIN:
        return validatePowerHardwarePin((PowerHardwarePin)value, diagnostics, context);
      case Eastadl21Package.SENSOR:
        return validateSensor((Sensor)value, diagnostics, context);
      case Eastadl21Package.ALLOCATION_TARGET:
        return validateAllocationTarget((AllocationTarget)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_CONNECTOR_PORT:
        return validateHardwareConnector_port((HardwareConnector_port)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR_PORT:
        return validateHardwarePortConnector_port((HardwarePortConnector_port)value, diagnostics, context);
      case Eastadl21Package.CLAMP_CONNECTOR:
        return validateClampConnector((ClampConnector)value, diagnostics, context);
      case Eastadl21Package.ENVIRONMENT:
        return validateEnvironment((Environment)value, diagnostics, context);
      case Eastadl21Package.CLAMP_CONNECTOR_PORT:
        return validateClampConnector_port((ClampConnector_port)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR:
        return validateBehavior((Behavior)value, diagnostics, context);
      case Eastadl21Package.MODE:
        return validateMode((Mode)value, diagnostics, context);
      case Eastadl21Package.MODE_GROUP:
        return validateModeGroup((ModeGroup)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_BEHAVIOR:
        return validateFunctionBehavior((FunctionBehavior)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_TRIGGER:
        return validateFunctionTrigger((FunctionTrigger)value, diagnostics, context);
      case Eastadl21Package.CONFIGURABLE_CONTAINER:
        return validateConfigurableContainer((ConfigurableContainer)value, diagnostics, context);
      case Eastadl21Package.CONFIGURATION_DECISION:
        return validateConfigurationDecision((ConfigurationDecision)value, diagnostics, context);
      case Eastadl21Package.CONFIGURATION_DECISION_FOLDER:
        return validateConfigurationDecisionFolder((ConfigurationDecisionFolder)value, diagnostics, context);
      case Eastadl21Package.CONFIGURATION_DECISION_MODEL:
        return validateConfigurationDecisionModel((ConfigurationDecisionModel)value, diagnostics, context);
      case Eastadl21Package.CONFIGURATION_DECISION_MODEL_ENTRY:
        return validateConfigurationDecisionModelEntry((ConfigurationDecisionModelEntry)value, diagnostics, context);
      case Eastadl21Package.CONTAINER_CONFIGURATION:
        return validateContainerConfiguration((ContainerConfiguration)value, diagnostics, context);
      case Eastadl21Package.FEATURE_CONFIGURATION:
        return validateFeatureConfiguration((FeatureConfiguration)value, diagnostics, context);
      case Eastadl21Package.INTERNAL_BINDING:
        return validateInternalBinding((InternalBinding)value, diagnostics, context);
      case Eastadl21Package.PRIVATE_CONTENT:
        return validatePrivateContent((PrivateContent)value, diagnostics, context);
      case Eastadl21Package.REUSE_META_INFORMATION:
        return validateReuseMetaInformation((ReuseMetaInformation)value, diagnostics, context);
      case Eastadl21Package.SELECTION_CRITERION:
        return validateSelectionCriterion((SelectionCriterion)value, diagnostics, context);
      case Eastadl21Package.VARIABILITY:
        return validateVariability((Variability)value, diagnostics, context);
      case Eastadl21Package.VARIABLE_ELEMENT:
        return validateVariableElement((VariableElement)value, diagnostics, context);
      case Eastadl21Package.VARIATION_GROUP:
        return validateVariationGroup((VariationGroup)value, diagnostics, context);
      case Eastadl21Package.VEHICLE_LEVEL_BINDING:
        return validateVehicleLevelBinding((VehicleLevelBinding)value, diagnostics, context);
      case Eastadl21Package.DERIVE_REQUIREMENT:
        return validateDeriveRequirement((DeriveRequirement)value, diagnostics, context);
      case Eastadl21Package.OPERATIONAL_SITUATION:
        return validateOperationalSituation((OperationalSituation)value, diagnostics, context);
      case Eastadl21Package.REQUIREMENTS_MODEL:
        return validateRequirementsModel((RequirementsModel)value, diagnostics, context);
      case Eastadl21Package.REQUIREMENTS_RELATIONSHIP:
        return validateRequirementsRelationship((RequirementsRelationship)value, diagnostics, context);
      case Eastadl21Package.REQUIREMENT:
        return validateRequirement((Requirement)value, diagnostics, context);
      case Eastadl21Package.REQUIREMENTS_HIERARCHY:
        return validateRequirementsHierarchy((RequirementsHierarchy)value, diagnostics, context);
      case Eastadl21Package.REFINE:
        return validateRefine((Refine)value, diagnostics, context);
      case Eastadl21Package.SATISFY:
        return validateSatisfy((Satisfy)value, diagnostics, context);
      case Eastadl21Package.REQUIREMENTS_LINK:
        return validateRequirementsLink((RequirementsLink)value, diagnostics, context);
      case Eastadl21Package.REQUIREMENTS_RELATIONSHIP_GROUP:
        return validateRequirementsRelationshipGroup((RequirementsRelationshipGroup)value, diagnostics, context);
      case Eastadl21Package.QUALITY_REQUIREMENT:
        return validateQualityRequirement((QualityRequirement)value, diagnostics, context);
      case Eastadl21Package.REFINE_REFINED_BY:
        return validateRefine_refinedBy((Refine_refinedBy)value, diagnostics, context);
      case Eastadl21Package.SATISFY_SATISFIED_BY:
        return validateSatisfy_satisfiedBy((Satisfy_satisfiedBy)value, diagnostics, context);
      case Eastadl21Package.ACTOR:
        return validateActor((Actor)value, diagnostics, context);
      case Eastadl21Package.EXTEND:
        return validateExtend((Extend)value, diagnostics, context);
      case Eastadl21Package.EXTENSION_POINT:
        return validateExtensionPoint((ExtensionPoint)value, diagnostics, context);
      case Eastadl21Package.INCLUDE:
        return validateInclude((Include)value, diagnostics, context);
      case Eastadl21Package.REDEFINABLE_ELEMENT:
        return validateRedefinableElement((RedefinableElement)value, diagnostics, context);
      case Eastadl21Package.USE_CASE:
        return validateUseCase((UseCase)value, diagnostics, context);
      case Eastadl21Package.VERIFICATION_VALIDATION:
        return validateVerificationValidation((VerificationValidation)value, diagnostics, context);
      case Eastadl21Package.VERIFY:
        return validateVerify((Verify)value, diagnostics, context);
      case Eastadl21Package.VV_ACTUAL_OUTCOME:
        return validateVVActualOutcome((VVActualOutcome)value, diagnostics, context);
      case Eastadl21Package.VV_CASE:
        return validateVVCase((VVCase)value, diagnostics, context);
      case Eastadl21Package.VV_INTENDED_OUTCOME:
        return validateVVIntendedOutcome((VVIntendedOutcome)value, diagnostics, context);
      case Eastadl21Package.VV_LOG:
        return validateVVLog((VVLog)value, diagnostics, context);
      case Eastadl21Package.VV_PROCEDURE:
        return validateVVProcedure((VVProcedure)value, diagnostics, context);
      case Eastadl21Package.VV_STIMULI:
        return validateVVStimuli((VVStimuli)value, diagnostics, context);
      case Eastadl21Package.VV_TARGET:
        return validateVVTarget((VVTarget)value, diagnostics, context);
      case Eastadl21Package.VV_CASE_VV_SUBJECT:
        return validateVVCase_vvSubject((VVCase_vvSubject)value, diagnostics, context);
      case Eastadl21Package.VV_TARGET_ELEMENT:
        return validateVVTarget_element((VVTarget_element)value, diagnostics, context);
      case Eastadl21Package.EVENT:
        return validateEvent((Event)value, diagnostics, context);
      case Eastadl21Package.EVENT_CHAIN:
        return validateEventChain((EventChain)value, diagnostics, context);
      case Eastadl21Package.PRECEDENCE_CONSTRAINT:
        return validatePrecedenceConstraint((PrecedenceConstraint)value, diagnostics, context);
      case Eastadl21Package.TIMING:
        return validateTiming((Timing)value, diagnostics, context);
      case Eastadl21Package.TIMING_CONSTRAINT:
        return validateTimingConstraint((TimingConstraint)value, diagnostics, context);
      case Eastadl21Package.TIMING_DESCRIPTION:
        return validateTimingDescription((TimingDescription)value, diagnostics, context);
      case Eastadl21Package.TIMING_EXPRESSION:
        return validateTimingExpression((TimingExpression)value, diagnostics, context);
      case Eastadl21Package.AUTOSAR_EVENT:
        return validateAUTOSAREvent((AUTOSAREvent)value, diagnostics, context);
      case Eastadl21Package.EVENT_FAULT_FAILURE:
        return validateEventFaultFailure((EventFaultFailure)value, diagnostics, context);
      case Eastadl21Package.EVENT_FEATURE_FLAW:
        return validateEventFeatureFlaw((EventFeatureFlaw)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION:
        return validateEventFunction((EventFunction)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT:
        return validateEventFunctionClientServerPort((EventFunctionClientServerPort)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION_FLOW_PORT:
        return validateEventFunctionFlowPort((EventFunctionFlowPort)value, diagnostics, context);
      case Eastadl21Package.EXTERNAL_EVENT:
        return validateExternalEvent((ExternalEvent)value, diagnostics, context);
      case Eastadl21Package.MODE_EVENT:
        return validateModeEvent((ModeEvent)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION_FUNCTION:
        return validateEventFunction_function((EventFunction_function)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT:
        return validateEventFunctionClientServerPort_port((EventFunctionClientServerPort_port)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION_FLOW_PORT_PORT:
        return validateEventFunctionFlowPort_port((EventFunctionFlowPort_port)value, diagnostics, context);
      case Eastadl21Package.AGE_CONSTRAINT:
        return validateAgeConstraint((AgeConstraint)value, diagnostics, context);
      case Eastadl21Package.ARBITRARY_CONSTRAINT:
        return validateArbitraryConstraint((ArbitraryConstraint)value, diagnostics, context);
      case Eastadl21Package.BURST_CONSTRAINT:
        return validateBurstConstraint((BurstConstraint)value, diagnostics, context);
      case Eastadl21Package.COMPARISON_CONSTRAINT:
        return validateComparisonConstraint((ComparisonConstraint)value, diagnostics, context);
      case Eastadl21Package.DELAY_CONSTRAINT:
        return validateDelayConstraint((DelayConstraint)value, diagnostics, context);
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT:
        return validateExecutionTimeConstraint((ExecutionTimeConstraint)value, diagnostics, context);
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT:
        return validateInputSynchronizationConstraint((InputSynchronizationConstraint)value, diagnostics, context);
      case Eastadl21Package.ORDER_CONSTRAINT:
        return validateOrderConstraint((OrderConstraint)value, diagnostics, context);
      case Eastadl21Package.OUTPUT_SYNCHRONIZATION_CONSTRAINT:
        return validateOutputSynchronizationConstraint((OutputSynchronizationConstraint)value, diagnostics, context);
      case Eastadl21Package.PATTERN_CONSTRAINT:
        return validatePatternConstraint((PatternConstraint)value, diagnostics, context);
      case Eastadl21Package.PERIODIC_CONSTRAINT:
        return validatePeriodicConstraint((PeriodicConstraint)value, diagnostics, context);
      case Eastadl21Package.REACTION_CONSTRAINT:
        return validateReactionConstraint((ReactionConstraint)value, diagnostics, context);
      case Eastadl21Package.REPETITION_CONSTRAINT:
        return validateRepetitionConstraint((RepetitionConstraint)value, diagnostics, context);
      case Eastadl21Package.SPORADIC_CONSTRAINT:
        return validateSporadicConstraint((SporadicConstraint)value, diagnostics, context);
      case Eastadl21Package.STRONG_DELAY_CONSTRAINT:
        return validateStrongDelayConstraint((StrongDelayConstraint)value, diagnostics, context);
      case Eastadl21Package.STRONG_SYNCHRONIZATION_CONSTRAINT:
        return validateStrongSynchronizationConstraint((StrongSynchronizationConstraint)value, diagnostics, context);
      case Eastadl21Package.SYNCHRONIZATION_CONSTRAINT:
        return validateSynchronizationConstraint((SynchronizationConstraint)value, diagnostics, context);
      case Eastadl21Package.PRECEDENCE_CONSTRAINT_PRECEDING:
        return validatePrecedenceConstraint_preceding((PrecedenceConstraint_preceding)value, diagnostics, context);
      case Eastadl21Package.PRECEDENCE_CONSTRAINT_SUCCESSIVE:
        return validatePrecedenceConstraint_successive((PrecedenceConstraint_successive)value, diagnostics, context);
      case Eastadl21Package.DEPENDABILITY:
        return validateDependability((Dependability)value, diagnostics, context);
      case Eastadl21Package.FEATURE_FLAW:
        return validateFeatureFlaw((FeatureFlaw)value, diagnostics, context);
      case Eastadl21Package.HAZARD:
        return validateHazard((Hazard)value, diagnostics, context);
      case Eastadl21Package.HAZARDOUS_EVENT:
        return validateHazardousEvent((HazardousEvent)value, diagnostics, context);
      case Eastadl21Package.ITEM:
        return validateItem((Item)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE:
        return validateFaultFailure((FaultFailure)value, diagnostics, context);
      case Eastadl21Package.QUANTITATIVE_SAFETY_CONSTRAINT:
        return validateQuantitativeSafetyConstraint((QuantitativeSafetyConstraint)value, diagnostics, context);
      case Eastadl21Package.SAFETY_CONSTRAINT:
        return validateSafetyConstraint((SafetyConstraint)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_ANOMALY:
        return validateFaultFailure_anomaly((FaultFailure_anomaly)value, diagnostics, context);
      case Eastadl21Package.ANOMALY:
        return validateAnomaly((Anomaly)value, diagnostics, context);
      case Eastadl21Package.ERROR_BEHAVIOR:
        return validateErrorBehavior((ErrorBehavior)value, diagnostics, context);
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE:
        return validateErrorModelPrototype((ErrorModelPrototype)value, diagnostics, context);
      case Eastadl21Package.ERROR_MODEL_TYPE:
        return validateErrorModelType((ErrorModelType)value, diagnostics, context);
      case Eastadl21Package.FAILURE_OUT_PORT:
        return validateFailureOutPort((FailureOutPort)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_PORT:
        return validateFaultFailurePort((FaultFailurePort)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK:
        return validateFaultFailurePropagationLink((FaultFailurePropagationLink)value, diagnostics, context);
      case Eastadl21Package.FAULT_IN_PORT:
        return validateFaultInPort((FaultInPort)value, diagnostics, context);
      case Eastadl21Package.INTERNAL_FAULT_PROTOTYPE:
        return validateInternalFaultPrototype((InternalFaultPrototype)value, diagnostics, context);
      case Eastadl21Package.PROCESS_FAULT_PROTOTYPE:
        return validateProcessFaultPrototype((ProcessFaultPrototype)value, diagnostics, context);
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE_FUNCTION_TARGET:
        return validateErrorModelPrototype_functionTarget((ErrorModelPrototype_functionTarget)value, diagnostics, context);
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE_HW_TARGET:
        return validateErrorModelPrototype_hwTarget((ErrorModelPrototype_hwTarget)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_PORT_FUNCTION_TARGET:
        return validateFaultFailurePort_functionTarget((FaultFailurePort_functionTarget)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_PORT_HW_TARGET:
        return validateFaultFailurePort_hwTarget((FaultFailurePort_hwTarget)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT:
        return validateFaultFailurePropagationLink_fromPort((FaultFailurePropagationLink_fromPort)value, diagnostics, context);
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_TO_PORT:
        return validateFaultFailurePropagationLink_toPort((FaultFailurePropagationLink_toPort)value, diagnostics, context);
      case Eastadl21Package.FUNCTIONAL_SAFETY_CONCEPT:
        return validateFunctionalSafetyConcept((FunctionalSafetyConcept)value, diagnostics, context);
      case Eastadl21Package.SAFETY_GOAL:
        return validateSafetyGoal((SafetyGoal)value, diagnostics, context);
      case Eastadl21Package.TECHNICAL_SAFETY_CONCEPT:
        return validateTechnicalSafetyConcept((TechnicalSafetyConcept)value, diagnostics, context);
      case Eastadl21Package.CLAIM:
        return validateClaim((Claim)value, diagnostics, context);
      case Eastadl21Package.GROUND:
        return validateGround((Ground)value, diagnostics, context);
      case Eastadl21Package.SAFETY_CASE:
        return validateSafetyCase((SafetyCase)value, diagnostics, context);
      case Eastadl21Package.WARRANT:
        return validateWarrant((Warrant)value, diagnostics, context);
      case Eastadl21Package.GENERIC_CONSTRAINT:
        return validateGenericConstraint((GenericConstraint)value, diagnostics, context);
      case Eastadl21Package.GENERIC_CONSTRAINT_SET:
        return validateGenericConstraintSet((GenericConstraintSet)value, diagnostics, context);
      case Eastadl21Package.TAKE_RATE_CONSTRAINT:
        return validateTakeRateConstraint((TakeRateConstraint)value, diagnostics, context);
      case Eastadl21Package.COMMENT:
        return validateComment((Comment)value, diagnostics, context);
      case Eastadl21Package.CONTEXT:
        return validateContext((Context)value, diagnostics, context);
      case Eastadl21Package.EA_CONNECTOR:
        return validateEAConnector((EAConnector)value, diagnostics, context);
      case Eastadl21Package.EA_ELEMENT:
        return validateEAElement((EAElement)value, diagnostics, context);
      case Eastadl21Package.EA_PACKAGE:
        return validateEAPackage((EAPackage)value, diagnostics, context);
      case Eastadl21Package.EA_PACKAGEABLE_ELEMENT:
        return validateEAPackageableElement((EAPackageableElement)value, diagnostics, context);
      case Eastadl21Package.EA_PORT:
        return validateEAPort((EAPort)value, diagnostics, context);
      case Eastadl21Package.EA_PROTOTYPE:
        return validateEAPrototype((EAPrototype)value, diagnostics, context);
      case Eastadl21Package.EA_TYPE:
        return validateEAType((EAType)value, diagnostics, context);
      case Eastadl21Package.EAXML:
        return validateEAXML((EAXML)value, diagnostics, context);
      case Eastadl21Package.RATIONALE:
        return validateRationale((Rationale)value, diagnostics, context);
      case Eastadl21Package.REALIZATION:
        return validateRealization((Realization)value, diagnostics, context);
      case Eastadl21Package.REFERRABLE:
        return validateReferrable((Referrable)value, diagnostics, context);
      case Eastadl21Package.RELATIONSHIP:
        return validateRelationship((Relationship)value, diagnostics, context);
      case Eastadl21Package.TRACEABLE_SPECIFICATION:
        return validateTraceableSpecification((TraceableSpecification)value, diagnostics, context);
      case Eastadl21Package.IDENTIFIABLE:
        return validateIdentifiable((Identifiable)value, diagnostics, context);
      case Eastadl21Package.REALIZATION_REALIZED:
        return validateRealization_realized((Realization_realized)value, diagnostics, context);
      case Eastadl21Package.REALIZATION_REALIZED_BY:
        return validateRealization_realizedBy((Realization_realizedBy)value, diagnostics, context);
      case Eastadl21Package.ARRAY_DATATYPE:
        return validateArrayDatatype((ArrayDatatype)value, diagnostics, context);
      case Eastadl21Package.COMPOSITE_DATATYPE:
        return validateCompositeDatatype((CompositeDatatype)value, diagnostics, context);
      case Eastadl21Package.EA_BOOLEAN:
        return validateEABoolean((EABoolean)value, diagnostics, context);
      case Eastadl21Package.EA_DATATYPE:
        return validateEADatatype((EADatatype)value, diagnostics, context);
      case Eastadl21Package.EA_DATATYPE_PROTOTYPE:
        return validateEADatatypePrototype((EADatatypePrototype)value, diagnostics, context);
      case Eastadl21Package.EA_NUMERICAL:
        return validateEANumerical((EANumerical)value, diagnostics, context);
      case Eastadl21Package.EA_STRING:
        return validateEAString((EAString)value, diagnostics, context);
      case Eastadl21Package.ENUMERATION:
        return validateEnumeration((Enumeration)value, diagnostics, context);
      case Eastadl21Package.ENUMERATION_LITERAL:
        return validateEnumerationLiteral((EnumerationLiteral)value, diagnostics, context);
      case Eastadl21Package.QUANTITY:
        return validateQuantity((Quantity)value, diagnostics, context);
      case Eastadl21Package.RANGEABLE_VALUE_TYPE:
        return validateRangeableValueType((RangeableValueType)value, diagnostics, context);
      case Eastadl21Package.UNIT:
        return validateUnit((Unit)value, diagnostics, context);
      case Eastadl21Package.EA_ARRAY_VALUE:
        return validateEAArrayValue((EAArrayValue)value, diagnostics, context);
      case Eastadl21Package.EA_BOOLEAN_VALUE:
        return validateEABooleanValue((EABooleanValue)value, diagnostics, context);
      case Eastadl21Package.EA_COMPOSITE_VALUE:
        return validateEACompositeValue((EACompositeValue)value, diagnostics, context);
      case Eastadl21Package.EA_ENUMERATION_VALUE:
        return validateEAEnumerationValue((EAEnumerationValue)value, diagnostics, context);
      case Eastadl21Package.EA_EXPRESSION:
        return validateEAExpression((EAExpression)value, diagnostics, context);
      case Eastadl21Package.EA_NUMERICAL_VALUE:
        return validateEANumericalValue((EANumericalValue)value, diagnostics, context);
      case Eastadl21Package.EA_STRING_VALUE:
        return validateEAStringValue((EAStringValue)value, diagnostics, context);
      case Eastadl21Package.EA_VALUE:
        return validateEAValue((EAValue)value, diagnostics, context);
      case Eastadl21Package.USER_ATTRIBUTE_DEFINITION:
        return validateUserAttributeDefinition((UserAttributeDefinition)value, diagnostics, context);
      case Eastadl21Package.USER_ATTRIBUTED_ELEMENT:
        return validateUserAttributedElement((UserAttributedElement)value, diagnostics, context);
      case Eastadl21Package.USER_ELEMENT_TYPE:
        return validateUserElementType((UserElementType)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_BINDING_ATTRIBUTE:
        return validateBehaviorConstraintBindingAttribute((BehaviorConstraintBindingAttribute)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT:
        return validateBehaviorConstraintBindingEvent((BehaviorConstraintBindingEvent)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING:
        return validateBehaviorConstraintInternalBinding((BehaviorConstraintInternalBinding)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PARAMETER:
        return validateBehaviorConstraintParameter((BehaviorConstraintParameter)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE:
        return validateBehaviorConstraintPrototype((BehaviorConstraintPrototype)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING:
        return validateBehaviorConstraintTargetBinding((BehaviorConstraintTargetBinding)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE:
        return validateBehaviorConstraintType((BehaviorConstraintType)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR:
        return validateBehaviorConstraintInternalBinding_bindingThroughFunctionConnector((BehaviorConstraintInternalBinding_bindingThroughFunctionConnector)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_HARDWARE_CONNECTOR:
        return validateBehaviorConstraintInternalBinding_bindingThroughHardwareConnector((BehaviorConstraintInternalBinding_bindingThroughHardwareConnector)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET:
        return validateBehaviorConstraintPrototype_errorModelTarget((BehaviorConstraintPrototype_errorModelTarget)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_FUNCTION_TARGET:
        return validateBehaviorConstraintPrototype_functionTarget((BehaviorConstraintPrototype_functionTarget)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_HARDWARE_COMPONENT_TARGET:
        return validateBehaviorConstraintPrototype_hardwareComponentTarget((BehaviorConstraintPrototype_hardwareComponentTarget)value, diagnostics, context);
      case Eastadl21Package.ATTRIBUTE:
        return validateAttribute((Attribute)value, diagnostics, context);
      case Eastadl21Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
        return validateAttributeQuantificationConstraint((AttributeQuantificationConstraint)value, diagnostics, context);
      case Eastadl21Package.BEHAVIOR_ATTRIBUTE_BINDING:
        return validateBehaviorAttributeBinding((BehaviorAttributeBinding)value, diagnostics, context);
      case Eastadl21Package.LOGICAL_EVENT:
        return validateLogicalEvent((LogicalEvent)value, diagnostics, context);
      case Eastadl21Package.QUANTIFICATION:
        return validateQuantification((Quantification)value, diagnostics, context);
      case Eastadl21Package.COMPUTATION_CONSTRAINT:
        return validateComputationConstraint((ComputationConstraint)value, diagnostics, context);
      case Eastadl21Package.LOGICAL_PATH:
        return validateLogicalPath((LogicalPath)value, diagnostics, context);
      case Eastadl21Package.LOGICAL_TRANSFORMATION:
        return validateLogicalTransformation((LogicalTransformation)value, diagnostics, context);
      case Eastadl21Package.TRANSFORMATION_OCCURRENCE:
        return validateTransformationOccurrence((TransformationOccurrence)value, diagnostics, context);
      case Eastadl21Package.LOGICAL_TIME_CONDITION:
        return validateLogicalTimeCondition((LogicalTimeCondition)value, diagnostics, context);
      case Eastadl21Package.STATE:
        return validateState((State)value, diagnostics, context);
      case Eastadl21Package.STATE_EVENT:
        return validateStateEvent((StateEvent)value, diagnostics, context);
      case Eastadl21Package.SYNCHRONOUS_TRANSITION:
        return validateSynchronousTransition((SynchronousTransition)value, diagnostics, context);
      case Eastadl21Package.TEMPORAL_CONSTRAINT:
        return validateTemporalConstraint((TemporalConstraint)value, diagnostics, context);
      case Eastadl21Package.TRANSITION:
        return validateTransition((Transition)value, diagnostics, context);
      case Eastadl21Package.TRANSITION_EVENT:
        return validateTransitionEvent((TransitionEvent)value, diagnostics, context);
      case Eastadl21Package.ARCHITECTURAL_DESCRIPTION:
        return validateArchitecturalDescription((ArchitecturalDescription)value, diagnostics, context);
      case Eastadl21Package.ARCHITECTURAL_MODEL:
        return validateArchitecturalModel((ArchitecturalModel)value, diagnostics, context);
      case Eastadl21Package.ARCHITECTURE:
        return validateArchitecture((Architecture)value, diagnostics, context);
      case Eastadl21Package.CONCEPT:
        return validateConcept((Concept)value, diagnostics, context);
      case Eastadl21Package.MISSION:
        return validateMission((Mission)value, diagnostics, context);
      case Eastadl21Package.VEHICLE_SYSTEM:
        return validateVehicleSystem((VehicleSystem)value, diagnostics, context);
      case Eastadl21Package.STAKEHOLDER:
        return validateStakeholder((Stakeholder)value, diagnostics, context);
      case Eastadl21Package.STAKEHOLDER_NEED:
        return validateStakeholderNeed((StakeholderNeed)value, diagnostics, context);
      case Eastadl21Package.BUSINESS_OPPORTUNITY:
        return validateBusinessOpportunity((BusinessOpportunity)value, diagnostics, context);
      case Eastadl21Package.PROBLEM_STATEMENT:
        return validateProblemStatement((ProblemStatement)value, diagnostics, context);
      case Eastadl21Package.PRODUCT_POSITIONING:
        return validateProductPositioning((ProductPositioning)value, diagnostics, context);
      case Eastadl21Package.SYSTEM:
        return validateSystem((org.eclipse.eatop.eastadl21.System)value, diagnostics, context);
      case Eastadl21Package.TIMING_DESCRIPTION_EVENT:
        return validateTimingDescriptionEvent((TimingDescriptionEvent)value, diagnostics, context);
      case Eastadl21Package.BINDING_TIME_KIND:
        return validateBindingTimeKind((BindingTimeKind)value, diagnostics, context);
      case Eastadl21Package.VARIABILITY_DEPENDENCY_KIND:
        return validateVariabilityDependencyKind((VariabilityDependencyKind)value, diagnostics, context);
      case Eastadl21Package.DEVIATION_PERMISSION_KIND:
        return validateDeviationPermissionKind((DeviationPermissionKind)value, diagnostics, context);
      case Eastadl21Package.CLIENT_SERVER_KIND:
        return validateClientServerKind((ClientServerKind)value, diagnostics, context);
      case Eastadl21Package.EA_DIRECTION_KIND:
        return validateEADirectionKind((EADirectionKind)value, diagnostics, context);
      case Eastadl21Package.HARDWARE_BUS_KIND:
        return validateHardwareBusKind((HardwareBusKind)value, diagnostics, context);
      case Eastadl21Package.IO_HARDWARE_PIN_KIND:
        return validateIOHardwarePinKind((IOHardwarePinKind)value, diagnostics, context);
      case Eastadl21Package.FUNCTION_BEHAVIOR_KIND:
        return validateFunctionBehaviorKind((FunctionBehaviorKind)value, diagnostics, context);
      case Eastadl21Package.TRIGGER_POLICY_KIND:
        return validateTriggerPolicyKind((TriggerPolicyKind)value, diagnostics, context);
      case Eastadl21Package.QUALITY_REQUIREMENT_KIND:
        return validateQualityRequirementKind((QualityRequirementKind)value, diagnostics, context);
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_KIND:
        return validateEventFunctionClientServerPortKind((EventFunctionClientServerPortKind)value, diagnostics, context);
      case Eastadl21Package.COMPARISON_KIND:
        return validateComparisonKind((ComparisonKind)value, diagnostics, context);
      case Eastadl21Package.CONTROLLABILITY_CLASS_KIND:
        return validateControllabilityClassKind((ControllabilityClassKind)value, diagnostics, context);
      case Eastadl21Package.DEVELOPMENT_CATEGORY_KIND:
        return validateDevelopmentCategoryKind((DevelopmentCategoryKind)value, diagnostics, context);
      case Eastadl21Package.EXPOSURE_CLASS_KIND:
        return validateExposureClassKind((ExposureClassKind)value, diagnostics, context);
      case Eastadl21Package.SEVERITY_CLASS_KIND:
        return validateSeverityClassKind((SeverityClassKind)value, diagnostics, context);
      case Eastadl21Package.ASIL_KIND:
        return validateASILKind((ASILKind)value, diagnostics, context);
      case Eastadl21Package.ERROR_BEHAVIOR_KIND:
        return validateErrorBehaviorKind((ErrorBehaviorKind)value, diagnostics, context);
      case Eastadl21Package.LIFECYCLE_STAGE_KIND:
        return validateLifecycleStageKind((LifecycleStageKind)value, diagnostics, context);
      case Eastadl21Package.GENERIC_CONSTRAINT_KIND:
        return validateGenericConstraintKind((GenericConstraintKind)value, diagnostics, context);
      case Eastadl21Package.BOOLEAN:
        return validateBoolean((Boolean)value, diagnostics, context);
      case Eastadl21Package.FLOAT:
        return validateFloat((Double)value, diagnostics, context);
      case Eastadl21Package.IDENTIFIER:
        return validateIdentifier((String)value, diagnostics, context);
      case Eastadl21Package.INTEGER:
        return validateInteger((Integer)value, diagnostics, context);
      case Eastadl21Package.NUMERICAL:
        return validateNumerical((String)value, diagnostics, context);
      case Eastadl21Package.REF:
        return validateRef((String)value, diagnostics, context);
      case Eastadl21Package.STRING:
        return validateString((String)value, diagnostics, context);
      default:
        return true;
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVehicleLevel(VehicleLevel vehicleLevel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vehicleLevel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSystemModel(SystemModel systemModel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(systemModel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAnalysisLevel(AnalysisLevel analysisLevel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(analysisLevel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDesignLevel(DesignLevel designLevel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(designLevel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateImplementationLevel(ImplementationLevel implementationLevel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(implementationLevel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBindingTime(BindingTime bindingTime, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(bindingTime, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeature(Feature feature, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(feature, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureConstraint(FeatureConstraint featureConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureGroup(FeatureGroup featureGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureGroup, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureLink(FeatureLink featureLink, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureLink, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureModel(FeatureModel featureModel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureModel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureTreeNode(FeatureTreeNode featureTreeNode, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureTreeNode, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDeviationAttributeSet(DeviationAttributeSet deviationAttributeSet, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(deviationAttributeSet, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVehicleFeature(VehicleFeature vehicleFeature, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vehicleFeature, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAllocateableElement(AllocateableElement allocateableElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(allocateableElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAllocation(Allocation allocation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(allocation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAnalysisFunctionPrototype(AnalysisFunctionPrototype analysisFunctionPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(analysisFunctionPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAnalysisFunctionType(AnalysisFunctionType analysisFunctionType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(analysisFunctionType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBasicSoftwareFunctionType(BasicSoftwareFunctionType basicSoftwareFunctionType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(basicSoftwareFunctionType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDesignFunctionPrototype(DesignFunctionPrototype designFunctionPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(designFunctionPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDesignFunctionType(DesignFunctionType designFunctionType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(designFunctionType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionalDevice(FunctionalDevice functionalDevice, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionalDevice, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionAllocation(FunctionAllocation functionAllocation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionAllocation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionClientServerInterface(FunctionClientServerInterface functionClientServerInterface, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionClientServerInterface, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionClientServerPort(FunctionClientServerPort functionClientServerPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionClientServerPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionConnector(FunctionConnector functionConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionFlowPort(FunctionFlowPort functionFlowPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionFlowPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionPort(FunctionPort functionPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionPowerPort(FunctionPowerPort functionPowerPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionPowerPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionPrototype(FunctionPrototype functionPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionType(FunctionType functionType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwareFunctionType(HardwareFunctionType hardwareFunctionType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwareFunctionType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateLocalDeviceManager(LocalDeviceManager localDeviceManager, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(localDeviceManager, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateOperation(Operation operation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(operation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePortGroup(PortGroup portGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(portGroup, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionAllocation_allocatedElement(FunctionAllocation_allocatedElement functionAllocation_allocatedElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionAllocation_allocatedElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionAllocation_target(FunctionAllocation_target functionAllocation_target, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionAllocation_target, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionConnector_port(FunctionConnector_port functionConnector_port, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionConnector_port, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateActuator(Actuator actuator, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(actuator, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateCommunicationHardwarePin(CommunicationHardwarePin communicationHardwarePin, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(communicationHardwarePin, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateElectricalComponent(ElectricalComponent electricalComponent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(electricalComponent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwareComponentPrototype(HardwareComponentPrototype hardwareComponentPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwareComponentPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwareComponentType(HardwareComponentType hardwareComponentType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwareComponentType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwareConnector(HardwareConnector hardwareConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwareConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwarePin(HardwarePin hardwarePin, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwarePin, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwarePort(HardwarePort hardwarePort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwarePort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwarePortConnector(HardwarePortConnector hardwarePortConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwarePortConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateIOHardwarePin(IOHardwarePin ioHardwarePin, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(ioHardwarePin, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateNode(Node node, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(node, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePowerHardwarePin(PowerHardwarePin powerHardwarePin, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(powerHardwarePin, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSensor(Sensor sensor, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(sensor, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAllocationTarget(AllocationTarget allocationTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(allocationTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwareConnector_port(HardwareConnector_port hardwareConnector_port, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwareConnector_port, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwarePortConnector_port(HardwarePortConnector_port hardwarePortConnector_port, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hardwarePortConnector_port, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateClampConnector(ClampConnector clampConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(clampConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEnvironment(Environment environment, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(environment, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateClampConnector_port(ClampConnector_port clampConnector_port, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(clampConnector_port, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehavior(Behavior behavior, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behavior, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateMode(Mode mode, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(mode, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateModeGroup(ModeGroup modeGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(modeGroup, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionBehavior(FunctionBehavior functionBehavior, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionBehavior, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionTrigger(FunctionTrigger functionTrigger, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionTrigger, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateConfigurableContainer(ConfigurableContainer configurableContainer, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(configurableContainer, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateConfigurationDecision(ConfigurationDecision configurationDecision, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(configurationDecision, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateConfigurationDecisionFolder(ConfigurationDecisionFolder configurationDecisionFolder, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(configurationDecisionFolder, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateConfigurationDecisionModel(ConfigurationDecisionModel configurationDecisionModel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(configurationDecisionModel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateConfigurationDecisionModelEntry(ConfigurationDecisionModelEntry configurationDecisionModelEntry, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(configurationDecisionModelEntry, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateContainerConfiguration(ContainerConfiguration containerConfiguration, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(containerConfiguration, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureConfiguration(FeatureConfiguration featureConfiguration, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureConfiguration, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateInternalBinding(InternalBinding internalBinding, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(internalBinding, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePrivateContent(PrivateContent privateContent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(privateContent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateReuseMetaInformation(ReuseMetaInformation reuseMetaInformation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(reuseMetaInformation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSelectionCriterion(SelectionCriterion selectionCriterion, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(selectionCriterion, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVariability(Variability variability, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(variability, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVariableElement(VariableElement variableElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(variableElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVariationGroup(VariationGroup variationGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(variationGroup, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVehicleLevelBinding(VehicleLevelBinding vehicleLevelBinding, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vehicleLevelBinding, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDeriveRequirement(DeriveRequirement deriveRequirement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(deriveRequirement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateOperationalSituation(OperationalSituation operationalSituation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(operationalSituation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRequirementsModel(RequirementsModel requirementsModel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(requirementsModel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRequirementsRelationship(RequirementsRelationship requirementsRelationship, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(requirementsRelationship, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRequirement(Requirement requirement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(requirement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRequirementsHierarchy(RequirementsHierarchy requirementsHierarchy, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(requirementsHierarchy, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRefine(Refine refine, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(refine, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSatisfy(Satisfy satisfy, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(satisfy, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRequirementsLink(RequirementsLink requirementsLink, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(requirementsLink, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRequirementsRelationshipGroup(RequirementsRelationshipGroup requirementsRelationshipGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(requirementsRelationshipGroup, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQualityRequirement(QualityRequirement qualityRequirement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(qualityRequirement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRefine_refinedBy(Refine_refinedBy refine_refinedBy, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(refine_refinedBy, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSatisfy_satisfiedBy(Satisfy_satisfiedBy satisfy_satisfiedBy, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(satisfy_satisfiedBy, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateActor(Actor actor, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(actor, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateExtend(Extend extend, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(extend, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateExtensionPoint(ExtensionPoint extensionPoint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(extensionPoint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateInclude(Include include, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(include, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRedefinableElement(RedefinableElement redefinableElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(redefinableElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateUseCase(UseCase useCase, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(useCase, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVerificationValidation(VerificationValidation verificationValidation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(verificationValidation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVerify(Verify verify, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(verify, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVActualOutcome(VVActualOutcome vvActualOutcome, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvActualOutcome, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVCase(VVCase vvCase, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvCase, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVIntendedOutcome(VVIntendedOutcome vvIntendedOutcome, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvIntendedOutcome, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVLog(VVLog vvLog, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvLog, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVProcedure(VVProcedure vvProcedure, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvProcedure, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVStimuli(VVStimuli vvStimuli, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvStimuli, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVTarget(VVTarget vvTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVCase_vvSubject(VVCase_vvSubject vvCase_vvSubject, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvCase_vvSubject, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVVTarget_element(VVTarget_element vvTarget_element, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vvTarget_element, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEvent(Event event, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(event, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventChain(EventChain eventChain, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventChain, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePrecedenceConstraint(PrecedenceConstraint precedenceConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(precedenceConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTiming(Timing timing, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(timing, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTimingConstraint(TimingConstraint timingConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(timingConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTimingDescription(TimingDescription timingDescription, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(timingDescription, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTimingExpression(TimingExpression timingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(timingExpression, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAUTOSAREvent(AUTOSAREvent autosarEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(autosarEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFaultFailure(EventFaultFailure eventFaultFailure, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFaultFailure, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFeatureFlaw(EventFeatureFlaw eventFeatureFlaw, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFeatureFlaw, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunction(EventFunction eventFunction, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFunction, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunctionClientServerPort(EventFunctionClientServerPort eventFunctionClientServerPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFunctionClientServerPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunctionFlowPort(EventFunctionFlowPort eventFunctionFlowPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFunctionFlowPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateExternalEvent(ExternalEvent externalEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(externalEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateModeEvent(ModeEvent modeEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(modeEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunction_function(EventFunction_function eventFunction_function, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFunction_function, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunctionClientServerPort_port(EventFunctionClientServerPort_port eventFunctionClientServerPort_port, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFunctionClientServerPort_port, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunctionFlowPort_port(EventFunctionFlowPort_port eventFunctionFlowPort_port, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eventFunctionFlowPort_port, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAgeConstraint(AgeConstraint ageConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(ageConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateArbitraryConstraint(ArbitraryConstraint arbitraryConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(arbitraryConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBurstConstraint(BurstConstraint burstConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(burstConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateComparisonConstraint(ComparisonConstraint comparisonConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(comparisonConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDelayConstraint(DelayConstraint delayConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(delayConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateExecutionTimeConstraint(ExecutionTimeConstraint executionTimeConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(executionTimeConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateInputSynchronizationConstraint(InputSynchronizationConstraint inputSynchronizationConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(inputSynchronizationConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateOrderConstraint(OrderConstraint orderConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(orderConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateOutputSynchronizationConstraint(OutputSynchronizationConstraint outputSynchronizationConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(outputSynchronizationConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePatternConstraint(PatternConstraint patternConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(patternConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePeriodicConstraint(PeriodicConstraint periodicConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(periodicConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateReactionConstraint(ReactionConstraint reactionConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(reactionConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRepetitionConstraint(RepetitionConstraint repetitionConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(repetitionConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSporadicConstraint(SporadicConstraint sporadicConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(sporadicConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateStrongDelayConstraint(StrongDelayConstraint strongDelayConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(strongDelayConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateStrongSynchronizationConstraint(StrongSynchronizationConstraint strongSynchronizationConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(strongSynchronizationConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSynchronizationConstraint(SynchronizationConstraint synchronizationConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(synchronizationConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePrecedenceConstraint_preceding(PrecedenceConstraint_preceding precedenceConstraint_preceding, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(precedenceConstraint_preceding, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePrecedenceConstraint_successive(PrecedenceConstraint_successive precedenceConstraint_successive, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(precedenceConstraint_successive, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDependability(Dependability dependability, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(dependability, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFeatureFlaw(FeatureFlaw featureFlaw, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(featureFlaw, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHazard(Hazard hazard, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hazard, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHazardousEvent(HazardousEvent hazardousEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(hazardousEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateItem(Item item, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(item, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailure(FaultFailure faultFailure, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailure, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantitativeSafetyConstraint(QuantitativeSafetyConstraint quantitativeSafetyConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(quantitativeSafetyConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSafetyConstraint(SafetyConstraint safetyConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(safetyConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailure_anomaly(FaultFailure_anomaly faultFailure_anomaly, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailure_anomaly, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAnomaly(Anomaly anomaly, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(anomaly, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateErrorBehavior(ErrorBehavior errorBehavior, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(errorBehavior, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateErrorModelPrototype(ErrorModelPrototype errorModelPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(errorModelPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateErrorModelType(ErrorModelType errorModelType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(errorModelType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFailureOutPort(FailureOutPort failureOutPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(failureOutPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailurePort(FaultFailurePort faultFailurePort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailurePort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailurePropagationLink(FaultFailurePropagationLink faultFailurePropagationLink, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailurePropagationLink, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultInPort(FaultInPort faultInPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultInPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateInternalFaultPrototype(InternalFaultPrototype internalFaultPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(internalFaultPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateProcessFaultPrototype(ProcessFaultPrototype processFaultPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(processFaultPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateErrorModelPrototype_functionTarget(ErrorModelPrototype_functionTarget errorModelPrototype_functionTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(errorModelPrototype_functionTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateErrorModelPrototype_hwTarget(ErrorModelPrototype_hwTarget errorModelPrototype_hwTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(errorModelPrototype_hwTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailurePort_functionTarget(FaultFailurePort_functionTarget faultFailurePort_functionTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailurePort_functionTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailurePort_hwTarget(FaultFailurePort_hwTarget faultFailurePort_hwTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailurePort_hwTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailurePropagationLink_fromPort(FaultFailurePropagationLink_fromPort faultFailurePropagationLink_fromPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailurePropagationLink_fromPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFaultFailurePropagationLink_toPort(FaultFailurePropagationLink_toPort faultFailurePropagationLink_toPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(faultFailurePropagationLink_toPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionalSafetyConcept(FunctionalSafetyConcept functionalSafetyConcept, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(functionalSafetyConcept, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSafetyGoal(SafetyGoal safetyGoal, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(safetyGoal, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTechnicalSafetyConcept(TechnicalSafetyConcept technicalSafetyConcept, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(technicalSafetyConcept, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateClaim(Claim claim, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(claim, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateGround(Ground ground, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(ground, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSafetyCase(SafetyCase safetyCase, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(safetyCase, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateWarrant(Warrant warrant, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(warrant, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateGenericConstraint(GenericConstraint genericConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(genericConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateGenericConstraintSet(GenericConstraintSet genericConstraintSet, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(genericConstraintSet, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTakeRateConstraint(TakeRateConstraint takeRateConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(takeRateConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateComment(Comment comment, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(comment, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateContext(Context context, DiagnosticChain diagnostics, Map<Object, Object> theContext)
  {
    return validate_EveryDefaultConstraint(context, diagnostics, theContext);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAConnector(EAConnector eaConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAElement(EAElement eaElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAPackage(EAPackage eaPackage, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaPackage, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAPackageableElement(EAPackageableElement eaPackageableElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaPackageableElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAPort(EAPort eaPort, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaPort, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAPrototype(EAPrototype eaPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAType(EAType eaType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAXML(EAXML eaxml, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaxml, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRationale(Rationale rationale, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(rationale, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRealization(Realization realization, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(realization, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateReferrable(Referrable referrable, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(referrable, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRelationship(Relationship relationship, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(relationship, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTraceableSpecification(TraceableSpecification traceableSpecification, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(traceableSpecification, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateIdentifiable(Identifiable identifiable, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(identifiable, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRealization_realized(Realization_realized realization_realized, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(realization_realized, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRealization_realizedBy(Realization_realizedBy realization_realizedBy, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(realization_realizedBy, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateArrayDatatype(ArrayDatatype arrayDatatype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(arrayDatatype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateCompositeDatatype(CompositeDatatype compositeDatatype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(compositeDatatype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEABoolean(EABoolean eaBoolean, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaBoolean, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEADatatype(EADatatype eaDatatype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaDatatype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEADatatypePrototype(EADatatypePrototype eaDatatypePrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaDatatypePrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEANumerical(EANumerical eaNumerical, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaNumerical, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAString(EAString eaString, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaString, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEnumeration(Enumeration enumeration, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(enumeration, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEnumerationLiteral(EnumerationLiteral enumerationLiteral, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(enumerationLiteral, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantity(Quantity quantity, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(quantity, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRangeableValueType(RangeableValueType rangeableValueType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(rangeableValueType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateUnit(Unit unit, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(unit, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAArrayValue(EAArrayValue eaArrayValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaArrayValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEABooleanValue(EABooleanValue eaBooleanValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaBooleanValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEACompositeValue(EACompositeValue eaCompositeValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaCompositeValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAEnumerationValue(EAEnumerationValue eaEnumerationValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaEnumerationValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAExpression(EAExpression eaExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaExpression, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEANumericalValue(EANumericalValue eaNumericalValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaNumericalValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAStringValue(EAStringValue eaStringValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaStringValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEAValue(EAValue eaValue, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(eaValue, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateUserAttributeDefinition(UserAttributeDefinition userAttributeDefinition, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(userAttributeDefinition, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateUserAttributedElement(UserAttributedElement userAttributedElement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(userAttributedElement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateUserElementType(UserElementType userElementType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(userElementType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintBindingAttribute(BehaviorConstraintBindingAttribute behaviorConstraintBindingAttribute, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintBindingAttribute, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintBindingEvent(BehaviorConstraintBindingEvent behaviorConstraintBindingEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintBindingEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintInternalBinding(BehaviorConstraintInternalBinding behaviorConstraintInternalBinding, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintInternalBinding, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintParameter(BehaviorConstraintParameter behaviorConstraintParameter, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintParameter, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintPrototype(BehaviorConstraintPrototype behaviorConstraintPrototype, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintPrototype, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintTargetBinding(BehaviorConstraintTargetBinding behaviorConstraintTargetBinding, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintTargetBinding, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintType(BehaviorConstraintType behaviorConstraintType, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintType, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintInternalBinding_bindingThroughFunctionConnector(BehaviorConstraintInternalBinding_bindingThroughFunctionConnector behaviorConstraintInternalBinding_bindingThroughFunctionConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintInternalBinding_bindingThroughFunctionConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintInternalBinding_bindingThroughHardwareConnector(BehaviorConstraintInternalBinding_bindingThroughHardwareConnector behaviorConstraintInternalBinding_bindingThroughHardwareConnector, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintInternalBinding_bindingThroughHardwareConnector, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintPrototype_errorModelTarget(BehaviorConstraintPrototype_errorModelTarget behaviorConstraintPrototype_errorModelTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintPrototype_errorModelTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintPrototype_functionTarget(BehaviorConstraintPrototype_functionTarget behaviorConstraintPrototype_functionTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintPrototype_functionTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorConstraintPrototype_hardwareComponentTarget(BehaviorConstraintPrototype_hardwareComponentTarget behaviorConstraintPrototype_hardwareComponentTarget, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorConstraintPrototype_hardwareComponentTarget, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAttribute(Attribute attribute, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(attribute, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateAttributeQuantificationConstraint(AttributeQuantificationConstraint attributeQuantificationConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(attributeQuantificationConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBehaviorAttributeBinding(BehaviorAttributeBinding behaviorAttributeBinding, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(behaviorAttributeBinding, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateLogicalEvent(LogicalEvent logicalEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(logicalEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantification(Quantification quantification, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(quantification, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateComputationConstraint(ComputationConstraint computationConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(computationConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateLogicalPath(LogicalPath logicalPath, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(logicalPath, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateLogicalTransformation(LogicalTransformation logicalTransformation, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(logicalTransformation, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTransformationOccurrence(TransformationOccurrence transformationOccurrence, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(transformationOccurrence, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateLogicalTimeCondition(LogicalTimeCondition logicalTimeCondition, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(logicalTimeCondition, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateState(State state, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(state, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateStateEvent(StateEvent stateEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(stateEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSynchronousTransition(SynchronousTransition synchronousTransition, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(synchronousTransition, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTemporalConstraint(TemporalConstraint temporalConstraint, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(temporalConstraint, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTransition(Transition transition, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(transition, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTransitionEvent(TransitionEvent transitionEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(transitionEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateArchitecturalDescription(ArchitecturalDescription architecturalDescription, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(architecturalDescription, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateArchitecturalModel(ArchitecturalModel architecturalModel, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(architecturalModel, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateArchitecture(Architecture architecture, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(architecture, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateConcept(Concept concept, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(concept, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateMission(Mission mission, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(mission, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVehicleSystem(VehicleSystem vehicleSystem, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(vehicleSystem, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateStakeholder(Stakeholder stakeholder, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(stakeholder, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateStakeholderNeed(StakeholderNeed stakeholderNeed, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(stakeholderNeed, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBusinessOpportunity(BusinessOpportunity businessOpportunity, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(businessOpportunity, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateProblemStatement(ProblemStatement problemStatement, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(problemStatement, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateProductPositioning(ProductPositioning productPositioning, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(productPositioning, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSystem(org.eclipse.eatop.eastadl21.System system, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(system, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTimingDescriptionEvent(TimingDescriptionEvent timingDescriptionEvent, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validate_EveryDefaultConstraint(timingDescriptionEvent, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBindingTimeKind(BindingTimeKind bindingTimeKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateVariabilityDependencyKind(VariabilityDependencyKind variabilityDependencyKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDeviationPermissionKind(DeviationPermissionKind deviationPermissionKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateClientServerKind(ClientServerKind clientServerKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEADirectionKind(EADirectionKind eaDirectionKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateHardwareBusKind(HardwareBusKind hardwareBusKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateIOHardwarePinKind(IOHardwarePinKind ioHardwarePinKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFunctionBehaviorKind(FunctionBehaviorKind functionBehaviorKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateTriggerPolicyKind(TriggerPolicyKind triggerPolicyKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQualityRequirementKind(QualityRequirementKind qualityRequirementKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateEventFunctionClientServerPortKind(EventFunctionClientServerPortKind eventFunctionClientServerPortKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateComparisonKind(ComparisonKind comparisonKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateControllabilityClassKind(ControllabilityClassKind controllabilityClassKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDevelopmentCategoryKind(DevelopmentCategoryKind developmentCategoryKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateExposureClassKind(ExposureClassKind exposureClassKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSeverityClassKind(SeverityClassKind severityClassKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateASILKind(ASILKind asilKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateErrorBehaviorKind(ErrorBehaviorKind errorBehaviorKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateLifecycleStageKind(LifecycleStageKind lifecycleStageKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateGenericConstraintKind(GenericConstraintKind genericConstraintKind, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBoolean(Boolean boolean_, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    boolean result = validateBoolean_Pattern(boolean_, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateBoolean_Pattern
   */
  public static final  PatternMatcher [][] BOOLEAN__PATTERN__VALUES =
    new PatternMatcher [][]
    {
      new PatternMatcher []
      {
        XMLTypeUtil.createPatternMatcher("0|1|true|false")
      }
    };

  /**
   * Validates the Pattern constraint of '<em>Boolean</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateBoolean_Pattern(Boolean boolean_, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validatePattern(Eastadl21Package.eINSTANCE.getBoolean(), boolean_, BOOLEAN__PATTERN__VALUES, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateFloat(Double float_, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateIdentifier(String identifier, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    boolean result = validateIdentifier_Pattern(identifier, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateIdentifier_Pattern
   */
  public static final  PatternMatcher [][] IDENTIFIER__PATTERN__VALUES =
    new PatternMatcher [][]
    {
      new PatternMatcher []
      {
        XMLTypeUtil.createPatternMatcher("[a-zA-Z]([a-zA-Z0-9]|_[a-zA-Z0-9])*_?")
      }
    };

  /**
   * Validates the Pattern constraint of '<em>Identifier</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateIdentifier_Pattern(String identifier, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validatePattern(Eastadl21Package.eINSTANCE.getIdentifier(), identifier, IDENTIFIER__PATTERN__VALUES, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateInteger(Integer integer, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    boolean result = validateInteger_Pattern(integer, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateInteger_Pattern
   */
  public static final  PatternMatcher [][] INTEGER__PATTERN__VALUES =
    new PatternMatcher [][]
    {
      new PatternMatcher []
      {
        XMLTypeUtil.createPatternMatcher("[+\\-]?[1-9][0-9]*|0x[0-9a-f]*|0[0-7]*|0b[0-1]*")
      }
    };

  /**
   * Validates the Pattern constraint of '<em>Integer</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateInteger_Pattern(Integer integer, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validatePattern(Eastadl21Package.eINSTANCE.getInteger(), integer, INTEGER__PATTERN__VALUES, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateNumerical(String numerical, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    boolean result = validateNumerical_Pattern(numerical, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateNumerical_Pattern
   */
  public static final  PatternMatcher [][] NUMERICAL__PATTERN__VALUES =
    new PatternMatcher [][]
    {
      new PatternMatcher []
      {
        XMLTypeUtil.createPatternMatcher("(0x[0-9a-f]*)|(0[1-7][0-7]*)|(0b[0-1]*)|([+\\-]?[0-9]+(\\.[0-9]*)?(E([+\\-]?)[0-9]*)?)")
      }
    };

  /**
   * Validates the Pattern constraint of '<em>Numerical</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateNumerical_Pattern(String numerical, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validatePattern(Eastadl21Package.eINSTANCE.getNumerical(), numerical, NUMERICAL__PATTERN__VALUES, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRef(String ref, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    boolean result = validateRef_Pattern(ref, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateRef_Pattern
   */
  public static final  PatternMatcher [][] REF__PATTERN__VALUES =
    new PatternMatcher [][]
    {
      new PatternMatcher []
      {
        XMLTypeUtil.createPatternMatcher("/?[a-zA-Z][a-zA-Z0-9_]{0,127}(/[a-zA-Z][a-zA-Z0-9_]{0,127})*")
      }
    };

  /**
   * Validates the Pattern constraint of '<em>Ref</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateRef_Pattern(String ref, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return validatePattern(Eastadl21Package.eINSTANCE.getRef(), ref, REF__PATTERN__VALUES, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateString(String string, DiagnosticChain diagnostics, Map<Object, Object> context)
  {
    return true;
  }

  /**
   * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public ResourceLocator getResourceLocator()
  {
    return Activator.INSTANCE;
  }

} //Eastadl21Validator
