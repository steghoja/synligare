/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Event class stands for all the forms of identifiable state changes that are possible to constrain with respect to timing using TADL2.
 * 
 * Semantics:
 * An event denotes a distinct form of state change in a running system, taking place at distinct points in time called occurrence of the event. That is, a running system can be observed by identifying certain forms of state changes to watch for, and for each such observation point, noting the times when changes occur. This notion of observation also applies to a hypothetical predicted run of a system or a system model - from a timing perspective, the only information that needs to be in the output of such a prediction is a sequence of times for each observation point, indicating the times that each event is predicted to occur.
 * 
 * In system models, events appear syntactically as names indicating the state changes of interest. Semantically, an event name is a variable standing for some statically unknown set of occurrences. Note that this connection is purely conceptual; occurrences never exist concretely in any system model as they are a purely semantic notion representing the state changes that can be observed when a system is executed, or simulated, or perhaps only mathematically predicted.
 * 
 * TADL2 assumes that occurrences are characterized by two pieces of information: a timestamp indicating when the corresponding state change occurred, and a color that partitions different event occurrences into groups that should be understood as being causally related. The timestamp is a real value of SI unit seconds, whereas the color value is drawn from some abstract, possibly infinite type whose only restriction is that must support an equality test on its values.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Event</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEvent()
 * @model abstract="true"
 *        annotation="MetaData guid='{0DBBF893-62B0-4b5c-9114-81B9149DCD65}' id='207926920' EA\040name='Event'"
 *        extendedMetaData="name='EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENTS'"
 * @generated
 */
public interface Event extends TimingDescription
{
} // Event
