/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;
import org.eclipse.eatop.eastadl21.FaultFailurePort;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fault Failure Propagation Link from Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FaultFailurePropagationLink_fromPortImpl#getFaultFailurePort <em>Fault Failure Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FaultFailurePropagationLink_fromPortImpl#getErrorModelPrototype <em>Error Model Prototype</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FaultFailurePropagationLink_fromPortImpl extends ExtendedEObjectImpl implements FaultFailurePropagationLink_fromPort
{
  /**
   * The cached value of the '{@link #getFaultFailurePort() <em>Fault Failure Port</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFaultFailurePort()
   * @generated
   * @ordered
   */
  protected FaultFailurePort faultFailurePort;

  /**
   * The cached value of the '{@link #getErrorModelPrototype() <em>Error Model Prototype</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getErrorModelPrototype()
   * @generated
   * @ordered
   */
  protected EList<ErrorModelPrototype> errorModelPrototype;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected FaultFailurePropagationLink_fromPortImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getFaultFailurePropagationLink_fromPort();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePort getFaultFailurePort()
  {
    if (faultFailurePort != null && faultFailurePort.eIsProxy())
    {
      InternalEObject oldFaultFailurePort = (InternalEObject)faultFailurePort;
      faultFailurePort = (FaultFailurePort)eResolveProxy(oldFaultFailurePort);
      if (faultFailurePort != oldFaultFailurePort)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__FAULT_FAILURE_PORT, oldFaultFailurePort, faultFailurePort));
      }
    }
    return faultFailurePort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FaultFailurePort basicGetFaultFailurePort()
  {
    return faultFailurePort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFaultFailurePort(FaultFailurePort newFaultFailurePort)
  {
    FaultFailurePort oldFaultFailurePort = faultFailurePort;
    faultFailurePort = newFaultFailurePort;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__FAULT_FAILURE_PORT, oldFaultFailurePort, faultFailurePort));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ErrorModelPrototype> getErrorModelPrototype()
  {
    if (errorModelPrototype == null)
    {
      errorModelPrototype = new EObjectResolvingEList<ErrorModelPrototype>(ErrorModelPrototype.class, this, Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__ERROR_MODEL_PROTOTYPE);
    }
    return errorModelPrototype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__FAULT_FAILURE_PORT:
        if (resolve) return getFaultFailurePort();
        return basicGetFaultFailurePort();
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__ERROR_MODEL_PROTOTYPE:
        return getErrorModelPrototype();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__FAULT_FAILURE_PORT:
   			setFaultFailurePort((FaultFailurePort)newValue);
        return;
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__ERROR_MODEL_PROTOTYPE:
        getErrorModelPrototype().clear();
        getErrorModelPrototype().addAll((Collection<? extends ErrorModelPrototype>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__FAULT_FAILURE_PORT:
        	setFaultFailurePort((FaultFailurePort)null);
        return;
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__ERROR_MODEL_PROTOTYPE:
        getErrorModelPrototype().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__FAULT_FAILURE_PORT:
        return faultFailurePort != null;
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT__ERROR_MODEL_PROTOTYPE:
        return errorModelPrototype != null && !errorModelPrototype.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //FaultFailurePropagationLink_fromPortImpl
