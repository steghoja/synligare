/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure Propagation Link from Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel._instanceRef.FaultFailurePropagationLink_fromPort</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort#getFaultFailurePort <em>Fault Failure Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort#getErrorModelPrototype <em>Error Model Prototype</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink_fromPort()
 * @model annotation="MetaData guid='{015A7DCE-E556-4836-AF16-71450B207B85}' id='-1326193498' EA\040name='FaultFailurePropagationLink_fromPort'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='FAULT-FAILURE-PROPAGATION-LINK--FROM-PORT-IREF'"
 *        extendedMetaData="name='FAULT-FAILURE-PROPAGATION-LINK--FROM-PORT-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-PROPAGATION-LINK--FROM-PORT-IREFS'"
 * @generated
 */
public interface FaultFailurePropagationLink_fromPort extends EObject
{
  /**
   * Returns the value of the '<em><b>Fault Failure Port</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Fault Failure Port</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Fault Failure Port</em>' reference.
   * @see #setFaultFailurePort(FaultFailurePort)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink_fromPort_FaultFailurePort()
   * @model required="true"
   *        annotation="MetaData guid='{468C1B84-5FFF-477e-9FDB-2F54D9236ED7}' id='-480777964' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FAULT-FAILURE-PORT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-PORT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FaultFailurePort getFaultFailurePort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort#getFaultFailurePort <em>Fault Failure Port</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Fault Failure Port</em>' reference.
   * @see #getFaultFailurePort()
   * @generated
   */
  void setFaultFailurePort(FaultFailurePort value);

  /**
   * Returns the value of the '<em><b>Error Model Prototype</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.ErrorModelPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Error Model Prototype</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Error Model Prototype</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePropagationLink_fromPort_ErrorModelPrototype()
   * @model annotation="MetaData guid='{A1287D0B-09E1-4402-B513-00CBB87AFB01}' id='201289790' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='ERROR-MODEL-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<ErrorModelPrototype> getErrorModelPrototype();

} // FaultFailurePropagationLink_fromPort
