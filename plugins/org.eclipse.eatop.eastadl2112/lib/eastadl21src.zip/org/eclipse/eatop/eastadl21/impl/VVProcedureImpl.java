/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.VVIntendedOutcome;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.VVStimuli;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VV Procedure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVProcedureImpl#getVvStimuli <em>Vv Stimuli</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVProcedureImpl#getVvIntendedOutcome <em>Vv Intended Outcome</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVProcedureImpl#getAbstractVVProcedure <em>Abstract VV Procedure</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VVProcedureImpl extends TraceableSpecificationImpl implements VVProcedure
{
  /**
   * The cached value of the '{@link #getVvStimuli() <em>Vv Stimuli</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvStimuli()
   * @generated
   * @ordered
   */
  protected EList<VVStimuli> vvStimuli;

  /**
   * The cached value of the '{@link #getVvIntendedOutcome() <em>Vv Intended Outcome</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvIntendedOutcome()
   * @generated
   * @ordered
   */
  protected EList<VVIntendedOutcome> vvIntendedOutcome;

  /**
   * The cached value of the '{@link #getAbstractVVProcedure() <em>Abstract VV Procedure</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAbstractVVProcedure()
   * @generated
   * @ordered
   */
  protected VVProcedure abstractVVProcedure;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VVProcedureImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getVVProcedure();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVStimuli> getVvStimuli()
  {
    if (vvStimuli == null)
    {
      vvStimuli = new EObjectContainmentEList<VVStimuli>(VVStimuli.class, this, Eastadl21Package.VV_PROCEDURE__VV_STIMULI);
    }
    return vvStimuli;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVIntendedOutcome> getVvIntendedOutcome()
  {
    if (vvIntendedOutcome == null)
    {
      vvIntendedOutcome = new EObjectContainmentEList<VVIntendedOutcome>(VVIntendedOutcome.class, this, Eastadl21Package.VV_PROCEDURE__VV_INTENDED_OUTCOME);
    }
    return vvIntendedOutcome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVProcedure getAbstractVVProcedure()
  {
    if (abstractVVProcedure != null && abstractVVProcedure.eIsProxy())
    {
      InternalEObject oldAbstractVVProcedure = (InternalEObject)abstractVVProcedure;
      abstractVVProcedure = (VVProcedure)eResolveProxy(oldAbstractVVProcedure);
      if (abstractVVProcedure != oldAbstractVVProcedure)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.VV_PROCEDURE__ABSTRACT_VV_PROCEDURE, oldAbstractVVProcedure, abstractVVProcedure));
      }
    }
    return abstractVVProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVProcedure basicGetAbstractVVProcedure()
  {
    return abstractVVProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAbstractVVProcedure(VVProcedure newAbstractVVProcedure)
  {
    VVProcedure oldAbstractVVProcedure = abstractVVProcedure;
    abstractVVProcedure = newAbstractVVProcedure;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.VV_PROCEDURE__ABSTRACT_VV_PROCEDURE, oldAbstractVVProcedure, abstractVVProcedure));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_PROCEDURE__VV_STIMULI:
        return ((InternalEList<?>)getVvStimuli()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.VV_PROCEDURE__VV_INTENDED_OUTCOME:
        return ((InternalEList<?>)getVvIntendedOutcome()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_PROCEDURE__VV_STIMULI:
        return getVvStimuli();
      case Eastadl21Package.VV_PROCEDURE__VV_INTENDED_OUTCOME:
        return getVvIntendedOutcome();
      case Eastadl21Package.VV_PROCEDURE__ABSTRACT_VV_PROCEDURE:
        if (resolve) return getAbstractVVProcedure();
        return basicGetAbstractVVProcedure();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_PROCEDURE__VV_STIMULI:
        getVvStimuli().clear();
        getVvStimuli().addAll((Collection<? extends VVStimuli>)newValue);
        return;
      case Eastadl21Package.VV_PROCEDURE__VV_INTENDED_OUTCOME:
        getVvIntendedOutcome().clear();
        getVvIntendedOutcome().addAll((Collection<? extends VVIntendedOutcome>)newValue);
        return;
      case Eastadl21Package.VV_PROCEDURE__ABSTRACT_VV_PROCEDURE:
   			setAbstractVVProcedure((VVProcedure)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_PROCEDURE__VV_STIMULI:
        getVvStimuli().clear();
        return;
      case Eastadl21Package.VV_PROCEDURE__VV_INTENDED_OUTCOME:
        getVvIntendedOutcome().clear();
        return;
      case Eastadl21Package.VV_PROCEDURE__ABSTRACT_VV_PROCEDURE:
        	setAbstractVVProcedure((VVProcedure)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_PROCEDURE__VV_STIMULI:
        return vvStimuli != null && !vvStimuli.isEmpty();
      case Eastadl21Package.VV_PROCEDURE__VV_INTENDED_OUTCOME:
        return vvIntendedOutcome != null && !vvIntendedOutcome.isEmpty();
      case Eastadl21Package.VV_PROCEDURE__ABSTRACT_VV_PROCEDURE:
        return abstractVVProcedure != null;
    }
    return super.eIsSet(featureID);
  }

} //VVProcedureImpl
