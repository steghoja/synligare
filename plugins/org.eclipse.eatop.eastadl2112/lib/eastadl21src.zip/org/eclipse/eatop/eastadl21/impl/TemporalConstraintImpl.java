/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.State;
import org.eclipse.eatop.eastadl21.TemporalConstraint;
import org.eclipse.eatop.eastadl21.Transition;
import org.eclipse.eatop.eastadl21.TransitionEvent;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Temporal Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TemporalConstraintImpl#getAssertion <em>Assertion</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TemporalConstraintImpl#getTimeCondition <em>Time Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TemporalConstraintImpl#getTransitionEvent <em>Transition Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TemporalConstraintImpl#getTransition <em>Transition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TemporalConstraintImpl#getInitState <em>Init State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TemporalConstraintImpl#getState <em>State</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TemporalConstraintImpl extends EAElementImpl implements TemporalConstraint
{
  /**
   * The cached value of the '{@link #getAssertion() <em>Assertion</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAssertion()
   * @generated
   * @ordered
   */
  protected EAExpression assertion;

  /**
   * The cached value of the '{@link #getTimeCondition() <em>Time Condition</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTimeCondition()
   * @generated
   * @ordered
   */
  protected EList<LogicalTimeCondition> timeCondition;

  /**
   * The cached value of the '{@link #getTransitionEvent() <em>Transition Event</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTransitionEvent()
   * @generated
   * @ordered
   */
  protected EList<TransitionEvent> transitionEvent;

  /**
   * The cached value of the '{@link #getTransition() <em>Transition</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTransition()
   * @generated
   * @ordered
   */
  protected EList<Transition> transition;

  /**
   * The cached value of the '{@link #getInitState() <em>Init State</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInitState()
   * @generated
   * @ordered
   */
  protected State initState;

  /**
   * The cached value of the '{@link #getState() <em>State</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getState()
   * @generated
   * @ordered
   */
  protected EList<State> state;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected TemporalConstraintImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getTemporalConstraint();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAExpression getAssertion()
  {
    return assertion;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetAssertion(EAExpression newAssertion, NotificationChain msgs)
  {
    EAExpression oldAssertion = assertion;
    assertion = newAssertion;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION, oldAssertion, newAssertion);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAssertion(EAExpression newAssertion)
  {
    if (newAssertion != assertion)
    {
      NotificationChain msgs = null;
      if (assertion != null)
        msgs = ((InternalEObject)assertion).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION, null, msgs);
      if (newAssertion != null)
        msgs = ((InternalEObject)newAssertion).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION, null, msgs);
      msgs = basicSetAssertion(newAssertion, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION, newAssertion, newAssertion));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<LogicalTimeCondition> getTimeCondition()
  {
    if (timeCondition == null)
    {
      timeCondition = new EObjectContainmentEList<LogicalTimeCondition>(LogicalTimeCondition.class, this, Eastadl21Package.TEMPORAL_CONSTRAINT__TIME_CONDITION);
    }
    return timeCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<TransitionEvent> getTransitionEvent()
  {
    if (transitionEvent == null)
    {
      transitionEvent = new EObjectContainmentEList<TransitionEvent>(TransitionEvent.class, this, Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION_EVENT);
    }
    return transitionEvent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Transition> getTransition()
  {
    if (transition == null)
    {
      transition = new EObjectContainmentEList<Transition>(Transition.class, this, Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION);
    }
    return transition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public State getInitState()
  {
    if (initState != null && initState.eIsProxy())
    {
      InternalEObject oldInitState = (InternalEObject)initState;
      initState = (State)eResolveProxy(oldInitState);
      if (initState != oldInitState)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.TEMPORAL_CONSTRAINT__INIT_STATE, oldInitState, initState));
      }
    }
    return initState;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public State basicGetInitState()
  {
    return initState;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInitState(State newInitState)
  {
    State oldInitState = initState;
    initState = newInitState;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.TEMPORAL_CONSTRAINT__INIT_STATE, oldInitState, initState));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<State> getState()
  {
    if (state == null)
    {
      state = new EObjectContainmentEList<State>(State.class, this, Eastadl21Package.TEMPORAL_CONSTRAINT__STATE);
    }
    return state;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION:
        return basicSetAssertion(null, msgs);
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TIME_CONDITION:
        return ((InternalEList<?>)getTimeCondition()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION_EVENT:
        return ((InternalEList<?>)getTransitionEvent()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION:
        return ((InternalEList<?>)getTransition()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.TEMPORAL_CONSTRAINT__STATE:
        return ((InternalEList<?>)getState()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION:
        return getAssertion();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TIME_CONDITION:
        return getTimeCondition();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION_EVENT:
        return getTransitionEvent();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION:
        return getTransition();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__INIT_STATE:
        if (resolve) return getInitState();
        return basicGetInitState();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__STATE:
        return getState();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION:
   			setAssertion((EAExpression)newValue);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TIME_CONDITION:
        getTimeCondition().clear();
        getTimeCondition().addAll((Collection<? extends LogicalTimeCondition>)newValue);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION_EVENT:
        getTransitionEvent().clear();
        getTransitionEvent().addAll((Collection<? extends TransitionEvent>)newValue);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION:
        getTransition().clear();
        getTransition().addAll((Collection<? extends Transition>)newValue);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__INIT_STATE:
   			setInitState((State)newValue);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__STATE:
        getState().clear();
        getState().addAll((Collection<? extends State>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION:
        	setAssertion((EAExpression)null);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TIME_CONDITION:
        getTimeCondition().clear();
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION_EVENT:
        getTransitionEvent().clear();
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION:
        getTransition().clear();
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__INIT_STATE:
        	setInitState((State)null);
        return;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__STATE:
        getState().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.TEMPORAL_CONSTRAINT__ASSERTION:
        return assertion != null;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TIME_CONDITION:
        return timeCondition != null && !timeCondition.isEmpty();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION_EVENT:
        return transitionEvent != null && !transitionEvent.isEmpty();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__TRANSITION:
        return transition != null && !transition.isEmpty();
      case Eastadl21Package.TEMPORAL_CONSTRAINT__INIT_STATE:
        return initState != null;
      case Eastadl21Package.TEMPORAL_CONSTRAINT__STATE:
        return state != null && !state.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //TemporalConstraintImpl
