/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Include</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Include is a specialization of the Relationship and represents a relationship between two UseCases, implying that the behavior of the included UseCase is inserted into the behavior of the including UseCase. The including UseCase may only depend on the result (value) of the included UseCase. This value is obtained as a result of the execution of the included UseCase. Note that the included UseCase is not optional and is always required for the including UseCase to execute correctly.
 * 
 * Semantics:
 * The Include relationship identifies an addition UseCase, which is inserted in the including UseCase.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.UseCases.Include</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Include#getAddition <em>Addition</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getInclude()
 * @model annotation="MetaData guid='{25607FCA-9F63-4d8b-9F9B-FCF79200D3C8}' id='1342016794' EA\040name='Include'"
 *        extendedMetaData="name='INCLUDE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INCLUDES'"
 * @generated
 */
public interface Include extends Relationship
{
  /**
   * Returns the value of the '<em><b>Addition</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Addition</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Addition</em>' reference.
   * @see #setAddition(UseCase)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getInclude_Addition()
   * @model required="true"
   *        annotation="MetaData guid='{25E96C14-3D16-4336-B9DD-8C22F048B2F6}' id='61521155' EA\040name=''"
   *        extendedMetaData="name='ADDITION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ADDITION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  UseCase getAddition();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Include#getAddition <em>Addition</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Addition</em>' reference.
   * @see #getAddition()
   * @generated
   */
  void setAddition(UseCase value);

} // Include
