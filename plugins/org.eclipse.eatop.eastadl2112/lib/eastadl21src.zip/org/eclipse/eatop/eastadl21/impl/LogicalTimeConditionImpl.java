/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import org.eclipse.eatop.eastadl21.EAValue;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.TransitionEvent;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Logical Time Condition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getIsLogicalTimeSuspended <em>Is Logical Time Suspended</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getWidth <em>Width</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getStartPointReference <em>Start Point Reference</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getEndPointReference <em>End Point Reference</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.LogicalTimeConditionImpl#getConsecutiveTimeCondition <em>Consecutive Time Condition</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class LogicalTimeConditionImpl extends EAElementImpl implements LogicalTimeCondition
{
  /**
   * The default value of the '{@link #getIsLogicalTimeSuspended() <em>Is Logical Time Suspended</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsLogicalTimeSuspended()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_LOGICAL_TIME_SUSPENDED_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsLogicalTimeSuspended() <em>Is Logical Time Suspended</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsLogicalTimeSuspended()
   * @generated
   * @ordered
   */
  protected Boolean isLogicalTimeSuspended = IS_LOGICAL_TIME_SUSPENDED_EDEFAULT;

  /**
   * This is true if the Is Logical Time Suspended attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isLogicalTimeSuspendedESet;

  /**
   * The cached value of the '{@link #getUpper() <em>Upper</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpper()
   * @generated
   * @ordered
   */
  protected EAValue upper;

  /**
   * The cached value of the '{@link #getWidth() <em>Width</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidth()
   * @generated
   * @ordered
   */
  protected EAValue width;

  /**
   * The cached value of the '{@link #getLower() <em>Lower</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLower()
   * @generated
   * @ordered
   */
  protected EAValue lower;

  /**
   * The cached value of the '{@link #getStartPointReference() <em>Start Point Reference</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStartPointReference()
   * @generated
   * @ordered
   */
  protected TransitionEvent startPointReference;

  /**
   * The cached value of the '{@link #getEndPointReference() <em>End Point Reference</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEndPointReference()
   * @generated
   * @ordered
   */
  protected TransitionEvent endPointReference;

  /**
   * The cached value of the '{@link #getConsecutiveTimeCondition() <em>Consecutive Time Condition</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConsecutiveTimeCondition()
   * @generated
   * @ordered
   */
  protected LogicalTimeCondition consecutiveTimeCondition;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected LogicalTimeConditionImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getLogicalTimeCondition();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsLogicalTimeSuspended()
  {
    return isLogicalTimeSuspended;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsLogicalTimeSuspended(Boolean newIsLogicalTimeSuspended)
  {
    Boolean oldIsLogicalTimeSuspended = isLogicalTimeSuspended;
    isLogicalTimeSuspended = newIsLogicalTimeSuspended;
    boolean oldIsLogicalTimeSuspendedESet = isLogicalTimeSuspendedESet;
    isLogicalTimeSuspendedESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__IS_LOGICAL_TIME_SUSPENDED, oldIsLogicalTimeSuspended, isLogicalTimeSuspended, !oldIsLogicalTimeSuspendedESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsLogicalTimeSuspended()
  {
    Boolean oldIsLogicalTimeSuspended = isLogicalTimeSuspended;
    boolean oldIsLogicalTimeSuspendedESet = isLogicalTimeSuspendedESet;
    isLogicalTimeSuspended = IS_LOGICAL_TIME_SUSPENDED_EDEFAULT;
    isLogicalTimeSuspendedESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.LOGICAL_TIME_CONDITION__IS_LOGICAL_TIME_SUSPENDED, oldIsLogicalTimeSuspended, IS_LOGICAL_TIME_SUSPENDED_EDEFAULT, oldIsLogicalTimeSuspendedESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsLogicalTimeSuspended()
  {
    return isLogicalTimeSuspendedESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAValue getUpper()
  {
    return upper;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetUpper(EAValue newUpper, NotificationChain msgs)
  {
    EAValue oldUpper = upper;
    upper = newUpper;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER, oldUpper, newUpper);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUpper(EAValue newUpper)
  {
    if (newUpper != upper)
    {
      NotificationChain msgs = null;
      if (upper != null)
        msgs = ((InternalEObject)upper).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER, null, msgs);
      if (newUpper != null)
        msgs = ((InternalEObject)newUpper).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER, null, msgs);
      msgs = basicSetUpper(newUpper, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER, newUpper, newUpper));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAValue getWidth()
  {
    return width;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetWidth(EAValue newWidth, NotificationChain msgs)
  {
    EAValue oldWidth = width;
    width = newWidth;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH, oldWidth, newWidth);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWidth(EAValue newWidth)
  {
    if (newWidth != width)
    {
      NotificationChain msgs = null;
      if (width != null)
        msgs = ((InternalEObject)width).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH, null, msgs);
      if (newWidth != null)
        msgs = ((InternalEObject)newWidth).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH, null, msgs);
      msgs = basicSetWidth(newWidth, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH, newWidth, newWidth));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAValue getLower()
  {
    return lower;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetLower(EAValue newLower, NotificationChain msgs)
  {
    EAValue oldLower = lower;
    lower = newLower;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER, oldLower, newLower);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLower(EAValue newLower)
  {
    if (newLower != lower)
    {
      NotificationChain msgs = null;
      if (lower != null)
        msgs = ((InternalEObject)lower).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER, null, msgs);
      if (newLower != null)
        msgs = ((InternalEObject)newLower).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER, null, msgs);
      msgs = basicSetLower(newLower, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER, newLower, newLower));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent getStartPointReference()
  {
    if (startPointReference != null && startPointReference.eIsProxy())
    {
      InternalEObject oldStartPointReference = (InternalEObject)startPointReference;
      startPointReference = (TransitionEvent)eResolveProxy(oldStartPointReference);
      if (startPointReference != oldStartPointReference)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.LOGICAL_TIME_CONDITION__START_POINT_REFERENCE, oldStartPointReference, startPointReference));
      }
    }
    return startPointReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent basicGetStartPointReference()
  {
    return startPointReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStartPointReference(TransitionEvent newStartPointReference)
  {
    TransitionEvent oldStartPointReference = startPointReference;
    startPointReference = newStartPointReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__START_POINT_REFERENCE, oldStartPointReference, startPointReference));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent getEndPointReference()
  {
    if (endPointReference != null && endPointReference.eIsProxy())
    {
      InternalEObject oldEndPointReference = (InternalEObject)endPointReference;
      endPointReference = (TransitionEvent)eResolveProxy(oldEndPointReference);
      if (endPointReference != oldEndPointReference)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.LOGICAL_TIME_CONDITION__END_POINT_REFERENCE, oldEndPointReference, endPointReference));
      }
    }
    return endPointReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransitionEvent basicGetEndPointReference()
  {
    return endPointReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEndPointReference(TransitionEvent newEndPointReference)
  {
    TransitionEvent oldEndPointReference = endPointReference;
    endPointReference = newEndPointReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__END_POINT_REFERENCE, oldEndPointReference, endPointReference));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition getConsecutiveTimeCondition()
  {
    if (consecutiveTimeCondition != null && consecutiveTimeCondition.eIsProxy())
    {
      InternalEObject oldConsecutiveTimeCondition = (InternalEObject)consecutiveTimeCondition;
      consecutiveTimeCondition = (LogicalTimeCondition)eResolveProxy(oldConsecutiveTimeCondition);
      if (consecutiveTimeCondition != oldConsecutiveTimeCondition)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.LOGICAL_TIME_CONDITION__CONSECUTIVE_TIME_CONDITION, oldConsecutiveTimeCondition, consecutiveTimeCondition));
      }
    }
    return consecutiveTimeCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition basicGetConsecutiveTimeCondition()
  {
    return consecutiveTimeCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConsecutiveTimeCondition(LogicalTimeCondition newConsecutiveTimeCondition)
  {
    LogicalTimeCondition oldConsecutiveTimeCondition = consecutiveTimeCondition;
    consecutiveTimeCondition = newConsecutiveTimeCondition;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.LOGICAL_TIME_CONDITION__CONSECUTIVE_TIME_CONDITION, oldConsecutiveTimeCondition, consecutiveTimeCondition));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER:
        return basicSetUpper(null, msgs);
      case Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH:
        return basicSetWidth(null, msgs);
      case Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER:
        return basicSetLower(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TIME_CONDITION__IS_LOGICAL_TIME_SUSPENDED:
        return getIsLogicalTimeSuspended();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER:
        return getUpper();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH:
        return getWidth();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER:
        return getLower();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__START_POINT_REFERENCE:
        if (resolve) return getStartPointReference();
        return basicGetStartPointReference();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__END_POINT_REFERENCE:
        if (resolve) return getEndPointReference();
        return basicGetEndPointReference();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__CONSECUTIVE_TIME_CONDITION:
        if (resolve) return getConsecutiveTimeCondition();
        return basicGetConsecutiveTimeCondition();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TIME_CONDITION__IS_LOGICAL_TIME_SUSPENDED:
   			setIsLogicalTimeSuspended((Boolean)newValue);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER:
   			setUpper((EAValue)newValue);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH:
   			setWidth((EAValue)newValue);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER:
   			setLower((EAValue)newValue);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__START_POINT_REFERENCE:
   			setStartPointReference((TransitionEvent)newValue);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__END_POINT_REFERENCE:
   			setEndPointReference((TransitionEvent)newValue);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__CONSECUTIVE_TIME_CONDITION:
   			setConsecutiveTimeCondition((LogicalTimeCondition)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TIME_CONDITION__IS_LOGICAL_TIME_SUSPENDED:
        unsetIsLogicalTimeSuspended();
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER:
        	setUpper((EAValue)null);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH:
        	setWidth((EAValue)null);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER:
        	setLower((EAValue)null);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__START_POINT_REFERENCE:
        	setStartPointReference((TransitionEvent)null);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__END_POINT_REFERENCE:
        	setEndPointReference((TransitionEvent)null);
        return;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__CONSECUTIVE_TIME_CONDITION:
        	setConsecutiveTimeCondition((LogicalTimeCondition)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.LOGICAL_TIME_CONDITION__IS_LOGICAL_TIME_SUSPENDED:
        return isSetIsLogicalTimeSuspended();
      case Eastadl21Package.LOGICAL_TIME_CONDITION__UPPER:
        return upper != null;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__WIDTH:
        return width != null;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__LOWER:
        return lower != null;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__START_POINT_REFERENCE:
        return startPointReference != null;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__END_POINT_REFERENCE:
        return endPointReference != null;
      case Eastadl21Package.LOGICAL_TIME_CONDITION__CONSECUTIVE_TIME_CONDITION:
        return consecutiveTimeCondition != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (isLogicalTimeSuspended: ");
    if (isLogicalTimeSuspendedESet) result.append(isLogicalTimeSuspended); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //LogicalTimeConditionImpl
