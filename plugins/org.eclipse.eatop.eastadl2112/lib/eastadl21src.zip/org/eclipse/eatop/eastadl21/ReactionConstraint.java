/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reaction Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A ReactionConstraint defines how long after the occurrence of a stimulus a corresponding response must occur.
 * 
 * This constraint provides an alternative to the ordinary DelayConstraint for situations where the causal relation between event occurrences must be taken into account. It differs from the DelayConstraint in that it applies to an event chain, and only looks at the response occurrences that have the same color as each particular stimulus occurrence. It is the earliest of these response occurrences that is required to lie within the prescribed time bounds. If the roles of stimulus and response are swapped, and the time bounds negated, an AgeConstraint is obtained.
 * 
 * Semantics:
 * A system behavior satisfies a ReactionConstraint c if and only if
 * for each occurrence x in c.scope.stimulus,
 * 		there is an occurrence y in c.scope.response such that
 * 			y.color = x.color
 * 		and
 * 			y is minimal in c.scope.response with that color
 * 		and
 * 			c.minimum &lt;= y - x &lt;= c.maximum
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingConstraints.ReactionConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.ReactionConstraint#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ReactionConstraint#getMaximum <em>Maximum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ReactionConstraint#getScope <em>Scope</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getReactionConstraint()
 * @model annotation="MetaData guid='{A14C059A-B356-43e1-A356-AEA5E1780FB8}' id='1491920018' EA\040name='ReactionConstraint'"
 *        extendedMetaData="name='REACTION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REACTION-CONSTRAINTS'"
 * @generated
 */
public interface ReactionConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Minimum</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Minimum</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Minimum</em>' containment reference.
   * @see #setMinimum(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getReactionConstraint_Minimum()
   * @model containment="true"
   *        annotation="MetaData guid='{C5BB0A40-270C-4c5b-946D-A77C4F5B3DF8}' id='-489833212' EA\040name=''"
   *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getMinimum();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ReactionConstraint#getMinimum <em>Minimum</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Minimum</em>' containment reference.
   * @see #getMinimum()
   * @generated
   */
  void setMinimum(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Maximum</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Maximum</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Maximum</em>' containment reference.
   * @see #setMaximum(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getReactionConstraint_Maximum()
   * @model containment="true"
   *        annotation="MetaData guid='{98B5CA22-CD00-46d6-A49C-86D243378785}' id='-486813259' EA\040name=''"
   *        extendedMetaData="name='MAXIMUM' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MAXIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getMaximum();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ReactionConstraint#getMaximum <em>Maximum</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Maximum</em>' containment reference.
   * @see #getMaximum()
   * @generated
   */
  void setMaximum(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Scope</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Scope</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Scope</em>' reference.
   * @see #setScope(EventChain)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getReactionConstraint_Scope()
   * @model required="true"
   *        annotation="MetaData guid='{F49FCACA-D1BA-48a0-A807-1E966D2BD6CB}' id='982605244' EA\040name=''"
   *        extendedMetaData="name='SCOPE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SCOPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EventChain getScope();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ReactionConstraint#getScope <em>Scope</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Scope</em>' reference.
   * @see #getScope()
   * @generated
   */
  void setScope(EventChain value);

} // ReactionConstraint
