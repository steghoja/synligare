/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Safety Goal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * SafetyGoal represents the top-level safety requirement defined in ISO26262. Its purpose is to define how to avoid its associated HazardousEvents, or reduce the risk associated with the hazardous event to an acceptable level.
 * 
 * The SafetyGoal is defined through one or several associated requirement elements.
 * 
 * An ASIL shall be assigned to each SafetyGoal, to represent the integrity level at which the SafetyGoal must be met.
 * 
 * Similar SafetyGoals can be combined into one SafetyGoal. If different ASILs are assigned to similar SafetyGoals, the highest ASIL shall be assigned to the combined SafetyGoal.
 * 
 * For every SafetyGoal, a safe state should be defined, by referencing a specific mode. The safe state is a system state to be maintained or to be reached when a potential source of its hazardous event is detected.
 * 
 * Semantics:
 * SafetyGoal represents a safety Goal according to ISO26262. Requirements define the SafetyGoal, and HazardousEvents identify the responsibility of each SafetyGoal. HazardClassification defines the integrity classification of the SafetyGoal, and safeStates may be defined through associated Modes.
 * 
 * Notation:
 * SafetyGoal is a box with text SafetyGoal at the top left.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.SafetyRequirement.SafetyGoal</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyGoal#getHazardClassification <em>Hazard Classification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyGoal#getSafeState <em>Safe State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyGoal#getDerivedFrom <em>Derived From</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyGoal#getRequirement <em>Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyGoal()
 * @model annotation="MetaData guid='{DBA4E896-787E-4d35-A873-78BC77E4BA58}' id='130' EA\040name='SafetyGoal'"
 *        extendedMetaData="name='SAFETY-GOAL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-GOALS'"
 * @generated
 */
public interface SafetyGoal extends EAElement
{
  /**
   * Returns the value of the '<em><b>Hazard Classification</b></em>' attribute.
   * The default value is <code>"ASIL_A"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.ASILKind}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hazard Classification</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hazard Classification</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ASILKind
   * @see #isSetHazardClassification()
   * @see #unsetHazardClassification()
   * @see #setHazardClassification(ASILKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyGoal_HazardClassification()
   * @model default="ASIL_A" unsettable="true" required="true"
   *        annotation="MetaData guid='{40B36B62-200F-4b8c-AF3C-C70E8CCA13BA}' id='-461160803' EA\040name='hazardClassification'"
   *        extendedMetaData="name='HAZARD-CLASSIFICATION' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARD-CLASSIFICATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ASILKind getHazardClassification();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyGoal#getHazardClassification <em>Hazard Classification</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Hazard Classification</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ASILKind
   * @see #isSetHazardClassification()
   * @see #HazardClassification()
   * @see #getHazardClassification()
   * @generated
   */
  void setHazardClassification(ASILKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyGoal#getHazardClassification <em>Hazard Classification</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetHazardClassification()
   * @see #getHazardClassification()
   * @see #setHazardClassification(ASILKind)
   * @generated
   */
  void unsetHazardClassification();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.SafetyGoal#getHazardClassification <em>Hazard Classification</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Hazard Classification</em>' attribute is set.
   * @see #HazardClassification()
   * @see #getHazardClassification()
   * @see #setHazardClassification(ASILKind)
   * @generated
   */
  boolean isSetHazardClassification();

  /**
   * Returns the value of the '<em><b>Safe State</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Mode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Safe State</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Safe State</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyGoal_SafeState()
   * @model annotation="MetaData guid='{0BE69F1F-5D2D-4e60-AE0A-81E8537D23D7}' id='373428407' EA\040name=''"
   *        extendedMetaData="name='SAFE-STATE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFE-STATE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Mode> getSafeState();

  /**
   * Returns the value of the '<em><b>Derived From</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HazardousEvent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Derived From</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Derived From</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyGoal_DerivedFrom()
   * @model required="true"
   *        annotation="MetaData guid='{C07755A0-C481-4012-AABB-5E8515D88DC1}' id='672421936' EA\040name=''"
   *        extendedMetaData="name='DERIVED-FROM-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DERIVED-FROM-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<HazardousEvent> getDerivedFrom();

  /**
   * Returns the value of the '<em><b>Requirement</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Requirement</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Requirement</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyGoal_Requirement()
   * @model required="true"
   *        annotation="MetaData guid='{E7F66B16-370F-42ba-86F6-ED4616737803}' id='1270025633' EA\040name=''"
   *        extendedMetaData="name='REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getRequirement();

} // SafetyGoal
