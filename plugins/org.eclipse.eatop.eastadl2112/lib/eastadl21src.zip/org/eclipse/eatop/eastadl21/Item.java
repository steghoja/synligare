/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Item entity identifies the scope of safety information and the safety assessment, i.e. the part of the system onto which the ISO26262 related information applies. Safety analyses are carried out on the basis of an item definition and the safety concepts are derived from it.
 * 
 * Semantics:
 * Item represents the scope of safety information and the safety assessment through its reference to one or several Features.
 * 
 * Extension:
 * UML::Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.Item</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Item#getDevelopmentCategory <em>Development Category</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Item#getVehicleFeature <em>Vehicle Feature</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getItem()
 * @model annotation="MetaData guid='{6CAEDE1D-1594-4a0f-B057-7A01287047A2}' id='-1001949859' EA\040name='Item'"
 *        extendedMetaData="name='ITEM' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ITEMS'"
 * @generated
 */
public interface Item extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Development Category</b></em>' attribute.
   * The default value is <code>"NEWITEMDEVELOPMENT"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.DevelopmentCategoryKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The Item entity identifies the scope of safety information and the safety assessment, i.e. the part of the system onto which the ISO26262 related information applies. Safety analyses are carried out on the basis of an item definition and the safety concepts are derived from it.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Development Category</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.DevelopmentCategoryKind
   * @see #isSetDevelopmentCategory()
   * @see #unsetDevelopmentCategory()
   * @see #setDevelopmentCategory(DevelopmentCategoryKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getItem_DevelopmentCategory()
   * @model default="NEWITEMDEVELOPMENT" unsettable="true" required="true"
   *        annotation="MetaData guid='{302E62E1-6B3F-4456-8A04-47BC380C6912}' id='1378625577' EA\040name='developmentCategory'"
   *        extendedMetaData="name='DEVELOPMENT-CATEGORY' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DEVELOPMENT-CATEGORYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  DevelopmentCategoryKind getDevelopmentCategory();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Item#getDevelopmentCategory <em>Development Category</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Development Category</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.DevelopmentCategoryKind
   * @see #isSetDevelopmentCategory()
   * @see #DevelopmentCategory()
   * @see #getDevelopmentCategory()
   * @generated
   */
  void setDevelopmentCategory(DevelopmentCategoryKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.Item#getDevelopmentCategory <em>Development Category</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetDevelopmentCategory()
   * @see #getDevelopmentCategory()
   * @see #setDevelopmentCategory(DevelopmentCategoryKind)
   * @generated
   */
  void unsetDevelopmentCategory();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.Item#getDevelopmentCategory <em>Development Category</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Development Category</em>' attribute is set.
   * @see #DevelopmentCategory()
   * @see #getDevelopmentCategory()
   * @see #setDevelopmentCategory(DevelopmentCategoryKind)
   * @generated
   */
  boolean isSetDevelopmentCategory();

  /**
   * Returns the value of the '<em><b>Vehicle Feature</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.VehicleFeature}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vehicle Feature</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vehicle Feature</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getItem_VehicleFeature()
   * @model required="true"
   *        annotation="MetaData guid='{8E1ECEA0-5C4D-424a-8A95-15B5DA067FC2}' id='-1263099088' EA\040name=''"
   *        extendedMetaData="name='VEHICLE-FEATURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VEHICLE-FEATURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<VehicleFeature> getVehicleFeature();

} // Item
