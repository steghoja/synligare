/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirements Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of requirements, their relationships, and use cases. This collection can be done across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * The RequirementsModel is a container element for requirement-related elements.
 * 
 * Constraints:
 * [1] The validFor attribute of the UserElementType shall be "Requirement".
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.RequirementsModel</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsModel#getOperationalSituation <em>Operational Situation</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsModel#getRequirement <em>Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsModel#getRequirementsRelationshipGroup <em>Requirements Relationship Group</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsModel#getRequirementsHierarchy <em>Requirements Hierarchy</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsModel#getUseCase <em>Use Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsModel#getRequirementType <em>Requirement Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel()
 * @model annotation="MetaData guid='{F443F5A4-76DC-4b62-A5E1-4686627B7404}' id='1142395347' EA\040name='RequirementsModel'"
 *        extendedMetaData="name='REQUIREMENTS-MODEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-MODELS'"
 * @generated
 */
public interface RequirementsModel extends Context
{
  /**
   * Returns the value of the '<em><b>Operational Situation</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.OperationalSituation}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Operational Situation</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Operational Situation</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel_OperationalSituation()
   * @model containment="true"
   *        annotation="MetaData guid='{857B776A-1992-4fa3-9E75-41F55EA25B7D}' id='-1099029428' EA\040name=''"
   *        extendedMetaData="name='OPERATIONAL-SITUATION' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPERATIONAL-SITUATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<OperationalSituation> getOperationalSituation();

  /**
   * Returns the value of the '<em><b>Requirement</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Requirement</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Requirement</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel_Requirement()
   * @model containment="true"
   *        annotation="MetaData guid='{F70BD1B8-1631-4ad1-A22D-BD6E5E35FC70}' id='-182348380' EA\040name=''"
   *        extendedMetaData="name='REQUIREMENT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Requirement> getRequirement();

  /**
   * Returns the value of the '<em><b>Requirements Relationship Group</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Requirements Relationship Group</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Requirements Relationship Group</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel_RequirementsRelationshipGroup()
   * @model containment="true"
   *        annotation="MetaData guid='{83C7197A-73E9-4bbf-8D95-24C875B0F67A}' id='387368419' EA\040name=''"
   *        extendedMetaData="name='REQUIREMENTS-RELATIONSHIP-GROUP' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-RELATIONSHIP-GROUPS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<RequirementsRelationshipGroup> getRequirementsRelationshipGroup();

  /**
   * Returns the value of the '<em><b>Requirements Hierarchy</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.RequirementsHierarchy}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Requirements Hierarchy</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Requirements Hierarchy</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel_RequirementsHierarchy()
   * @model containment="true"
   *        annotation="MetaData guid='{9D0DA25E-BA99-4773-91AA-E501C1A67784}' id='753212687' EA\040name=''"
   *        extendedMetaData="name='REQUIREMENTS-HIERARCHY' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-HIERARCHYS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<RequirementsHierarchy> getRequirementsHierarchy();

  /**
   * Returns the value of the '<em><b>Use Case</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.UseCase}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Use Case</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Use Case</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel_UseCase()
   * @model containment="true"
   *        annotation="MetaData guid='{C4DECA73-D13A-47a2-B1E9-FB9E8222B4C0}' id='1948091697' EA\040name=''"
   *        extendedMetaData="name='USE-CASE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='USE-CASES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<UseCase> getUseCase();

  /**
   * Returns the value of the '<em><b>Requirement Type</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.UserElementType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Requirement Type</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Requirement Type</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsModel_RequirementType()
   * @model containment="true"
   *        annotation="MetaData guid='{A9A88EEA-C7A5-4b4a-860A-863F96D3E733}' id='976770768' EA\040name=''"
   *        extendedMetaData="name='REQUIREMENT-TYPE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENT-TYPES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<UserElementType> getRequirementType();

} // RequirementsModel
