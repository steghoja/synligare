/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Infrastructure.Elements.EAPrototype</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEAPrototype()
 * @model abstract="true"
 *        annotation="MetaData guid='{1E1AF782-BA77-49a6-B9E4-B1D058AA66E9}' id='1885866039' EA\040name='EAPrototype'"
 *        extendedMetaData="name='EA-PROTOTYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-PROTOTYPES'"
 * @generated
 */
public interface EAPrototype extends EObject
{
} // EAPrototype
