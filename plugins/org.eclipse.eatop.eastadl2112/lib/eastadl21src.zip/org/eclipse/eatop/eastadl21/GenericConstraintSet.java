/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generic Constraint Set</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of generic constraints. This collection can be used across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * GenericConstraintSet is a container element for GenericConstraints and has no specific semantics.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.GenericConstraints.GenericConstraintSet</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.GenericConstraintSet#getGenericConstraint <em>Generic Constraint</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraintSet()
 * @model annotation="MetaData guid='{9FB33A5A-6E9C-48f6-9E1B-528814E0020C}' id='1020524990' EA\040name='GenericConstraintSet'"
 *        extendedMetaData="name='GENERIC-CONSTRAINT-SET' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='GENERIC-CONSTRAINT-SETS'"
 * @generated
 */
public interface GenericConstraintSet extends Context
{
  /**
   * Returns the value of the '<em><b>Generic Constraint</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.GenericConstraint}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Generic Constraint</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Generic Constraint</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraintSet_GenericConstraint()
   * @model containment="true"
   *        annotation="MetaData guid='{7964FBB8-A941-4042-93D8-1AECFDC6DCB9}' id='1276821964' EA\040name=''"
   *        extendedMetaData="name='GENERIC-CONSTRAINT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='GENERIC-CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<GenericConstraint> getGenericConstraint();

} // GenericConstraintSet
