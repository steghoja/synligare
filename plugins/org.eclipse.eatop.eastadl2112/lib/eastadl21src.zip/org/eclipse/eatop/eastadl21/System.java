/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The top level element of the System Description.
 * The System description defines five major elements: Topology, Software, Communication, Mapping and Mapping Constraints.
 * 
 * The System element directly aggregates the elements describing the Software, Mapping and Mapping Constraints; it contains a reference to an ASAM FIBEX description specifying Communication and Topology.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.AUTOSAR.SystemTemplate.System</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSystem()
 * @model annotation="MetaData guid='{04841ADB-4C41-4546-9D56-FD0A0638415D}' id='-1663746' EA\040name='System'"
 *        extendedMetaData="name='SYSTEM' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SYSTEMS'"
 * @generated
 */
public interface System extends EObject
{
} // System
