/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Order Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An OrderConstraint imposes an order between the occurrences of an event called source and an event called target. 
 * 
 * The OrderConstraint is a minor variant of an application of StrongDelayConstraint with lower set to 0 and upper to infinity; the difference being that the OrderConstraint does not allow matching target and source occurrences to coincide. 
 * 
 * Semantics:
 * A system behavior satisfies an OrderConstraint c if and only if
 * c.source and c.target have the same number of occurrences, 
 * and for each index i,
 * 		if there is an i:th occurrence of c.source at time x, there is 
 * 		also an i:th occurrence of c.target at time y such that
 * 			x &lt; y
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingConstraints.OrderConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.OrderConstraint#getSource <em>Source</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.OrderConstraint#getTarget <em>Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getOrderConstraint()
 * @model annotation="MetaData guid='{A932BD5E-6627-41e3-916D-5B169F2D445A}' id='1098865067' EA\040name='OrderConstraint'"
 *        extendedMetaData="name='ORDER-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ORDER-CONSTRAINTS'"
 * @generated
 */
public interface OrderConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Source</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source</em>' reference.
   * @see #setSource(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getOrderConstraint_Source()
   * @model required="true"
   *        annotation="MetaData guid='{06C805E4-EFEA-486a-ACF1-143B1DB69BCE}' id='-2045920536' EA\040name=''"
   *        extendedMetaData="name='SOURCE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getSource();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.OrderConstraint#getSource <em>Source</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Source</em>' reference.
   * @see #getSource()
   * @generated
   */
  void setSource(Event value);

  /**
   * Returns the value of the '<em><b>Target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target</em>' reference.
   * @see #setTarget(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getOrderConstraint_Target()
   * @model required="true"
   *        annotation="MetaData guid='{F2ED4809-6685-46fc-AD3A-C3F42711C0C1}' id='2043775118' EA\040name=''"
   *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getTarget();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.OrderConstraint#getTarget <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target</em>' reference.
   * @see #getTarget()
   * @generated
   */
  void setTarget(Event value);

} // OrderConstraint
