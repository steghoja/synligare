/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Precedence Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The PrecedenceConstraint represents a particular constraint applied on the execution sequence of functions.
 * 
 * Semantics:
 * The semantics for the PrecedenceConstraint metaclass is to define an association relationship between Functions, indicating the association relationship such that all predecessors have completed before the successors are started.
 * 
 * Note: Without a precedence relation, Functions are executed according to their data dependencies, if these are uni-directional. For bi-directional data dependencies, execution order is not defined unless the PrecedenceDependency relationship is used.
 * 
 * Notation:
 * PrecedenceConstraint is shown as a dashed arrow with "Precedes" next to it. It points from preceeding to the successive entity.
 * 
 * Extension: 
 * The PrecedenceConstraint extends UML2 metaclass Class and Dependency.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.PrecedenceConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint#getPreceding <em>Preceding</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint#getSuccessive <em>Successive</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrecedenceConstraint()
 * @model annotation="MetaData guid='{AE2CA1E7-22D4-49a5-97EE-B2E6557437D6}' id='114' EA\040name='PrecedenceConstraint'"
 *        extendedMetaData="name='PRECEDENCE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRECEDENCE-CONSTRAINTS'"
 * @generated
 */
public interface PrecedenceConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Preceding</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Preceding</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Preceding</em>' containment reference.
   * @see #setPreceding(PrecedenceConstraint_preceding)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrecedenceConstraint_Preceding()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{10EE6344-F9F0-4f4d-9439-3BDB1872C477}' id='1106143144' EA\040name=''"
   *        annotation="TaggedValues xml.name='PRECEDING-IREF' xml.namePlural='PRECEDING-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='PRECEDING-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRECEDING-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  PrecedenceConstraint_preceding getPreceding();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint#getPreceding <em>Preceding</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Preceding</em>' containment reference.
   * @see #getPreceding()
   * @generated
   */
  void setPreceding(PrecedenceConstraint_preceding value);

  /**
   * Returns the value of the '<em><b>Successive</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Successive</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Successive</em>' containment reference.
   * @see #setSuccessive(PrecedenceConstraint_successive)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrecedenceConstraint_Successive()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{678DB6AE-0386-4e92-AFCD-482BD78BB220}' id='-1774643055' EA\040name=''"
   *        annotation="TaggedValues xml.name='SUCCESSIVE-IREF' xml.namePlural='SUCCESSIVE-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='SUCCESSIVE-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SUCCESSIVE-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  PrecedenceConstraint_successive getSuccessive();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint#getSuccessive <em>Successive</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Successive</em>' containment reference.
   * @see #getSuccessive()
   * @generated
   */
  void setSuccessive(PrecedenceConstraint_successive value);

} // PrecedenceConstraint
