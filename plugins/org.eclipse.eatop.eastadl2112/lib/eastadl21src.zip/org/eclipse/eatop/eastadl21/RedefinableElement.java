/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Redefinable Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * RedefinableElement represents an element that, when defined in the context of a classifier, can be redefined more specifically or differently in the context of another classifier that specializes (directly or indirectly) the context classifier
 * 
 * A redefinable element is a named element that can be redefined in the context of a generalization.
 * 
 * The RedefinableElement is an abstract metaclass.
 * 
 * Semantics:
 * RedefinableElementrepresents an element that can be redefined in the context of another classifier. Semantics is given by its specializations.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.UseCases.RedefinableElement</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRedefinableElement()
 * @model abstract="true"
 *        annotation="MetaData guid='{E171A705-D2D0-445d-B752-A3990AFA7A3A}' id='976773013' EA\040name='RedefinableElement'"
 *        extendedMetaData="name='REDEFINABLE-ELEMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REDEFINABLE-ELEMENTS'"
 * @generated
 */
public interface RedefinableElement extends EAElement
{
} // RedefinableElement
