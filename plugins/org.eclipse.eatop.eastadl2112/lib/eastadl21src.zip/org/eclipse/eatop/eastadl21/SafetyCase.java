/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Safety Case</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * SafetyCase represents a safety case that communicates a clear, comprehensive and defensible argument that a system is acceptably safe to operate in a given context.
 * 
 * Safety Cases are used in safety related systems, where failures can lead to catastrophic or at least dangerous consequences.
 * 
 * 
 * Semantics:
 * The SafetyCase element is a container element for warrant, type and claim that together represent evidence of safety for the system or item in its context.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.SafetyCase.SafetyCase</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyCase#getContext <em>Context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyCase#getStage <em>Stage</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyCase#getSafetyCase <em>Safety Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyCase#getWarrant <em>Warrant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyCase#getClaim <em>Claim</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SafetyCase#getGround <em>Ground</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase()
 * @model annotation="MetaData guid='{77CF85EC-DD28-43a8-B24C-012935A1F689}' id='1439056641' EA\040name='SafetyCase'"
 *        extendedMetaData="name='SAFETY-CASE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-CASES'"
 * @generated
 */
public interface SafetyCase extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Context</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Description of how the SafetyCase Warrant (argument) relates to, and depends upon, information from other viewpoints.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Context</em>' attribute.
   * @see #isSetContext()
   * @see #unsetContext()
   * @see #setContext(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase_Context()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{E54A2B5A-4CB1-4b6c-BFEB-4A1D1E20E554}' id='-2091186558' EA\040name='context'"
   *        extendedMetaData="name='CONTEXT' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTEXTS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getContext();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyCase#getContext <em>Context</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Context</em>' attribute.
   * @see #isSetContext()
   * @see #Context()
   * @see #getContext()
   * @generated
   */
  void setContext(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyCase#getContext <em>Context</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetContext()
   * @see #getContext()
   * @see #setContext(String)
   * @generated
   */
  void unsetContext();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.SafetyCase#getContext <em>Context</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Context</em>' attribute is set.
   * @see #Context()
   * @see #getContext()
   * @see #setContext(String)
   * @generated
   */
  boolean isSetContext();

  /**
   * Returns the value of the '<em><b>Stage</b></em>' attribute.
   * The default value is <code>"PRELIMINARYSAFETYCASE"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.LifecycleStageKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Safety case life cycle stage (preliminary, interim or operational).
   * <!-- end-model-doc -->
   * @return the value of the '<em>Stage</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.LifecycleStageKind
   * @see #isSetStage()
   * @see #unsetStage()
   * @see #setStage(LifecycleStageKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase_Stage()
   * @model default="PRELIMINARYSAFETYCASE" unsettable="true" required="true"
   *        annotation="MetaData guid='{D76C48F0-4808-446c-AC4B-4B5B91B48202}' id='1039184514' EA\040name='stage'"
   *        extendedMetaData="name='STAGE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STAGES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  LifecycleStageKind getStage();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyCase#getStage <em>Stage</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Stage</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.LifecycleStageKind
   * @see #isSetStage()
   * @see #Stage()
   * @see #getStage()
   * @generated
   */
  void setStage(LifecycleStageKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.SafetyCase#getStage <em>Stage</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetStage()
   * @see #getStage()
   * @see #setStage(LifecycleStageKind)
   * @generated
   */
  void unsetStage();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.SafetyCase#getStage <em>Stage</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Stage</em>' attribute is set.
   * @see #Stage()
   * @see #getStage()
   * @see #setStage(LifecycleStageKind)
   * @generated
   */
  boolean isSetStage();

  /**
   * Returns the value of the '<em><b>Safety Case</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.SafetyCase}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Safety Case</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Safety Case</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase_SafetyCase()
   * @model containment="true"
   *        annotation="MetaData guid='{16CC920F-4CB8-4d9d-BDC8-C16AA8D2E810}' id='-1405105864' EA\040name=''"
   *        extendedMetaData="name='SAFETY-CASE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-CASES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<SafetyCase> getSafetyCase();

  /**
   * Returns the value of the '<em><b>Warrant</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Warrant}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Warrant</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Warrant</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase_Warrant()
   * @model containment="true"
   *        annotation="MetaData guid='{360A4A45-81B6-4684-9DD0-8D6B6BE6AD3E}' id='-1052807215' EA\040name=''"
   *        extendedMetaData="name='WARRANT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='WARRANTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Warrant> getWarrant();

  /**
   * Returns the value of the '<em><b>Claim</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Claim}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Claim</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Claim</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase_Claim()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{F35301F5-9B12-4c9d-A31E-1AB4C5B07924}' id='-182925587' EA\040name=''"
   *        extendedMetaData="name='CLAIM' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CLAIMS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Claim> getClaim();

  /**
   * Returns the value of the '<em><b>Ground</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Ground}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ground</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ground</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSafetyCase_Ground()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{5C963C0A-42D9-4efa-9281-23DCDA7914B1}' id='977847723' EA\040name=''"
   *        extendedMetaData="name='GROUND' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='GROUNDS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<Ground> getGround();

} // SafetyCase
