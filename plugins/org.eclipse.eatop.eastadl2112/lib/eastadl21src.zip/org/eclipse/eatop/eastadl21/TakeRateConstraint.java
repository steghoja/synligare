/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Take Rate Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The TakeRateConstraint defines the ratio between the number of configurations that includes the target elements and the number of configurations that include the source. If several source elements are referenced, it would be the configurations in which all these exist.
 * 
 * TakeRateConstraint complements configuration decisions, as the latter defines the rules for actual configuration. TakeRateConstraint defines expected rates of configurations and the set of constraints should be consistent with the configuration decisions. Also, the set of TakeRateConstraints shall be consistent among themselves.
 * 
 * Constraints:
 * [1] The cardinality of target is &gt; 0 
 * 
 * Semantics:
 * The TakeRate constraint defines frequency of configurations. Let sourceamount and targetamount be the number of system configurations where all source and target elements, respectively, are included. takeRate= targetamount/sourceamount. If no source is associated, takeRate=targetamount.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.GenericConstraints.TakeRateConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.TakeRateConstraint#getTakeRate <em>Take Rate</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TakeRateConstraint#getSource <em>Source</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTakeRateConstraint()
 * @model annotation="MetaData guid='{FF2481C2-2FB3-4425-8DAD-5E9B3F06041E}' id='1272610541' EA\040name='TakeRateConstraint'"
 *        extendedMetaData="name='TAKE-RATE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TAKE-RATE-CONSTRAINTS'"
 * @generated
 */
public interface TakeRateConstraint extends GenericConstraint
{
  /**
   * Returns the value of the '<em><b>Take Rate</b></em>' attribute.
   * The default value is <code>"0.0"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The rate of target compared with source configurations.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Take Rate</em>' attribute.
   * @see #isSetTakeRate()
   * @see #unsetTakeRate()
   * @see #setTakeRate(Double)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTakeRateConstraint_TakeRate()
   * @model default="0.0" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Float" required="true"
   *        annotation="MetaData guid='{30F7A585-1209-4a4a-910E-C90B76508DF2}' id='2051523560' EA\040name='takeRate'"
   *        extendedMetaData="name='TAKE-RATE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TAKE-RATES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Double getTakeRate();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.TakeRateConstraint#getTakeRate <em>Take Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Take Rate</em>' attribute.
   * @see #isSetTakeRate()
   * @see #TakeRate()
   * @see #getTakeRate()
   * @generated
   */
  void setTakeRate(Double value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.TakeRateConstraint#getTakeRate <em>Take Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetTakeRate()
   * @see #getTakeRate()
   * @see #setTakeRate(Double)
   * @generated
   */
  void unsetTakeRate();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.TakeRateConstraint#getTakeRate <em>Take Rate</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Take Rate</em>' attribute is set.
   * @see #TakeRate()
   * @see #getTakeRate()
   * @see #setTakeRate(Double)
   * @generated
   */
  boolean isSetTakeRate();

  /**
   * Returns the value of the '<em><b>Source</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Identifiable}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTakeRateConstraint_Source()
   * @model annotation="MetaData guid='{461CC9E1-8A78-42f1-A2D9-37D449035687}' id='-2046546884' EA\040name=''"
   *        extendedMetaData="name='SOURCE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Identifiable> getSource();

} // TakeRateConstraint
