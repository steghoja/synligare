/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Process Fault Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The ProcessFaultPrototype metaclass represents the anomalies that the target component/system can have due to design or implementation flaws (e.g., incorrect requirements, buffer size configuration, scheduling, etc.). 
 * 
 * Semantics:
 * The ProcessFaultPrototype represents general internal anomalies of a component that are introduced during design and implementation.
 * 
 * Extension:
 * UML::Part / UML::Event
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel.ProcessFaultPrototype</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProcessFaultPrototype()
 * @model annotation="MetaData guid='{5AE83656-B18A-4ab2-9C2A-66420D1AC8E3}' id='-197676681' EA\040name='ProcessFaultPrototype'"
 *        extendedMetaData="name='PROCESS-FAULT-PROTOTYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROCESS-FAULT-PROTOTYPES'"
 * @generated
 */
public interface ProcessFaultPrototype extends Anomaly
{
} // ProcessFaultPrototype
