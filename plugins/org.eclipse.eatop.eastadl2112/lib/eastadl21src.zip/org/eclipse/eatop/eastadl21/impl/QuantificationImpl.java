/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Attribute;
import org.eclipse.eatop.eastadl21.EADatatype;
import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.EAValue;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.Quantification;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Quantification</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.QuantificationImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.QuantificationImpl#getTimeCondition <em>Time Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.QuantificationImpl#getOperand <em>Operand</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class QuantificationImpl extends EAElementImpl implements Quantification
{
  /**
   * The cached value of the '{@link #getType() <em>Type</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getType()
   * @generated
   * @ordered
   */
  protected EADatatype type;

  /**
   * The cached value of the '{@link #getTimeCondition() <em>Time Condition</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTimeCondition()
   * @generated
   * @ordered
   */
  protected LogicalTimeCondition timeCondition;

  /**
   * The cached value of the '{@link #getOperand() <em>Operand</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOperand()
   * @generated
   * @ordered
   */
  protected EList<Attribute> operand;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected QuantificationImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getQuantification();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EADatatype getType()
  {
    if (type != null && type.eIsProxy())
    {
      InternalEObject oldType = (InternalEObject)type;
      type = (EADatatype)eResolveProxy(oldType);
      if (type != oldType)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.QUANTIFICATION__TYPE, oldType, type));
      }
    }
    return type;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EADatatype basicGetType()
  {
    return type;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setType(EADatatype newType)
  {
    EADatatype oldType = type;
    type = newType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.QUANTIFICATION__TYPE, oldType, type));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition getTimeCondition()
  {
    if (timeCondition != null && timeCondition.eIsProxy())
    {
      InternalEObject oldTimeCondition = (InternalEObject)timeCondition;
      timeCondition = (LogicalTimeCondition)eResolveProxy(oldTimeCondition);
      if (timeCondition != oldTimeCondition)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.QUANTIFICATION__TIME_CONDITION, oldTimeCondition, timeCondition));
      }
    }
    return timeCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LogicalTimeCondition basicGetTimeCondition()
  {
    return timeCondition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTimeCondition(LogicalTimeCondition newTimeCondition)
  {
    LogicalTimeCondition oldTimeCondition = timeCondition;
    timeCondition = newTimeCondition;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.QUANTIFICATION__TIME_CONDITION, oldTimeCondition, timeCondition));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Attribute> getOperand()
  {
    if (operand == null)
    {
      operand = new EObjectResolvingEList<Attribute>(Attribute.class, this, Eastadl21Package.QUANTIFICATION__OPERAND);
    }
    return operand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.QUANTIFICATION__TYPE:
        if (resolve) return getType();
        return basicGetType();
      case Eastadl21Package.QUANTIFICATION__TIME_CONDITION:
        if (resolve) return getTimeCondition();
        return basicGetTimeCondition();
      case Eastadl21Package.QUANTIFICATION__OPERAND:
        return getOperand();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.QUANTIFICATION__TYPE:
   			setType((EADatatype)newValue);
        return;
      case Eastadl21Package.QUANTIFICATION__TIME_CONDITION:
   			setTimeCondition((LogicalTimeCondition)newValue);
        return;
      case Eastadl21Package.QUANTIFICATION__OPERAND:
        getOperand().clear();
        getOperand().addAll((Collection<? extends Attribute>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.QUANTIFICATION__TYPE:
        	setType((EADatatype)null);
        return;
      case Eastadl21Package.QUANTIFICATION__TIME_CONDITION:
        	setTimeCondition((LogicalTimeCondition)null);
        return;
      case Eastadl21Package.QUANTIFICATION__OPERAND:
        getOperand().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.QUANTIFICATION__TYPE:
        return type != null;
      case Eastadl21Package.QUANTIFICATION__TIME_CONDITION:
        return timeCondition != null;
      case Eastadl21Package.QUANTIFICATION__OPERAND:
        return operand != null && !operand.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass)
  {
    if (baseClass == EAValue.class)
    {
      switch (derivedFeatureID)
      {
        case Eastadl21Package.QUANTIFICATION__TYPE: return Eastadl21Package.EA_VALUE__TYPE;
        default: return -1;
      }
    }
    if (baseClass == EAExpression.class)
    {
      switch (derivedFeatureID)
      {
        default: return -1;
      }
    }
    return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass)
  {
    if (baseClass == EAValue.class)
    {
      switch (baseFeatureID)
      {
        case Eastadl21Package.EA_VALUE__TYPE: return Eastadl21Package.QUANTIFICATION__TYPE;
        default: return -1;
      }
    }
    if (baseClass == EAExpression.class)
    {
      switch (baseFeatureID)
      {
        default: return -1;
      }
    }
    return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
  }

} //QuantificationImpl
