/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.EAPackage;
import org.eclipse.eatop.eastadl21.EAXML;
import org.eclipse.eatop.eastadl21.Eastadl21Package;

import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>EAXML</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.EAXMLImpl#gGetTopLevelPackage <em>GTop Level Package</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.EAXMLImpl#getTopLevelPackage <em>Top Level Package</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EAXMLImpl extends ExtendedEObjectImpl implements EAXML
{
  /**
   * The cached value of the '{@link #getTopLevelPackage() <em>Top Level Package</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTopLevelPackage()
   * @generated
   * @ordered
   */
  protected EList<EAPackage> topLevelPackage;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EAXMLImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getEAXML();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<GEAPackage> gGetTopLevelPackage()
  {
  
  
    
    
      
                
          EList untypedList = getTopLevelPackage();
          return untypedList;
              
      
      
      
    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<EAPackage> getTopLevelPackage()
  {
    if (topLevelPackage == null)
    {
      topLevelPackage = new EObjectContainmentEList<EAPackage>(EAPackage.class, this, Eastadl21Package.EAXML__TOP_LEVEL_PACKAGE);
    }
    return topLevelPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.EAXML__TOP_LEVEL_PACKAGE:
        return ((InternalEList<?>)getTopLevelPackage()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.EAXML__GTOP_LEVEL_PACKAGE:
        return gGetTopLevelPackage();
      case Eastadl21Package.EAXML__TOP_LEVEL_PACKAGE:
        return getTopLevelPackage();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.EAXML__GTOP_LEVEL_PACKAGE:
        gGetTopLevelPackage().clear();
        gGetTopLevelPackage().addAll((Collection<? extends GEAPackage>)newValue);
        return;
      case Eastadl21Package.EAXML__TOP_LEVEL_PACKAGE:
        getTopLevelPackage().clear();
        getTopLevelPackage().addAll((Collection<? extends EAPackage>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.EAXML__GTOP_LEVEL_PACKAGE:
        gGetTopLevelPackage().clear();
        return;
      case Eastadl21Package.EAXML__TOP_LEVEL_PACKAGE:
        getTopLevelPackage().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.EAXML__GTOP_LEVEL_PACKAGE:
        return !gGetTopLevelPackage().isEmpty();
      case Eastadl21Package.EAXML__TOP_LEVEL_PACKAGE:
        return topLevelPackage != null && !topLevelPackage.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //EAXMLImpl
