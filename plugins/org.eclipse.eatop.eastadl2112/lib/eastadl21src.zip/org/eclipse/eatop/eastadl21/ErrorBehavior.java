/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Error Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ErrorBehavior represents the descriptions of failure logics or semantics that the target element identified by the ErrorModelType exhibits. Typically the target is a system, a function, a software component, or a hardware device.
 * 
 * Each ErrorBehavior description relates the occurrences of internal faults and incoming external faults to failures. The faults and failures that the errorBehavior propagates to and from the target element are declared through the ports of the error model.
 * 
 * 
 * Semantics: 
 * ErrorBehavior defines the error propagation logic of its containing ErrorModelType.
 * 
 * The ErrorBehavior description represents the error propagations from internal faults or incoming faults to external failures. Faults are identified by the internalFault and externalFault associations respectively. The propagated failures are identified by the externalFailure association. 
 * 
 * The ErrorBehavior is defined in the failureLogic string, either directly or as a URL referencing an external specification. 
 * 
 * The failureLogic can be based on different formalisms, depending on the analysis techniques and tools available. This is indicated by its type:ErrorBehaviorKind attribute. The failureLogic attribute contains the actual failure propagation logic. 
 * 
 * Extension:
 * UML:Behavior
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel.ErrorBehavior</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getFailureLogic <em>Failure Logic</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getInternalFault <em>Internal Fault</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getInternalFailure <em>Internal Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getExternalFault <em>External Fault</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getExternalFailure <em>External Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getProcessFault <em>Process Fault</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior()
 * @model annotation="MetaData guid='{FDD0F9D2-00C0-4d7a-84CA-3C9F54C90763}' id='879276328' EA\040name='ErrorBehavior'"
 *        extendedMetaData="name='ERROR-BEHAVIOR' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-BEHAVIORS'"
 * @generated
 */
public interface ErrorBehavior extends EAElement
{
  /**
   * Returns the value of the '<em><b>Failure Logic</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The specification of error behavior based on an external formalism or the path to the file containing the external specification.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Failure Logic</em>' attribute.
   * @see #isSetFailureLogic()
   * @see #unsetFailureLogic()
   * @see #setFailureLogic(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_FailureLogic()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String"
   *        annotation="MetaData guid='{31D11790-AA73-42c5-A798-580B7A85D2C4}' id='-894776066' EA\040name='failureLogic'"
   *        extendedMetaData="name='FAILURE-LOGIC' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAILURE-LOGICS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getFailureLogic();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getFailureLogic <em>Failure Logic</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Failure Logic</em>' attribute.
   * @see #isSetFailureLogic()
   * @see #FailureLogic()
   * @see #getFailureLogic()
   * @generated
   */
  void setFailureLogic(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getFailureLogic <em>Failure Logic</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetFailureLogic()
   * @see #getFailureLogic()
   * @see #setFailureLogic(String)
   * @generated
   */
  void unsetFailureLogic();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getFailureLogic <em>Failure Logic</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Failure Logic</em>' attribute is set.
   * @see #FailureLogic()
   * @see #getFailureLogic()
   * @see #setFailureLogic(String)
   * @generated
   */
  boolean isSetFailureLogic();

  /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * The default value is <code>"HIP_HOPS"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.ErrorBehaviorKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The type of formalism applied for the error behavior description.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ErrorBehaviorKind
   * @see #isSetType()
   * @see #unsetType()
   * @see #setType(ErrorBehaviorKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_Type()
   * @model default="HIP_HOPS" unsettable="true" required="true"
   *        annotation="MetaData guid='{A6095AB0-E512-4b82-B5E8-604FEF795605}' id='1135120590' EA\040name='type'"
   *        extendedMetaData="name='TYPE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TYPES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ErrorBehaviorKind getType();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ErrorBehaviorKind
   * @see #isSetType()
   * @see #Type()
   * @see #getType()
   * @generated
   */
  void setType(ErrorBehaviorKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetType()
   * @see #getType()
   * @see #setType(ErrorBehaviorKind)
   * @generated
   */
  void unsetType();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ErrorBehavior#getType <em>Type</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Type</em>' attribute is set.
   * @see #Type()
   * @see #getType()
   * @see #setType(ErrorBehaviorKind)
   * @generated
   */
  boolean isSetType();

  /**
   * Returns the value of the '<em><b>Internal Fault</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.InternalFaultPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Internal Fault</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Internal Fault</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_InternalFault()
   * @model annotation="MetaData guid='{89171740-83E9-4dc1-B917-916E5C35A059}' id='-1776671632' EA\040name=''"
   *        extendedMetaData="name='INTERNAL-FAULT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERNAL-FAULT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<InternalFaultPrototype> getInternalFault();

  /**
   * Returns the value of the '<em><b>Internal Failure</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FailureOutPort}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Internal Failure</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Internal Failure</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_InternalFailure()
   * @model annotation="MetaData guid='{B94AA683-F6FB-49db-A454-A315E8625C2C}' id='-1592132140' EA\040name=''"
   *        extendedMetaData="name='INTERNAL-FAILURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERNAL-FAILURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FailureOutPort> getInternalFailure();

  /**
   * Returns the value of the '<em><b>External Fault</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FaultInPort}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>External Fault</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>External Fault</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_ExternalFault()
   * @model annotation="MetaData guid='{C0321849-9FD5-42c2-86AD-428875932DE8}' id='-1035182745' EA\040name=''"
   *        extendedMetaData="name='EXTERNAL-FAULT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTERNAL-FAULT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FaultInPort> getExternalFault();

  /**
   * Returns the value of the '<em><b>External Failure</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FailureOutPort}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>External Failure</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>External Failure</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_ExternalFailure()
   * @model required="true"
   *        annotation="MetaData guid='{EE128ADD-2945-4b76-80DA-9E10D4385AF5}' id='1568642042' EA\040name=''"
   *        extendedMetaData="name='EXTERNAL-FAILURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTERNAL-FAILURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FailureOutPort> getExternalFailure();

  /**
   * Returns the value of the '<em><b>Process Fault</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.ProcessFaultPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Process Fault</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Process Fault</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getErrorBehavior_ProcessFault()
   * @model annotation="MetaData guid='{38AA1366-A462-46df-BDBC-1B18527E799B}' id='1848842297' EA\040name=''"
   *        extendedMetaData="name='PROCESS-FAULT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROCESS-FAULT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<ProcessFaultPrototype> getProcessFault();

} // ErrorBehavior
