/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variability</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of variability descriptions, related feature models, and decision models. This collection can be done across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * See description.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Variability.Variability</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Variability#getProductFeatureModel <em>Product Feature Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Variability#getConfiguration <em>Configuration</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Variability#getDecisionModel <em>Decision Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Variability#getVariableElement <em>Variable Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Variability#getConfigurableContainer <em>Configurable Container</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariability()
 * @model annotation="MetaData guid='{E26E1B9C-C049-4270-BE5E-F4A29D566864}' id='-1019107050' EA\040name='Variability'"
 *        extendedMetaData="name='VARIABILITY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABILITYS'"
 * @generated
 */
public interface Variability extends Context
{
  /**
   * Returns the value of the '<em><b>Product Feature Model</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FeatureModel}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Product Feature Model</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Product Feature Model</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariability_ProductFeatureModel()
   * @model containment="true"
   *        annotation="MetaData guid='{D074206F-224D-45b1-BD80-C5AC859A8147}' id='-938748441' EA\040name=''"
   *        extendedMetaData="name='PRODUCT-FEATURE-MODEL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRODUCT-FEATURE-MODELS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<FeatureModel> getProductFeatureModel();

  /**
   * Returns the value of the '<em><b>Configuration</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FeatureConfiguration}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Configuration</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Configuration</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariability_Configuration()
   * @model containment="true"
   *        annotation="MetaData guid='{29B8EFD1-97EF-46ee-9441-DD0DE9E12006}' id='-1923145446' EA\040name=''"
   *        extendedMetaData="name='CONFIGURATION' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<FeatureConfiguration> getConfiguration();

  /**
   * Returns the value of the '<em><b>Decision Model</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.VehicleLevelBinding}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Decision Model</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Decision Model</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariability_DecisionModel()
   * @model containment="true"
   *        annotation="MetaData guid='{16081482-701E-4f9c-8AE7-16B0A892C0D0}' id='-1779028589' EA\040name=''"
   *        extendedMetaData="name='DECISION-MODEL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DECISION-MODELS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<VehicleLevelBinding> getDecisionModel();

  /**
   * Returns the value of the '<em><b>Variable Element</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.VariableElement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Variable Element</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Variable Element</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariability_VariableElement()
   * @model containment="true"
   *        annotation="MetaData guid='{7A44F09C-8FA1-462e-9055-1A00EB5BEA62}' id='-1590691339' EA\040name=''"
   *        extendedMetaData="name='VARIABLE-ELEMENT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABLE-ELEMENTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<VariableElement> getVariableElement();

  /**
   * Returns the value of the '<em><b>Configurable Container</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.ConfigurableContainer}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Configurable Container</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Configurable Container</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariability_ConfigurableContainer()
   * @model containment="true"
   *        annotation="MetaData guid='{187E0BB9-5E2A-4848-88CA-2CFF016BD707}' id='-510272465' EA\040name=''"
   *        extendedMetaData="name='CONFIGURABLE-CONTAINER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURABLE-CONTAINERS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<ConfigurableContainer> getConfigurableContainer();

} // Variability
