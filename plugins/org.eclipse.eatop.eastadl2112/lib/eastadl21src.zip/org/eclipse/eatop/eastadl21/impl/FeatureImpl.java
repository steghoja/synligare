/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.BindingTime;
import org.eclipse.eatop.eastadl21.EADatatype;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Feature;
import org.eclipse.eatop.eastadl21.FeatureTreeNode;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FeatureImpl#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FeatureImpl#getRequiredBindingTime <em>Required Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FeatureImpl#getActualBindingTime <em>Actual Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FeatureImpl#getFeatureParameter <em>Feature Parameter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.FeatureImpl#getChildNode <em>Child Node</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FeatureImpl extends FeatureTreeNodeImpl implements Feature
{
  /**
   * The default value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCardinality()
   * @generated
   * @ordered
   */
  protected static final String CARDINALITY_EDEFAULT = "";

  /**
   * The cached value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCardinality()
   * @generated
   * @ordered
   */
  protected String cardinality = CARDINALITY_EDEFAULT;

  /**
   * This is true if the Cardinality attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean cardinalityESet;

  /**
   * The cached value of the '{@link #getRequiredBindingTime() <em>Required Binding Time</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRequiredBindingTime()
   * @generated
   * @ordered
   */
  protected BindingTime requiredBindingTime;

  /**
   * The cached value of the '{@link #getActualBindingTime() <em>Actual Binding Time</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getActualBindingTime()
   * @generated
   * @ordered
   */
  protected BindingTime actualBindingTime;

  /**
   * The cached value of the '{@link #getFeatureParameter() <em>Feature Parameter</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFeatureParameter()
   * @generated
   * @ordered
   */
  protected EADatatype featureParameter;

  /**
   * The cached value of the '{@link #getChildNode() <em>Child Node</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getChildNode()
   * @generated
   * @ordered
   */
  protected EList<FeatureTreeNode> childNode;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected FeatureImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getFeature();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCardinality()
  {
    return cardinality;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCardinality(String newCardinality)
  {
    String oldCardinality = cardinality;
    cardinality = newCardinality;
    boolean oldCardinalityESet = cardinalityESet;
    cardinalityESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FEATURE__CARDINALITY, oldCardinality, cardinality, !oldCardinalityESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetCardinality()
  {
    String oldCardinality = cardinality;
    boolean oldCardinalityESet = cardinalityESet;
    cardinality = CARDINALITY_EDEFAULT;
    cardinalityESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.FEATURE__CARDINALITY, oldCardinality, CARDINALITY_EDEFAULT, oldCardinalityESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetCardinality()
  {
    return cardinalityESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BindingTime getRequiredBindingTime()
  {
    return requiredBindingTime;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetRequiredBindingTime(BindingTime newRequiredBindingTime, NotificationChain msgs)
  {
    BindingTime oldRequiredBindingTime = requiredBindingTime;
    requiredBindingTime = newRequiredBindingTime;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME, oldRequiredBindingTime, newRequiredBindingTime);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRequiredBindingTime(BindingTime newRequiredBindingTime)
  {
    if (newRequiredBindingTime != requiredBindingTime)
    {
      NotificationChain msgs = null;
      if (requiredBindingTime != null)
        msgs = ((InternalEObject)requiredBindingTime).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME, null, msgs);
      if (newRequiredBindingTime != null)
        msgs = ((InternalEObject)newRequiredBindingTime).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME, null, msgs);
      msgs = basicSetRequiredBindingTime(newRequiredBindingTime, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME, newRequiredBindingTime, newRequiredBindingTime));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BindingTime getActualBindingTime()
  {
    return actualBindingTime;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetActualBindingTime(BindingTime newActualBindingTime, NotificationChain msgs)
  {
    BindingTime oldActualBindingTime = actualBindingTime;
    actualBindingTime = newActualBindingTime;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME, oldActualBindingTime, newActualBindingTime);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setActualBindingTime(BindingTime newActualBindingTime)
  {
    if (newActualBindingTime != actualBindingTime)
    {
      NotificationChain msgs = null;
      if (actualBindingTime != null)
        msgs = ((InternalEObject)actualBindingTime).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME, null, msgs);
      if (newActualBindingTime != null)
        msgs = ((InternalEObject)newActualBindingTime).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME, null, msgs);
      msgs = basicSetActualBindingTime(newActualBindingTime, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME, newActualBindingTime, newActualBindingTime));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EADatatype getFeatureParameter()
  {
    if (featureParameter != null && featureParameter.eIsProxy())
    {
      InternalEObject oldFeatureParameter = (InternalEObject)featureParameter;
      featureParameter = (EADatatype)eResolveProxy(oldFeatureParameter);
      if (featureParameter != oldFeatureParameter)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.FEATURE__FEATURE_PARAMETER, oldFeatureParameter, featureParameter));
      }
    }
    return featureParameter;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EADatatype basicGetFeatureParameter()
  {
    return featureParameter;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFeatureParameter(EADatatype newFeatureParameter)
  {
    EADatatype oldFeatureParameter = featureParameter;
    featureParameter = newFeatureParameter;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.FEATURE__FEATURE_PARAMETER, oldFeatureParameter, featureParameter));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<FeatureTreeNode> getChildNode()
  {
    if (childNode == null)
    {
      childNode = new EObjectContainmentEList<FeatureTreeNode>(FeatureTreeNode.class, this, Eastadl21Package.FEATURE__CHILD_NODE);
    }
    return childNode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME:
        return basicSetRequiredBindingTime(null, msgs);
      case Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME:
        return basicSetActualBindingTime(null, msgs);
      case Eastadl21Package.FEATURE__CHILD_NODE:
        return ((InternalEList<?>)getChildNode()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.FEATURE__CARDINALITY:
        return getCardinality();
      case Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME:
        return getRequiredBindingTime();
      case Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME:
        return getActualBindingTime();
      case Eastadl21Package.FEATURE__FEATURE_PARAMETER:
        if (resolve) return getFeatureParameter();
        return basicGetFeatureParameter();
      case Eastadl21Package.FEATURE__CHILD_NODE:
        return getChildNode();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.FEATURE__CARDINALITY:
   			setCardinality((String)newValue);
        return;
      case Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME:
   			setRequiredBindingTime((BindingTime)newValue);
        return;
      case Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME:
   			setActualBindingTime((BindingTime)newValue);
        return;
      case Eastadl21Package.FEATURE__FEATURE_PARAMETER:
   			setFeatureParameter((EADatatype)newValue);
        return;
      case Eastadl21Package.FEATURE__CHILD_NODE:
        getChildNode().clear();
        getChildNode().addAll((Collection<? extends FeatureTreeNode>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.FEATURE__CARDINALITY:
        unsetCardinality();
        return;
      case Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME:
        	setRequiredBindingTime((BindingTime)null);
        return;
      case Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME:
        	setActualBindingTime((BindingTime)null);
        return;
      case Eastadl21Package.FEATURE__FEATURE_PARAMETER:
        	setFeatureParameter((EADatatype)null);
        return;
      case Eastadl21Package.FEATURE__CHILD_NODE:
        getChildNode().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.FEATURE__CARDINALITY:
        return isSetCardinality();
      case Eastadl21Package.FEATURE__REQUIRED_BINDING_TIME:
        return requiredBindingTime != null;
      case Eastadl21Package.FEATURE__ACTUAL_BINDING_TIME:
        return actualBindingTime != null;
      case Eastadl21Package.FEATURE__FEATURE_PARAMETER:
        return featureParameter != null;
      case Eastadl21Package.FEATURE__CHILD_NODE:
        return childNode != null && !childNode.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (cardinality: ");
    if (cardinalityESet) result.append(cardinality); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //FeatureImpl
