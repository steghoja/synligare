/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import org.eclipse.eatop.common.resource.impl.EastADLXMLResourceImpl;

import org.eclipse.eatop.eastadl21.Eastadl21Package;

import org.eclipse.eatop.serialization.SerializationFactory;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.xmi.XMLHelper;
import org.eclipse.emf.ecore.xmi.XMLLoad;
import org.eclipse.emf.ecore.xmi.XMLSave;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see org.eclipse.eatop.eastadl21.util.Eastadl21ResourceFactoryImpl
 * @generated
 */
public class Eastadl21ResourceImpl extends EastADLXMLResourceImpl
{
  /**
   * Creates an instance of the resource.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param uri the URI of the new resource.
   * @generated
   */
  public Eastadl21ResourceImpl(URI uri)
  {
    super(uri);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  
  @Override
  protected XMLLoad createXMLLoad() {
    return SerializationFactory.createXMLLoad(Eastadl21Package.eINSTANCE, this);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  
  @Override
  protected XMLSave createXMLSave() {
    return SerializationFactory.createXMLSave(this);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  
  @Override
  protected XMLHelper createXMLHelper() {
    return SerializationFactory.createXMLHelper(this);
  }
} //Eastadl21ResourceImpl
