/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delay Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A DelayConstraint imposes limits between the occurrences of an event called source and an event called target.
 * 
 * This notion of delay is entirely based on the distance between source and target occurrences; whether a matching target occurrence is actually caused by the corresponding source occurrence is of no importance. This means that one-to-many and many-to-one source-target patterns are allowed, and so are stray target occurrences that are not within the prescribed distance of any source occurrence.
 * 
 * Semantics:
 * A system behavior satisfies a DelayConstraint c if and only if
 * for each occurrence x of c.source,
 * 		there is an occurrence y of c.target such that
 * 			c.lower &lt;= y - x &lt;= c.upper
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingConstraints.DelayConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.DelayConstraint#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.DelayConstraint#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.DelayConstraint#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.DelayConstraint#getSource <em>Source</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDelayConstraint()
 * @model annotation="MetaData guid='{7C272A2B-FBDD-4ebf-A74E-FD54AA968328}' id='-35465690' EA\040name='DelayConstraint'"
 *        extendedMetaData="name='DELAY-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DELAY-CONSTRAINTS'"
 * @generated
 */
public interface DelayConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Lower</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lower</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lower</em>' containment reference.
   * @see #setLower(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDelayConstraint_Lower()
   * @model containment="true"
   *        annotation="MetaData guid='{DA4A627C-C182-4b39-96AD-5988E8FC48E2}' id='-1942126557' EA\040name=''"
   *        extendedMetaData="name='LOWER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOWERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getLower();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.DelayConstraint#getLower <em>Lower</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lower</em>' containment reference.
   * @see #getLower()
   * @generated
   */
  void setLower(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Upper</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Upper</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Upper</em>' containment reference.
   * @see #setUpper(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDelayConstraint_Upper()
   * @model containment="true"
   *        annotation="MetaData guid='{F934EE60-2B77-42e9-ACDC-C9C72E996E37}' id='-940873750' EA\040name=''"
   *        extendedMetaData="name='UPPER' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='UPPERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getUpper();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.DelayConstraint#getUpper <em>Upper</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Upper</em>' containment reference.
   * @see #getUpper()
   * @generated
   */
  void setUpper(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target</em>' reference.
   * @see #setTarget(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDelayConstraint_Target()
   * @model required="true"
   *        annotation="MetaData guid='{19EFE1AB-A26B-4758-B89D-9D53E08A9407}' id='-344507923' EA\040name=''"
   *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getTarget();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.DelayConstraint#getTarget <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target</em>' reference.
   * @see #getTarget()
   * @generated
   */
  void setTarget(Event value);

  /**
   * Returns the value of the '<em><b>Source</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source</em>' reference.
   * @see #setSource(Event)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getDelayConstraint_Source()
   * @model required="true"
   *        annotation="MetaData guid='{79E7E190-3E5F-4e97-B26E-316C0F80CBC8}' id='621023151' EA\040name=''"
   *        extendedMetaData="name='SOURCE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Event getSource();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.DelayConstraint#getSource <em>Source</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Source</em>' reference.
   * @see #getSource()
   * @generated
   */
  void setSource(Event value);

} // DelayConstraint
