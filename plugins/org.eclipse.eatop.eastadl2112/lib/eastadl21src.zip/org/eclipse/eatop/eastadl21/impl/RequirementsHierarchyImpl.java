/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Requirement;
import org.eclipse.eatop.eastadl21.RequirementsHierarchy;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Requirements Hierarchy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.RequirementsHierarchyImpl#getContainedRequirement <em>Contained Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.RequirementsHierarchyImpl#getChildHierarchy <em>Child Hierarchy</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RequirementsHierarchyImpl extends TraceableSpecificationImpl implements RequirementsHierarchy
{
  /**
   * The cached value of the '{@link #getContainedRequirement() <em>Contained Requirement</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getContainedRequirement()
   * @generated
   * @ordered
   */
  protected Requirement containedRequirement;

  /**
   * The cached value of the '{@link #getChildHierarchy() <em>Child Hierarchy</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getChildHierarchy()
   * @generated
   * @ordered
   */
  protected EList<RequirementsHierarchy> childHierarchy;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected RequirementsHierarchyImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getRequirementsHierarchy();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Requirement getContainedRequirement()
  {
    if (containedRequirement != null && containedRequirement.eIsProxy())
    {
      InternalEObject oldContainedRequirement = (InternalEObject)containedRequirement;
      containedRequirement = (Requirement)eResolveProxy(oldContainedRequirement);
      if (containedRequirement != oldContainedRequirement)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT, oldContainedRequirement, containedRequirement));
      }
    }
    return containedRequirement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Requirement basicGetContainedRequirement()
  {
    return containedRequirement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setContainedRequirement(Requirement newContainedRequirement)
  {
    Requirement oldContainedRequirement = containedRequirement;
    containedRequirement = newContainedRequirement;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT, oldContainedRequirement, containedRequirement));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<RequirementsHierarchy> getChildHierarchy()
  {
    if (childHierarchy == null)
    {
      childHierarchy = new EObjectContainmentEList<RequirementsHierarchy>(RequirementsHierarchy.class, this, Eastadl21Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY);
    }
    return childHierarchy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
        return ((InternalEList<?>)getChildHierarchy()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
        if (resolve) return getContainedRequirement();
        return basicGetContainedRequirement();
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
        return getChildHierarchy();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
   			setContainedRequirement((Requirement)newValue);
        return;
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
        getChildHierarchy().clear();
        getChildHierarchy().addAll((Collection<? extends RequirementsHierarchy>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
        	setContainedRequirement((Requirement)null);
        return;
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
        getChildHierarchy().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
        return containedRequirement != null;
      case Eastadl21Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
        return childHierarchy != null && !childHierarchy.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //RequirementsHierarchyImpl
