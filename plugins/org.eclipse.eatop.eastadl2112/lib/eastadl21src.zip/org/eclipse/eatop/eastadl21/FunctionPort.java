/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Function Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The ports conserve variables for component interaction.
 * 
 * Semantics:
 * Subclasses of the abstract class FunctionPort add their own semantics.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Structure.FunctionModeling.FunctionPort</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFunctionPort()
 * @model abstract="true"
 *        annotation="MetaData guid='{3539CC74-9CB1-4588-8DC1-56763EC80FCE}' id='1798500223' EA\040name='FunctionPort'"
 *        annotation="Stereotype Stereotype='atpPrototype'"
 *        extendedMetaData="name='FUNCTION-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PORTS'"
 * @generated
 */
public interface FunctionPort extends EAPort, EAElement
{
} // FunctionPort
