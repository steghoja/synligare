/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variable Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VariableElement is a marker class that marks an artifact element denoted by association optionalElement as being optional, i.e. it will not be present in all configurations of the complete system. A typical example is an optional FunctionPrototype.
 * 
 * In addition, the VariableElement can be used to extend the EAST-ADL variability approach to other languages and standards by pointing from the VariableElement to the respective (non EAST-ADL) element with association optionalElement, thus marking the non EAST-ADL element as optional and providing configuration support within its containing ConfigurableContainer.
 * 
 * Refer to the documentation of meta-class ConfigurableContainer for a detailed explanation of how ConfigurableContainer and VariableElement work together.
 * 
 * 
 * Constraints:
 * [1] Identifies either one FunctionPrototype or one FunctionPort or one FunctionConnector or one HardwareComponentPrototype or one HardwarePin or one ClampConnector.
 * 
 * Semantics:
 * Marks the element identified by association optionalElement as optional.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Variability.VariableElement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariableElement#getOptionalElement <em>Optional Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariableElement#getReuseMetaInformation <em>Reuse Meta Information</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariableElement#getRequiredBindingTime <em>Required Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VariableElement#getActualBindingTime <em>Actual Binding Time</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariableElement()
 * @model annotation="MetaData guid='{69EE1EC3-79AD-4dc0-9EB9-17F38822FEF6}' id='137' EA\040name='VariableElement'"
 *        extendedMetaData="name='VARIABLE-ELEMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABLE-ELEMENTS'"
 * @generated
 */
public interface VariableElement extends EAElement
{
  /**
   * Returns the value of the '<em><b>Optional Element</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Identifiable}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Optional Element</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Optional Element</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariableElement_OptionalElement()
   * @model required="true"
   *        annotation="MetaData guid='{ABAC037A-4A09-4931-BA14-3A57B512E7A6}' id='-2031220913' EA\040name=''"
   *        extendedMetaData="name='OPTIONAL-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPTIONAL-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Identifiable> getOptionalElement();

  /**
   * Returns the value of the '<em><b>Reuse Meta Information</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Reuse Meta Information</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Reuse Meta Information</em>' containment reference.
   * @see #setReuseMetaInformation(ReuseMetaInformation)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariableElement_ReuseMetaInformation()
   * @model containment="true"
   *        annotation="MetaData guid='{0EDD419C-6973-4ff4-84D1-774975BF2711}' id='59' EA\040name=''"
   *        extendedMetaData="name='REUSE-META-INFORMATION' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REUSE-META-INFORMATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ReuseMetaInformation getReuseMetaInformation();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VariableElement#getReuseMetaInformation <em>Reuse Meta Information</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Reuse Meta Information</em>' containment reference.
   * @see #getReuseMetaInformation()
   * @generated
   */
  void setReuseMetaInformation(ReuseMetaInformation value);

  /**
   * Returns the value of the '<em><b>Required Binding Time</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Required Binding Time</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Required Binding Time</em>' containment reference.
   * @see #setRequiredBindingTime(BindingTime)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariableElement_RequiredBindingTime()
   * @model containment="true"
   *        annotation="MetaData guid='{139EDAF3-D173-4ee8-A086-2B55E7678712}' id='253' EA\040name=''"
   *        extendedMetaData="name='REQUIRED-BINDING-TIME' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIRED-BINDING-TIMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  BindingTime getRequiredBindingTime();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VariableElement#getRequiredBindingTime <em>Required Binding Time</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Required Binding Time</em>' containment reference.
   * @see #getRequiredBindingTime()
   * @generated
   */
  void setRequiredBindingTime(BindingTime value);

  /**
   * Returns the value of the '<em><b>Actual Binding Time</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Actual Binding Time</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Actual Binding Time</em>' containment reference.
   * @see #setActualBindingTime(BindingTime)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVariableElement_ActualBindingTime()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{0418FACB-2298-4e8d-975B-EA9EC16E5E4C}' id='254' EA\040name=''"
   *        extendedMetaData="name='ACTUAL-BINDING-TIME' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ACTUAL-BINDING-TIMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  BindingTime getActualBindingTime();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VariableElement#getActualBindingTime <em>Actual Binding Time</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Actual Binding Time</em>' containment reference.
   * @see #getActualBindingTime()
   * @generated
   */
  void setActualBindingTime(BindingTime value);

} // VariableElement
