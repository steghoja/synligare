/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure Port function Target</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel._instanceRef.FaultFailurePort_functionTarget</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget#getFunctionPort <em>Function Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget#getFunctionPrototype <em>Function Prototype</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePort_functionTarget()
 * @model annotation="MetaData guid='{6B419F32-EDC1-4bcb-A6A2-2503354C3687}' id='-1801057139' EA\040name='FaultFailurePort_functionTarget'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='FAULT-FAILURE-PORT--FUNCTION-TARGET-IREF'"
 *        extendedMetaData="name='FAULT-FAILURE-PORT--FUNCTION-TARGET-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-PORT--FUNCTION-TARGET-IREFS'"
 * @generated
 */
public interface FaultFailurePort_functionTarget extends EObject
{
  /**
   * Returns the value of the '<em><b>Function Port</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Function Port</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Function Port</em>' reference.
   * @see #setFunctionPort(FunctionPort)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePort_functionTarget_FunctionPort()
   * @model required="true"
   *        annotation="MetaData guid='{90BCB7C5-E83B-4029-8524-021D1F737A2C}' id='-1336513016' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FUNCTION-PORT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PORT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FunctionPort getFunctionPort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget#getFunctionPort <em>Function Port</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Function Port</em>' reference.
   * @see #getFunctionPort()
   * @generated
   */
  void setFunctionPort(FunctionPort value);

  /**
   * Returns the value of the '<em><b>Function Prototype</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FunctionPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Function Prototype</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Function Prototype</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePort_functionTarget_FunctionPrototype()
   * @model annotation="MetaData guid='{C592AA16-CA61-4046-B871-6D48398420CF}' id='-1167631997' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FUNCTION-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FunctionPrototype> getFunctionPrototype();

} // FaultFailurePort_functionTarget
