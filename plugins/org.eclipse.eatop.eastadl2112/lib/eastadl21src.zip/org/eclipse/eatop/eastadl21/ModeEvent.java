/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mode Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A mode that identifies when the mode starts or ends.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Events.ModeEvent</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.ModeEvent#getStart <em>Start</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ModeEvent#getEnd <em>End</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getModeEvent()
 * @model annotation="MetaData guid='{B3B8B5BA-0FA0-4e8e-8424-D316F9DE5A7E}' id='-1330746526' EA\040name='ModeEvent'"
 *        extendedMetaData="name='MODE-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-EVENTS'"
 * @generated
 */
public interface ModeEvent extends Event
{
  /**
   * Returns the value of the '<em><b>Start</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Mode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Start</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Start</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getModeEvent_Start()
   * @model annotation="MetaData guid='{758D2E29-5BA0-4abe-BD2E-95BA5F08A58C}' id='-1949765630' EA\040name=''"
   *        extendedMetaData="name='START-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='START-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Mode> getStart();

  /**
   * Returns the value of the '<em><b>End</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Mode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>End</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>End</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getModeEvent_End()
   * @model annotation="MetaData guid='{99CEB068-BC63-4a65-90B0-BCC86C617EFE}' id='2104560037' EA\040name=''"
   *        extendedMetaData="name='END-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='END-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Mode> getEnd();

} // ModeEvent
