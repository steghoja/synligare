/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Timing Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A Timing Expression, denoted by texp, is a term built from an arithmetic expression by applying an optional unit and referencing an optional time base. It stands for a value in the real number system extended with positive and negative infinity.
 * 
 * Grammar:
 * texp   ::=   aexp
 *     |   aexp UN
 *     |   aexp on TB
 *     |   aexp UN on TB
 * 	
 * Semantics:
 * Given a particular variable assignment, the meaning of a timing expression texp in that assignment is a value in the real number system extended with positive and negative infinity. Depending on the form of texp, this value is defined as follows:
 * - If texp is of the form aexp, its meaning is the meaning of aexp in the given variable assignment.
 * - If texp is of the form aexp UN, its meaning is r * k, where r is the meaning of aexp in the given variable assignment, and k is the factor of UN in the Universal time base.
 * - If texp is of the form aexp on TB, its meaning is f (r), where f is the meaning of TB in the given variable assignment, and r is the meaning of aexp in the same assignment.
 * - If texp is of the form aexp UN on TB, its meaning is f (r * k), where f is the meaning of TB in the given variable assignment, r is the meaning of aexp in the same assignment, k is the factor of UN in DI, and DI is the dimension of TB.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingExpression</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTimingExpression()
 * @model annotation="MetaData guid='{B1CF0C00-0E84-47ae-ADAA-021C50C03B9C}' id='1462213362' EA\040name='TimingExpression'"
 *        extendedMetaData="name='TIMING-EXPRESSION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIMING-EXPRESSIONS'"
 * @generated
 */
public interface TimingExpression extends EAExpression
{
} // TimingExpression
