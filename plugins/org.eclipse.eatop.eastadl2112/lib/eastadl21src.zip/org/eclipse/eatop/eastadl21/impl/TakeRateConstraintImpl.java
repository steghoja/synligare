/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Identifiable;
import org.eclipse.eatop.eastadl21.TakeRateConstraint;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Take Rate Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TakeRateConstraintImpl#getTakeRate <em>Take Rate</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.TakeRateConstraintImpl#getSource <em>Source</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TakeRateConstraintImpl extends GenericConstraintImpl implements TakeRateConstraint
{
  /**
   * The default value of the '{@link #getTakeRate() <em>Take Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTakeRate()
   * @generated
   * @ordered
   */
  protected static final Double TAKE_RATE_EDEFAULT = new Double(0.0);

  /**
   * The cached value of the '{@link #getTakeRate() <em>Take Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTakeRate()
   * @generated
   * @ordered
   */
  protected Double takeRate = TAKE_RATE_EDEFAULT;

  /**
   * This is true if the Take Rate attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean takeRateESet;

  /**
   * The cached value of the '{@link #getSource() <em>Source</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSource()
   * @generated
   * @ordered
   */
  protected EList<Identifiable> source;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected TakeRateConstraintImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getTakeRateConstraint();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Double getTakeRate()
  {
    return takeRate;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTakeRate(Double newTakeRate)
  {
    Double oldTakeRate = takeRate;
    takeRate = newTakeRate;
    boolean oldTakeRateESet = takeRateESet;
    takeRateESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.TAKE_RATE_CONSTRAINT__TAKE_RATE, oldTakeRate, takeRate, !oldTakeRateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetTakeRate()
  {
    Double oldTakeRate = takeRate;
    boolean oldTakeRateESet = takeRateESet;
    takeRate = TAKE_RATE_EDEFAULT;
    takeRateESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.TAKE_RATE_CONSTRAINT__TAKE_RATE, oldTakeRate, TAKE_RATE_EDEFAULT, oldTakeRateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetTakeRate()
  {
    return takeRateESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Identifiable> getSource()
  {
    if (source == null)
    {
      source = new EObjectResolvingEList<Identifiable>(Identifiable.class, this, Eastadl21Package.TAKE_RATE_CONSTRAINT__SOURCE);
    }
    return source;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__TAKE_RATE:
        return getTakeRate();
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__SOURCE:
        return getSource();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__TAKE_RATE:
   			setTakeRate((Double)newValue);
        return;
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__SOURCE:
        getSource().clear();
        getSource().addAll((Collection<? extends Identifiable>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__TAKE_RATE:
        unsetTakeRate();
        return;
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__SOURCE:
        getSource().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__TAKE_RATE:
        return isSetTakeRate();
      case Eastadl21Package.TAKE_RATE_CONSTRAINT__SOURCE:
        return source != null && !source.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (takeRate: ");
    if (takeRateESet) result.append(takeRate); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //TakeRateConstraintImpl
