/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Claim;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Ground;
import org.eclipse.eatop.eastadl21.Rationale;
import org.eclipse.eatop.eastadl21.Warrant;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Warrant</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.WarrantImpl#getDecomposedGoal <em>Decomposed Goal</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.WarrantImpl#getEvidence <em>Evidence</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.WarrantImpl#getJustification <em>Justification</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class WarrantImpl extends TraceableSpecificationImpl implements Warrant
{
  /**
   * The cached value of the '{@link #getDecomposedGoal() <em>Decomposed Goal</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDecomposedGoal()
   * @generated
   * @ordered
   */
  protected EList<Claim> decomposedGoal;

  /**
   * The cached value of the '{@link #getEvidence() <em>Evidence</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEvidence()
   * @generated
   * @ordered
   */
  protected EList<Ground> evidence;

  /**
   * The cached value of the '{@link #getJustification() <em>Justification</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustification()
   * @generated
   * @ordered
   */
  protected EList<Rationale> justification;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected WarrantImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getWarrant();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Claim> getDecomposedGoal()
  {
    if (decomposedGoal == null)
    {
      decomposedGoal = new EObjectResolvingEList<Claim>(Claim.class, this, Eastadl21Package.WARRANT__DECOMPOSED_GOAL);
    }
    return decomposedGoal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Ground> getEvidence()
  {
    if (evidence == null)
    {
      evidence = new EObjectResolvingEList<Ground>(Ground.class, this, Eastadl21Package.WARRANT__EVIDENCE);
    }
    return evidence;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Rationale> getJustification()
  {
    if (justification == null)
    {
      justification = new EObjectContainmentEList<Rationale>(Rationale.class, this, Eastadl21Package.WARRANT__JUSTIFICATION);
    }
    return justification;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.WARRANT__JUSTIFICATION:
        return ((InternalEList<?>)getJustification()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.WARRANT__DECOMPOSED_GOAL:
        return getDecomposedGoal();
      case Eastadl21Package.WARRANT__EVIDENCE:
        return getEvidence();
      case Eastadl21Package.WARRANT__JUSTIFICATION:
        return getJustification();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.WARRANT__DECOMPOSED_GOAL:
        getDecomposedGoal().clear();
        getDecomposedGoal().addAll((Collection<? extends Claim>)newValue);
        return;
      case Eastadl21Package.WARRANT__EVIDENCE:
        getEvidence().clear();
        getEvidence().addAll((Collection<? extends Ground>)newValue);
        return;
      case Eastadl21Package.WARRANT__JUSTIFICATION:
        getJustification().clear();
        getJustification().addAll((Collection<? extends Rationale>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.WARRANT__DECOMPOSED_GOAL:
        getDecomposedGoal().clear();
        return;
      case Eastadl21Package.WARRANT__EVIDENCE:
        getEvidence().clear();
        return;
      case Eastadl21Package.WARRANT__JUSTIFICATION:
        getJustification().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.WARRANT__DECOMPOSED_GOAL:
        return decomposedGoal != null && !decomposedGoal.isEmpty();
      case Eastadl21Package.WARRANT__EVIDENCE:
        return evidence != null && !evidence.isEmpty();
      case Eastadl21Package.WARRANT__JUSTIFICATION:
        return justification != null && !justification.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //WarrantImpl
