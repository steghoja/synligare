/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Synchronization Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An OutputSynchronizationConstraint defines how far apart the responses that belong to a certain stimulus may occur.
 * 
 * This constraint provides an alternative to the ordinary SynchronizationConstraint for situations where the causal relation between event occurrences must be taken into account. It differs from the SynchronizationConstraint in that it applies to a set of event chains, and only looks at the response occurrences that have the same color as each particular stimulus occurrence. It is the earliest of these response occurrences for each chain that are required to lie no more than tolerance time units apart. If the roles of stimuli and responses are swapped, an InputSynchronizationConstraint is obtained.
 * 
 * Constraints:
 * [1] All scopes must reference one common stimulus event.
 * 
 * Semantics:
 * A system behavior satisfies an OutputSynchronizationConstraint c if and only if
 * for each occurrence x in c.scope(1).stimulus,
 * 	     there is a time t such that for each c.scope index i,
 * 		there is an occurrence y in c.scope(i).response such that
 * 		      y.color = x.color
 * 		and
 * 		      y is minimal in c.scope(i).response with that color
 * 		and
 * 		      0 &lt;= y - t &lt;= c.tolerance
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.TimingConstraints.OutputSynchronizationConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint#getTolerance <em>Tolerance</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint#getScope <em>Scope</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getOutputSynchronizationConstraint()
 * @model annotation="MetaData guid='{4DBDA42C-1E2D-456f-BDB7-C5148A00CD04}' id='831212856' EA\040name='OutputSynchronizationConstraint'"
 *        extendedMetaData="name='OUTPUT-SYNCHRONIZATION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OUTPUT-SYNCHRONIZATION-CONSTRAINTS'"
 * @generated
 */
public interface OutputSynchronizationConstraint extends TimingConstraint
{
  /**
   * Returns the value of the '<em><b>Tolerance</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tolerance</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tolerance</em>' containment reference.
   * @see #setTolerance(TimingExpression)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getOutputSynchronizationConstraint_Tolerance()
   * @model containment="true"
   *        annotation="MetaData guid='{DFDDE8C3-65E0-4b1d-98F6-296F7B543569}' id='1085640457' EA\040name=''"
   *        extendedMetaData="name='TOLERANCE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TOLERANCES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  TimingExpression getTolerance();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint#getTolerance <em>Tolerance</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tolerance</em>' containment reference.
   * @see #getTolerance()
   * @generated
   */
  void setTolerance(TimingExpression value);

  /**
   * Returns the value of the '<em><b>Scope</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.EventChain}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Scope</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Scope</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getOutputSynchronizationConstraint_Scope()
   * @model lower="2"
   *        annotation="MetaData guid='{ACE490F0-EEE5-43d5-BFAD-90E9A359A98D}' id='-1463524851' EA\040name=''"
   *        extendedMetaData="name='SCOPE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SCOPE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<EventChain> getScope();

} // OutputSynchronizationConstraint
