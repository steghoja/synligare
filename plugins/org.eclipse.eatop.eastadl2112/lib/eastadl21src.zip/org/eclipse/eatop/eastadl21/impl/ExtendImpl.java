/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Extend;
import org.eclipse.eatop.eastadl21.ExtensionPoint;
import org.eclipse.eatop.eastadl21.UseCase;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Extend</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExtendImpl#getExtendedCase <em>Extended Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExtendImpl#getExtensionLocation <em>Extension Location</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ExtendImpl extends RelationshipImpl implements Extend
{
  /**
   * The cached value of the '{@link #getExtendedCase() <em>Extended Case</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExtendedCase()
   * @generated
   * @ordered
   */
  protected UseCase extendedCase;

  /**
   * The cached value of the '{@link #getExtensionLocation() <em>Extension Location</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getExtensionLocation()
   * @generated
   * @ordered
   */
  protected EList<ExtensionPoint> extensionLocation;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExtendImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getExtend();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UseCase getExtendedCase()
  {
    if (extendedCase != null && extendedCase.eIsProxy())
    {
      InternalEObject oldExtendedCase = (InternalEObject)extendedCase;
      extendedCase = (UseCase)eResolveProxy(oldExtendedCase);
      if (extendedCase != oldExtendedCase)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.EXTEND__EXTENDED_CASE, oldExtendedCase, extendedCase));
      }
    }
    return extendedCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UseCase basicGetExtendedCase()
  {
    return extendedCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setExtendedCase(UseCase newExtendedCase)
  {
    UseCase oldExtendedCase = extendedCase;
    extendedCase = newExtendedCase;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXTEND__EXTENDED_CASE, oldExtendedCase, extendedCase));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ExtensionPoint> getExtensionLocation()
  {
    if (extensionLocation == null)
    {
      extensionLocation = new EObjectResolvingEList<ExtensionPoint>(ExtensionPoint.class, this, Eastadl21Package.EXTEND__EXTENSION_LOCATION);
    }
    return extensionLocation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXTEND__EXTENDED_CASE:
        if (resolve) return getExtendedCase();
        return basicGetExtendedCase();
      case Eastadl21Package.EXTEND__EXTENSION_LOCATION:
        return getExtensionLocation();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXTEND__EXTENDED_CASE:
   			setExtendedCase((UseCase)newValue);
        return;
      case Eastadl21Package.EXTEND__EXTENSION_LOCATION:
        getExtensionLocation().clear();
        getExtensionLocation().addAll((Collection<? extends ExtensionPoint>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXTEND__EXTENDED_CASE:
        	setExtendedCase((UseCase)null);
        return;
      case Eastadl21Package.EXTEND__EXTENSION_LOCATION:
        getExtensionLocation().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXTEND__EXTENDED_CASE:
        return extendedCase != null;
      case Eastadl21Package.EXTEND__EXTENSION_LOCATION:
        return extensionLocation != null && !extensionLocation.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ExtendImpl
