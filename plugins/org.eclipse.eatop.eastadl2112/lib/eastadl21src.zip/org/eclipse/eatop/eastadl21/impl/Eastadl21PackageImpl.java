/**
 */
package org.eclipse.eatop.eastadl21.impl;

import java.io.IOException;

import java.net.URL;

import org.eclipse.eatop.eastadl21.Eastadl21Factory;
import org.eclipse.eatop.eastadl21.Eastadl21Package;

import org.eclipse.eatop.eastadl21.util.Eastadl21Validator;

import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GelementsPackage;

import org.eclipse.eatop.geastadl.ginfrastructure.gprimitivetypes.GprimitivetypesPackage;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.common.util.WrappedException;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.resource.Resource;

import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Eastadl21PackageImpl extends EPackageImpl implements Eastadl21Package
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected String packageFilename = "eastadl21.ecore";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vehicleLevelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass systemModelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass analysisLevelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass designLevelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass implementationLevelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass bindingTimeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureGroupEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureLinkEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureModelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureTreeNodeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass deviationAttributeSetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vehicleFeatureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass allocateableElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass allocationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass analysisFunctionPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass analysisFunctionTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass basicSoftwareFunctionTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass designFunctionPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass designFunctionTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionalDeviceEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionAllocationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionClientServerInterfaceEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionClientServerPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionFlowPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionPowerPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwareFunctionTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass localDeviceManagerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass operationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass portGroupEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionAllocation_allocatedElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionAllocation_targetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionConnector_portEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass actuatorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass communicationHardwarePinEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass electricalComponentEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwareComponentPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwareComponentTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwareConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwarePinEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwarePortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwarePortConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass ioHardwarePinEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass nodeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass powerHardwarePinEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass sensorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass allocationTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwareConnector_portEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwarePortConnector_portEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass clampConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass environmentEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass clampConnector_portEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass modeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass modeGroupEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionBehaviorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionTriggerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configurableContainerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configurationDecisionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configurationDecisionFolderEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configurationDecisionModelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configurationDecisionModelEntryEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass containerConfigurationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureConfigurationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass internalBindingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass privateContentEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass reuseMetaInformationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass selectionCriterionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass variabilityEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass variableElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass variationGroupEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vehicleLevelBindingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass deriveRequirementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass operationalSituationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass requirementsModelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass requirementsRelationshipEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass requirementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass requirementsHierarchyEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass refineEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass satisfyEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass requirementsLinkEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass requirementsRelationshipGroupEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass qualityRequirementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass refine_refinedByEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass satisfy_satisfiedByEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass actorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass extendEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass extensionPointEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass includeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass redefinableElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass useCaseEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass verificationValidationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass verifyEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvActualOutcomeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvCaseEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvIntendedOutcomeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvLogEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvProcedureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvStimuliEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvCase_vvSubjectEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vvTarget_elementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventChainEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass precedenceConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass timingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass timingConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass timingDescriptionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass timingExpressionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass autosarEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFaultFailureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFeatureFlawEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFunctionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFunctionClientServerPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFunctionFlowPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass externalEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass modeEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFunction_functionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFunctionClientServerPort_portEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventFunctionFlowPort_portEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass ageConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass arbitraryConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass burstConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass comparisonConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass delayConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass executionTimeConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputSynchronizationConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass orderConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputSynchronizationConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass patternConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass periodicConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass reactionConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass repetitionConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass sporadicConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass strongDelayConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass strongSynchronizationConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass synchronizationConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass precedenceConstraint_precedingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass precedenceConstraint_successiveEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass dependabilityEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass featureFlawEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hazardEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hazardousEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass itemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass quantitativeSafetyConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass safetyConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailure_anomalyEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass anomalyEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass errorBehaviorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass errorModelPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass errorModelTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass failureOutPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailurePortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailurePropagationLinkEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultInPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass internalFaultPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass processFaultPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass errorModelPrototype_functionTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass errorModelPrototype_hwTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailurePort_functionTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailurePort_hwTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailurePropagationLink_fromPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass faultFailurePropagationLink_toPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass functionalSafetyConceptEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass safetyGoalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass technicalSafetyConceptEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass claimEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass groundEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass safetyCaseEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass warrantEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genericConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genericConstraintSetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass takeRateConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass commentEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass contextEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaPackageEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaPackageableElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaxmlEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass rationaleEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass realizationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass referrableEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass relationshipEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass traceableSpecificationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass identifiableEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass realization_realizedEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass realization_realizedByEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass arrayDatatypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass compositeDatatypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaBooleanEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaDatatypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaDatatypePrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaNumericalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaStringEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass enumerationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass enumerationLiteralEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass quantityEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass rangeableValueTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass unitEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaArrayValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaBooleanValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaCompositeValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaEnumerationValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaExpressionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaNumericalValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaStringValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eaValueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass userAttributeDefinitionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass userAttributedElementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass userElementTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintBindingAttributeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintBindingEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintInternalBindingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintParameterEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintPrototypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintTargetBindingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintInternalBinding_bindingThroughFunctionConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintInternalBinding_bindingThroughHardwareConnectorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintPrototype_errorModelTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintPrototype_functionTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorConstraintPrototype_hardwareComponentTargetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass attributeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass attributeQuantificationConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass behaviorAttributeBindingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass logicalEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass quantificationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass computationConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass logicalPathEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass logicalTransformationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass transformationOccurrenceEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass logicalTimeConditionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass stateEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass stateEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass synchronousTransitionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass temporalConstraintEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass transitionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass transitionEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass architecturalDescriptionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass architecturalModelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass architectureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass conceptEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass missionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vehicleSystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass stakeholderEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass stakeholderNeedEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass businessOpportunityEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass problemStatementEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass productPositioningEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass systemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass timingDescriptionEventEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum bindingTimeKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum variabilityDependencyKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum deviationPermissionKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum clientServerKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum eaDirectionKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum hardwareBusKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum ioHardwarePinKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum functionBehaviorKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum triggerPolicyKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum qualityRequirementKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum eventFunctionClientServerPortKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum comparisonKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum controllabilityClassKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum developmentCategoryKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum exposureClassKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum severityClassKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum asilKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum errorBehaviorKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum lifecycleStageKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum genericConstraintKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType booleanEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType floatEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType identifierEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType integerEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType numericalEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType refEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType stringEDataType = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#eNS_URI
   * @see #init()
   * @generated
   */
  private Eastadl21PackageImpl()
  {
    super(eNS_URI, Eastadl21Factory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
   * 
   * <p>This method is used to initialize {@link Eastadl21Package#eINSTANCE} when that field is accessed.
   * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @generated
   */
  public static Eastadl21Package init()
  {
    if (isInited) return (Eastadl21Package)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI);

    // Obtain or create and register package
    Eastadl21PackageImpl theEastadl21Package = (Eastadl21PackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof Eastadl21PackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new Eastadl21PackageImpl());

    isInited = true;

    // Initialize simple dependencies
    GelementsPackage.eINSTANCE.eClass();
    GprimitivetypesPackage.eINSTANCE.eClass();

    // Load packages
    theEastadl21Package.loadPackage();

    // Fix loaded packages
    theEastadl21Package.fixPackageContents();

    // Register package validator
    EValidator.Registry.INSTANCE.put
      (theEastadl21Package, 
       new EValidator.Descriptor()
       {
         public EValidator getEValidator()
         {
           return Eastadl21Validator.INSTANCE;
         }
       });

    // Mark meta-data to indicate it can't be changed
    theEastadl21Package.freeze();

  
    // Update the registry and return the package
    EPackage.Registry.INSTANCE.put(Eastadl21Package.eNS_URI, theEastadl21Package);
    return theEastadl21Package;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVehicleLevel()
  {
    if (vehicleLevelEClass == null)
    {
      vehicleLevelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(0);
    }
    return vehicleLevelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleLevel_TechnicalFeatureModel()
  {
        return (EReference)getVehicleLevel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSystemModel()
  {
    if (systemModelEClass == null)
    {
      systemModelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(1);
    }
    return systemModelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSystemModel_VehicleLevel()
  {
        return (EReference)getSystemModel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSystemModel_AnalysisLevel()
  {
        return (EReference)getSystemModel().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSystemModel_DesignLevel()
  {
        return (EReference)getSystemModel().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSystemModel_ImplementationLevel()
  {
        return (EReference)getSystemModel().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAnalysisLevel()
  {
    if (analysisLevelEClass == null)
    {
      analysisLevelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(2);
    }
    return analysisLevelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAnalysisLevel_FunctionalAnalysisArchitecture()
  {
        return (EReference)getAnalysisLevel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDesignLevel()
  {
    if (designLevelEClass == null)
    {
      designLevelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(3);
    }
    return designLevelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDesignLevel_Allocation()
  {
        return (EReference)getDesignLevel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDesignLevel_FunctionalDesignArchitecture()
  {
        return (EReference)getDesignLevel().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDesignLevel_HardwareDesignArchitecture()
  {
        return (EReference)getDesignLevel().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getImplementationLevel()
  {
    if (implementationLevelEClass == null)
    {
      implementationLevelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(4);
    }
    return implementationLevelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getImplementationLevel_AutosarSystem()
  {
        return (EReference)getImplementationLevel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBindingTime()
  {
    if (bindingTimeEClass == null)
    {
      bindingTimeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(5);
    }
    return bindingTimeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBindingTime_Kind()
  {
        return (EAttribute)getBindingTime().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeature()
  {
    if (featureEClass == null)
    {
      featureEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(7);
    }
    return featureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFeature_Cardinality()
  {
        return (EAttribute)getFeature().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeature_RequiredBindingTime()
  {
        return (EReference)getFeature().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeature_ActualBindingTime()
  {
        return (EReference)getFeature().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeature_FeatureParameter()
  {
        return (EReference)getFeature().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeature_ChildNode()
  {
        return (EReference)getFeature().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureConstraint()
  {
    if (featureConstraintEClass == null)
    {
      featureConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(8);
    }
    return featureConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFeatureConstraint_Criterion()
  {
        return (EAttribute)getFeatureConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureGroup()
  {
    if (featureGroupEClass == null)
    {
      featureGroupEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(9);
    }
    return featureGroupEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFeatureGroup_Cardinality()
  {
        return (EAttribute)getFeatureGroup().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureGroup_ChildFeature()
  {
        return (EReference)getFeatureGroup().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureLink()
  {
    if (featureLinkEClass == null)
    {
      featureLinkEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(10);
    }
    return featureLinkEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFeatureLink_CustomType()
  {
        return (EAttribute)getFeatureLink().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFeatureLink_IsBidirectional()
  {
        return (EAttribute)getFeatureLink().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFeatureLink_Kind()
  {
        return (EAttribute)getFeatureLink().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureLink_End()
  {
        return (EReference)getFeatureLink().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureLink_Start()
  {
        return (EReference)getFeatureLink().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureModel()
  {
    if (featureModelEClass == null)
    {
      featureModelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(11);
    }
    return featureModelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureModel_RootFeature()
  {
        return (EReference)getFeatureModel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureModel_FeatureConstraint()
  {
        return (EReference)getFeatureModel().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureModel_FeatureLink()
  {
        return (EReference)getFeatureModel().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureTreeNode()
  {
    if (featureTreeNodeEClass == null)
    {
      featureTreeNodeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(12);
    }
    return featureTreeNodeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDeviationAttributeSet()
  {
    if (deviationAttributeSetEClass == null)
    {
      deviationAttributeSetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(14);
    }
    return deviationAttributeSetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowChangeAttribute()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowChangeCardinality()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowChangeDescription()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowChangeName()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowMove()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowReduction()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowRefinement()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowRegrouping()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDeviationAttributeSet_AllowRemoval()
  {
        return (EAttribute)getDeviationAttributeSet().getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVehicleFeature()
  {
    if (vehicleFeatureEClass == null)
    {
      vehicleFeatureEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(16);
    }
    return vehicleFeatureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVehicleFeature_IsCustomerVisible()
  {
        return (EAttribute)getVehicleFeature().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVehicleFeature_IsDesignVariabilityRationale()
  {
        return (EAttribute)getVehicleFeature().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVehicleFeature_IsRemoved()
  {
        return (EAttribute)getVehicleFeature().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleFeature_DeviationAttributeSet()
  {
        return (EReference)getVehicleFeature().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAllocateableElement()
  {
    if (allocateableElementEClass == null)
    {
      allocateableElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(17);
    }
    return allocateableElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAllocation()
  {
    if (allocationEClass == null)
    {
      allocationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(18);
    }
    return allocationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAllocation_FunctionAllocation()
  {
        return (EReference)getAllocation().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAnalysisFunctionPrototype()
  {
    if (analysisFunctionPrototypeEClass == null)
    {
      analysisFunctionPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(19);
    }
    return analysisFunctionPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAnalysisFunctionPrototype_Type()
  {
        return (EReference)getAnalysisFunctionPrototype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAnalysisFunctionType()
  {
    if (analysisFunctionTypeEClass == null)
    {
      analysisFunctionTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(20);
    }
    return analysisFunctionTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAnalysisFunctionType_Part()
  {
        return (EReference)getAnalysisFunctionType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBasicSoftwareFunctionType()
  {
    if (basicSoftwareFunctionTypeEClass == null)
    {
      basicSoftwareFunctionTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(21);
    }
    return basicSoftwareFunctionTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDesignFunctionPrototype()
  {
    if (designFunctionPrototypeEClass == null)
    {
      designFunctionPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(23);
    }
    return designFunctionPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDesignFunctionPrototype_Type()
  {
        return (EReference)getDesignFunctionPrototype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDesignFunctionType()
  {
    if (designFunctionTypeEClass == null)
    {
      designFunctionTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(24);
    }
    return designFunctionTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDesignFunctionType_Part()
  {
        return (EReference)getDesignFunctionType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionalDevice()
  {
    if (functionalDeviceEClass == null)
    {
      functionalDeviceEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(26);
    }
    return functionalDeviceEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionAllocation()
  {
    if (functionAllocationEClass == null)
    {
      functionAllocationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(27);
    }
    return functionAllocationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionAllocation_AllocatedElement()
  {
        return (EReference)getFunctionAllocation().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionAllocation_Target()
  {
        return (EReference)getFunctionAllocation().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionClientServerInterface()
  {
    if (functionClientServerInterfaceEClass == null)
    {
      functionClientServerInterfaceEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(28);
    }
    return functionClientServerInterfaceEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionClientServerInterface_Operation()
  {
        return (EReference)getFunctionClientServerInterface().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionClientServerPort()
  {
    if (functionClientServerPortEClass == null)
    {
      functionClientServerPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(29);
    }
    return functionClientServerPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFunctionClientServerPort_Kind()
  {
        return (EAttribute)getFunctionClientServerPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionClientServerPort_Type()
  {
        return (EReference)getFunctionClientServerPort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionConnector()
  {
    if (functionConnectorEClass == null)
    {
      functionConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(30);
    }
    return functionConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionConnector_Port()
  {
        return (EReference)getFunctionConnector().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionFlowPort()
  {
    if (functionFlowPortEClass == null)
    {
      functionFlowPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(31);
    }
    return functionFlowPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFunctionFlowPort_Direction()
  {
        return (EAttribute)getFunctionFlowPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionFlowPort_Type()
  {
        return (EReference)getFunctionFlowPort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionFlowPort_DefaultValue()
  {
        return (EReference)getFunctionFlowPort().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionPort()
  {
    if (functionPortEClass == null)
    {
      functionPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(32);
    }
    return functionPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionPowerPort()
  {
    if (functionPowerPortEClass == null)
    {
      functionPowerPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(33);
    }
    return functionPowerPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionPowerPort_Type()
  {
        return (EReference)getFunctionPowerPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionPrototype()
  {
    if (functionPrototypeEClass == null)
    {
      functionPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(34);
    }
    return functionPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionType()
  {
    if (functionTypeEClass == null)
    {
      functionTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(35);
    }
    return functionTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFunctionType_IsElementary()
  {
        return (EAttribute)getFunctionType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionType_Port()
  {
        return (EReference)getFunctionType().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionType_PortGroup()
  {
        return (EReference)getFunctionType().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionType_Connector()
  {
        return (EReference)getFunctionType().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwareFunctionType()
  {
    if (hardwareFunctionTypeEClass == null)
    {
      hardwareFunctionTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(36);
    }
    return hardwareFunctionTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareFunctionType_HardwareComponent()
  {
        return (EReference)getHardwareFunctionType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getLocalDeviceManager()
  {
    if (localDeviceManagerEClass == null)
    {
      localDeviceManagerEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(37);
    }
    return localDeviceManagerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOperation()
  {
    if (operationEClass == null)
    {
      operationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(38);
    }
    return operationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOperation_Argument()
  {
        return (EReference)getOperation().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOperation_Return()
  {
        return (EReference)getOperation().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPortGroup()
  {
    if (portGroupEClass == null)
    {
      portGroupEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(39);
    }
    return portGroupEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPortGroup_PortGroup()
  {
        return (EReference)getPortGroup().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPortGroup_Port()
  {
        return (EReference)getPortGroup().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionAllocation_allocatedElement()
  {
    if (functionAllocation_allocatedElementEClass == null)
    {
      functionAllocation_allocatedElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(40);
    }
    return functionAllocation_allocatedElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionAllocation_allocatedElement_AllocateableElement_context()
  {
        return (EReference)getFunctionAllocation_allocatedElement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionAllocation_allocatedElement_AllocateableElement()
  {
        return (EReference)getFunctionAllocation_allocatedElement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionAllocation_target()
  {
    if (functionAllocation_targetEClass == null)
    {
      functionAllocation_targetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(41);
    }
    return functionAllocation_targetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionAllocation_target_AllocationTarget_context()
  {
        return (EReference)getFunctionAllocation_target().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionAllocation_target_AllocationTarget()
  {
        return (EReference)getFunctionAllocation_target().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionConnector_port()
  {
    if (functionConnector_portEClass == null)
    {
      functionConnector_portEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(42);
    }
    return functionConnector_portEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionConnector_port_FunctionPrototype()
  {
        return (EReference)getFunctionConnector_port().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionConnector_port_FunctionPort()
  {
        return (EReference)getFunctionConnector_port().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getActuator()
  {
    if (actuatorEClass == null)
    {
      actuatorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(43);
    }
    return actuatorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getCommunicationHardwarePin()
  {
    if (communicationHardwarePinEClass == null)
    {
      communicationHardwarePinEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(44);
    }
    return communicationHardwarePinEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getElectricalComponent()
  {
    if (electricalComponentEClass == null)
    {
      electricalComponentEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(45);
    }
    return electricalComponentEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElectricalComponent_IsActive()
  {
        return (EAttribute)getElectricalComponent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwareComponentPrototype()
  {
    if (hardwareComponentPrototypeEClass == null)
    {
      hardwareComponentPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(47);
    }
    return hardwareComponentPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareComponentPrototype_Type()
  {
        return (EReference)getHardwareComponentPrototype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwareComponentType()
  {
    if (hardwareComponentTypeEClass == null)
    {
      hardwareComponentTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(48);
    }
    return hardwareComponentTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareComponentType_Connector()
  {
        return (EReference)getHardwareComponentType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareComponentType_Pin()
  {
        return (EReference)getHardwareComponentType().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareComponentType_Part()
  {
        return (EReference)getHardwareComponentType().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareComponentType_Port()
  {
        return (EReference)getHardwareComponentType().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareComponentType_PortConnector()
  {
        return (EReference)getHardwareComponentType().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwareConnector()
  {
    if (hardwareConnectorEClass == null)
    {
      hardwareConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(49);
    }
    return hardwareConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareConnector_Port()
  {
        return (EReference)getHardwareConnector().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwarePin()
  {
    if (hardwarePinEClass == null)
    {
      hardwarePinEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(50);
    }
    return hardwarePinEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHardwarePin_Direction()
  {
        return (EAttribute)getHardwarePin().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHardwarePin_IsGround()
  {
        return (EAttribute)getHardwarePin().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwarePort()
  {
    if (hardwarePortEClass == null)
    {
      hardwarePortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(51);
    }
    return hardwarePortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHardwarePort_IsShield()
  {
        return (EAttribute)getHardwarePort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePort_ContainedPin()
  {
        return (EReference)getHardwarePort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePort_ContainedPort()
  {
        return (EReference)getHardwarePort().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePort_ReferencedPin()
  {
        return (EReference)getHardwarePort().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwarePortConnector()
  {
    if (hardwarePortConnectorEClass == null)
    {
      hardwarePortConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(52);
    }
    return hardwarePortConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHardwarePortConnector_BusType()
  {
        return (EAttribute)getHardwarePortConnector().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHardwarePortConnector_BusSpeed()
  {
        return (EAttribute)getHardwarePortConnector().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePortConnector_Connector()
  {
        return (EReference)getHardwarePortConnector().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePortConnector_Port()
  {
        return (EReference)getHardwarePortConnector().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIOHardwarePin()
  {
    if (ioHardwarePinEClass == null)
    {
      ioHardwarePinEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(53);
    }
    return ioHardwarePinEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIOHardwarePin_Type()
  {
        return (EAttribute)getIOHardwarePin().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getNode()
  {
    if (nodeEClass == null)
    {
      nodeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(55);
    }
    return nodeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNode_ExecutionRate()
  {
        return (EAttribute)getNode().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPowerHardwarePin()
  {
    if (powerHardwarePinEClass == null)
    {
      powerHardwarePinEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(56);
    }
    return powerHardwarePinEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSensor()
  {
    if (sensorEClass == null)
    {
      sensorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(57);
    }
    return sensorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAllocationTarget()
  {
    if (allocationTargetEClass == null)
    {
      allocationTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(58);
    }
    return allocationTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwareConnector_port()
  {
    if (hardwareConnector_portEClass == null)
    {
      hardwareConnector_portEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(59);
    }
    return hardwareConnector_portEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareConnector_port_HardwareComponentPrototype()
  {
        return (EReference)getHardwareConnector_port().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwareConnector_port_HardwarePin()
  {
        return (EReference)getHardwareConnector_port().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardwarePortConnector_port()
  {
    if (hardwarePortConnector_portEClass == null)
    {
      hardwarePortConnector_portEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(60);
    }
    return hardwarePortConnector_portEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePortConnector_port_HardwareComponentPrototype()
  {
        return (EReference)getHardwarePortConnector_port().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardwarePortConnector_port_HardwarePort()
  {
        return (EReference)getHardwarePortConnector_port().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getClampConnector()
  {
    if (clampConnectorEClass == null)
    {
      clampConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(61);
    }
    return clampConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClampConnector_Port()
  {
        return (EReference)getClampConnector().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEnvironment()
  {
    if (environmentEClass == null)
    {
      environmentEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(62);
    }
    return environmentEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEnvironment_ClampConnector()
  {
        return (EReference)getEnvironment().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEnvironment_EnvironmentModel()
  {
        return (EReference)getEnvironment().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getClampConnector_port()
  {
    if (clampConnector_portEClass == null)
    {
      clampConnector_portEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(63);
    }
    return clampConnector_portEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClampConnector_port_FunctionPrototype()
  {
        return (EReference)getClampConnector_port().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClampConnector_port_FunctionPort()
  {
        return (EReference)getClampConnector_port().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehavior()
  {
    if (behaviorEClass == null)
    {
      behaviorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(64);
    }
    return behaviorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehavior_ModeGroup()
  {
        return (EReference)getBehavior().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehavior_Behavior()
  {
        return (EReference)getBehavior().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehavior_FunctionTrigger()
  {
        return (EReference)getBehavior().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMode()
  {
    if (modeEClass == null)
    {
      modeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(65);
    }
    return modeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMode_Condition()
  {
        return (EAttribute)getMode().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getModeGroup()
  {
    if (modeGroupEClass == null)
    {
      modeGroupEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(66);
    }
    return modeGroupEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getModeGroup_Precondition()
  {
        return (EAttribute)getModeGroup().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getModeGroup_Mode()
  {
        return (EReference)getModeGroup().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionBehavior()
  {
    if (functionBehaviorEClass == null)
    {
      functionBehaviorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(67);
    }
    return functionBehaviorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFunctionBehavior_Path()
  {
        return (EAttribute)getFunctionBehavior().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFunctionBehavior_Representation()
  {
        return (EAttribute)getFunctionBehavior().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionBehavior_Mode()
  {
        return (EReference)getFunctionBehavior().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionBehavior_Function()
  {
        return (EReference)getFunctionBehavior().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionTrigger()
  {
    if (functionTriggerEClass == null)
    {
      functionTriggerEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(69);
    }
    return functionTriggerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFunctionTrigger_TriggerPolicy()
  {
        return (EAttribute)getFunctionTrigger().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionTrigger_Function()
  {
        return (EReference)getFunctionTrigger().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionTrigger_Mode()
  {
        return (EReference)getFunctionTrigger().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionTrigger_FunctionPrototype()
  {
        return (EReference)getFunctionTrigger().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionTrigger_Port()
  {
        return (EReference)getFunctionTrigger().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigurableContainer()
  {
    if (configurableContainerEClass == null)
    {
      configurableContainerEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(71);
    }
    return configurableContainerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurableContainer_ConfigurableElement()
  {
        return (EReference)getConfigurableContainer().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurableContainer_PublicFeatureModel()
  {
        return (EReference)getConfigurableContainer().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurableContainer_VariationGroup()
  {
        return (EReference)getConfigurableContainer().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurableContainer_InternalBinding()
  {
        return (EReference)getConfigurableContainer().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurableContainer_PrivateContent()
  {
        return (EReference)getConfigurableContainer().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigurationDecision()
  {
    if (configurationDecisionEClass == null)
    {
      configurationDecisionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(72);
    }
    return configurationDecisionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfigurationDecision_Criterion()
  {
        return (EAttribute)getConfigurationDecision().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfigurationDecision_Effect()
  {
        return (EAttribute)getConfigurationDecision().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfigurationDecision_IsEquivalence()
  {
        return (EAttribute)getConfigurationDecision().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurationDecision_SelectionCriterion()
  {
        return (EReference)getConfigurationDecision().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurationDecision_Target()
  {
        return (EReference)getConfigurationDecision().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigurationDecisionFolder()
  {
    if (configurationDecisionFolderEClass == null)
    {
      configurationDecisionFolderEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(73);
    }
    return configurationDecisionFolderEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurationDecisionFolder_ChildEntry()
  {
        return (EReference)getConfigurationDecisionFolder().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigurationDecisionModel()
  {
    if (configurationDecisionModelEClass == null)
    {
      configurationDecisionModelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(74);
    }
    return configurationDecisionModelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigurationDecisionModel_RootEntry()
  {
        return (EReference)getConfigurationDecisionModel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigurationDecisionModelEntry()
  {
    if (configurationDecisionModelEntryEClass == null)
    {
      configurationDecisionModelEntryEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(75);
    }
    return configurationDecisionModelEntryEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfigurationDecisionModelEntry_IsActive()
  {
        return (EAttribute)getConfigurationDecisionModelEntry().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getContainerConfiguration()
  {
    if (containerConfigurationEClass == null)
    {
      containerConfigurationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(76);
    }
    return containerConfigurationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getContainerConfiguration_ConfiguredContainer()
  {
        return (EReference)getContainerConfiguration().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureConfiguration()
  {
    if (featureConfigurationEClass == null)
    {
      featureConfigurationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(77);
    }
    return featureConfigurationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureConfiguration_ConfiguredFeatureModel()
  {
        return (EReference)getFeatureConfiguration().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInternalBinding()
  {
    if (internalBindingEClass == null)
    {
      internalBindingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(78);
    }
    return internalBindingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPrivateContent()
  {
    if (privateContentEClass == null)
    {
      privateContentEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(79);
    }
    return privateContentEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrivateContent_PrivateElement()
  {
        return (EReference)getPrivateContent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getReuseMetaInformation()
  {
    if (reuseMetaInformationEClass == null)
    {
      reuseMetaInformationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(80);
    }
    return reuseMetaInformationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getReuseMetaInformation_Information()
  {
        return (EAttribute)getReuseMetaInformation().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getReuseMetaInformation_IsReusable()
  {
        return (EAttribute)getReuseMetaInformation().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSelectionCriterion()
  {
    if (selectionCriterionEClass == null)
    {
      selectionCriterionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(81);
    }
    return selectionCriterionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSelectionCriterion_Source()
  {
        return (EReference)getSelectionCriterion().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVariability()
  {
    if (variabilityEClass == null)
    {
      variabilityEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(82);
    }
    return variabilityEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariability_ProductFeatureModel()
  {
        return (EReference)getVariability().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariability_Configuration()
  {
        return (EReference)getVariability().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariability_DecisionModel()
  {
        return (EReference)getVariability().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariability_VariableElement()
  {
        return (EReference)getVariability().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariability_ConfigurableContainer()
  {
        return (EReference)getVariability().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVariableElement()
  {
    if (variableElementEClass == null)
    {
      variableElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(83);
    }
    return variableElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariableElement_OptionalElement()
  {
        return (EReference)getVariableElement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariableElement_ReuseMetaInformation()
  {
        return (EReference)getVariableElement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariableElement_RequiredBindingTime()
  {
        return (EReference)getVariableElement().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariableElement_ActualBindingTime()
  {
        return (EReference)getVariableElement().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVariationGroup()
  {
    if (variationGroupEClass == null)
    {
      variationGroupEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(84);
    }
    return variationGroupEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVariationGroup_Constraint()
  {
        return (EAttribute)getVariationGroup().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVariationGroup_Kind()
  {
        return (EAttribute)getVariationGroup().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariationGroup_VariableElement()
  {
        return (EReference)getVariationGroup().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVehicleLevelBinding()
  {
    if (vehicleLevelBindingEClass == null)
    {
      vehicleLevelBindingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(85);
    }
    return vehicleLevelBindingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleLevelBinding_TargetFeatureModel()
  {
        return (EReference)getVehicleLevelBinding().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleLevelBinding_SourceVehicleFeatureModel()
  {
        return (EReference)getVehicleLevelBinding().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDeriveRequirement()
  {
    if (deriveRequirementEClass == null)
    {
      deriveRequirementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(86);
    }
    return deriveRequirementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDeriveRequirement_Derived()
  {
        return (EReference)getDeriveRequirement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDeriveRequirement_DerivedFrom()
  {
        return (EReference)getDeriveRequirement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOperationalSituation()
  {
    if (operationalSituationEClass == null)
    {
      operationalSituationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(87);
    }
    return operationalSituationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRequirementsModel()
  {
    if (requirementsModelEClass == null)
    {
      requirementsModelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(88);
    }
    return requirementsModelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsModel_OperationalSituation()
  {
        return (EReference)getRequirementsModel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsModel_Requirement()
  {
        return (EReference)getRequirementsModel().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsModel_RequirementsRelationshipGroup()
  {
        return (EReference)getRequirementsModel().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsModel_RequirementsHierarchy()
  {
        return (EReference)getRequirementsModel().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsModel_UseCase()
  {
        return (EReference)getRequirementsModel().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsModel_RequirementType()
  {
        return (EReference)getRequirementsModel().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRequirementsRelationship()
  {
    if (requirementsRelationshipEClass == null)
    {
      requirementsRelationshipEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(89);
    }
    return requirementsRelationshipEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRequirement()
  {
    if (requirementEClass == null)
    {
      requirementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(90);
    }
    return requirementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRequirement_Formalism()
  {
        return (EAttribute)getRequirement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRequirement_Url()
  {
        return (EAttribute)getRequirement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirement_Mode()
  {
        return (EReference)getRequirement().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRequirementsHierarchy()
  {
    if (requirementsHierarchyEClass == null)
    {
      requirementsHierarchyEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(91);
    }
    return requirementsHierarchyEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsHierarchy_ContainedRequirement()
  {
        return (EReference)getRequirementsHierarchy().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsHierarchy_ChildHierarchy()
  {
        return (EReference)getRequirementsHierarchy().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRefine()
  {
    if (refineEClass == null)
    {
      refineEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(92);
    }
    return refineEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRefine_RefinedRequirement()
  {
        return (EReference)getRefine().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRefine_RefinedBy()
  {
        return (EReference)getRefine().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSatisfy()
  {
    if (satisfyEClass == null)
    {
      satisfyEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(93);
    }
    return satisfyEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSatisfy_SatisfiedRequirement()
  {
        return (EReference)getSatisfy().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSatisfy_SatisfiedUseCase()
  {
        return (EReference)getSatisfy().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSatisfy_SatisfiedBy()
  {
        return (EReference)getSatisfy().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRequirementsLink()
  {
    if (requirementsLinkEClass == null)
    {
      requirementsLinkEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(94);
    }
    return requirementsLinkEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRequirementsLink_IsBidirectional()
  {
        return (EAttribute)getRequirementsLink().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsLink_Source()
  {
        return (EReference)getRequirementsLink().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsLink_Target()
  {
        return (EReference)getRequirementsLink().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRequirementsRelationshipGroup()
  {
    if (requirementsRelationshipGroupEClass == null)
    {
      requirementsRelationshipGroupEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(95);
    }
    return requirementsRelationshipGroupEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRequirementsRelationshipGroup_RequirementsRelationship()
  {
        return (EReference)getRequirementsRelationshipGroup().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getQualityRequirement()
  {
    if (qualityRequirementEClass == null)
    {
      qualityRequirementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(96);
    }
    return qualityRequirementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQualityRequirement_Kind()
  {
        return (EAttribute)getQualityRequirement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRefine_refinedBy()
  {
    if (refine_refinedByEClass == null)
    {
      refine_refinedByEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(98);
    }
    return refine_refinedByEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRefine_refinedBy_Identifiable_context()
  {
        return (EReference)getRefine_refinedBy().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRefine_refinedBy_Identifiable_target()
  {
        return (EReference)getRefine_refinedBy().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSatisfy_satisfiedBy()
  {
    if (satisfy_satisfiedByEClass == null)
    {
      satisfy_satisfiedByEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(99);
    }
    return satisfy_satisfiedByEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSatisfy_satisfiedBy_Identifiable_target()
  {
        return (EReference)getSatisfy_satisfiedBy().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSatisfy_satisfiedBy_Identifiable_context()
  {
        return (EReference)getSatisfy_satisfiedBy().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getActor()
  {
    if (actorEClass == null)
    {
      actorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(100);
    }
    return actorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getExtend()
  {
    if (extendEClass == null)
    {
      extendEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(101);
    }
    return extendEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExtend_ExtendedCase()
  {
        return (EReference)getExtend().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExtend_ExtensionLocation()
  {
        return (EReference)getExtend().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getExtensionPoint()
  {
    if (extensionPointEClass == null)
    {
      extensionPointEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(102);
    }
    return extensionPointEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInclude()
  {
    if (includeEClass == null)
    {
      includeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(103);
    }
    return includeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInclude_Addition()
  {
        return (EReference)getInclude().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRedefinableElement()
  {
    if (redefinableElementEClass == null)
    {
      redefinableElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(104);
    }
    return redefinableElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUseCase()
  {
    if (useCaseEClass == null)
    {
      useCaseEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(105);
    }
    return useCaseEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUseCase_Extend()
  {
        return (EReference)getUseCase().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUseCase_ExtensionPoint()
  {
        return (EReference)getUseCase().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUseCase_Include()
  {
        return (EReference)getUseCase().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVerificationValidation()
  {
    if (verificationValidationEClass == null)
    {
      verificationValidationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(106);
    }
    return verificationValidationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVerificationValidation_VvTarget()
  {
        return (EReference)getVerificationValidation().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVerificationValidation_VvCase()
  {
        return (EReference)getVerificationValidation().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVerificationValidation_Verify()
  {
        return (EReference)getVerificationValidation().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVerify()
  {
    if (verifyEClass == null)
    {
      verifyEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(107);
    }
    return verifyEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVerify_VerifiedByCase()
  {
        return (EReference)getVerify().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVerify_VerifiedByProcedure()
  {
        return (EReference)getVerify().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVerify_VerifiedRequirement()
  {
        return (EReference)getVerify().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVActualOutcome()
  {
    if (vvActualOutcomeEClass == null)
    {
      vvActualOutcomeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(108);
    }
    return vvActualOutcomeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVActualOutcome_IntendedOutcome()
  {
        return (EReference)getVVActualOutcome().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVCase()
  {
    if (vvCaseEClass == null)
    {
      vvCaseEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(109);
    }
    return vvCaseEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_VvTarget()
  {
        return (EReference)getVVCase().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_VvProcedure()
  {
        return (EReference)getVVCase().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_VvLog()
  {
        return (EReference)getVVCase().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_AbstractVVCase()
  {
        return (EReference)getVVCase().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_VvSubject()
  {
        return (EReference)getVVCase().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVIntendedOutcome()
  {
    if (vvIntendedOutcomeEClass == null)
    {
      vvIntendedOutcomeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(110);
    }
    return vvIntendedOutcomeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVLog()
  {
    if (vvLogEClass == null)
    {
      vvLogEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(111);
    }
    return vvLogEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVVLog_Date()
  {
        return (EAttribute)getVVLog().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVLog_VvActualOutcome()
  {
        return (EReference)getVVLog().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVLog_PerformedVVProcedure()
  {
        return (EReference)getVVLog().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVProcedure()
  {
    if (vvProcedureEClass == null)
    {
      vvProcedureEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(112);
    }
    return vvProcedureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVProcedure_VvStimuli()
  {
        return (EReference)getVVProcedure().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVProcedure_VvIntendedOutcome()
  {
        return (EReference)getVVProcedure().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVProcedure_AbstractVVProcedure()
  {
        return (EReference)getVVProcedure().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVStimuli()
  {
    if (vvStimuliEClass == null)
    {
      vvStimuliEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(113);
    }
    return vvStimuliEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVTarget()
  {
    if (vvTargetEClass == null)
    {
      vvTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(114);
    }
    return vvTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVTarget_Element()
  {
        return (EReference)getVVTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVCase_vvSubject()
  {
    if (vvCase_vvSubjectEClass == null)
    {
      vvCase_vvSubjectEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(115);
    }
    return vvCase_vvSubjectEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_vvSubject_Identifiable_context()
  {
        return (EReference)getVVCase_vvSubject().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVCase_vvSubject_Identifiable_target()
  {
        return (EReference)getVVCase_vvSubject().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVVTarget_element()
  {
    if (vvTarget_elementEClass == null)
    {
      vvTarget_elementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(116);
    }
    return vvTarget_elementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVTarget_element_Identifiable_context()
  {
        return (EReference)getVVTarget_element().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVVTarget_element_Identifiable_target()
  {
        return (EReference)getVVTarget_element().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEvent()
  {
    if (eventEClass == null)
    {
      eventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(117);
    }
    return eventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventChain()
  {
    if (eventChainEClass == null)
    {
      eventChainEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(118);
    }
    return eventChainEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventChain_Segment()
  {
        return (EReference)getEventChain().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventChain_Stimulus()
  {
        return (EReference)getEventChain().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventChain_Response()
  {
        return (EReference)getEventChain().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPrecedenceConstraint()
  {
    if (precedenceConstraintEClass == null)
    {
      precedenceConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(119);
    }
    return precedenceConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrecedenceConstraint_Preceding()
  {
        return (EReference)getPrecedenceConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrecedenceConstraint_Successive()
  {
        return (EReference)getPrecedenceConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTiming()
  {
    if (timingEClass == null)
    {
      timingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(120);
    }
    return timingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTiming_Description()
  {
        return (EReference)getTiming().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTiming_Constraint()
  {
        return (EReference)getTiming().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTimingConstraint()
  {
    if (timingConstraintEClass == null)
    {
      timingConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(121);
    }
    return timingConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTimingConstraint_Mode()
  {
        return (EReference)getTimingConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTimingDescription()
  {
    if (timingDescriptionEClass == null)
    {
      timingDescriptionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(122);
    }
    return timingDescriptionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTimingExpression()
  {
    if (timingExpressionEClass == null)
    {
      timingExpressionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(123);
    }
    return timingExpressionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAUTOSAREvent()
  {
    if (autosarEventEClass == null)
    {
      autosarEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(124);
    }
    return autosarEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAUTOSAREvent_Ref()
  {
        return (EReference)getAUTOSAREvent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFaultFailure()
  {
    if (eventFaultFailureEClass == null)
    {
      eventFaultFailureEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(125);
    }
    return eventFaultFailureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFaultFailure_FaultFailure()
  {
        return (EReference)getEventFaultFailure().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFeatureFlaw()
  {
    if (eventFeatureFlawEClass == null)
    {
      eventFeatureFlawEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(126);
    }
    return eventFeatureFlawEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFeatureFlaw_FeatureFlaw()
  {
        return (EReference)getEventFeatureFlaw().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFunction()
  {
    if (eventFunctionEClass == null)
    {
      eventFunctionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(127);
    }
    return eventFunctionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunction_FunctionType()
  {
        return (EReference)getEventFunction().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunction_Function()
  {
        return (EReference)getEventFunction().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFunctionClientServerPort()
  {
    if (eventFunctionClientServerPortEClass == null)
    {
      eventFunctionClientServerPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(128);
    }
    return eventFunctionClientServerPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEventFunctionClientServerPort_EventKind()
  {
        return (EAttribute)getEventFunctionClientServerPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunctionClientServerPort_Port()
  {
        return (EReference)getEventFunctionClientServerPort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFunctionFlowPort()
  {
    if (eventFunctionFlowPortEClass == null)
    {
      eventFunctionFlowPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(130);
    }
    return eventFunctionFlowPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunctionFlowPort_Port()
  {
        return (EReference)getEventFunctionFlowPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getExternalEvent()
  {
    if (externalEventEClass == null)
    {
      externalEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(131);
    }
    return externalEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getModeEvent()
  {
    if (modeEventEClass == null)
    {
      modeEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(132);
    }
    return modeEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getModeEvent_Start()
  {
        return (EReference)getModeEvent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getModeEvent_End()
  {
        return (EReference)getModeEvent().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFunction_function()
  {
    if (eventFunction_functionEClass == null)
    {
      eventFunction_functionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(133);
    }
    return eventFunction_functionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunction_function_FunctionPrototype_context()
  {
        return (EReference)getEventFunction_function().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunction_function_FunctionPrototype_target()
  {
        return (EReference)getEventFunction_function().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFunctionClientServerPort_port()
  {
    if (eventFunctionClientServerPort_portEClass == null)
    {
      eventFunctionClientServerPort_portEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(134);
    }
    return eventFunctionClientServerPort_portEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunctionClientServerPort_port_FunctionPrototype()
  {
        return (EReference)getEventFunctionClientServerPort_port().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunctionClientServerPort_port_FunctionClientServerPort()
  {
        return (EReference)getEventFunctionClientServerPort_port().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventFunctionFlowPort_port()
  {
    if (eventFunctionFlowPort_portEClass == null)
    {
      eventFunctionFlowPort_portEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(135);
    }
    return eventFunctionFlowPort_portEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunctionFlowPort_port_FunctionPrototype()
  {
        return (EReference)getEventFunctionFlowPort_port().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventFunctionFlowPort_port_FunctionFlowPort()
  {
        return (EReference)getEventFunctionFlowPort_port().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAgeConstraint()
  {
    if (ageConstraintEClass == null)
    {
      ageConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(136);
    }
    return ageConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAgeConstraint_Minimum()
  {
        return (EReference)getAgeConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAgeConstraint_Maximum()
  {
        return (EReference)getAgeConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAgeConstraint_Scope()
  {
        return (EReference)getAgeConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getArbitraryConstraint()
  {
    if (arbitraryConstraintEClass == null)
    {
      arbitraryConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(137);
    }
    return arbitraryConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArbitraryConstraint_Maximum()
  {
        return (EReference)getArbitraryConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArbitraryConstraint_Minimum()
  {
        return (EReference)getArbitraryConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArbitraryConstraint_Event()
  {
        return (EReference)getArbitraryConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBurstConstraint()
  {
    if (burstConstraintEClass == null)
    {
      burstConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(138);
    }
    return burstConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBurstConstraint_MaxOccurences()
  {
        return (EAttribute)getBurstConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBurstConstraint_Event()
  {
        return (EReference)getBurstConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBurstConstraint_Length()
  {
        return (EReference)getBurstConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBurstConstraint_Minimum()
  {
        return (EReference)getBurstConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getComparisonConstraint()
  {
    if (comparisonConstraintEClass == null)
    {
      comparisonConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(139);
    }
    return comparisonConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getComparisonConstraint_Operator()
  {
        return (EAttribute)getComparisonConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getComparisonConstraint_LeftOperand()
  {
        return (EReference)getComparisonConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getComparisonConstraint_RightOperand()
  {
        return (EReference)getComparisonConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDelayConstraint()
  {
    if (delayConstraintEClass == null)
    {
      delayConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(141);
    }
    return delayConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDelayConstraint_Lower()
  {
        return (EReference)getDelayConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDelayConstraint_Upper()
  {
        return (EReference)getDelayConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDelayConstraint_Target()
  {
        return (EReference)getDelayConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDelayConstraint_Source()
  {
        return (EReference)getDelayConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getExecutionTimeConstraint()
  {
    if (executionTimeConstraintEClass == null)
    {
      executionTimeConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(142);
    }
    return executionTimeConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExecutionTimeConstraint_Lower()
  {
        return (EReference)getExecutionTimeConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExecutionTimeConstraint_Upper()
  {
        return (EReference)getExecutionTimeConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExecutionTimeConstraint_Resume()
  {
        return (EReference)getExecutionTimeConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExecutionTimeConstraint_Start()
  {
        return (EReference)getExecutionTimeConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExecutionTimeConstraint_Preemption()
  {
        return (EReference)getExecutionTimeConstraint().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getExecutionTimeConstraint_Stop()
  {
        return (EReference)getExecutionTimeConstraint().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputSynchronizationConstraint()
  {
    if (inputSynchronizationConstraintEClass == null)
    {
      inputSynchronizationConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(143);
    }
    return inputSynchronizationConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSynchronizationConstraint_Tolerance()
  {
        return (EReference)getInputSynchronizationConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSynchronizationConstraint_Scope()
  {
        return (EReference)getInputSynchronizationConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOrderConstraint()
  {
    if (orderConstraintEClass == null)
    {
      orderConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(144);
    }
    return orderConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOrderConstraint_Source()
  {
        return (EReference)getOrderConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOrderConstraint_Target()
  {
        return (EReference)getOrderConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputSynchronizationConstraint()
  {
    if (outputSynchronizationConstraintEClass == null)
    {
      outputSynchronizationConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(145);
    }
    return outputSynchronizationConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSynchronizationConstraint_Tolerance()
  {
        return (EReference)getOutputSynchronizationConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSynchronizationConstraint_Scope()
  {
        return (EReference)getOutputSynchronizationConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPatternConstraint()
  {
    if (patternConstraintEClass == null)
    {
      patternConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(146);
    }
    return patternConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPatternConstraint_Period()
  {
        return (EReference)getPatternConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPatternConstraint_Event()
  {
        return (EReference)getPatternConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPatternConstraint_Minimum()
  {
        return (EReference)getPatternConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPatternConstraint_Offset()
  {
        return (EReference)getPatternConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPatternConstraint_Jitter()
  {
        return (EReference)getPatternConstraint().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPeriodicConstraint()
  {
    if (periodicConstraintEClass == null)
    {
      periodicConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(147);
    }
    return periodicConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPeriodicConstraint_Event()
  {
        return (EReference)getPeriodicConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPeriodicConstraint_Jitter()
  {
        return (EReference)getPeriodicConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPeriodicConstraint_Period()
  {
        return (EReference)getPeriodicConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPeriodicConstraint_Minimum()
  {
        return (EReference)getPeriodicConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getReactionConstraint()
  {
    if (reactionConstraintEClass == null)
    {
      reactionConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(148);
    }
    return reactionConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getReactionConstraint_Minimum()
  {
        return (EReference)getReactionConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getReactionConstraint_Maximum()
  {
        return (EReference)getReactionConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getReactionConstraint_Scope()
  {
        return (EReference)getReactionConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRepetitionConstraint()
  {
    if (repetitionConstraintEClass == null)
    {
      repetitionConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(149);
    }
    return repetitionConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRepetitionConstraint_Span()
  {
        return (EAttribute)getRepetitionConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRepetitionConstraint_Event()
  {
        return (EReference)getRepetitionConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRepetitionConstraint_Lower()
  {
        return (EReference)getRepetitionConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRepetitionConstraint_Upper()
  {
        return (EReference)getRepetitionConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRepetitionConstraint_Jitter()
  {
        return (EReference)getRepetitionConstraint().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSporadicConstraint()
  {
    if (sporadicConstraintEClass == null)
    {
      sporadicConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(150);
    }
    return sporadicConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSporadicConstraint_Event()
  {
        return (EReference)getSporadicConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSporadicConstraint_Jitter()
  {
        return (EReference)getSporadicConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSporadicConstraint_Lower()
  {
        return (EReference)getSporadicConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSporadicConstraint_Upper()
  {
        return (EReference)getSporadicConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSporadicConstraint_Minimum()
  {
        return (EReference)getSporadicConstraint().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStrongDelayConstraint()
  {
    if (strongDelayConstraintEClass == null)
    {
      strongDelayConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(151);
    }
    return strongDelayConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStrongDelayConstraint_Upper()
  {
        return (EReference)getStrongDelayConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStrongDelayConstraint_Lower()
  {
        return (EReference)getStrongDelayConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStrongDelayConstraint_Source()
  {
        return (EReference)getStrongDelayConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStrongDelayConstraint_Target()
  {
        return (EReference)getStrongDelayConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStrongSynchronizationConstraint()
  {
    if (strongSynchronizationConstraintEClass == null)
    {
      strongSynchronizationConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(152);
    }
    return strongSynchronizationConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStrongSynchronizationConstraint_Tolerance()
  {
        return (EReference)getStrongSynchronizationConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStrongSynchronizationConstraint_Event()
  {
        return (EReference)getStrongSynchronizationConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSynchronizationConstraint()
  {
    if (synchronizationConstraintEClass == null)
    {
      synchronizationConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(153);
    }
    return synchronizationConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSynchronizationConstraint_Tolerance()
  {
        return (EReference)getSynchronizationConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSynchronizationConstraint_Event()
  {
        return (EReference)getSynchronizationConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPrecedenceConstraint_preceding()
  {
    if (precedenceConstraint_precedingEClass == null)
    {
      precedenceConstraint_precedingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(154);
    }
    return precedenceConstraint_precedingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrecedenceConstraint_preceding_FunctionPrototype_target()
  {
        return (EReference)getPrecedenceConstraint_preceding().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrecedenceConstraint_preceding_FunctionPrototype_context()
  {
        return (EReference)getPrecedenceConstraint_preceding().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPrecedenceConstraint_successive()
  {
    if (precedenceConstraint_successiveEClass == null)
    {
      precedenceConstraint_successiveEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(155);
    }
    return precedenceConstraint_successiveEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrecedenceConstraint_successive_FunctionPrototype_context()
  {
        return (EReference)getPrecedenceConstraint_successive().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPrecedenceConstraint_successive_FunctionPrototype_target()
  {
        return (EReference)getPrecedenceConstraint_successive().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDependability()
  {
    if (dependabilityEClass == null)
    {
      dependabilityEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(157);
    }
    return dependabilityEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_FeatureFlaw()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_TechnicalSafetyConcept()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_SafetyCase()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_Hazard()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_FaultFailure()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_EaDatatype()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_HazardousEvent()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_SafetyConstraint()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_ErrorModelType()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_FunctionalSafetyConcept()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_QuantitiativeSafetyConstraint()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_Item()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDependability_SafetyGoal()
  {
        return (EReference)getDependability().getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFeatureFlaw()
  {
    if (featureFlawEClass == null)
    {
      featureFlawEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(160);
    }
    return featureFlawEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureFlaw_Item()
  {
        return (EReference)getFeatureFlaw().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFeatureFlaw_NonFulfilledRequirement()
  {
        return (EReference)getFeatureFlaw().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHazard()
  {
    if (hazardEClass == null)
    {
      hazardEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(161);
    }
    return hazardEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazard_Malfunction()
  {
        return (EReference)getHazard().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazard_Item()
  {
        return (EReference)getHazard().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHazardousEvent()
  {
    if (hazardousEventEClass == null)
    {
      hazardousEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(162);
    }
    return hazardousEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHazardousEvent_ClassificationAssumptions()
  {
        return (EAttribute)getHazardousEvent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHazardousEvent_Controllability()
  {
        return (EAttribute)getHazardousEvent().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHazardousEvent_Exposure()
  {
        return (EAttribute)getHazardousEvent().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHazardousEvent_HazardClassification()
  {
        return (EAttribute)getHazardousEvent().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHazardousEvent_Severity()
  {
        return (EAttribute)getHazardousEvent().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazardousEvent_OperatingMode()
  {
        return (EReference)getHazardousEvent().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazardousEvent_ExternalMeasures()
  {
        return (EReference)getHazardousEvent().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazardousEvent_OperationalSituationUseCase()
  {
        return (EReference)getHazardousEvent().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazardousEvent_Environment()
  {
        return (EReference)getHazardousEvent().getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazardousEvent_Hazard()
  {
        return (EReference)getHazardousEvent().getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHazardousEvent_Traffic()
  {
        return (EReference)getHazardousEvent().getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getItem()
  {
    if (itemEClass == null)
    {
      itemEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(163);
    }
    return itemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getItem_DevelopmentCategory()
  {
        return (EAttribute)getItem().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getItem_VehicleFeature()
  {
        return (EReference)getItem().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailure()
  {
    if (faultFailureEClass == null)
    {
      faultFailureEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(166);
    }
    return faultFailureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailure_Anomaly()
  {
        return (EReference)getFaultFailure().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailure_FaultFailureValue()
  {
        return (EReference)getFaultFailure().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getQuantitativeSafetyConstraint()
  {
    if (quantitativeSafetyConstraintEClass == null)
    {
      quantitativeSafetyConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(167);
    }
    return quantitativeSafetyConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantitativeSafetyConstraint_FailureRate()
  {
        return (EAttribute)getQuantitativeSafetyConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantitativeSafetyConstraint_RepairRate()
  {
        return (EAttribute)getQuantitativeSafetyConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getQuantitativeSafetyConstraint_ConstrainedFaultFailure()
  {
        return (EReference)getQuantitativeSafetyConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSafetyConstraint()
  {
    if (safetyConstraintEClass == null)
    {
      safetyConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(168);
    }
    return safetyConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSafetyConstraint_AsilValue()
  {
        return (EAttribute)getSafetyConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyConstraint_ConstrainedFaultFailure()
  {
        return (EReference)getSafetyConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailure_anomaly()
  {
    if (faultFailure_anomalyEClass == null)
    {
      faultFailure_anomalyEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(169);
    }
    return faultFailure_anomalyEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailure_anomaly_Anomaly()
  {
        return (EReference)getFaultFailure_anomaly().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailure_anomaly_ErrorModelPrototype()
  {
        return (EReference)getFaultFailure_anomaly().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAnomaly()
  {
    if (anomalyEClass == null)
    {
      anomalyEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(170);
    }
    return anomalyEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAnomaly_Type()
  {
        return (EReference)getAnomaly().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getErrorBehavior()
  {
    if (errorBehaviorEClass == null)
    {
      errorBehaviorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(171);
    }
    return errorBehaviorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getErrorBehavior_FailureLogic()
  {
        return (EAttribute)getErrorBehavior().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getErrorBehavior_Type()
  {
        return (EAttribute)getErrorBehavior().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorBehavior_InternalFault()
  {
        return (EReference)getErrorBehavior().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorBehavior_InternalFailure()
  {
        return (EReference)getErrorBehavior().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorBehavior_ExternalFault()
  {
        return (EReference)getErrorBehavior().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorBehavior_ExternalFailure()
  {
        return (EReference)getErrorBehavior().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorBehavior_ProcessFault()
  {
        return (EReference)getErrorBehavior().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getErrorModelPrototype()
  {
    if (errorModelPrototypeEClass == null)
    {
      errorModelPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(173);
    }
    return errorModelPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_Target()
  {
        return (EReference)getErrorModelPrototype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_Type()
  {
        return (EReference)getErrorModelPrototype().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_FunctionTarget()
  {
        return (EReference)getErrorModelPrototype().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_HwTarget()
  {
        return (EReference)getErrorModelPrototype().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getErrorModelType()
  {
    if (errorModelTypeEClass == null)
    {
      errorModelTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(174);
    }
    return errorModelTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_ErrorBehaviorDescription()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_Target()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_HwTarget()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_FaultFailureConnector()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_ExternalFault()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_Part()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_Failure()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_InternalFault()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelType_ProcessFault()
  {
        return (EReference)getErrorModelType().getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFailureOutPort()
  {
    if (failureOutPortEClass == null)
    {
      failureOutPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(175);
    }
    return failureOutPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailurePort()
  {
    if (faultFailurePortEClass == null)
    {
      faultFailurePortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(176);
    }
    return faultFailurePortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePort_FunctionTarget()
  {
        return (EReference)getFaultFailurePort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePort_HwTarget()
  {
        return (EReference)getFaultFailurePort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailurePropagationLink()
  {
    if (faultFailurePropagationLinkEClass == null)
    {
      faultFailurePropagationLinkEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(177);
    }
    return faultFailurePropagationLinkEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFaultFailurePropagationLink_ImmediatePropagation()
  {
        return (EAttribute)getFaultFailurePropagationLink().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePropagationLink_FromPort()
  {
        return (EReference)getFaultFailurePropagationLink().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePropagationLink_ToPort()
  {
        return (EReference)getFaultFailurePropagationLink().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultInPort()
  {
    if (faultInPortEClass == null)
    {
      faultInPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(178);
    }
    return faultInPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInternalFaultPrototype()
  {
    if (internalFaultPrototypeEClass == null)
    {
      internalFaultPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(179);
    }
    return internalFaultPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getProcessFaultPrototype()
  {
    if (processFaultPrototypeEClass == null)
    {
      processFaultPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(180);
    }
    return processFaultPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getErrorModelPrototype_functionTarget()
  {
    if (errorModelPrototype_functionTargetEClass == null)
    {
      errorModelPrototype_functionTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(181);
    }
    return errorModelPrototype_functionTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_functionTarget_FunctionPrototype()
  {
        return (EReference)getErrorModelPrototype_functionTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_functionTarget_FunctionPrototype_context()
  {
        return (EReference)getErrorModelPrototype_functionTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getErrorModelPrototype_hwTarget()
  {
    if (errorModelPrototype_hwTargetEClass == null)
    {
      errorModelPrototype_hwTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(182);
    }
    return errorModelPrototype_hwTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_hwTarget_HardwareComponentPrototype_context()
  {
        return (EReference)getErrorModelPrototype_hwTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getErrorModelPrototype_hwTarget_HardwareComponentPrototype()
  {
        return (EReference)getErrorModelPrototype_hwTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailurePort_functionTarget()
  {
    if (faultFailurePort_functionTargetEClass == null)
    {
      faultFailurePort_functionTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(183);
    }
    return faultFailurePort_functionTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePort_functionTarget_FunctionPort()
  {
        return (EReference)getFaultFailurePort_functionTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePort_functionTarget_FunctionPrototype()
  {
        return (EReference)getFaultFailurePort_functionTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailurePort_hwTarget()
  {
    if (faultFailurePort_hwTargetEClass == null)
    {
      faultFailurePort_hwTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(184);
    }
    return faultFailurePort_hwTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePort_hwTarget_HardwarePort()
  {
        return (EReference)getFaultFailurePort_hwTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePort_hwTarget_HardwareComponentPrototype()
  {
        return (EReference)getFaultFailurePort_hwTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailurePropagationLink_fromPort()
  {
    if (faultFailurePropagationLink_fromPortEClass == null)
    {
      faultFailurePropagationLink_fromPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(185);
    }
    return faultFailurePropagationLink_fromPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePropagationLink_fromPort_FaultFailurePort()
  {
        return (EReference)getFaultFailurePropagationLink_fromPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePropagationLink_fromPort_ErrorModelPrototype()
  {
        return (EReference)getFaultFailurePropagationLink_fromPort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFaultFailurePropagationLink_toPort()
  {
    if (faultFailurePropagationLink_toPortEClass == null)
    {
      faultFailurePropagationLink_toPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(186);
    }
    return faultFailurePropagationLink_toPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePropagationLink_toPort_FaultFailurePort()
  {
        return (EReference)getFaultFailurePropagationLink_toPort().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFaultFailurePropagationLink_toPort_ErrorModelPrototype()
  {
        return (EReference)getFaultFailurePropagationLink_toPort().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFunctionalSafetyConcept()
  {
    if (functionalSafetyConceptEClass == null)
    {
      functionalSafetyConceptEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(187);
    }
    return functionalSafetyConceptEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFunctionalSafetyConcept_FunctionalSafetyRequirement()
  {
        return (EReference)getFunctionalSafetyConcept().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSafetyGoal()
  {
    if (safetyGoalEClass == null)
    {
      safetyGoalEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(188);
    }
    return safetyGoalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSafetyGoal_HazardClassification()
  {
        return (EAttribute)getSafetyGoal().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyGoal_SafeState()
  {
        return (EReference)getSafetyGoal().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyGoal_DerivedFrom()
  {
        return (EReference)getSafetyGoal().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyGoal_Requirement()
  {
        return (EReference)getSafetyGoal().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTechnicalSafetyConcept()
  {
    if (technicalSafetyConceptEClass == null)
    {
      technicalSafetyConceptEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(189);
    }
    return technicalSafetyConceptEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTechnicalSafetyConcept_TechnicalSafetyRequirement()
  {
        return (EReference)getTechnicalSafetyConcept().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getClaim()
  {
    if (claimEClass == null)
    {
      claimEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(190);
    }
    return claimEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClaim_Evidence()
  {
        return (EReference)getClaim().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClaim_Justification()
  {
        return (EReference)getClaim().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClaim_SupportedArgument()
  {
        return (EReference)getClaim().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClaim_SafetyRequirement()
  {
        return (EReference)getClaim().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getClaim_GoalDecompositionStrategy()
  {
        return (EReference)getClaim().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGround()
  {
    if (groundEClass == null)
    {
      groundEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(191);
    }
    return groundEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGround_SafetyEvidence()
  {
        return (EReference)getGround().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGround_Justification()
  {
        return (EReference)getGround().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSafetyCase()
  {
    if (safetyCaseEClass == null)
    {
      safetyCaseEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(193);
    }
    return safetyCaseEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSafetyCase_Context()
  {
        return (EAttribute)getSafetyCase().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSafetyCase_Stage()
  {
        return (EAttribute)getSafetyCase().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyCase_SafetyCase()
  {
        return (EReference)getSafetyCase().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyCase_Warrant()
  {
        return (EReference)getSafetyCase().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyCase_Claim()
  {
        return (EReference)getSafetyCase().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSafetyCase_Ground()
  {
        return (EReference)getSafetyCase().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getWarrant()
  {
    if (warrantEClass == null)
    {
      warrantEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(194);
    }
    return warrantEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getWarrant_DecomposedGoal()
  {
        return (EReference)getWarrant().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getWarrant_Evidence()
  {
        return (EReference)getWarrant().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getWarrant_Justification()
  {
        return (EReference)getWarrant().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenericConstraint()
  {
    if (genericConstraintEClass == null)
    {
      genericConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(195);
    }
    return genericConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenericConstraint_Kind()
  {
        return (EAttribute)getGenericConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenericConstraint_Target()
  {
        return (EReference)getGenericConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenericConstraint_Mode()
  {
        return (EReference)getGenericConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenericConstraint_Value()
  {
        return (EReference)getGenericConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenericConstraintSet()
  {
    if (genericConstraintSetEClass == null)
    {
      genericConstraintSetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(197);
    }
    return genericConstraintSetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenericConstraintSet_GenericConstraint()
  {
        return (EReference)getGenericConstraintSet().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTakeRateConstraint()
  {
    if (takeRateConstraintEClass == null)
    {
      takeRateConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(198);
    }
    return takeRateConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTakeRateConstraint_TakeRate()
  {
        return (EAttribute)getTakeRateConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTakeRateConstraint_Source()
  {
        return (EReference)getTakeRateConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getComment()
  {
    if (commentEClass == null)
    {
      commentEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(199);
    }
    return commentEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getComment_Body()
  {
        return (EAttribute)getComment().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getContext()
  {
    if (contextEClass == null)
    {
      contextEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(200);
    }
    return contextEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getContext_TraceableSpecification()
  {
        return (EReference)getContext().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getContext_OwnedRelationship()
  {
        return (EReference)getContext().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAConnector()
  {
    if (eaConnectorEClass == null)
    {
      eaConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(201);
    }
    return eaConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAElement()
  {
    if (eaElementEClass == null)
    {
      eaElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(202);
    }
    return eaElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEAElement_Name()
  {
        return (EAttribute)getEAElement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAElement_OwnedComment()
  {
        return (EReference)getEAElement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAPackage()
  {
    if (eaPackageEClass == null)
    {
      eaPackageEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(203);
    }
    return eaPackageEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAPackage_SubPackage()
  {
        return (EReference)getEAPackage().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAPackage_Element()
  {
        return (EReference)getEAPackage().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAPackageableElement()
  {
    if (eaPackageableElementEClass == null)
    {
      eaPackageableElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(204);
    }
    return eaPackageableElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAPackageableElement_EAPackage_element()
  {
        return (EReference)getEAPackageableElement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAPort()
  {
    if (eaPortEClass == null)
    {
      eaPortEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(205);
    }
    return eaPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAPrototype()
  {
    if (eaPrototypeEClass == null)
    {
      eaPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(206);
    }
    return eaPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAType()
  {
    if (eaTypeEClass == null)
    {
      eaTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(207);
    }
    return eaTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAXML()
  {
    if (eaxmlEClass == null)
    {
      eaxmlEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(208);
    }
    return eaxmlEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAXML_TopLevelPackage()
  {
        return (EReference)getEAXML().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRationale()
  {
    if (rationaleEClass == null)
    {
      rationaleEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(209);
    }
    return rationaleEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRealization()
  {
    if (realizationEClass == null)
    {
      realizationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(210);
    }
    return realizationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRealization_Realized()
  {
        return (EReference)getRealization().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRealization_RealizedBy()
  {
        return (EReference)getRealization().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getReferrable()
  {
    if (referrableEClass == null)
    {
      referrableEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(211);
    }
    return referrableEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getReferrable_ShortName()
  {
        return (EAttribute)getReferrable().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRelationship()
  {
    if (relationshipEClass == null)
    {
      relationshipEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(212);
    }
    return relationshipEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTraceableSpecification()
  {
    if (traceableSpecificationEClass == null)
    {
      traceableSpecificationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(213);
    }
    return traceableSpecificationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTraceableSpecification_Text()
  {
        return (EAttribute)getTraceableSpecification().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIdentifiable()
  {
    if (identifiableEClass == null)
    {
      identifiableEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(214);
    }
    return identifiableEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIdentifiable_Category()
  {
        return (EAttribute)getIdentifiable().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIdentifiable_Uuid()
  {
        return (EAttribute)getIdentifiable().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRealization_realized()
  {
    if (realization_realizedEClass == null)
    {
      realization_realizedEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(215);
    }
    return realization_realizedEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRealization_realized_Identifiable_target()
  {
        return (EReference)getRealization_realized().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRealization_realized_Identifiable_context()
  {
        return (EReference)getRealization_realized().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRealization_realizedBy()
  {
    if (realization_realizedByEClass == null)
    {
      realization_realizedByEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(216);
    }
    return realization_realizedByEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRealization_realizedBy_Identifiable_context()
  {
        return (EReference)getRealization_realizedBy().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRealization_realizedBy_Identifiable_target()
  {
        return (EReference)getRealization_realizedBy().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getArrayDatatype()
  {
    if (arrayDatatypeEClass == null)
    {
      arrayDatatypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(217);
    }
    return arrayDatatypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getArrayDatatype_MaxLength()
  {
        return (EAttribute)getArrayDatatype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getArrayDatatype_MinLength()
  {
        return (EAttribute)getArrayDatatype().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArrayDatatype_ElementType()
  {
        return (EReference)getArrayDatatype().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getCompositeDatatype()
  {
    if (compositeDatatypeEClass == null)
    {
      compositeDatatypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(218);
    }
    return compositeDatatypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCompositeDatatype_DatatypePrototype()
  {
        return (EReference)getCompositeDatatype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEABoolean()
  {
    if (eaBooleanEClass == null)
    {
      eaBooleanEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(219);
    }
    return eaBooleanEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEADatatype()
  {
    if (eaDatatypeEClass == null)
    {
      eaDatatypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(220);
    }
    return eaDatatypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEADatatypePrototype()
  {
    if (eaDatatypePrototypeEClass == null)
    {
      eaDatatypePrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(221);
    }
    return eaDatatypePrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEADatatypePrototype_Type()
  {
        return (EReference)getEADatatypePrototype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEANumerical()
  {
    if (eaNumericalEClass == null)
    {
      eaNumericalEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(222);
    }
    return eaNumericalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEANumerical_Max()
  {
        return (EAttribute)getEANumerical().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEANumerical_Min()
  {
        return (EAttribute)getEANumerical().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEANumerical_Unit()
  {
        return (EReference)getEANumerical().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAString()
  {
    if (eaStringEClass == null)
    {
      eaStringEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(223);
    }
    return eaStringEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEnumeration()
  {
    if (enumerationEClass == null)
    {
      enumerationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(224);
    }
    return enumerationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEnumeration_IsMultiValued()
  {
        return (EAttribute)getEnumeration().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEnumeration_Literal()
  {
        return (EReference)getEnumeration().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEnumerationLiteral()
  {
    if (enumerationLiteralEClass == null)
    {
      enumerationLiteralEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(225);
    }
    return enumerationLiteralEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getQuantity()
  {
    if (quantityEClass == null)
    {
      quantityEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(226);
    }
    return quantityEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_AmountOfSubstanceExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_ElectricCurrentExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_LengthExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_LuminousIntensityExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_MassExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_ThermodynamicTemperatureExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getQuantity_TimeExp()
  {
        return (EAttribute)getQuantity().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRangeableValueType()
  {
    if (rangeableValueTypeEClass == null)
    {
      rangeableValueTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(227);
    }
    return rangeableValueTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRangeableValueType_Accuracy()
  {
        return (EAttribute)getRangeableValueType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRangeableValueType_Resolution()
  {
        return (EAttribute)getRangeableValueType().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRangeableValueType_SignificantDigits()
  {
        return (EAttribute)getRangeableValueType().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRangeableValueType_BaseRangeable()
  {
        return (EReference)getRangeableValueType().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUnit()
  {
    if (unitEClass == null)
    {
      unitEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(228);
    }
    return unitEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUnit_Factor()
  {
        return (EAttribute)getUnit().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUnit_Symbol()
  {
        return (EAttribute)getUnit().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUnit_Offset()
  {
        return (EAttribute)getUnit().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUnit_Reference()
  {
        return (EReference)getUnit().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUnit_Quantity()
  {
        return (EReference)getUnit().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAArrayValue()
  {
    if (eaArrayValueEClass == null)
    {
      eaArrayValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(229);
    }
    return eaArrayValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAArrayValue_Value()
  {
        return (EReference)getEAArrayValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEABooleanValue()
  {
    if (eaBooleanValueEClass == null)
    {
      eaBooleanValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(230);
    }
    return eaBooleanValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEABooleanValue_Value()
  {
        return (EAttribute)getEABooleanValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEACompositeValue()
  {
    if (eaCompositeValueEClass == null)
    {
      eaCompositeValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(231);
    }
    return eaCompositeValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEACompositeValue_Value()
  {
        return (EReference)getEACompositeValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAEnumerationValue()
  {
    if (eaEnumerationValueEClass == null)
    {
      eaEnumerationValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(232);
    }
    return eaEnumerationValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAEnumerationValue_Value()
  {
        return (EReference)getEAEnumerationValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAExpression()
  {
    if (eaExpressionEClass == null)
    {
      eaExpressionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(233);
    }
    return eaExpressionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEANumericalValue()
  {
    if (eaNumericalValueEClass == null)
    {
      eaNumericalValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(234);
    }
    return eaNumericalValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEANumericalValue_Value()
  {
        return (EAttribute)getEANumericalValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAStringValue()
  {
    if (eaStringValueEClass == null)
    {
      eaStringValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(235);
    }
    return eaStringValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getEAStringValue_Value()
  {
        return (EAttribute)getEAStringValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEAValue()
  {
    if (eaValueEClass == null)
    {
      eaValueEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(236);
    }
    return eaValueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEAValue_Type()
  {
        return (EReference)getEAValue().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUserAttributeDefinition()
  {
    if (userAttributeDefinitionEClass == null)
    {
      userAttributeDefinitionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(237);
    }
    return userAttributeDefinitionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserAttributeDefinition_DefaultValue()
  {
        return (EReference)getUserAttributeDefinition().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserAttributeDefinition_Type()
  {
        return (EReference)getUserAttributeDefinition().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUserAttributedElement()
  {
    if (userAttributedElementEClass == null)
    {
      userAttributedElementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(238);
    }
    return userAttributedElementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserAttributedElement_UaValue()
  {
        return (EReference)getUserAttributedElement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserAttributedElement_AttributedElement()
  {
        return (EReference)getUserAttributedElement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserAttributedElement_UaType()
  {
        return (EReference)getUserAttributedElement().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUserElementType()
  {
    if (userElementTypeEClass == null)
    {
      userElementTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(239);
    }
    return userElementTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUserElementType_ValidFor()
  {
        return (EAttribute)getUserElementType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUserElementType_Key()
  {
        return (EAttribute)getUserElementType().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserElementType_UaDefinition()
  {
        return (EReference)getUserElementType().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintBindingAttribute()
  {
    if (behaviorConstraintBindingAttributeEClass == null)
    {
      behaviorConstraintBindingAttributeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(247);
    }
    return behaviorConstraintBindingAttributeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintBindingEvent()
  {
    if (behaviorConstraintBindingEventEClass == null)
    {
      behaviorConstraintBindingEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(248);
    }
    return behaviorConstraintBindingEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintInternalBinding()
  {
    if (behaviorConstraintInternalBindingEClass == null)
    {
      behaviorConstraintInternalBindingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(249);
    }
    return behaviorConstraintInternalBindingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_BindingThroughClampConnector()
  {
        return (EReference)getBehaviorConstraintInternalBinding().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_BindingThroughHardwareConnector()
  {
        return (EReference)getBehaviorConstraintInternalBinding().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_BindingThroughFunctionConnector()
  {
        return (EReference)getBehaviorConstraintInternalBinding().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintParameter()
  {
    if (behaviorConstraintParameterEClass == null)
    {
      behaviorConstraintParameterEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(250);
    }
    return behaviorConstraintParameterEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintPrototype()
  {
    if (behaviorConstraintPrototypeEClass == null)
    {
      behaviorConstraintPrototypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(251);
    }
    return behaviorConstraintPrototypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_Type()
  {
        return (EReference)getBehaviorConstraintPrototype().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_InstantiationVariable()
  {
        return (EReference)getBehaviorConstraintPrototype().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_TargetedVehicleFeatureElement()
  {
        return (EReference)getBehaviorConstraintPrototype().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_ErrorModelTarget()
  {
        return (EReference)getBehaviorConstraintPrototype().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_FunctionTarget()
  {
        return (EReference)getBehaviorConstraintPrototype().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_HardwareComponentTarget()
  {
        return (EReference)getBehaviorConstraintPrototype().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintTargetBinding()
  {
    if (behaviorConstraintTargetBindingEClass == null)
    {
      behaviorConstraintTargetBindingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(252);
    }
    return behaviorConstraintTargetBindingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_TargetedVehicleFeature()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_ConstrainedModeBehavior()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_TargetedHardwareComponentType()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_BehaviorConstraintType()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_TargetedFunctionType()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_ConstrainedFunctionTriggering()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_ConstrainedFunctionBehavior()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintTargetBinding_ConstrainedErrorModel()
  {
        return (EReference)getBehaviorConstraintTargetBinding().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintType()
  {
    if (behaviorConstraintTypeEClass == null)
    {
      behaviorConstraintTypeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(253);
    }
    return behaviorConstraintTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintType_InterfaceVariable()
  {
        return (EReference)getBehaviorConstraintType().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintType_SharedVariable()
  {
        return (EReference)getBehaviorConstraintType().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintType_Part()
  {
        return (EReference)getBehaviorConstraintType().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintType_AttributeQuantificationConstraint()
  {
        return (EReference)getBehaviorConstraintType().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintType_ComputationConstraint()
  {
        return (EReference)getBehaviorConstraintType().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintType_TemporalConstraint()
  {
        return (EReference)getBehaviorConstraintType().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector()
  {
    if (behaviorConstraintInternalBinding_bindingThroughFunctionConnectorEClass == null)
    {
      behaviorConstraintInternalBinding_bindingThroughFunctionConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(254);
    }
    return behaviorConstraintInternalBinding_bindingThroughFunctionConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector_FunctionPrototype()
  {
        return (EReference)getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector_FunctionConnector()
  {
        return (EReference)getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector()
  {
    if (behaviorConstraintInternalBinding_bindingThroughHardwareConnectorEClass == null)
    {
      behaviorConstraintInternalBinding_bindingThroughHardwareConnectorEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(255);
    }
    return behaviorConstraintInternalBinding_bindingThroughHardwareConnectorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector_HardwareConnector()
  {
        return (EReference)getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector_HardwareComponentPrototype()
  {
        return (EReference)getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintPrototype_errorModelTarget()
  {
    if (behaviorConstraintPrototype_errorModelTargetEClass == null)
    {
      behaviorConstraintPrototype_errorModelTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(256);
    }
    return behaviorConstraintPrototype_errorModelTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_errorModelTarget_ErrorModelPrototype_target()
  {
        return (EReference)getBehaviorConstraintPrototype_errorModelTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_errorModelTarget_ErrorModelPrototype_context()
  {
        return (EReference)getBehaviorConstraintPrototype_errorModelTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintPrototype_functionTarget()
  {
    if (behaviorConstraintPrototype_functionTargetEClass == null)
    {
      behaviorConstraintPrototype_functionTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(257);
    }
    return behaviorConstraintPrototype_functionTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_functionTarget_FunctionPrototype_context()
  {
        return (EReference)getBehaviorConstraintPrototype_functionTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_functionTarget_FunctionPrototype_target()
  {
        return (EReference)getBehaviorConstraintPrototype_functionTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorConstraintPrototype_hardwareComponentTarget()
  {
    if (behaviorConstraintPrototype_hardwareComponentTargetEClass == null)
    {
      behaviorConstraintPrototype_hardwareComponentTargetEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(258);
    }
    return behaviorConstraintPrototype_hardwareComponentTargetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_hardwareComponentTarget_HardwareComponentPrototype_target()
  {
        return (EReference)getBehaviorConstraintPrototype_hardwareComponentTarget().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorConstraintPrototype_hardwareComponentTarget_HardwareComponentPrototype_context()
  {
        return (EReference)getBehaviorConstraintPrototype_hardwareComponentTarget().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAttribute()
  {
    if (attributeEClass == null)
    {
      attributeEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(259);
    }
    return attributeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAttribute_IsExternVisible()
  {
        return (EAttribute)getAttribute().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAttribute_Type()
  {
        return (EReference)getAttribute().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAttributeQuantificationConstraint()
  {
    if (attributeQuantificationConstraintEClass == null)
    {
      attributeQuantificationConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(260);
    }
    return attributeQuantificationConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAttributeQuantificationConstraint_Attribute()
  {
        return (EReference)getAttributeQuantificationConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAttributeQuantificationConstraint_Quantification()
  {
        return (EReference)getAttributeQuantificationConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBehaviorAttributeBinding()
  {
    if (behaviorAttributeBindingEClass == null)
    {
      behaviorAttributeBindingEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(261);
    }
    return behaviorAttributeBindingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorAttributeBinding_VisibleThroughFunctionPort()
  {
        return (EReference)getBehaviorAttributeBinding().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorAttributeBinding_VisibleThroughHardwarePin()
  {
        return (EReference)getBehaviorAttributeBinding().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorAttributeBinding_Attribute()
  {
        return (EReference)getBehaviorAttributeBinding().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorAttributeBinding_VisibleThroughHardwarePort()
  {
        return (EReference)getBehaviorAttributeBinding().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBehaviorAttributeBinding_VisibleThroughAnomaly()
  {
        return (EReference)getBehaviorAttributeBinding().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getLogicalEvent()
  {
    if (logicalEventEClass == null)
    {
      logicalEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(262);
    }
    return logicalEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getLogicalEvent_IsExternVisible()
  {
        return (EAttribute)getLogicalEvent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalEvent_VisibleThroughFunctionPort()
  {
        return (EReference)getLogicalEvent().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getQuantification()
  {
    if (quantificationEClass == null)
    {
      quantificationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(263);
    }
    return quantificationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getQuantification_TimeCondition()
  {
        return (EReference)getQuantification().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getQuantification_Operand()
  {
        return (EReference)getQuantification().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getComputationConstraint()
  {
    if (computationConstraintEClass == null)
    {
      computationConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(264);
    }
    return computationConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getComputationConstraint_LogicalPath()
  {
        return (EReference)getComputationConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getComputationConstraint_LogicalTransformation()
  {
        return (EReference)getComputationConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getLogicalPath()
  {
    if (logicalPathEClass == null)
    {
      logicalPathEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(265);
    }
    return logicalPathEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_PrecedingExecutionEventChain()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_CorrespondingExecutionEventChain()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_Strand()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_Segment()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_LogicalResponse()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_SucceedingExecutionEventChain()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_LogicalStimulus()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalPath_TransformationOccurrence()
  {
        return (EReference)getLogicalPath().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getLogicalTransformation()
  {
    if (logicalTransformationEClass == null)
    {
      logicalTransformationEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(266);
    }
    return logicalTransformationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getLogicalTransformation_IsClientServerInterface()
  {
        return (EAttribute)getLogicalTransformation().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_Expression()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_In()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_ClientServerInterfaceOperation()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_TimeInvariant()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_PostCondition()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_PreCondition()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_Out()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_QuantificationInvariant()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTransformation_Contained()
  {
        return (EReference)getLogicalTransformation().getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTransformationOccurrence()
  {
    if (transformationOccurrenceEClass == null)
    {
      transformationOccurrenceEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(267);
    }
    return transformationOccurrenceEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformationOccurrence_OutQuantification()
  {
        return (EReference)getTransformationOccurrence().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformationOccurrence_TimeCondition()
  {
        return (EReference)getTransformationOccurrence().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformationOccurrence_InQuantification()
  {
        return (EReference)getTransformationOccurrence().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformationOccurrence_InvokedLogicalTransformation()
  {
        return (EReference)getTransformationOccurrence().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getLogicalTimeCondition()
  {
    if (logicalTimeConditionEClass == null)
    {
      logicalTimeConditionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(268);
    }
    return logicalTimeConditionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getLogicalTimeCondition_IsLogicalTimeSuspended()
  {
        return (EAttribute)getLogicalTimeCondition().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTimeCondition_Upper()
  {
        return (EReference)getLogicalTimeCondition().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTimeCondition_Width()
  {
        return (EReference)getLogicalTimeCondition().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTimeCondition_Lower()
  {
        return (EReference)getLogicalTimeCondition().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTimeCondition_StartPointReference()
  {
        return (EReference)getLogicalTimeCondition().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTimeCondition_EndPointReference()
  {
        return (EReference)getLogicalTimeCondition().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLogicalTimeCondition_ConsecutiveTimeCondition()
  {
        return (EReference)getLogicalTimeCondition().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getState()
  {
    if (stateEClass == null)
    {
      stateEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(269);
    }
    return stateEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getState_IsErrorState()
  {
        return (EAttribute)getState().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getState_IsHazard()
  {
        return (EAttribute)getState().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getState_IsInitState()
  {
        return (EAttribute)getState().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getState_IsMode()
  {
        return (EAttribute)getState().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getState_HazardDeclaration()
  {
        return (EReference)getState().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getState_TimeInvariant()
  {
        return (EReference)getState().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getState_ModeDeclaration()
  {
        return (EReference)getState().getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getState_QuantificationInvariant()
  {
        return (EReference)getState().getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStateEvent()
  {
    if (stateEventEClass == null)
    {
      stateEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(270);
    }
    return stateEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStateEvent_End()
  {
        return (EReference)getStateEvent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStateEvent_Start()
  {
        return (EReference)getStateEvent().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSynchronousTransition()
  {
    if (synchronousTransitionEClass == null)
    {
      synchronousTransitionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(271);
    }
    return synchronousTransitionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSynchronousTransition_WriteTransitionEvent()
  {
        return (EReference)getSynchronousTransition().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSynchronousTransition_ReadTransitionEvent()
  {
        return (EReference)getSynchronousTransition().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTemporalConstraint()
  {
    if (temporalConstraintEClass == null)
    {
      temporalConstraintEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(272);
    }
    return temporalConstraintEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTemporalConstraint_Assertion()
  {
        return (EReference)getTemporalConstraint().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTemporalConstraint_TimeCondition()
  {
        return (EReference)getTemporalConstraint().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTemporalConstraint_TransitionEvent()
  {
        return (EReference)getTemporalConstraint().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTemporalConstraint_Transition()
  {
        return (EReference)getTemporalConstraint().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTemporalConstraint_InitState()
  {
        return (EReference)getTemporalConstraint().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTemporalConstraint_State()
  {
        return (EReference)getTemporalConstraint().getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTransition()
  {
    if (transitionEClass == null)
    {
      transitionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(273);
    }
    return transitionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransition_Effect()
  {
        return (EReference)getTransition().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransition_To()
  {
        return (EReference)getTransition().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransition_QuantificationGuard()
  {
        return (EReference)getTransition().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransition_From()
  {
        return (EReference)getTransition().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransition_TimeGuard()
  {
        return (EReference)getTransition().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTransitionEvent()
  {
    if (transitionEventEClass == null)
    {
      transitionEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(274);
    }
    return transitionEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransitionEvent_OccurredHazardousEvent()
  {
        return (EReference)getTransitionEvent().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransitionEvent_OccurredFeatureFlaw()
  {
        return (EReference)getTransitionEvent().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransitionEvent_OccurredLogicalEvent()
  {
        return (EReference)getTransitionEvent().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransitionEvent_OccurredFaultFailure()
  {
        return (EReference)getTransitionEvent().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransitionEvent_OccurredExecutionEvent()
  {
        return (EReference)getTransitionEvent().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getArchitecturalDescription()
  {
    if (architecturalDescriptionEClass == null)
    {
      architecturalDescriptionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(275);
    }
    return architecturalDescriptionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArchitecturalDescription_Identifies()
  {
        return (EReference)getArchitecturalDescription().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArchitecturalDescription_Aggregates()
  {
        return (EReference)getArchitecturalDescription().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getArchitecturalModel()
  {
    if (architecturalModelEClass == null)
    {
      architecturalModelEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(276);
    }
    return architecturalModelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArchitecturalModel_IsConceptFor()
  {
        return (EReference)getArchitecturalModel().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getArchitecture()
  {
    if (architectureEClass == null)
    {
      architectureEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(277);
    }
    return architectureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getArchitecture_DescribedBy()
  {
        return (EReference)getArchitecture().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConcept()
  {
    if (conceptEClass == null)
    {
      conceptEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(278);
    }
    return conceptEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMission()
  {
    if (missionEClass == null)
    {
      missionEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(279);
    }
    return missionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVehicleSystem()
  {
    if (vehicleSystemEClass == null)
    {
      vehicleSystemEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(280);
    }
    return vehicleSystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleSystem_Has()
  {
        return (EReference)getVehicleSystem().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleSystem_HasAn()
  {
        return (EReference)getVehicleSystem().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVehicleSystem_Fulfills()
  {
        return (EReference)getVehicleSystem().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStakeholder()
  {
    if (stakeholderEClass == null)
    {
      stakeholderEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(281);
    }
    return stakeholderEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStakeholder_Responsibilities()
  {
        return (EAttribute)getStakeholder().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStakeholder_SuccessCriteria()
  {
        return (EAttribute)getStakeholder().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStakeholderNeed()
  {
    if (stakeholderNeedEClass == null)
    {
      stakeholderNeedEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(282);
    }
    return stakeholderNeedEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStakeholderNeed_Need()
  {
        return (EAttribute)getStakeholderNeed().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStakeholderNeed_Priority()
  {
        return (EAttribute)getStakeholderNeed().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStakeholderNeed_Stakeholder()
  {
        return (EReference)getStakeholderNeed().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getStakeholderNeed_ProblemStatement()
  {
        return (EReference)getStakeholderNeed().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBusinessOpportunity()
  {
    if (businessOpportunityEClass == null)
    {
      businessOpportunityEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(283);
    }
    return businessOpportunityEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBusinessOpportunity_BusinessOpportunity()
  {
        return (EAttribute)getBusinessOpportunity().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBusinessOpportunity_MotivatesDevelopmentOf()
  {
        return (EReference)getBusinessOpportunity().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBusinessOpportunity_ProductPositioning()
  {
        return (EReference)getBusinessOpportunity().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBusinessOpportunity_ProblemStatement()
  {
        return (EReference)getBusinessOpportunity().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getProblemStatement()
  {
    if (problemStatementEClass == null)
    {
      problemStatementEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(284);
    }
    return problemStatementEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProblemStatement_Impact()
  {
        return (EAttribute)getProblemStatement().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProblemStatement_Problem()
  {
        return (EAttribute)getProblemStatement().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProblemStatement_SolutionBenefits()
  {
        return (EAttribute)getProblemStatement().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getProblemStatement_Affects()
  {
        return (EReference)getProblemStatement().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getProductPositioning()
  {
    if (productPositioningEClass == null)
    {
      productPositioningEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(285);
    }
    return productPositioningEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProductPositioning_DrivingNeeds()
  {
        return (EAttribute)getProductPositioning().getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProductPositioning_KeyCapabilities()
  {
        return (EAttribute)getProductPositioning().getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProductPositioning_PrimaryCompetitiveAlternative()
  {
        return (EAttribute)getProductPositioning().getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProductPositioning_PrimaryDifferentiation()
  {
        return (EAttribute)getProductPositioning().getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getProductPositioning_TargetCustomers()
  {
        return (EAttribute)getProductPositioning().getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSystem()
  {
    if (systemEClass == null)
    {
      systemEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(286);
    }
    return systemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTimingDescriptionEvent()
  {
    if (timingDescriptionEventEClass == null)
    {
      timingDescriptionEventEClass = (EClass)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(287);
    }
    return timingDescriptionEventEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getBindingTimeKind()
  {
    if (bindingTimeKindEEnum == null)
    {
      bindingTimeKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(6);
    }
    return bindingTimeKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getVariabilityDependencyKind()
  {
    if (variabilityDependencyKindEEnum == null)
    {
      variabilityDependencyKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(13);
    }
    return variabilityDependencyKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getDeviationPermissionKind()
  {
    if (deviationPermissionKindEEnum == null)
    {
      deviationPermissionKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(15);
    }
    return deviationPermissionKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getClientServerKind()
  {
    if (clientServerKindEEnum == null)
    {
      clientServerKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(22);
    }
    return clientServerKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getEADirectionKind()
  {
    if (eaDirectionKindEEnum == null)
    {
      eaDirectionKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(25);
    }
    return eaDirectionKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getHardwareBusKind()
  {
    if (hardwareBusKindEEnum == null)
    {
      hardwareBusKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(46);
    }
    return hardwareBusKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getIOHardwarePinKind()
  {
    if (ioHardwarePinKindEEnum == null)
    {
      ioHardwarePinKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(54);
    }
    return ioHardwarePinKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getFunctionBehaviorKind()
  {
    if (functionBehaviorKindEEnum == null)
    {
      functionBehaviorKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(68);
    }
    return functionBehaviorKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getTriggerPolicyKind()
  {
    if (triggerPolicyKindEEnum == null)
    {
      triggerPolicyKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(70);
    }
    return triggerPolicyKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getQualityRequirementKind()
  {
    if (qualityRequirementKindEEnum == null)
    {
      qualityRequirementKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(97);
    }
    return qualityRequirementKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getEventFunctionClientServerPortKind()
  {
    if (eventFunctionClientServerPortKindEEnum == null)
    {
      eventFunctionClientServerPortKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(129);
    }
    return eventFunctionClientServerPortKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getComparisonKind()
  {
    if (comparisonKindEEnum == null)
    {
      comparisonKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(140);
    }
    return comparisonKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getControllabilityClassKind()
  {
    if (controllabilityClassKindEEnum == null)
    {
      controllabilityClassKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(156);
    }
    return controllabilityClassKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getDevelopmentCategoryKind()
  {
    if (developmentCategoryKindEEnum == null)
    {
      developmentCategoryKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(158);
    }
    return developmentCategoryKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getExposureClassKind()
  {
    if (exposureClassKindEEnum == null)
    {
      exposureClassKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(159);
    }
    return exposureClassKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getSeverityClassKind()
  {
    if (severityClassKindEEnum == null)
    {
      severityClassKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(164);
    }
    return severityClassKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getASILKind()
  {
    if (asilKindEEnum == null)
    {
      asilKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(165);
    }
    return asilKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getErrorBehaviorKind()
  {
    if (errorBehaviorKindEEnum == null)
    {
      errorBehaviorKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(172);
    }
    return errorBehaviorKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getLifecycleStageKind()
  {
    if (lifecycleStageKindEEnum == null)
    {
      lifecycleStageKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(192);
    }
    return lifecycleStageKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getGenericConstraintKind()
  {
    if (genericConstraintKindEEnum == null)
    {
      genericConstraintKindEEnum = (EEnum)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(196);
    }
    return genericConstraintKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getBoolean()
  {
    if (booleanEDataType == null)
    {
      booleanEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(240);
    }
    return booleanEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getFloat()
  {
    if (floatEDataType == null)
    {
      floatEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(241);
    }
    return floatEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getIdentifier()
  {
    if (identifierEDataType == null)
    {
      identifierEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(242);
    }
    return identifierEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getInteger()
  {
    if (integerEDataType == null)
    {
      integerEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(243);
    }
    return integerEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getNumerical()
  {
    if (numericalEDataType == null)
    {
      numericalEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(244);
    }
    return numericalEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getRef()
  {
    if (refEDataType == null)
    {
      refEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(245);
    }
    return refEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getString()
  {
    if (stringEDataType == null)
    {
      stringEDataType = (EDataType)EPackage.Registry.INSTANCE.getEPackage(Eastadl21Package.eNS_URI).getEClassifiers().get(246);
    }
    return stringEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eastadl21Factory getEastadl21Factory()
  {
    return (Eastadl21Factory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isLoaded = false;

  /**
   * Laods the package and any sub-packages from their serialized form.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void loadPackage()
  {
    if (isLoaded) return;
    isLoaded = true;

    URL url = getClass().getResource(packageFilename);
    if (url == null)
    {
      throw new RuntimeException("Missing serialized package: " + packageFilename);
    }
    URI uri = URI.createURI(url.toString());
    Resource resource = new EcoreResourceFactoryImpl().createResource(uri);
    try
    {
      resource.load(null);
    }
    catch (IOException exception)
    {
      throw new WrappedException(exception);
    }
    initializeFromLoadedEPackage(this, (EPackage)resource.getContents().get(0));
    createResource(eNS_URI);
  }


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isFixed = false;

  /**
   * Fixes up the loaded package, to make it appear as if it had been programmatically built.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void fixPackageContents()
  {
    if (isFixed) return;
    isFixed = true;
    fixEClassifiers();
  }

  /**
   * Sets the instance class on the given classifier.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected void fixInstanceClass(EClassifier eClassifier)
  {
    if (eClassifier.getInstanceClassName() == null)
    {
      eClassifier.setInstanceClassName("org.eclipse.eatop.eastadl21." + eClassifier.getName());
      setGeneratedClassName(eClassifier);
    }
  }

} //Eastadl21PackageImpl
