/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Flaw</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * FeatureFlaw denotes an abstract failure of a set of items, i.e. an inability to fulfill one or several of its requirements.
 * 
 * Semantics:
 * FeatureFlaw represents functional anomalies derivable from each foreseeable source, nonFulfilledRequirements identifies those requirements that correspond to the FeatureFlaw.
 * 
 * Extension:
 * UML::Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.FeatureFlaw</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureFlaw#getItem <em>Item</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FeatureFlaw#getNonFulfilledRequirement <em>Non Fulfilled Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureFlaw()
 * @model annotation="MetaData guid='{CB7D0AE0-1A33-4c7c-981C-58043770E110}' id='-112118986' EA\040name='FeatureFlaw'"
 *        extendedMetaData="name='FEATURE-FLAW' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-FLAWS'"
 * @generated
 */
public interface FeatureFlaw extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Item</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Item}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Item</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Item</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureFlaw_Item()
   * @model required="true"
   *        annotation="MetaData guid='{DD145DDA-B338-4c2e-9F9E-104B2C5A3D98}' id='1024025684' EA\040name=''"
   *        extendedMetaData="name='ITEM-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ITEM-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Item> getItem();

  /**
   * Returns the value of the '<em><b>Non Fulfilled Requirement</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Requirement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Non Fulfilled Requirement</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Non Fulfilled Requirement</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeatureFlaw_NonFulfilledRequirement()
   * @model annotation="MetaData guid='{21C70DC8-DCC6-4bbf-86F3-36D78FF43EF9}' id='1803326432' EA\040name=''"
   *        extendedMetaData="name='NON-FULFILLED-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NON-FULFILLED-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Requirement> getNonFulfilledRequirement();

} // FeatureFlaw
