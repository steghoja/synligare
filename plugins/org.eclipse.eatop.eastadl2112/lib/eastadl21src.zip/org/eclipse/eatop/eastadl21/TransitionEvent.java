/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A transition event denotes the occurrence, i.e. the actual happening, of certain logical, execution specific, and erroneous conditions, that fires the transitions of discrete behavior.
 * 
 * * An occurred logical event (occurredLogicalEvent) denotes a logical condition (e.g. when the measured value of vehicle speed is below 30 km/h) that takes place at a particular time instance and becomes valid in a certain time interval according to the definition of corresponding quantification. Logical events of input or output variables (defined through Attribute) can be communicated through the corresponding ports. 
 * 
 * * An occurred execution specific event (occurredExecutionEvent) denotes a distinct form of condition change in system execution at distinct points in time, such as at the triggering of a function, or at the receiving/sending of data from/to ports. 
 * 
 * * The occurrence of a fault, a failure, or a hazard (occurredFeatureFlaw, occurredHazardousEvent, or occurredFaultFailure) denotes a distinct form of deviation from nominal behaviors in certain time condition, of which the estimated existences are expressed by the corresponding anomaly or hazard definition. 
 * 
 * Constraints:
 * [1] The set of occurred erroneous events ((occurredFeatureFlaw, occurredHazardousEvent, or occurredAnomaly) is a symmetric set difference of feature flaws (Dependability::FeatureFlaw), system hazards (Dependability::HazardeousEvent, and system faults/failures (ErrorModel::Anomaly) as such concepts only differ in scope or in abstraction level.
 * 
 * Semantics:
 * A transition between two states of discrete behavior can be fired to respond to the occurrence of an event (which is indicated by the role readEventOccurrences?) or to signal the occurrence of an event (which is indicated by the role writeEventOccurrance!).
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.TemporalConstraint.TransitionEvent</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransitionEvent#getOccurredHazardousEvent <em>Occurred Hazardous Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransitionEvent#getOccurredFeatureFlaw <em>Occurred Feature Flaw</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransitionEvent#getOccurredLogicalEvent <em>Occurred Logical Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransitionEvent#getOccurredFaultFailure <em>Occurred Fault Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransitionEvent#getOccurredExecutionEvent <em>Occurred Execution Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransitionEvent()
 * @model annotation="MetaData guid='{27FAAB95-EFEB-4890-B54C-9373CED0BCF5}' id='1745438653' EA\040name='TransitionEvent'"
 *        extendedMetaData="name='TRANSITION-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRANSITION-EVENTS'"
 * @generated
 */
public interface TransitionEvent extends BehaviorConstraintParameter, EAElement
{
  /**
   * Returns the value of the '<em><b>Occurred Hazardous Event</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HazardousEvent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Occurred Hazardous Event</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Occurred Hazardous Event</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransitionEvent_OccurredHazardousEvent()
   * @model annotation="MetaData guid='{D6C97FBE-A71D-46f7-90CD-05E26AB46196}' id='-1541889792' EA\040name=''"
   *        extendedMetaData="name='OCCURRED-HAZARDOUS-EVENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OCCURRED-HAZARDOUS-EVENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<HazardousEvent> getOccurredHazardousEvent();

  /**
   * Returns the value of the '<em><b>Occurred Feature Flaw</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FeatureFlaw}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Occurred Feature Flaw</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Occurred Feature Flaw</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransitionEvent_OccurredFeatureFlaw()
   * @model annotation="MetaData guid='{1A6B36AD-91C6-4ec7-936C-196313C02170}' id='-529633490' EA\040name=''"
   *        extendedMetaData="name='OCCURRED-FEATURE-FLAW-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OCCURRED-FEATURE-FLAW-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FeatureFlaw> getOccurredFeatureFlaw();

  /**
   * Returns the value of the '<em><b>Occurred Logical Event</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.LogicalEvent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Occurred Logical Event</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Occurred Logical Event</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransitionEvent_OccurredLogicalEvent()
   * @model annotation="MetaData guid='{930FC418-3723-4cbb-A8C0-87BD28A1309C}' id='367561075' EA\040name=''"
   *        extendedMetaData="name='OCCURRED-LOGICAL-EVENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OCCURRED-LOGICAL-EVENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<LogicalEvent> getOccurredLogicalEvent();

  /**
   * Returns the value of the '<em><b>Occurred Fault Failure</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FaultFailure}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Occurred Fault Failure</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Occurred Fault Failure</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransitionEvent_OccurredFaultFailure()
   * @model annotation="MetaData guid='{E2718551-F628-45df-B430-1F5788D2D54A}' id='677014363' EA\040name=''"
   *        extendedMetaData="name='OCCURRED-FAULT-FAILURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OCCURRED-FAULT-FAILURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FaultFailure> getOccurredFaultFailure();

  /**
   * Returns the value of the '<em><b>Occurred Execution Event</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Event}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Occurred Execution Event</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Occurred Execution Event</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransitionEvent_OccurredExecutionEvent()
   * @model annotation="MetaData guid='{6B52AC2D-C06F-41a9-B19D-002051A293F0}' id='955927809' EA\040name=''"
   *        extendedMetaData="name='OCCURRED-EXECUTION-EVENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OCCURRED-EXECUTION-EVENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Event> getOccurredExecutionEvent();

} // TransitionEvent
