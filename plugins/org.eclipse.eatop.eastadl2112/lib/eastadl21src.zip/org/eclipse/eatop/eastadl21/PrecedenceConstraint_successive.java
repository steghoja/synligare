/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Precedence Constraint successive</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing._instanceRef.PrecedenceConstraint_successive</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive#getFunctionPrototype_context <em>Function Prototype context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive#getFunctionPrototype_target <em>Function Prototype target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrecedenceConstraint_successive()
 * @model annotation="MetaData guid='{CE49681D-F53A-4b5e-94FD-BBD9E8E6053A}' id='-161707476' EA\040name='PrecedenceConstraint_successive'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='PRECEDENCE-CONSTRAINT--SUCCESSIVE-IREF'"
 *        extendedMetaData="name='PRECEDENCE-CONSTRAINT--SUCCESSIVE-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRECEDENCE-CONSTRAINT--SUCCESSIVE-IREFS'"
 * @generated
 */
public interface PrecedenceConstraint_successive extends EObject
{
  /**
   * Returns the value of the '<em><b>Function Prototype context</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FunctionPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Function Prototype context</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Function Prototype context</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrecedenceConstraint_successive_FunctionPrototype_context()
   * @model annotation="MetaData guid='{2CAD1ECC-098B-4f1a-9C2D-415CA0B5A8EA}' id='-1017407618' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FUNCTION-PROTOTYPE-CONTEXT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-CONTEXT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FunctionPrototype> getFunctionPrototype_context();

  /**
   * Returns the value of the '<em><b>Function Prototype target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Function Prototype target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Function Prototype target</em>' reference.
   * @see #setFunctionPrototype_target(FunctionPrototype)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrecedenceConstraint_successive_FunctionPrototype_target()
   * @model required="true"
   *        annotation="MetaData guid='{737A3282-8001-4ac6-8323-B639C4982E69}' id='-751377200' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FUNCTION-PROTOTYPE-TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FunctionPrototype getFunctionPrototype_target();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive#getFunctionPrototype_target <em>Function Prototype target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Function Prototype target</em>' reference.
   * @see #getFunctionPrototype_target()
   * @generated
   */
  void setFunctionPrototype_target(FunctionPrototype value);

} // PrecedenceConstraint_successive
