/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import java.util.List;

import org.eclipse.eatop.eastadl21.AUTOSAREvent;
import org.eclipse.eatop.eastadl21.Actor;
import org.eclipse.eatop.eastadl21.Actuator;
import org.eclipse.eatop.eastadl21.AgeConstraint;
import org.eclipse.eatop.eastadl21.AllocateableElement;
import org.eclipse.eatop.eastadl21.Allocation;
import org.eclipse.eatop.eastadl21.AllocationTarget;
import org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype;
import org.eclipse.eatop.eastadl21.AnalysisFunctionType;
import org.eclipse.eatop.eastadl21.AnalysisLevel;
import org.eclipse.eatop.eastadl21.Anomaly;
import org.eclipse.eatop.eastadl21.ArbitraryConstraint;
import org.eclipse.eatop.eastadl21.ArchitecturalDescription;
import org.eclipse.eatop.eastadl21.ArchitecturalModel;
import org.eclipse.eatop.eastadl21.Architecture;
import org.eclipse.eatop.eastadl21.ArrayDatatype;
import org.eclipse.eatop.eastadl21.Attribute;
import org.eclipse.eatop.eastadl21.AttributeQuantificationConstraint;
import org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType;
import org.eclipse.eatop.eastadl21.Behavior;
import org.eclipse.eatop.eastadl21.BehaviorAttributeBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingAttribute;
import org.eclipse.eatop.eastadl21.BehaviorConstraintBindingEvent;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector;
import org.eclipse.eatop.eastadl21.BehaviorConstraintParameter;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_errorModelTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintPrototype_hardwareComponentTarget;
import org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintType;
import org.eclipse.eatop.eastadl21.BindingTime;
import org.eclipse.eatop.eastadl21.BurstConstraint;
import org.eclipse.eatop.eastadl21.BusinessOpportunity;
import org.eclipse.eatop.eastadl21.Claim;
import org.eclipse.eatop.eastadl21.ClampConnector;
import org.eclipse.eatop.eastadl21.ClampConnector_port;
import org.eclipse.eatop.eastadl21.Comment;
import org.eclipse.eatop.eastadl21.CommunicationHardwarePin;
import org.eclipse.eatop.eastadl21.ComparisonConstraint;
import org.eclipse.eatop.eastadl21.CompositeDatatype;
import org.eclipse.eatop.eastadl21.ComputationConstraint;
import org.eclipse.eatop.eastadl21.Concept;
import org.eclipse.eatop.eastadl21.ConfigurableContainer;
import org.eclipse.eatop.eastadl21.ConfigurationDecision;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionFolder;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionModel;
import org.eclipse.eatop.eastadl21.ConfigurationDecisionModelEntry;
import org.eclipse.eatop.eastadl21.ContainerConfiguration;
import org.eclipse.eatop.eastadl21.Context;
import org.eclipse.eatop.eastadl21.DelayConstraint;
import org.eclipse.eatop.eastadl21.Dependability;
import org.eclipse.eatop.eastadl21.DeriveRequirement;
import org.eclipse.eatop.eastadl21.DesignFunctionPrototype;
import org.eclipse.eatop.eastadl21.DesignFunctionType;
import org.eclipse.eatop.eastadl21.DesignLevel;
import org.eclipse.eatop.eastadl21.DeviationAttributeSet;
import org.eclipse.eatop.eastadl21.EAArrayValue;
import org.eclipse.eatop.eastadl21.EABoolean;
import org.eclipse.eatop.eastadl21.EABooleanValue;
import org.eclipse.eatop.eastadl21.EACompositeValue;
import org.eclipse.eatop.eastadl21.EAConnector;
import org.eclipse.eatop.eastadl21.EADatatype;
import org.eclipse.eatop.eastadl21.EADatatypePrototype;
import org.eclipse.eatop.eastadl21.EAElement;
import org.eclipse.eatop.eastadl21.EAEnumerationValue;
import org.eclipse.eatop.eastadl21.EAExpression;
import org.eclipse.eatop.eastadl21.EANumerical;
import org.eclipse.eatop.eastadl21.EANumericalValue;
import org.eclipse.eatop.eastadl21.EAPackage;
import org.eclipse.eatop.eastadl21.EAPackageableElement;
import org.eclipse.eatop.eastadl21.EAPort;
import org.eclipse.eatop.eastadl21.EAPrototype;
import org.eclipse.eatop.eastadl21.EAString;
import org.eclipse.eatop.eastadl21.EAStringValue;
import org.eclipse.eatop.eastadl21.EAType;
import org.eclipse.eatop.eastadl21.EAValue;
import org.eclipse.eatop.eastadl21.EAXML;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ElectricalComponent;
import org.eclipse.eatop.eastadl21.Enumeration;
import org.eclipse.eatop.eastadl21.EnumerationLiteral;
import org.eclipse.eatop.eastadl21.Environment;
import org.eclipse.eatop.eastadl21.ErrorBehavior;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_functionTarget;
import org.eclipse.eatop.eastadl21.ErrorModelPrototype_hwTarget;
import org.eclipse.eatop.eastadl21.ErrorModelType;
import org.eclipse.eatop.eastadl21.Event;
import org.eclipse.eatop.eastadl21.EventChain;
import org.eclipse.eatop.eastadl21.EventFaultFailure;
import org.eclipse.eatop.eastadl21.EventFeatureFlaw;
import org.eclipse.eatop.eastadl21.EventFunction;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort;
import org.eclipse.eatop.eastadl21.EventFunctionClientServerPort_port;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort;
import org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port;
import org.eclipse.eatop.eastadl21.EventFunction_function;
import org.eclipse.eatop.eastadl21.ExecutionTimeConstraint;
import org.eclipse.eatop.eastadl21.Extend;
import org.eclipse.eatop.eastadl21.ExtensionPoint;
import org.eclipse.eatop.eastadl21.ExternalEvent;
import org.eclipse.eatop.eastadl21.FailureOutPort;
import org.eclipse.eatop.eastadl21.FaultFailure;
import org.eclipse.eatop.eastadl21.FaultFailurePort;
import org.eclipse.eatop.eastadl21.FaultFailurePort_functionTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_fromPort;
import org.eclipse.eatop.eastadl21.FaultFailurePropagationLink_toPort;
import org.eclipse.eatop.eastadl21.FaultFailure_anomaly;
import org.eclipse.eatop.eastadl21.FaultInPort;
import org.eclipse.eatop.eastadl21.Feature;
import org.eclipse.eatop.eastadl21.FeatureConfiguration;
import org.eclipse.eatop.eastadl21.FeatureConstraint;
import org.eclipse.eatop.eastadl21.FeatureFlaw;
import org.eclipse.eatop.eastadl21.FeatureGroup;
import org.eclipse.eatop.eastadl21.FeatureLink;
import org.eclipse.eatop.eastadl21.FeatureModel;
import org.eclipse.eatop.eastadl21.FeatureTreeNode;
import org.eclipse.eatop.eastadl21.FunctionAllocation;
import org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement;
import org.eclipse.eatop.eastadl21.FunctionAllocation_target;
import org.eclipse.eatop.eastadl21.FunctionBehavior;
import org.eclipse.eatop.eastadl21.FunctionClientServerInterface;
import org.eclipse.eatop.eastadl21.FunctionClientServerPort;
import org.eclipse.eatop.eastadl21.FunctionConnector;
import org.eclipse.eatop.eastadl21.FunctionConnector_port;
import org.eclipse.eatop.eastadl21.FunctionFlowPort;
import org.eclipse.eatop.eastadl21.FunctionPort;
import org.eclipse.eatop.eastadl21.FunctionPowerPort;
import org.eclipse.eatop.eastadl21.FunctionPrototype;
import org.eclipse.eatop.eastadl21.FunctionTrigger;
import org.eclipse.eatop.eastadl21.FunctionType;
import org.eclipse.eatop.eastadl21.FunctionalDevice;
import org.eclipse.eatop.eastadl21.FunctionalSafetyConcept;
import org.eclipse.eatop.eastadl21.GenericConstraint;
import org.eclipse.eatop.eastadl21.GenericConstraintSet;
import org.eclipse.eatop.eastadl21.Ground;
import org.eclipse.eatop.eastadl21.HardwareComponentPrototype;
import org.eclipse.eatop.eastadl21.HardwareComponentType;
import org.eclipse.eatop.eastadl21.HardwareConnector;
import org.eclipse.eatop.eastadl21.HardwareConnector_port;
import org.eclipse.eatop.eastadl21.HardwareFunctionType;
import org.eclipse.eatop.eastadl21.HardwarePin;
import org.eclipse.eatop.eastadl21.HardwarePort;
import org.eclipse.eatop.eastadl21.HardwarePortConnector;
import org.eclipse.eatop.eastadl21.HardwarePortConnector_port;
import org.eclipse.eatop.eastadl21.Hazard;
import org.eclipse.eatop.eastadl21.HazardousEvent;
import org.eclipse.eatop.eastadl21.IOHardwarePin;
import org.eclipse.eatop.eastadl21.Identifiable;
import org.eclipse.eatop.eastadl21.ImplementationLevel;
import org.eclipse.eatop.eastadl21.Include;
import org.eclipse.eatop.eastadl21.InputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.InternalBinding;
import org.eclipse.eatop.eastadl21.InternalFaultPrototype;
import org.eclipse.eatop.eastadl21.Item;
import org.eclipse.eatop.eastadl21.LocalDeviceManager;
import org.eclipse.eatop.eastadl21.LogicalEvent;
import org.eclipse.eatop.eastadl21.LogicalPath;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.LogicalTransformation;
import org.eclipse.eatop.eastadl21.Mission;
import org.eclipse.eatop.eastadl21.Mode;
import org.eclipse.eatop.eastadl21.ModeEvent;
import org.eclipse.eatop.eastadl21.ModeGroup;
import org.eclipse.eatop.eastadl21.Node;
import org.eclipse.eatop.eastadl21.Operation;
import org.eclipse.eatop.eastadl21.OperationalSituation;
import org.eclipse.eatop.eastadl21.OrderConstraint;
import org.eclipse.eatop.eastadl21.OutputSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.PatternConstraint;
import org.eclipse.eatop.eastadl21.PeriodicConstraint;
import org.eclipse.eatop.eastadl21.PortGroup;
import org.eclipse.eatop.eastadl21.PowerHardwarePin;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_preceding;
import org.eclipse.eatop.eastadl21.PrecedenceConstraint_successive;
import org.eclipse.eatop.eastadl21.PrivateContent;
import org.eclipse.eatop.eastadl21.ProblemStatement;
import org.eclipse.eatop.eastadl21.ProcessFaultPrototype;
import org.eclipse.eatop.eastadl21.ProductPositioning;
import org.eclipse.eatop.eastadl21.QualityRequirement;
import org.eclipse.eatop.eastadl21.Quantification;
import org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint;
import org.eclipse.eatop.eastadl21.Quantity;
import org.eclipse.eatop.eastadl21.RangeableValueType;
import org.eclipse.eatop.eastadl21.Rationale;
import org.eclipse.eatop.eastadl21.ReactionConstraint;
import org.eclipse.eatop.eastadl21.Realization;
import org.eclipse.eatop.eastadl21.Realization_realized;
import org.eclipse.eatop.eastadl21.Realization_realizedBy;
import org.eclipse.eatop.eastadl21.RedefinableElement;
import org.eclipse.eatop.eastadl21.Referrable;
import org.eclipse.eatop.eastadl21.Refine;
import org.eclipse.eatop.eastadl21.Refine_refinedBy;
import org.eclipse.eatop.eastadl21.Relationship;
import org.eclipse.eatop.eastadl21.RepetitionConstraint;
import org.eclipse.eatop.eastadl21.Requirement;
import org.eclipse.eatop.eastadl21.RequirementsHierarchy;
import org.eclipse.eatop.eastadl21.RequirementsLink;
import org.eclipse.eatop.eastadl21.RequirementsModel;
import org.eclipse.eatop.eastadl21.RequirementsRelationship;
import org.eclipse.eatop.eastadl21.RequirementsRelationshipGroup;
import org.eclipse.eatop.eastadl21.ReuseMetaInformation;
import org.eclipse.eatop.eastadl21.SafetyCase;
import org.eclipse.eatop.eastadl21.SafetyConstraint;
import org.eclipse.eatop.eastadl21.SafetyGoal;
import org.eclipse.eatop.eastadl21.Satisfy;
import org.eclipse.eatop.eastadl21.Satisfy_satisfiedBy;
import org.eclipse.eatop.eastadl21.SelectionCriterion;
import org.eclipse.eatop.eastadl21.Sensor;
import org.eclipse.eatop.eastadl21.SporadicConstraint;
import org.eclipse.eatop.eastadl21.Stakeholder;
import org.eclipse.eatop.eastadl21.StakeholderNeed;
import org.eclipse.eatop.eastadl21.State;
import org.eclipse.eatop.eastadl21.StateEvent;
import org.eclipse.eatop.eastadl21.StrongDelayConstraint;
import org.eclipse.eatop.eastadl21.StrongSynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronizationConstraint;
import org.eclipse.eatop.eastadl21.SynchronousTransition;
import org.eclipse.eatop.eastadl21.SystemModel;
import org.eclipse.eatop.eastadl21.TakeRateConstraint;
import org.eclipse.eatop.eastadl21.TechnicalSafetyConcept;
import org.eclipse.eatop.eastadl21.TemporalConstraint;
import org.eclipse.eatop.eastadl21.Timing;
import org.eclipse.eatop.eastadl21.TimingConstraint;
import org.eclipse.eatop.eastadl21.TimingDescription;
import org.eclipse.eatop.eastadl21.TimingDescriptionEvent;
import org.eclipse.eatop.eastadl21.TimingExpression;
import org.eclipse.eatop.eastadl21.TraceableSpecification;
import org.eclipse.eatop.eastadl21.TransformationOccurrence;
import org.eclipse.eatop.eastadl21.Transition;
import org.eclipse.eatop.eastadl21.TransitionEvent;
import org.eclipse.eatop.eastadl21.Unit;
import org.eclipse.eatop.eastadl21.UseCase;
import org.eclipse.eatop.eastadl21.UserAttributeDefinition;
import org.eclipse.eatop.eastadl21.UserAttributedElement;
import org.eclipse.eatop.eastadl21.UserElementType;
import org.eclipse.eatop.eastadl21.VVActualOutcome;
import org.eclipse.eatop.eastadl21.VVCase;
import org.eclipse.eatop.eastadl21.VVCase_vvSubject;
import org.eclipse.eatop.eastadl21.VVIntendedOutcome;
import org.eclipse.eatop.eastadl21.VVLog;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.VVStimuli;
import org.eclipse.eatop.eastadl21.VVTarget;
import org.eclipse.eatop.eastadl21.VVTarget_element;
import org.eclipse.eatop.eastadl21.Variability;
import org.eclipse.eatop.eastadl21.VariableElement;
import org.eclipse.eatop.eastadl21.VariationGroup;
import org.eclipse.eatop.eastadl21.VehicleFeature;
import org.eclipse.eatop.eastadl21.VehicleLevel;
import org.eclipse.eatop.eastadl21.VehicleLevelBinding;
import org.eclipse.eatop.eastadl21.VehicleSystem;
import org.eclipse.eatop.eastadl21.VerificationValidation;
import org.eclipse.eatop.eastadl21.Verify;
import org.eclipse.eatop.eastadl21.Warrant;

import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackage;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackageableElement;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAXML;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GIdentifiable;
import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GReferrable;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package
 * @generated
 */
public class Eastadl21Switch<T>
{
  /**
   * The cached model package
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static Eastadl21Package modelPackage;

  /**
   * Creates an instance of the switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eastadl21Switch()
  {
    if (modelPackage == null)
    {
      modelPackage = Eastadl21Package.eINSTANCE;
    }
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  public T doSwitch(EObject theEObject)
  {
    return doSwitch(theEObject.eClass(), theEObject);
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  protected T doSwitch(EClass theEClass, EObject theEObject)
  {
    if (theEClass.eContainer() == modelPackage)
    {
      return doSwitch(theEClass.getClassifierID(), theEObject);
    }
    else
    {
      List<EClass> eSuperTypes = theEClass.getESuperTypes();
      return
        eSuperTypes.isEmpty() ?
          defaultCase(theEObject) :
          doSwitch(eSuperTypes.get(0), theEObject);
    }
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  protected T doSwitch(int classifierID, EObject theEObject)
  {
    switch (classifierID)
    {
      case Eastadl21Package.VEHICLE_LEVEL:
      {
        VehicleLevel vehicleLevel = (VehicleLevel)theEObject;
        T result = caseVehicleLevel(vehicleLevel);
        if (result == null) result = caseContext(vehicleLevel);
        if (result == null) result = caseEAPackageableElement(vehicleLevel);
        if (result == null) result = caseEAElement(vehicleLevel);
        if (result == null) result = caseGEAPackageableElement(vehicleLevel);
        if (result == null) result = caseIdentifiable(vehicleLevel);
        if (result == null) result = caseReferrable(vehicleLevel);
        if (result == null) result = caseGIdentifiable(vehicleLevel);
        if (result == null) result = caseGReferrable(vehicleLevel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SYSTEM_MODEL:
      {
        SystemModel systemModel = (SystemModel)theEObject;
        T result = caseSystemModel(systemModel);
        if (result == null) result = caseContext(systemModel);
        if (result == null) result = caseEAPackageableElement(systemModel);
        if (result == null) result = caseEAElement(systemModel);
        if (result == null) result = caseGEAPackageableElement(systemModel);
        if (result == null) result = caseIdentifiable(systemModel);
        if (result == null) result = caseReferrable(systemModel);
        if (result == null) result = caseGIdentifiable(systemModel);
        if (result == null) result = caseGReferrable(systemModel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ANALYSIS_LEVEL:
      {
        AnalysisLevel analysisLevel = (AnalysisLevel)theEObject;
        T result = caseAnalysisLevel(analysisLevel);
        if (result == null) result = caseContext(analysisLevel);
        if (result == null) result = caseEAPackageableElement(analysisLevel);
        if (result == null) result = caseEAElement(analysisLevel);
        if (result == null) result = caseGEAPackageableElement(analysisLevel);
        if (result == null) result = caseIdentifiable(analysisLevel);
        if (result == null) result = caseReferrable(analysisLevel);
        if (result == null) result = caseGIdentifiable(analysisLevel);
        if (result == null) result = caseGReferrable(analysisLevel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DESIGN_LEVEL:
      {
        DesignLevel designLevel = (DesignLevel)theEObject;
        T result = caseDesignLevel(designLevel);
        if (result == null) result = caseContext(designLevel);
        if (result == null) result = caseEAPackageableElement(designLevel);
        if (result == null) result = caseEAElement(designLevel);
        if (result == null) result = caseGEAPackageableElement(designLevel);
        if (result == null) result = caseIdentifiable(designLevel);
        if (result == null) result = caseReferrable(designLevel);
        if (result == null) result = caseGIdentifiable(designLevel);
        if (result == null) result = caseGReferrable(designLevel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.IMPLEMENTATION_LEVEL:
      {
        ImplementationLevel implementationLevel = (ImplementationLevel)theEObject;
        T result = caseImplementationLevel(implementationLevel);
        if (result == null) result = caseContext(implementationLevel);
        if (result == null) result = caseEAPackageableElement(implementationLevel);
        if (result == null) result = caseEAElement(implementationLevel);
        if (result == null) result = caseGEAPackageableElement(implementationLevel);
        if (result == null) result = caseIdentifiable(implementationLevel);
        if (result == null) result = caseReferrable(implementationLevel);
        if (result == null) result = caseGIdentifiable(implementationLevel);
        if (result == null) result = caseGReferrable(implementationLevel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BINDING_TIME:
      {
        BindingTime bindingTime = (BindingTime)theEObject;
        T result = caseBindingTime(bindingTime);
        if (result == null) result = caseEAElement(bindingTime);
        if (result == null) result = caseIdentifiable(bindingTime);
        if (result == null) result = caseReferrable(bindingTime);
        if (result == null) result = caseGIdentifiable(bindingTime);
        if (result == null) result = caseGReferrable(bindingTime);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE:
      {
        Feature feature = (Feature)theEObject;
        T result = caseFeature(feature);
        if (result == null) result = caseFeatureTreeNode(feature);
        if (result == null) result = caseContext(feature);
        if (result == null) result = caseEAPackageableElement(feature);
        if (result == null) result = caseEAElement(feature);
        if (result == null) result = caseGEAPackageableElement(feature);
        if (result == null) result = caseIdentifiable(feature);
        if (result == null) result = caseReferrable(feature);
        if (result == null) result = caseGIdentifiable(feature);
        if (result == null) result = caseGReferrable(feature);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_CONSTRAINT:
      {
        FeatureConstraint featureConstraint = (FeatureConstraint)theEObject;
        T result = caseFeatureConstraint(featureConstraint);
        if (result == null) result = caseEAElement(featureConstraint);
        if (result == null) result = caseIdentifiable(featureConstraint);
        if (result == null) result = caseReferrable(featureConstraint);
        if (result == null) result = caseGIdentifiable(featureConstraint);
        if (result == null) result = caseGReferrable(featureConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_GROUP:
      {
        FeatureGroup featureGroup = (FeatureGroup)theEObject;
        T result = caseFeatureGroup(featureGroup);
        if (result == null) result = caseFeatureTreeNode(featureGroup);
        if (result == null) result = caseContext(featureGroup);
        if (result == null) result = caseEAPackageableElement(featureGroup);
        if (result == null) result = caseEAElement(featureGroup);
        if (result == null) result = caseGEAPackageableElement(featureGroup);
        if (result == null) result = caseIdentifiable(featureGroup);
        if (result == null) result = caseReferrable(featureGroup);
        if (result == null) result = caseGIdentifiable(featureGroup);
        if (result == null) result = caseGReferrable(featureGroup);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_LINK:
      {
        FeatureLink featureLink = (FeatureLink)theEObject;
        T result = caseFeatureLink(featureLink);
        if (result == null) result = caseRelationship(featureLink);
        if (result == null) result = caseEAElement(featureLink);
        if (result == null) result = caseIdentifiable(featureLink);
        if (result == null) result = caseReferrable(featureLink);
        if (result == null) result = caseGIdentifiable(featureLink);
        if (result == null) result = caseGReferrable(featureLink);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_MODEL:
      {
        FeatureModel featureModel = (FeatureModel)theEObject;
        T result = caseFeatureModel(featureModel);
        if (result == null) result = caseContext(featureModel);
        if (result == null) result = caseEAPackageableElement(featureModel);
        if (result == null) result = caseEAElement(featureModel);
        if (result == null) result = caseGEAPackageableElement(featureModel);
        if (result == null) result = caseIdentifiable(featureModel);
        if (result == null) result = caseReferrable(featureModel);
        if (result == null) result = caseGIdentifiable(featureModel);
        if (result == null) result = caseGReferrable(featureModel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_TREE_NODE:
      {
        FeatureTreeNode featureTreeNode = (FeatureTreeNode)theEObject;
        T result = caseFeatureTreeNode(featureTreeNode);
        if (result == null) result = caseContext(featureTreeNode);
        if (result == null) result = caseEAPackageableElement(featureTreeNode);
        if (result == null) result = caseEAElement(featureTreeNode);
        if (result == null) result = caseGEAPackageableElement(featureTreeNode);
        if (result == null) result = caseIdentifiable(featureTreeNode);
        if (result == null) result = caseReferrable(featureTreeNode);
        if (result == null) result = caseGIdentifiable(featureTreeNode);
        if (result == null) result = caseGReferrable(featureTreeNode);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DEVIATION_ATTRIBUTE_SET:
      {
        DeviationAttributeSet deviationAttributeSet = (DeviationAttributeSet)theEObject;
        T result = caseDeviationAttributeSet(deviationAttributeSet);
        if (result == null) result = caseEAElement(deviationAttributeSet);
        if (result == null) result = caseIdentifiable(deviationAttributeSet);
        if (result == null) result = caseReferrable(deviationAttributeSet);
        if (result == null) result = caseGIdentifiable(deviationAttributeSet);
        if (result == null) result = caseGReferrable(deviationAttributeSet);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VEHICLE_FEATURE:
      {
        VehicleFeature vehicleFeature = (VehicleFeature)theEObject;
        T result = caseVehicleFeature(vehicleFeature);
        if (result == null) result = caseFeature(vehicleFeature);
        if (result == null) result = caseFeatureTreeNode(vehicleFeature);
        if (result == null) result = caseContext(vehicleFeature);
        if (result == null) result = caseEAPackageableElement(vehicleFeature);
        if (result == null) result = caseEAElement(vehicleFeature);
        if (result == null) result = caseGEAPackageableElement(vehicleFeature);
        if (result == null) result = caseIdentifiable(vehicleFeature);
        if (result == null) result = caseReferrable(vehicleFeature);
        if (result == null) result = caseGIdentifiable(vehicleFeature);
        if (result == null) result = caseGReferrable(vehicleFeature);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ALLOCATEABLE_ELEMENT:
      {
        AllocateableElement allocateableElement = (AllocateableElement)theEObject;
        T result = caseAllocateableElement(allocateableElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ALLOCATION:
      {
        Allocation allocation = (Allocation)theEObject;
        T result = caseAllocation(allocation);
        if (result == null) result = caseEAElement(allocation);
        if (result == null) result = caseIdentifiable(allocation);
        if (result == null) result = caseReferrable(allocation);
        if (result == null) result = caseGIdentifiable(allocation);
        if (result == null) result = caseGReferrable(allocation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ANALYSIS_FUNCTION_PROTOTYPE:
      {
        AnalysisFunctionPrototype analysisFunctionPrototype = (AnalysisFunctionPrototype)theEObject;
        T result = caseAnalysisFunctionPrototype(analysisFunctionPrototype);
        if (result == null) result = caseFunctionPrototype(analysisFunctionPrototype);
        if (result == null) result = caseEAPrototype(analysisFunctionPrototype);
        if (result == null) result = caseEAElement(analysisFunctionPrototype);
        if (result == null) result = caseIdentifiable(analysisFunctionPrototype);
        if (result == null) result = caseReferrable(analysisFunctionPrototype);
        if (result == null) result = caseGIdentifiable(analysisFunctionPrototype);
        if (result == null) result = caseGReferrable(analysisFunctionPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ANALYSIS_FUNCTION_TYPE:
      {
        AnalysisFunctionType analysisFunctionType = (AnalysisFunctionType)theEObject;
        T result = caseAnalysisFunctionType(analysisFunctionType);
        if (result == null) result = caseFunctionType(analysisFunctionType);
        if (result == null) result = caseEAType(analysisFunctionType);
        if (result == null) result = caseContext(analysisFunctionType);
        if (result == null) result = caseEAPackageableElement(analysisFunctionType);
        if (result == null) result = caseEAElement(analysisFunctionType);
        if (result == null) result = caseGEAPackageableElement(analysisFunctionType);
        if (result == null) result = caseIdentifiable(analysisFunctionType);
        if (result == null) result = caseReferrable(analysisFunctionType);
        if (result == null) result = caseGIdentifiable(analysisFunctionType);
        if (result == null) result = caseGReferrable(analysisFunctionType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BASIC_SOFTWARE_FUNCTION_TYPE:
      {
        BasicSoftwareFunctionType basicSoftwareFunctionType = (BasicSoftwareFunctionType)theEObject;
        T result = caseBasicSoftwareFunctionType(basicSoftwareFunctionType);
        if (result == null) result = caseDesignFunctionType(basicSoftwareFunctionType);
        if (result == null) result = caseFunctionType(basicSoftwareFunctionType);
        if (result == null) result = caseEAType(basicSoftwareFunctionType);
        if (result == null) result = caseContext(basicSoftwareFunctionType);
        if (result == null) result = caseEAPackageableElement(basicSoftwareFunctionType);
        if (result == null) result = caseEAElement(basicSoftwareFunctionType);
        if (result == null) result = caseGEAPackageableElement(basicSoftwareFunctionType);
        if (result == null) result = caseIdentifiable(basicSoftwareFunctionType);
        if (result == null) result = caseReferrable(basicSoftwareFunctionType);
        if (result == null) result = caseGIdentifiable(basicSoftwareFunctionType);
        if (result == null) result = caseGReferrable(basicSoftwareFunctionType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DESIGN_FUNCTION_PROTOTYPE:
      {
        DesignFunctionPrototype designFunctionPrototype = (DesignFunctionPrototype)theEObject;
        T result = caseDesignFunctionPrototype(designFunctionPrototype);
        if (result == null) result = caseFunctionPrototype(designFunctionPrototype);
        if (result == null) result = caseAllocateableElement(designFunctionPrototype);
        if (result == null) result = caseEAPrototype(designFunctionPrototype);
        if (result == null) result = caseEAElement(designFunctionPrototype);
        if (result == null) result = caseIdentifiable(designFunctionPrototype);
        if (result == null) result = caseReferrable(designFunctionPrototype);
        if (result == null) result = caseGIdentifiable(designFunctionPrototype);
        if (result == null) result = caseGReferrable(designFunctionPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DESIGN_FUNCTION_TYPE:
      {
        DesignFunctionType designFunctionType = (DesignFunctionType)theEObject;
        T result = caseDesignFunctionType(designFunctionType);
        if (result == null) result = caseFunctionType(designFunctionType);
        if (result == null) result = caseEAType(designFunctionType);
        if (result == null) result = caseContext(designFunctionType);
        if (result == null) result = caseEAPackageableElement(designFunctionType);
        if (result == null) result = caseEAElement(designFunctionType);
        if (result == null) result = caseGEAPackageableElement(designFunctionType);
        if (result == null) result = caseIdentifiable(designFunctionType);
        if (result == null) result = caseReferrable(designFunctionType);
        if (result == null) result = caseGIdentifiable(designFunctionType);
        if (result == null) result = caseGReferrable(designFunctionType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTIONAL_DEVICE:
      {
        FunctionalDevice functionalDevice = (FunctionalDevice)theEObject;
        T result = caseFunctionalDevice(functionalDevice);
        if (result == null) result = caseAnalysisFunctionType(functionalDevice);
        if (result == null) result = caseFunctionType(functionalDevice);
        if (result == null) result = caseEAType(functionalDevice);
        if (result == null) result = caseContext(functionalDevice);
        if (result == null) result = caseEAPackageableElement(functionalDevice);
        if (result == null) result = caseEAElement(functionalDevice);
        if (result == null) result = caseGEAPackageableElement(functionalDevice);
        if (result == null) result = caseIdentifiable(functionalDevice);
        if (result == null) result = caseReferrable(functionalDevice);
        if (result == null) result = caseGIdentifiable(functionalDevice);
        if (result == null) result = caseGReferrable(functionalDevice);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_ALLOCATION:
      {
        FunctionAllocation functionAllocation = (FunctionAllocation)theEObject;
        T result = caseFunctionAllocation(functionAllocation);
        if (result == null) result = caseEAElement(functionAllocation);
        if (result == null) result = caseIdentifiable(functionAllocation);
        if (result == null) result = caseReferrable(functionAllocation);
        if (result == null) result = caseGIdentifiable(functionAllocation);
        if (result == null) result = caseGReferrable(functionAllocation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_CLIENT_SERVER_INTERFACE:
      {
        FunctionClientServerInterface functionClientServerInterface = (FunctionClientServerInterface)theEObject;
        T result = caseFunctionClientServerInterface(functionClientServerInterface);
        if (result == null) result = caseTraceableSpecification(functionClientServerInterface);
        if (result == null) result = caseEAPackageableElement(functionClientServerInterface);
        if (result == null) result = caseEAElement(functionClientServerInterface);
        if (result == null) result = caseGEAPackageableElement(functionClientServerInterface);
        if (result == null) result = caseIdentifiable(functionClientServerInterface);
        if (result == null) result = caseReferrable(functionClientServerInterface);
        if (result == null) result = caseGIdentifiable(functionClientServerInterface);
        if (result == null) result = caseGReferrable(functionClientServerInterface);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_CLIENT_SERVER_PORT:
      {
        FunctionClientServerPort functionClientServerPort = (FunctionClientServerPort)theEObject;
        T result = caseFunctionClientServerPort(functionClientServerPort);
        if (result == null) result = caseFunctionPort(functionClientServerPort);
        if (result == null) result = caseEAPort(functionClientServerPort);
        if (result == null) result = caseEAElement(functionClientServerPort);
        if (result == null) result = caseIdentifiable(functionClientServerPort);
        if (result == null) result = caseReferrable(functionClientServerPort);
        if (result == null) result = caseGIdentifiable(functionClientServerPort);
        if (result == null) result = caseGReferrable(functionClientServerPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_CONNECTOR:
      {
        FunctionConnector functionConnector = (FunctionConnector)theEObject;
        T result = caseFunctionConnector(functionConnector);
        if (result == null) result = caseEAConnector(functionConnector);
        if (result == null) result = caseEAElement(functionConnector);
        if (result == null) result = caseAllocateableElement(functionConnector);
        if (result == null) result = caseIdentifiable(functionConnector);
        if (result == null) result = caseReferrable(functionConnector);
        if (result == null) result = caseGIdentifiable(functionConnector);
        if (result == null) result = caseGReferrable(functionConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_FLOW_PORT:
      {
        FunctionFlowPort functionFlowPort = (FunctionFlowPort)theEObject;
        T result = caseFunctionFlowPort(functionFlowPort);
        if (result == null) result = caseFunctionPort(functionFlowPort);
        if (result == null) result = caseEAPort(functionFlowPort);
        if (result == null) result = caseEAElement(functionFlowPort);
        if (result == null) result = caseIdentifiable(functionFlowPort);
        if (result == null) result = caseReferrable(functionFlowPort);
        if (result == null) result = caseGIdentifiable(functionFlowPort);
        if (result == null) result = caseGReferrable(functionFlowPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_PORT:
      {
        FunctionPort functionPort = (FunctionPort)theEObject;
        T result = caseFunctionPort(functionPort);
        if (result == null) result = caseEAPort(functionPort);
        if (result == null) result = caseEAElement(functionPort);
        if (result == null) result = caseIdentifiable(functionPort);
        if (result == null) result = caseReferrable(functionPort);
        if (result == null) result = caseGIdentifiable(functionPort);
        if (result == null) result = caseGReferrable(functionPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_POWER_PORT:
      {
        FunctionPowerPort functionPowerPort = (FunctionPowerPort)theEObject;
        T result = caseFunctionPowerPort(functionPowerPort);
        if (result == null) result = caseFunctionPort(functionPowerPort);
        if (result == null) result = caseEAPort(functionPowerPort);
        if (result == null) result = caseEAElement(functionPowerPort);
        if (result == null) result = caseIdentifiable(functionPowerPort);
        if (result == null) result = caseReferrable(functionPowerPort);
        if (result == null) result = caseGIdentifiable(functionPowerPort);
        if (result == null) result = caseGReferrable(functionPowerPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_PROTOTYPE:
      {
        FunctionPrototype functionPrototype = (FunctionPrototype)theEObject;
        T result = caseFunctionPrototype(functionPrototype);
        if (result == null) result = caseEAPrototype(functionPrototype);
        if (result == null) result = caseEAElement(functionPrototype);
        if (result == null) result = caseIdentifiable(functionPrototype);
        if (result == null) result = caseReferrable(functionPrototype);
        if (result == null) result = caseGIdentifiable(functionPrototype);
        if (result == null) result = caseGReferrable(functionPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_TYPE:
      {
        FunctionType functionType = (FunctionType)theEObject;
        T result = caseFunctionType(functionType);
        if (result == null) result = caseEAType(functionType);
        if (result == null) result = caseContext(functionType);
        if (result == null) result = caseEAPackageableElement(functionType);
        if (result == null) result = caseEAElement(functionType);
        if (result == null) result = caseGEAPackageableElement(functionType);
        if (result == null) result = caseIdentifiable(functionType);
        if (result == null) result = caseReferrable(functionType);
        if (result == null) result = caseGIdentifiable(functionType);
        if (result == null) result = caseGReferrable(functionType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_FUNCTION_TYPE:
      {
        HardwareFunctionType hardwareFunctionType = (HardwareFunctionType)theEObject;
        T result = caseHardwareFunctionType(hardwareFunctionType);
        if (result == null) result = caseDesignFunctionType(hardwareFunctionType);
        if (result == null) result = caseFunctionType(hardwareFunctionType);
        if (result == null) result = caseEAType(hardwareFunctionType);
        if (result == null) result = caseContext(hardwareFunctionType);
        if (result == null) result = caseEAPackageableElement(hardwareFunctionType);
        if (result == null) result = caseEAElement(hardwareFunctionType);
        if (result == null) result = caseGEAPackageableElement(hardwareFunctionType);
        if (result == null) result = caseIdentifiable(hardwareFunctionType);
        if (result == null) result = caseReferrable(hardwareFunctionType);
        if (result == null) result = caseGIdentifiable(hardwareFunctionType);
        if (result == null) result = caseGReferrable(hardwareFunctionType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.LOCAL_DEVICE_MANAGER:
      {
        LocalDeviceManager localDeviceManager = (LocalDeviceManager)theEObject;
        T result = caseLocalDeviceManager(localDeviceManager);
        if (result == null) result = caseDesignFunctionType(localDeviceManager);
        if (result == null) result = caseFunctionType(localDeviceManager);
        if (result == null) result = caseEAType(localDeviceManager);
        if (result == null) result = caseContext(localDeviceManager);
        if (result == null) result = caseEAPackageableElement(localDeviceManager);
        if (result == null) result = caseEAElement(localDeviceManager);
        if (result == null) result = caseGEAPackageableElement(localDeviceManager);
        if (result == null) result = caseIdentifiable(localDeviceManager);
        if (result == null) result = caseReferrable(localDeviceManager);
        if (result == null) result = caseGIdentifiable(localDeviceManager);
        if (result == null) result = caseGReferrable(localDeviceManager);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.OPERATION:
      {
        Operation operation = (Operation)theEObject;
        T result = caseOperation(operation);
        if (result == null) result = caseEAElement(operation);
        if (result == null) result = caseIdentifiable(operation);
        if (result == null) result = caseReferrable(operation);
        if (result == null) result = caseGIdentifiable(operation);
        if (result == null) result = caseGReferrable(operation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PORT_GROUP:
      {
        PortGroup portGroup = (PortGroup)theEObject;
        T result = casePortGroup(portGroup);
        if (result == null) result = caseEAElement(portGroup);
        if (result == null) result = caseIdentifiable(portGroup);
        if (result == null) result = caseReferrable(portGroup);
        if (result == null) result = caseGIdentifiable(portGroup);
        if (result == null) result = caseGReferrable(portGroup);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_ALLOCATION_ALLOCATED_ELEMENT:
      {
        FunctionAllocation_allocatedElement functionAllocation_allocatedElement = (FunctionAllocation_allocatedElement)theEObject;
        T result = caseFunctionAllocation_allocatedElement(functionAllocation_allocatedElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_ALLOCATION_TARGET:
      {
        FunctionAllocation_target functionAllocation_target = (FunctionAllocation_target)theEObject;
        T result = caseFunctionAllocation_target(functionAllocation_target);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_CONNECTOR_PORT:
      {
        FunctionConnector_port functionConnector_port = (FunctionConnector_port)theEObject;
        T result = caseFunctionConnector_port(functionConnector_port);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ACTUATOR:
      {
        Actuator actuator = (Actuator)theEObject;
        T result = caseActuator(actuator);
        if (result == null) result = caseHardwareComponentType(actuator);
        if (result == null) result = caseEAType(actuator);
        if (result == null) result = caseContext(actuator);
        if (result == null) result = caseEAPackageableElement(actuator);
        if (result == null) result = caseEAElement(actuator);
        if (result == null) result = caseGEAPackageableElement(actuator);
        if (result == null) result = caseIdentifiable(actuator);
        if (result == null) result = caseReferrable(actuator);
        if (result == null) result = caseGIdentifiable(actuator);
        if (result == null) result = caseGReferrable(actuator);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.COMMUNICATION_HARDWARE_PIN:
      {
        CommunicationHardwarePin communicationHardwarePin = (CommunicationHardwarePin)theEObject;
        T result = caseCommunicationHardwarePin(communicationHardwarePin);
        if (result == null) result = caseHardwarePin(communicationHardwarePin);
        if (result == null) result = caseEAPort(communicationHardwarePin);
        if (result == null) result = caseEAElement(communicationHardwarePin);
        if (result == null) result = caseIdentifiable(communicationHardwarePin);
        if (result == null) result = caseReferrable(communicationHardwarePin);
        if (result == null) result = caseGIdentifiable(communicationHardwarePin);
        if (result == null) result = caseGReferrable(communicationHardwarePin);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ELECTRICAL_COMPONENT:
      {
        ElectricalComponent electricalComponent = (ElectricalComponent)theEObject;
        T result = caseElectricalComponent(electricalComponent);
        if (result == null) result = caseHardwareComponentType(electricalComponent);
        if (result == null) result = caseEAType(electricalComponent);
        if (result == null) result = caseContext(electricalComponent);
        if (result == null) result = caseEAPackageableElement(electricalComponent);
        if (result == null) result = caseEAElement(electricalComponent);
        if (result == null) result = caseGEAPackageableElement(electricalComponent);
        if (result == null) result = caseIdentifiable(electricalComponent);
        if (result == null) result = caseReferrable(electricalComponent);
        if (result == null) result = caseGIdentifiable(electricalComponent);
        if (result == null) result = caseGReferrable(electricalComponent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_COMPONENT_PROTOTYPE:
      {
        HardwareComponentPrototype hardwareComponentPrototype = (HardwareComponentPrototype)theEObject;
        T result = caseHardwareComponentPrototype(hardwareComponentPrototype);
        if (result == null) result = caseEAPrototype(hardwareComponentPrototype);
        if (result == null) result = caseAllocationTarget(hardwareComponentPrototype);
        if (result == null) result = caseEAElement(hardwareComponentPrototype);
        if (result == null) result = caseIdentifiable(hardwareComponentPrototype);
        if (result == null) result = caseReferrable(hardwareComponentPrototype);
        if (result == null) result = caseGIdentifiable(hardwareComponentPrototype);
        if (result == null) result = caseGReferrable(hardwareComponentPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_COMPONENT_TYPE:
      {
        HardwareComponentType hardwareComponentType = (HardwareComponentType)theEObject;
        T result = caseHardwareComponentType(hardwareComponentType);
        if (result == null) result = caseEAType(hardwareComponentType);
        if (result == null) result = caseContext(hardwareComponentType);
        if (result == null) result = caseEAPackageableElement(hardwareComponentType);
        if (result == null) result = caseEAElement(hardwareComponentType);
        if (result == null) result = caseGEAPackageableElement(hardwareComponentType);
        if (result == null) result = caseIdentifiable(hardwareComponentType);
        if (result == null) result = caseReferrable(hardwareComponentType);
        if (result == null) result = caseGIdentifiable(hardwareComponentType);
        if (result == null) result = caseGReferrable(hardwareComponentType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_CONNECTOR:
      {
        HardwareConnector hardwareConnector = (HardwareConnector)theEObject;
        T result = caseHardwareConnector(hardwareConnector);
        if (result == null) result = caseEAElement(hardwareConnector);
        if (result == null) result = caseEAConnector(hardwareConnector);
        if (result == null) result = caseIdentifiable(hardwareConnector);
        if (result == null) result = caseReferrable(hardwareConnector);
        if (result == null) result = caseGIdentifiable(hardwareConnector);
        if (result == null) result = caseGReferrable(hardwareConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_PIN:
      {
        HardwarePin hardwarePin = (HardwarePin)theEObject;
        T result = caseHardwarePin(hardwarePin);
        if (result == null) result = caseEAPort(hardwarePin);
        if (result == null) result = caseEAElement(hardwarePin);
        if (result == null) result = caseIdentifiable(hardwarePin);
        if (result == null) result = caseReferrable(hardwarePin);
        if (result == null) result = caseGIdentifiable(hardwarePin);
        if (result == null) result = caseGReferrable(hardwarePin);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_PORT:
      {
        HardwarePort hardwarePort = (HardwarePort)theEObject;
        T result = caseHardwarePort(hardwarePort);
        if (result == null) result = caseAllocationTarget(hardwarePort);
        if (result == null) result = caseEAPort(hardwarePort);
        if (result == null) result = caseEAElement(hardwarePort);
        if (result == null) result = caseIdentifiable(hardwarePort);
        if (result == null) result = caseReferrable(hardwarePort);
        if (result == null) result = caseGIdentifiable(hardwarePort);
        if (result == null) result = caseGReferrable(hardwarePort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR:
      {
        HardwarePortConnector hardwarePortConnector = (HardwarePortConnector)theEObject;
        T result = caseHardwarePortConnector(hardwarePortConnector);
        if (result == null) result = caseAllocationTarget(hardwarePortConnector);
        if (result == null) result = caseEAConnector(hardwarePortConnector);
        if (result == null) result = caseEAElement(hardwarePortConnector);
        if (result == null) result = caseIdentifiable(hardwarePortConnector);
        if (result == null) result = caseReferrable(hardwarePortConnector);
        if (result == null) result = caseGIdentifiable(hardwarePortConnector);
        if (result == null) result = caseGReferrable(hardwarePortConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.IO_HARDWARE_PIN:
      {
        IOHardwarePin ioHardwarePin = (IOHardwarePin)theEObject;
        T result = caseIOHardwarePin(ioHardwarePin);
        if (result == null) result = caseHardwarePin(ioHardwarePin);
        if (result == null) result = caseEAPort(ioHardwarePin);
        if (result == null) result = caseEAElement(ioHardwarePin);
        if (result == null) result = caseIdentifiable(ioHardwarePin);
        if (result == null) result = caseReferrable(ioHardwarePin);
        if (result == null) result = caseGIdentifiable(ioHardwarePin);
        if (result == null) result = caseGReferrable(ioHardwarePin);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.NODE:
      {
        Node node = (Node)theEObject;
        T result = caseNode(node);
        if (result == null) result = caseHardwareComponentType(node);
        if (result == null) result = caseEAType(node);
        if (result == null) result = caseContext(node);
        if (result == null) result = caseEAPackageableElement(node);
        if (result == null) result = caseEAElement(node);
        if (result == null) result = caseGEAPackageableElement(node);
        if (result == null) result = caseIdentifiable(node);
        if (result == null) result = caseReferrable(node);
        if (result == null) result = caseGIdentifiable(node);
        if (result == null) result = caseGReferrable(node);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.POWER_HARDWARE_PIN:
      {
        PowerHardwarePin powerHardwarePin = (PowerHardwarePin)theEObject;
        T result = casePowerHardwarePin(powerHardwarePin);
        if (result == null) result = caseHardwarePin(powerHardwarePin);
        if (result == null) result = caseEAPort(powerHardwarePin);
        if (result == null) result = caseEAElement(powerHardwarePin);
        if (result == null) result = caseIdentifiable(powerHardwarePin);
        if (result == null) result = caseReferrable(powerHardwarePin);
        if (result == null) result = caseGIdentifiable(powerHardwarePin);
        if (result == null) result = caseGReferrable(powerHardwarePin);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SENSOR:
      {
        Sensor sensor = (Sensor)theEObject;
        T result = caseSensor(sensor);
        if (result == null) result = caseHardwareComponentType(sensor);
        if (result == null) result = caseEAType(sensor);
        if (result == null) result = caseContext(sensor);
        if (result == null) result = caseEAPackageableElement(sensor);
        if (result == null) result = caseEAElement(sensor);
        if (result == null) result = caseGEAPackageableElement(sensor);
        if (result == null) result = caseIdentifiable(sensor);
        if (result == null) result = caseReferrable(sensor);
        if (result == null) result = caseGIdentifiable(sensor);
        if (result == null) result = caseGReferrable(sensor);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ALLOCATION_TARGET:
      {
        AllocationTarget allocationTarget = (AllocationTarget)theEObject;
        T result = caseAllocationTarget(allocationTarget);
        if (result == null) result = caseEAElement(allocationTarget);
        if (result == null) result = caseIdentifiable(allocationTarget);
        if (result == null) result = caseReferrable(allocationTarget);
        if (result == null) result = caseGIdentifiable(allocationTarget);
        if (result == null) result = caseGReferrable(allocationTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_CONNECTOR_PORT:
      {
        HardwareConnector_port hardwareConnector_port = (HardwareConnector_port)theEObject;
        T result = caseHardwareConnector_port(hardwareConnector_port);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HARDWARE_PORT_CONNECTOR_PORT:
      {
        HardwarePortConnector_port hardwarePortConnector_port = (HardwarePortConnector_port)theEObject;
        T result = caseHardwarePortConnector_port(hardwarePortConnector_port);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CLAMP_CONNECTOR:
      {
        ClampConnector clampConnector = (ClampConnector)theEObject;
        T result = caseClampConnector(clampConnector);
        if (result == null) result = caseEAElement(clampConnector);
        if (result == null) result = caseIdentifiable(clampConnector);
        if (result == null) result = caseReferrable(clampConnector);
        if (result == null) result = caseGIdentifiable(clampConnector);
        if (result == null) result = caseGReferrable(clampConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ENVIRONMENT:
      {
        Environment environment = (Environment)theEObject;
        T result = caseEnvironment(environment);
        if (result == null) result = caseContext(environment);
        if (result == null) result = caseEAPackageableElement(environment);
        if (result == null) result = caseEAElement(environment);
        if (result == null) result = caseGEAPackageableElement(environment);
        if (result == null) result = caseIdentifiable(environment);
        if (result == null) result = caseReferrable(environment);
        if (result == null) result = caseGIdentifiable(environment);
        if (result == null) result = caseGReferrable(environment);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CLAMP_CONNECTOR_PORT:
      {
        ClampConnector_port clampConnector_port = (ClampConnector_port)theEObject;
        T result = caseClampConnector_port(clampConnector_port);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR:
      {
        Behavior behavior = (Behavior)theEObject;
        T result = caseBehavior(behavior);
        if (result == null) result = caseContext(behavior);
        if (result == null) result = caseEAPackageableElement(behavior);
        if (result == null) result = caseEAElement(behavior);
        if (result == null) result = caseGEAPackageableElement(behavior);
        if (result == null) result = caseIdentifiable(behavior);
        if (result == null) result = caseReferrable(behavior);
        if (result == null) result = caseGIdentifiable(behavior);
        if (result == null) result = caseGReferrable(behavior);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.MODE:
      {
        Mode mode = (Mode)theEObject;
        T result = caseMode(mode);
        if (result == null) result = caseEAElement(mode);
        if (result == null) result = caseIdentifiable(mode);
        if (result == null) result = caseReferrable(mode);
        if (result == null) result = caseGIdentifiable(mode);
        if (result == null) result = caseGReferrable(mode);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.MODE_GROUP:
      {
        ModeGroup modeGroup = (ModeGroup)theEObject;
        T result = caseModeGroup(modeGroup);
        if (result == null) result = caseTraceableSpecification(modeGroup);
        if (result == null) result = caseEAPackageableElement(modeGroup);
        if (result == null) result = caseEAElement(modeGroup);
        if (result == null) result = caseGEAPackageableElement(modeGroup);
        if (result == null) result = caseIdentifiable(modeGroup);
        if (result == null) result = caseReferrable(modeGroup);
        if (result == null) result = caseGIdentifiable(modeGroup);
        if (result == null) result = caseGReferrable(modeGroup);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_BEHAVIOR:
      {
        FunctionBehavior functionBehavior = (FunctionBehavior)theEObject;
        T result = caseFunctionBehavior(functionBehavior);
        if (result == null) result = caseContext(functionBehavior);
        if (result == null) result = caseEAPackageableElement(functionBehavior);
        if (result == null) result = caseEAElement(functionBehavior);
        if (result == null) result = caseGEAPackageableElement(functionBehavior);
        if (result == null) result = caseIdentifiable(functionBehavior);
        if (result == null) result = caseReferrable(functionBehavior);
        if (result == null) result = caseGIdentifiable(functionBehavior);
        if (result == null) result = caseGReferrable(functionBehavior);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTION_TRIGGER:
      {
        FunctionTrigger functionTrigger = (FunctionTrigger)theEObject;
        T result = caseFunctionTrigger(functionTrigger);
        if (result == null) result = caseEAExpression(functionTrigger);
        if (result == null) result = caseEAElement(functionTrigger);
        if (result == null) result = caseEAValue(functionTrigger);
        if (result == null) result = caseIdentifiable(functionTrigger);
        if (result == null) result = caseReferrable(functionTrigger);
        if (result == null) result = caseGIdentifiable(functionTrigger);
        if (result == null) result = caseGReferrable(functionTrigger);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONFIGURABLE_CONTAINER:
      {
        ConfigurableContainer configurableContainer = (ConfigurableContainer)theEObject;
        T result = caseConfigurableContainer(configurableContainer);
        if (result == null) result = caseEAElement(configurableContainer);
        if (result == null) result = caseIdentifiable(configurableContainer);
        if (result == null) result = caseReferrable(configurableContainer);
        if (result == null) result = caseGIdentifiable(configurableContainer);
        if (result == null) result = caseGReferrable(configurableContainer);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONFIGURATION_DECISION:
      {
        ConfigurationDecision configurationDecision = (ConfigurationDecision)theEObject;
        T result = caseConfigurationDecision(configurationDecision);
        if (result == null) result = caseConfigurationDecisionModelEntry(configurationDecision);
        if (result == null) result = caseEAElement(configurationDecision);
        if (result == null) result = caseIdentifiable(configurationDecision);
        if (result == null) result = caseReferrable(configurationDecision);
        if (result == null) result = caseGIdentifiable(configurationDecision);
        if (result == null) result = caseGReferrable(configurationDecision);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONFIGURATION_DECISION_FOLDER:
      {
        ConfigurationDecisionFolder configurationDecisionFolder = (ConfigurationDecisionFolder)theEObject;
        T result = caseConfigurationDecisionFolder(configurationDecisionFolder);
        if (result == null) result = caseConfigurationDecisionModelEntry(configurationDecisionFolder);
        if (result == null) result = caseEAElement(configurationDecisionFolder);
        if (result == null) result = caseIdentifiable(configurationDecisionFolder);
        if (result == null) result = caseReferrable(configurationDecisionFolder);
        if (result == null) result = caseGIdentifiable(configurationDecisionFolder);
        if (result == null) result = caseGReferrable(configurationDecisionFolder);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONFIGURATION_DECISION_MODEL:
      {
        ConfigurationDecisionModel configurationDecisionModel = (ConfigurationDecisionModel)theEObject;
        T result = caseConfigurationDecisionModel(configurationDecisionModel);
        if (result == null) result = caseEAElement(configurationDecisionModel);
        if (result == null) result = caseIdentifiable(configurationDecisionModel);
        if (result == null) result = caseReferrable(configurationDecisionModel);
        if (result == null) result = caseGIdentifiable(configurationDecisionModel);
        if (result == null) result = caseGReferrable(configurationDecisionModel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONFIGURATION_DECISION_MODEL_ENTRY:
      {
        ConfigurationDecisionModelEntry configurationDecisionModelEntry = (ConfigurationDecisionModelEntry)theEObject;
        T result = caseConfigurationDecisionModelEntry(configurationDecisionModelEntry);
        if (result == null) result = caseEAElement(configurationDecisionModelEntry);
        if (result == null) result = caseIdentifiable(configurationDecisionModelEntry);
        if (result == null) result = caseReferrable(configurationDecisionModelEntry);
        if (result == null) result = caseGIdentifiable(configurationDecisionModelEntry);
        if (result == null) result = caseGReferrable(configurationDecisionModelEntry);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONTAINER_CONFIGURATION:
      {
        ContainerConfiguration containerConfiguration = (ContainerConfiguration)theEObject;
        T result = caseContainerConfiguration(containerConfiguration);
        if (result == null) result = caseConfigurationDecisionModel(containerConfiguration);
        if (result == null) result = caseEAElement(containerConfiguration);
        if (result == null) result = caseIdentifiable(containerConfiguration);
        if (result == null) result = caseReferrable(containerConfiguration);
        if (result == null) result = caseGIdentifiable(containerConfiguration);
        if (result == null) result = caseGReferrable(containerConfiguration);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_CONFIGURATION:
      {
        FeatureConfiguration featureConfiguration = (FeatureConfiguration)theEObject;
        T result = caseFeatureConfiguration(featureConfiguration);
        if (result == null) result = caseConfigurationDecisionModel(featureConfiguration);
        if (result == null) result = caseEAElement(featureConfiguration);
        if (result == null) result = caseIdentifiable(featureConfiguration);
        if (result == null) result = caseReferrable(featureConfiguration);
        if (result == null) result = caseGIdentifiable(featureConfiguration);
        if (result == null) result = caseGReferrable(featureConfiguration);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.INTERNAL_BINDING:
      {
        InternalBinding internalBinding = (InternalBinding)theEObject;
        T result = caseInternalBinding(internalBinding);
        if (result == null) result = caseConfigurationDecisionModel(internalBinding);
        if (result == null) result = caseEAElement(internalBinding);
        if (result == null) result = caseIdentifiable(internalBinding);
        if (result == null) result = caseReferrable(internalBinding);
        if (result == null) result = caseGIdentifiable(internalBinding);
        if (result == null) result = caseGReferrable(internalBinding);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PRIVATE_CONTENT:
      {
        PrivateContent privateContent = (PrivateContent)theEObject;
        T result = casePrivateContent(privateContent);
        if (result == null) result = caseEAElement(privateContent);
        if (result == null) result = caseIdentifiable(privateContent);
        if (result == null) result = caseReferrable(privateContent);
        if (result == null) result = caseGIdentifiable(privateContent);
        if (result == null) result = caseGReferrable(privateContent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REUSE_META_INFORMATION:
      {
        ReuseMetaInformation reuseMetaInformation = (ReuseMetaInformation)theEObject;
        T result = caseReuseMetaInformation(reuseMetaInformation);
        if (result == null) result = caseTraceableSpecification(reuseMetaInformation);
        if (result == null) result = caseEAPackageableElement(reuseMetaInformation);
        if (result == null) result = caseEAElement(reuseMetaInformation);
        if (result == null) result = caseGEAPackageableElement(reuseMetaInformation);
        if (result == null) result = caseIdentifiable(reuseMetaInformation);
        if (result == null) result = caseReferrable(reuseMetaInformation);
        if (result == null) result = caseGIdentifiable(reuseMetaInformation);
        if (result == null) result = caseGReferrable(reuseMetaInformation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SELECTION_CRITERION:
      {
        SelectionCriterion selectionCriterion = (SelectionCriterion)theEObject;
        T result = caseSelectionCriterion(selectionCriterion);
        if (result == null) result = caseEAExpression(selectionCriterion);
        if (result == null) result = caseEAValue(selectionCriterion);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VARIABILITY:
      {
        Variability variability = (Variability)theEObject;
        T result = caseVariability(variability);
        if (result == null) result = caseContext(variability);
        if (result == null) result = caseEAPackageableElement(variability);
        if (result == null) result = caseEAElement(variability);
        if (result == null) result = caseGEAPackageableElement(variability);
        if (result == null) result = caseIdentifiable(variability);
        if (result == null) result = caseReferrable(variability);
        if (result == null) result = caseGIdentifiable(variability);
        if (result == null) result = caseGReferrable(variability);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VARIABLE_ELEMENT:
      {
        VariableElement variableElement = (VariableElement)theEObject;
        T result = caseVariableElement(variableElement);
        if (result == null) result = caseEAElement(variableElement);
        if (result == null) result = caseIdentifiable(variableElement);
        if (result == null) result = caseReferrable(variableElement);
        if (result == null) result = caseGIdentifiable(variableElement);
        if (result == null) result = caseGReferrable(variableElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VARIATION_GROUP:
      {
        VariationGroup variationGroup = (VariationGroup)theEObject;
        T result = caseVariationGroup(variationGroup);
        if (result == null) result = caseEAElement(variationGroup);
        if (result == null) result = caseIdentifiable(variationGroup);
        if (result == null) result = caseReferrable(variationGroup);
        if (result == null) result = caseGIdentifiable(variationGroup);
        if (result == null) result = caseGReferrable(variationGroup);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VEHICLE_LEVEL_BINDING:
      {
        VehicleLevelBinding vehicleLevelBinding = (VehicleLevelBinding)theEObject;
        T result = caseVehicleLevelBinding(vehicleLevelBinding);
        if (result == null) result = caseConfigurationDecisionModel(vehicleLevelBinding);
        if (result == null) result = caseEAElement(vehicleLevelBinding);
        if (result == null) result = caseIdentifiable(vehicleLevelBinding);
        if (result == null) result = caseReferrable(vehicleLevelBinding);
        if (result == null) result = caseGIdentifiable(vehicleLevelBinding);
        if (result == null) result = caseGReferrable(vehicleLevelBinding);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DERIVE_REQUIREMENT:
      {
        DeriveRequirement deriveRequirement = (DeriveRequirement)theEObject;
        T result = caseDeriveRequirement(deriveRequirement);
        if (result == null) result = caseRequirementsRelationship(deriveRequirement);
        if (result == null) result = caseRelationship(deriveRequirement);
        if (result == null) result = caseEAElement(deriveRequirement);
        if (result == null) result = caseIdentifiable(deriveRequirement);
        if (result == null) result = caseReferrable(deriveRequirement);
        if (result == null) result = caseGIdentifiable(deriveRequirement);
        if (result == null) result = caseGReferrable(deriveRequirement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.OPERATIONAL_SITUATION:
      {
        OperationalSituation operationalSituation = (OperationalSituation)theEObject;
        T result = caseOperationalSituation(operationalSituation);
        if (result == null) result = caseTraceableSpecification(operationalSituation);
        if (result == null) result = caseEAPackageableElement(operationalSituation);
        if (result == null) result = caseEAElement(operationalSituation);
        if (result == null) result = caseGEAPackageableElement(operationalSituation);
        if (result == null) result = caseIdentifiable(operationalSituation);
        if (result == null) result = caseReferrable(operationalSituation);
        if (result == null) result = caseGIdentifiable(operationalSituation);
        if (result == null) result = caseGReferrable(operationalSituation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REQUIREMENTS_MODEL:
      {
        RequirementsModel requirementsModel = (RequirementsModel)theEObject;
        T result = caseRequirementsModel(requirementsModel);
        if (result == null) result = caseContext(requirementsModel);
        if (result == null) result = caseEAPackageableElement(requirementsModel);
        if (result == null) result = caseEAElement(requirementsModel);
        if (result == null) result = caseGEAPackageableElement(requirementsModel);
        if (result == null) result = caseIdentifiable(requirementsModel);
        if (result == null) result = caseReferrable(requirementsModel);
        if (result == null) result = caseGIdentifiable(requirementsModel);
        if (result == null) result = caseGReferrable(requirementsModel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REQUIREMENTS_RELATIONSHIP:
      {
        RequirementsRelationship requirementsRelationship = (RequirementsRelationship)theEObject;
        T result = caseRequirementsRelationship(requirementsRelationship);
        if (result == null) result = caseRelationship(requirementsRelationship);
        if (result == null) result = caseEAElement(requirementsRelationship);
        if (result == null) result = caseIdentifiable(requirementsRelationship);
        if (result == null) result = caseReferrable(requirementsRelationship);
        if (result == null) result = caseGIdentifiable(requirementsRelationship);
        if (result == null) result = caseGReferrable(requirementsRelationship);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REQUIREMENT:
      {
        Requirement requirement = (Requirement)theEObject;
        T result = caseRequirement(requirement);
        if (result == null) result = caseTraceableSpecification(requirement);
        if (result == null) result = caseEAPackageableElement(requirement);
        if (result == null) result = caseEAElement(requirement);
        if (result == null) result = caseGEAPackageableElement(requirement);
        if (result == null) result = caseIdentifiable(requirement);
        if (result == null) result = caseReferrable(requirement);
        if (result == null) result = caseGIdentifiable(requirement);
        if (result == null) result = caseGReferrable(requirement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REQUIREMENTS_HIERARCHY:
      {
        RequirementsHierarchy requirementsHierarchy = (RequirementsHierarchy)theEObject;
        T result = caseRequirementsHierarchy(requirementsHierarchy);
        if (result == null) result = caseTraceableSpecification(requirementsHierarchy);
        if (result == null) result = caseEAPackageableElement(requirementsHierarchy);
        if (result == null) result = caseEAElement(requirementsHierarchy);
        if (result == null) result = caseGEAPackageableElement(requirementsHierarchy);
        if (result == null) result = caseIdentifiable(requirementsHierarchy);
        if (result == null) result = caseReferrable(requirementsHierarchy);
        if (result == null) result = caseGIdentifiable(requirementsHierarchy);
        if (result == null) result = caseGReferrable(requirementsHierarchy);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REFINE:
      {
        Refine refine = (Refine)theEObject;
        T result = caseRefine(refine);
        if (result == null) result = caseRequirementsRelationship(refine);
        if (result == null) result = caseRelationship(refine);
        if (result == null) result = caseEAElement(refine);
        if (result == null) result = caseIdentifiable(refine);
        if (result == null) result = caseReferrable(refine);
        if (result == null) result = caseGIdentifiable(refine);
        if (result == null) result = caseGReferrable(refine);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SATISFY:
      {
        Satisfy satisfy = (Satisfy)theEObject;
        T result = caseSatisfy(satisfy);
        if (result == null) result = caseRequirementsRelationship(satisfy);
        if (result == null) result = caseRelationship(satisfy);
        if (result == null) result = caseEAElement(satisfy);
        if (result == null) result = caseIdentifiable(satisfy);
        if (result == null) result = caseReferrable(satisfy);
        if (result == null) result = caseGIdentifiable(satisfy);
        if (result == null) result = caseGReferrable(satisfy);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REQUIREMENTS_LINK:
      {
        RequirementsLink requirementsLink = (RequirementsLink)theEObject;
        T result = caseRequirementsLink(requirementsLink);
        if (result == null) result = caseRequirementsRelationship(requirementsLink);
        if (result == null) result = caseRelationship(requirementsLink);
        if (result == null) result = caseEAElement(requirementsLink);
        if (result == null) result = caseIdentifiable(requirementsLink);
        if (result == null) result = caseReferrable(requirementsLink);
        if (result == null) result = caseGIdentifiable(requirementsLink);
        if (result == null) result = caseGReferrable(requirementsLink);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REQUIREMENTS_RELATIONSHIP_GROUP:
      {
        RequirementsRelationshipGroup requirementsRelationshipGroup = (RequirementsRelationshipGroup)theEObject;
        T result = caseRequirementsRelationshipGroup(requirementsRelationshipGroup);
        if (result == null) result = caseTraceableSpecification(requirementsRelationshipGroup);
        if (result == null) result = caseEAPackageableElement(requirementsRelationshipGroup);
        if (result == null) result = caseEAElement(requirementsRelationshipGroup);
        if (result == null) result = caseGEAPackageableElement(requirementsRelationshipGroup);
        if (result == null) result = caseIdentifiable(requirementsRelationshipGroup);
        if (result == null) result = caseReferrable(requirementsRelationshipGroup);
        if (result == null) result = caseGIdentifiable(requirementsRelationshipGroup);
        if (result == null) result = caseGReferrable(requirementsRelationshipGroup);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.QUALITY_REQUIREMENT:
      {
        QualityRequirement qualityRequirement = (QualityRequirement)theEObject;
        T result = caseQualityRequirement(qualityRequirement);
        if (result == null) result = caseRequirement(qualityRequirement);
        if (result == null) result = caseTraceableSpecification(qualityRequirement);
        if (result == null) result = caseEAPackageableElement(qualityRequirement);
        if (result == null) result = caseEAElement(qualityRequirement);
        if (result == null) result = caseGEAPackageableElement(qualityRequirement);
        if (result == null) result = caseIdentifiable(qualityRequirement);
        if (result == null) result = caseReferrable(qualityRequirement);
        if (result == null) result = caseGIdentifiable(qualityRequirement);
        if (result == null) result = caseGReferrable(qualityRequirement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REFINE_REFINED_BY:
      {
        Refine_refinedBy refine_refinedBy = (Refine_refinedBy)theEObject;
        T result = caseRefine_refinedBy(refine_refinedBy);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SATISFY_SATISFIED_BY:
      {
        Satisfy_satisfiedBy satisfy_satisfiedBy = (Satisfy_satisfiedBy)theEObject;
        T result = caseSatisfy_satisfiedBy(satisfy_satisfiedBy);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ACTOR:
      {
        Actor actor = (Actor)theEObject;
        T result = caseActor(actor);
        if (result == null) result = caseTraceableSpecification(actor);
        if (result == null) result = caseEAPackageableElement(actor);
        if (result == null) result = caseEAElement(actor);
        if (result == null) result = caseGEAPackageableElement(actor);
        if (result == null) result = caseIdentifiable(actor);
        if (result == null) result = caseReferrable(actor);
        if (result == null) result = caseGIdentifiable(actor);
        if (result == null) result = caseGReferrable(actor);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EXTEND:
      {
        Extend extend = (Extend)theEObject;
        T result = caseExtend(extend);
        if (result == null) result = caseRelationship(extend);
        if (result == null) result = caseEAElement(extend);
        if (result == null) result = caseIdentifiable(extend);
        if (result == null) result = caseReferrable(extend);
        if (result == null) result = caseGIdentifiable(extend);
        if (result == null) result = caseGReferrable(extend);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EXTENSION_POINT:
      {
        ExtensionPoint extensionPoint = (ExtensionPoint)theEObject;
        T result = caseExtensionPoint(extensionPoint);
        if (result == null) result = caseRedefinableElement(extensionPoint);
        if (result == null) result = caseEAElement(extensionPoint);
        if (result == null) result = caseIdentifiable(extensionPoint);
        if (result == null) result = caseReferrable(extensionPoint);
        if (result == null) result = caseGIdentifiable(extensionPoint);
        if (result == null) result = caseGReferrable(extensionPoint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.INCLUDE:
      {
        Include include = (Include)theEObject;
        T result = caseInclude(include);
        if (result == null) result = caseRelationship(include);
        if (result == null) result = caseEAElement(include);
        if (result == null) result = caseIdentifiable(include);
        if (result == null) result = caseReferrable(include);
        if (result == null) result = caseGIdentifiable(include);
        if (result == null) result = caseGReferrable(include);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REDEFINABLE_ELEMENT:
      {
        RedefinableElement redefinableElement = (RedefinableElement)theEObject;
        T result = caseRedefinableElement(redefinableElement);
        if (result == null) result = caseEAElement(redefinableElement);
        if (result == null) result = caseIdentifiable(redefinableElement);
        if (result == null) result = caseReferrable(redefinableElement);
        if (result == null) result = caseGIdentifiable(redefinableElement);
        if (result == null) result = caseGReferrable(redefinableElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.USE_CASE:
      {
        UseCase useCase = (UseCase)theEObject;
        T result = caseUseCase(useCase);
        if (result == null) result = caseTraceableSpecification(useCase);
        if (result == null) result = caseEAPackageableElement(useCase);
        if (result == null) result = caseEAElement(useCase);
        if (result == null) result = caseGEAPackageableElement(useCase);
        if (result == null) result = caseIdentifiable(useCase);
        if (result == null) result = caseReferrable(useCase);
        if (result == null) result = caseGIdentifiable(useCase);
        if (result == null) result = caseGReferrable(useCase);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VERIFICATION_VALIDATION:
      {
        VerificationValidation verificationValidation = (VerificationValidation)theEObject;
        T result = caseVerificationValidation(verificationValidation);
        if (result == null) result = caseContext(verificationValidation);
        if (result == null) result = caseEAPackageableElement(verificationValidation);
        if (result == null) result = caseEAElement(verificationValidation);
        if (result == null) result = caseGEAPackageableElement(verificationValidation);
        if (result == null) result = caseIdentifiable(verificationValidation);
        if (result == null) result = caseReferrable(verificationValidation);
        if (result == null) result = caseGIdentifiable(verificationValidation);
        if (result == null) result = caseGReferrable(verificationValidation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VERIFY:
      {
        Verify verify = (Verify)theEObject;
        T result = caseVerify(verify);
        if (result == null) result = caseRequirementsRelationship(verify);
        if (result == null) result = caseRelationship(verify);
        if (result == null) result = caseEAElement(verify);
        if (result == null) result = caseIdentifiable(verify);
        if (result == null) result = caseReferrable(verify);
        if (result == null) result = caseGIdentifiable(verify);
        if (result == null) result = caseGReferrable(verify);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_ACTUAL_OUTCOME:
      {
        VVActualOutcome vvActualOutcome = (VVActualOutcome)theEObject;
        T result = caseVVActualOutcome(vvActualOutcome);
        if (result == null) result = caseTraceableSpecification(vvActualOutcome);
        if (result == null) result = caseEAPackageableElement(vvActualOutcome);
        if (result == null) result = caseEAElement(vvActualOutcome);
        if (result == null) result = caseGEAPackageableElement(vvActualOutcome);
        if (result == null) result = caseIdentifiable(vvActualOutcome);
        if (result == null) result = caseReferrable(vvActualOutcome);
        if (result == null) result = caseGIdentifiable(vvActualOutcome);
        if (result == null) result = caseGReferrable(vvActualOutcome);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_CASE:
      {
        VVCase vvCase = (VVCase)theEObject;
        T result = caseVVCase(vvCase);
        if (result == null) result = caseTraceableSpecification(vvCase);
        if (result == null) result = caseEAPackageableElement(vvCase);
        if (result == null) result = caseEAElement(vvCase);
        if (result == null) result = caseGEAPackageableElement(vvCase);
        if (result == null) result = caseIdentifiable(vvCase);
        if (result == null) result = caseReferrable(vvCase);
        if (result == null) result = caseGIdentifiable(vvCase);
        if (result == null) result = caseGReferrable(vvCase);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_INTENDED_OUTCOME:
      {
        VVIntendedOutcome vvIntendedOutcome = (VVIntendedOutcome)theEObject;
        T result = caseVVIntendedOutcome(vvIntendedOutcome);
        if (result == null) result = caseTraceableSpecification(vvIntendedOutcome);
        if (result == null) result = caseEAPackageableElement(vvIntendedOutcome);
        if (result == null) result = caseEAElement(vvIntendedOutcome);
        if (result == null) result = caseGEAPackageableElement(vvIntendedOutcome);
        if (result == null) result = caseIdentifiable(vvIntendedOutcome);
        if (result == null) result = caseReferrable(vvIntendedOutcome);
        if (result == null) result = caseGIdentifiable(vvIntendedOutcome);
        if (result == null) result = caseGReferrable(vvIntendedOutcome);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_LOG:
      {
        VVLog vvLog = (VVLog)theEObject;
        T result = caseVVLog(vvLog);
        if (result == null) result = caseTraceableSpecification(vvLog);
        if (result == null) result = caseEAPackageableElement(vvLog);
        if (result == null) result = caseEAElement(vvLog);
        if (result == null) result = caseGEAPackageableElement(vvLog);
        if (result == null) result = caseIdentifiable(vvLog);
        if (result == null) result = caseReferrable(vvLog);
        if (result == null) result = caseGIdentifiable(vvLog);
        if (result == null) result = caseGReferrable(vvLog);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_PROCEDURE:
      {
        VVProcedure vvProcedure = (VVProcedure)theEObject;
        T result = caseVVProcedure(vvProcedure);
        if (result == null) result = caseTraceableSpecification(vvProcedure);
        if (result == null) result = caseEAPackageableElement(vvProcedure);
        if (result == null) result = caseEAElement(vvProcedure);
        if (result == null) result = caseGEAPackageableElement(vvProcedure);
        if (result == null) result = caseIdentifiable(vvProcedure);
        if (result == null) result = caseReferrable(vvProcedure);
        if (result == null) result = caseGIdentifiable(vvProcedure);
        if (result == null) result = caseGReferrable(vvProcedure);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_STIMULI:
      {
        VVStimuli vvStimuli = (VVStimuli)theEObject;
        T result = caseVVStimuli(vvStimuli);
        if (result == null) result = caseTraceableSpecification(vvStimuli);
        if (result == null) result = caseEAPackageableElement(vvStimuli);
        if (result == null) result = caseEAElement(vvStimuli);
        if (result == null) result = caseGEAPackageableElement(vvStimuli);
        if (result == null) result = caseIdentifiable(vvStimuli);
        if (result == null) result = caseReferrable(vvStimuli);
        if (result == null) result = caseGIdentifiable(vvStimuli);
        if (result == null) result = caseGReferrable(vvStimuli);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_TARGET:
      {
        VVTarget vvTarget = (VVTarget)theEObject;
        T result = caseVVTarget(vvTarget);
        if (result == null) result = caseTraceableSpecification(vvTarget);
        if (result == null) result = caseEAPackageableElement(vvTarget);
        if (result == null) result = caseEAElement(vvTarget);
        if (result == null) result = caseGEAPackageableElement(vvTarget);
        if (result == null) result = caseIdentifiable(vvTarget);
        if (result == null) result = caseReferrable(vvTarget);
        if (result == null) result = caseGIdentifiable(vvTarget);
        if (result == null) result = caseGReferrable(vvTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_CASE_VV_SUBJECT:
      {
        VVCase_vvSubject vvCase_vvSubject = (VVCase_vvSubject)theEObject;
        T result = caseVVCase_vvSubject(vvCase_vvSubject);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VV_TARGET_ELEMENT:
      {
        VVTarget_element vvTarget_element = (VVTarget_element)theEObject;
        T result = caseVVTarget_element(vvTarget_element);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT:
      {
        Event event = (Event)theEObject;
        T result = caseEvent(event);
        if (result == null) result = caseTimingDescription(event);
        if (result == null) result = caseEAElement(event);
        if (result == null) result = caseIdentifiable(event);
        if (result == null) result = caseReferrable(event);
        if (result == null) result = caseGIdentifiable(event);
        if (result == null) result = caseGReferrable(event);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_CHAIN:
      {
        EventChain eventChain = (EventChain)theEObject;
        T result = caseEventChain(eventChain);
        if (result == null) result = caseTimingDescription(eventChain);
        if (result == null) result = caseEAElement(eventChain);
        if (result == null) result = caseIdentifiable(eventChain);
        if (result == null) result = caseReferrable(eventChain);
        if (result == null) result = caseGIdentifiable(eventChain);
        if (result == null) result = caseGReferrable(eventChain);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PRECEDENCE_CONSTRAINT:
      {
        PrecedenceConstraint precedenceConstraint = (PrecedenceConstraint)theEObject;
        T result = casePrecedenceConstraint(precedenceConstraint);
        if (result == null) result = caseTimingConstraint(precedenceConstraint);
        if (result == null) result = caseEAElement(precedenceConstraint);
        if (result == null) result = caseIdentifiable(precedenceConstraint);
        if (result == null) result = caseReferrable(precedenceConstraint);
        if (result == null) result = caseGIdentifiable(precedenceConstraint);
        if (result == null) result = caseGReferrable(precedenceConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TIMING:
      {
        Timing timing = (Timing)theEObject;
        T result = caseTiming(timing);
        if (result == null) result = caseContext(timing);
        if (result == null) result = caseEAPackageableElement(timing);
        if (result == null) result = caseEAElement(timing);
        if (result == null) result = caseGEAPackageableElement(timing);
        if (result == null) result = caseIdentifiable(timing);
        if (result == null) result = caseReferrable(timing);
        if (result == null) result = caseGIdentifiable(timing);
        if (result == null) result = caseGReferrable(timing);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TIMING_CONSTRAINT:
      {
        TimingConstraint timingConstraint = (TimingConstraint)theEObject;
        T result = caseTimingConstraint(timingConstraint);
        if (result == null) result = caseEAElement(timingConstraint);
        if (result == null) result = caseIdentifiable(timingConstraint);
        if (result == null) result = caseReferrable(timingConstraint);
        if (result == null) result = caseGIdentifiable(timingConstraint);
        if (result == null) result = caseGReferrable(timingConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TIMING_DESCRIPTION:
      {
        TimingDescription timingDescription = (TimingDescription)theEObject;
        T result = caseTimingDescription(timingDescription);
        if (result == null) result = caseEAElement(timingDescription);
        if (result == null) result = caseIdentifiable(timingDescription);
        if (result == null) result = caseReferrable(timingDescription);
        if (result == null) result = caseGIdentifiable(timingDescription);
        if (result == null) result = caseGReferrable(timingDescription);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TIMING_EXPRESSION:
      {
        TimingExpression timingExpression = (TimingExpression)theEObject;
        T result = caseTimingExpression(timingExpression);
        if (result == null) result = caseEAExpression(timingExpression);
        if (result == null) result = caseEAValue(timingExpression);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.AUTOSAR_EVENT:
      {
        AUTOSAREvent autosarEvent = (AUTOSAREvent)theEObject;
        T result = caseAUTOSAREvent(autosarEvent);
        if (result == null) result = caseEvent(autosarEvent);
        if (result == null) result = caseTimingDescription(autosarEvent);
        if (result == null) result = caseEAElement(autosarEvent);
        if (result == null) result = caseIdentifiable(autosarEvent);
        if (result == null) result = caseReferrable(autosarEvent);
        if (result == null) result = caseGIdentifiable(autosarEvent);
        if (result == null) result = caseGReferrable(autosarEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FAULT_FAILURE:
      {
        EventFaultFailure eventFaultFailure = (EventFaultFailure)theEObject;
        T result = caseEventFaultFailure(eventFaultFailure);
        if (result == null) result = caseEvent(eventFaultFailure);
        if (result == null) result = caseTimingDescription(eventFaultFailure);
        if (result == null) result = caseEAElement(eventFaultFailure);
        if (result == null) result = caseIdentifiable(eventFaultFailure);
        if (result == null) result = caseReferrable(eventFaultFailure);
        if (result == null) result = caseGIdentifiable(eventFaultFailure);
        if (result == null) result = caseGReferrable(eventFaultFailure);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FEATURE_FLAW:
      {
        EventFeatureFlaw eventFeatureFlaw = (EventFeatureFlaw)theEObject;
        T result = caseEventFeatureFlaw(eventFeatureFlaw);
        if (result == null) result = caseEvent(eventFeatureFlaw);
        if (result == null) result = caseTimingDescription(eventFeatureFlaw);
        if (result == null) result = caseEAElement(eventFeatureFlaw);
        if (result == null) result = caseIdentifiable(eventFeatureFlaw);
        if (result == null) result = caseReferrable(eventFeatureFlaw);
        if (result == null) result = caseGIdentifiable(eventFeatureFlaw);
        if (result == null) result = caseGReferrable(eventFeatureFlaw);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FUNCTION:
      {
        EventFunction eventFunction = (EventFunction)theEObject;
        T result = caseEventFunction(eventFunction);
        if (result == null) result = caseEvent(eventFunction);
        if (result == null) result = caseTimingDescription(eventFunction);
        if (result == null) result = caseEAElement(eventFunction);
        if (result == null) result = caseIdentifiable(eventFunction);
        if (result == null) result = caseReferrable(eventFunction);
        if (result == null) result = caseGIdentifiable(eventFunction);
        if (result == null) result = caseGReferrable(eventFunction);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT:
      {
        EventFunctionClientServerPort eventFunctionClientServerPort = (EventFunctionClientServerPort)theEObject;
        T result = caseEventFunctionClientServerPort(eventFunctionClientServerPort);
        if (result == null) result = caseEAExpression(eventFunctionClientServerPort);
        if (result == null) result = caseEvent(eventFunctionClientServerPort);
        if (result == null) result = caseEAValue(eventFunctionClientServerPort);
        if (result == null) result = caseTimingDescription(eventFunctionClientServerPort);
        if (result == null) result = caseEAElement(eventFunctionClientServerPort);
        if (result == null) result = caseIdentifiable(eventFunctionClientServerPort);
        if (result == null) result = caseReferrable(eventFunctionClientServerPort);
        if (result == null) result = caseGIdentifiable(eventFunctionClientServerPort);
        if (result == null) result = caseGReferrable(eventFunctionClientServerPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FUNCTION_FLOW_PORT:
      {
        EventFunctionFlowPort eventFunctionFlowPort = (EventFunctionFlowPort)theEObject;
        T result = caseEventFunctionFlowPort(eventFunctionFlowPort);
        if (result == null) result = caseEAExpression(eventFunctionFlowPort);
        if (result == null) result = caseEvent(eventFunctionFlowPort);
        if (result == null) result = caseEAValue(eventFunctionFlowPort);
        if (result == null) result = caseTimingDescription(eventFunctionFlowPort);
        if (result == null) result = caseEAElement(eventFunctionFlowPort);
        if (result == null) result = caseIdentifiable(eventFunctionFlowPort);
        if (result == null) result = caseReferrable(eventFunctionFlowPort);
        if (result == null) result = caseGIdentifiable(eventFunctionFlowPort);
        if (result == null) result = caseGReferrable(eventFunctionFlowPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EXTERNAL_EVENT:
      {
        ExternalEvent externalEvent = (ExternalEvent)theEObject;
        T result = caseExternalEvent(externalEvent);
        if (result == null) result = caseEvent(externalEvent);
        if (result == null) result = caseTimingDescription(externalEvent);
        if (result == null) result = caseEAElement(externalEvent);
        if (result == null) result = caseIdentifiable(externalEvent);
        if (result == null) result = caseReferrable(externalEvent);
        if (result == null) result = caseGIdentifiable(externalEvent);
        if (result == null) result = caseGReferrable(externalEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.MODE_EVENT:
      {
        ModeEvent modeEvent = (ModeEvent)theEObject;
        T result = caseModeEvent(modeEvent);
        if (result == null) result = caseEvent(modeEvent);
        if (result == null) result = caseTimingDescription(modeEvent);
        if (result == null) result = caseEAElement(modeEvent);
        if (result == null) result = caseIdentifiable(modeEvent);
        if (result == null) result = caseReferrable(modeEvent);
        if (result == null) result = caseGIdentifiable(modeEvent);
        if (result == null) result = caseGReferrable(modeEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FUNCTION_FUNCTION:
      {
        EventFunction_function eventFunction_function = (EventFunction_function)theEObject;
        T result = caseEventFunction_function(eventFunction_function);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT:
      {
        EventFunctionClientServerPort_port eventFunctionClientServerPort_port = (EventFunctionClientServerPort_port)theEObject;
        T result = caseEventFunctionClientServerPort_port(eventFunctionClientServerPort_port);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EVENT_FUNCTION_FLOW_PORT_PORT:
      {
        EventFunctionFlowPort_port eventFunctionFlowPort_port = (EventFunctionFlowPort_port)theEObject;
        T result = caseEventFunctionFlowPort_port(eventFunctionFlowPort_port);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.AGE_CONSTRAINT:
      {
        AgeConstraint ageConstraint = (AgeConstraint)theEObject;
        T result = caseAgeConstraint(ageConstraint);
        if (result == null) result = caseTimingConstraint(ageConstraint);
        if (result == null) result = caseEAElement(ageConstraint);
        if (result == null) result = caseIdentifiable(ageConstraint);
        if (result == null) result = caseReferrable(ageConstraint);
        if (result == null) result = caseGIdentifiable(ageConstraint);
        if (result == null) result = caseGReferrable(ageConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ARBITRARY_CONSTRAINT:
      {
        ArbitraryConstraint arbitraryConstraint = (ArbitraryConstraint)theEObject;
        T result = caseArbitraryConstraint(arbitraryConstraint);
        if (result == null) result = caseTimingConstraint(arbitraryConstraint);
        if (result == null) result = caseEAElement(arbitraryConstraint);
        if (result == null) result = caseIdentifiable(arbitraryConstraint);
        if (result == null) result = caseReferrable(arbitraryConstraint);
        if (result == null) result = caseGIdentifiable(arbitraryConstraint);
        if (result == null) result = caseGReferrable(arbitraryConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BURST_CONSTRAINT:
      {
        BurstConstraint burstConstraint = (BurstConstraint)theEObject;
        T result = caseBurstConstraint(burstConstraint);
        if (result == null) result = caseTimingConstraint(burstConstraint);
        if (result == null) result = caseEAElement(burstConstraint);
        if (result == null) result = caseIdentifiable(burstConstraint);
        if (result == null) result = caseReferrable(burstConstraint);
        if (result == null) result = caseGIdentifiable(burstConstraint);
        if (result == null) result = caseGReferrable(burstConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.COMPARISON_CONSTRAINT:
      {
        ComparisonConstraint comparisonConstraint = (ComparisonConstraint)theEObject;
        T result = caseComparisonConstraint(comparisonConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DELAY_CONSTRAINT:
      {
        DelayConstraint delayConstraint = (DelayConstraint)theEObject;
        T result = caseDelayConstraint(delayConstraint);
        if (result == null) result = caseTimingConstraint(delayConstraint);
        if (result == null) result = caseEAElement(delayConstraint);
        if (result == null) result = caseIdentifiable(delayConstraint);
        if (result == null) result = caseReferrable(delayConstraint);
        if (result == null) result = caseGIdentifiable(delayConstraint);
        if (result == null) result = caseGReferrable(delayConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT:
      {
        ExecutionTimeConstraint executionTimeConstraint = (ExecutionTimeConstraint)theEObject;
        T result = caseExecutionTimeConstraint(executionTimeConstraint);
        if (result == null) result = caseTimingConstraint(executionTimeConstraint);
        if (result == null) result = caseEAElement(executionTimeConstraint);
        if (result == null) result = caseIdentifiable(executionTimeConstraint);
        if (result == null) result = caseReferrable(executionTimeConstraint);
        if (result == null) result = caseGIdentifiable(executionTimeConstraint);
        if (result == null) result = caseGReferrable(executionTimeConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.INPUT_SYNCHRONIZATION_CONSTRAINT:
      {
        InputSynchronizationConstraint inputSynchronizationConstraint = (InputSynchronizationConstraint)theEObject;
        T result = caseInputSynchronizationConstraint(inputSynchronizationConstraint);
        if (result == null) result = caseTimingConstraint(inputSynchronizationConstraint);
        if (result == null) result = caseEAElement(inputSynchronizationConstraint);
        if (result == null) result = caseIdentifiable(inputSynchronizationConstraint);
        if (result == null) result = caseReferrable(inputSynchronizationConstraint);
        if (result == null) result = caseGIdentifiable(inputSynchronizationConstraint);
        if (result == null) result = caseGReferrable(inputSynchronizationConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ORDER_CONSTRAINT:
      {
        OrderConstraint orderConstraint = (OrderConstraint)theEObject;
        T result = caseOrderConstraint(orderConstraint);
        if (result == null) result = caseTimingConstraint(orderConstraint);
        if (result == null) result = caseEAElement(orderConstraint);
        if (result == null) result = caseIdentifiable(orderConstraint);
        if (result == null) result = caseReferrable(orderConstraint);
        if (result == null) result = caseGIdentifiable(orderConstraint);
        if (result == null) result = caseGReferrable(orderConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.OUTPUT_SYNCHRONIZATION_CONSTRAINT:
      {
        OutputSynchronizationConstraint outputSynchronizationConstraint = (OutputSynchronizationConstraint)theEObject;
        T result = caseOutputSynchronizationConstraint(outputSynchronizationConstraint);
        if (result == null) result = caseTimingConstraint(outputSynchronizationConstraint);
        if (result == null) result = caseEAElement(outputSynchronizationConstraint);
        if (result == null) result = caseIdentifiable(outputSynchronizationConstraint);
        if (result == null) result = caseReferrable(outputSynchronizationConstraint);
        if (result == null) result = caseGIdentifiable(outputSynchronizationConstraint);
        if (result == null) result = caseGReferrable(outputSynchronizationConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PATTERN_CONSTRAINT:
      {
        PatternConstraint patternConstraint = (PatternConstraint)theEObject;
        T result = casePatternConstraint(patternConstraint);
        if (result == null) result = caseTimingConstraint(patternConstraint);
        if (result == null) result = caseEAElement(patternConstraint);
        if (result == null) result = caseIdentifiable(patternConstraint);
        if (result == null) result = caseReferrable(patternConstraint);
        if (result == null) result = caseGIdentifiable(patternConstraint);
        if (result == null) result = caseGReferrable(patternConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PERIODIC_CONSTRAINT:
      {
        PeriodicConstraint periodicConstraint = (PeriodicConstraint)theEObject;
        T result = casePeriodicConstraint(periodicConstraint);
        if (result == null) result = caseTimingConstraint(periodicConstraint);
        if (result == null) result = caseEAElement(periodicConstraint);
        if (result == null) result = caseIdentifiable(periodicConstraint);
        if (result == null) result = caseReferrable(periodicConstraint);
        if (result == null) result = caseGIdentifiable(periodicConstraint);
        if (result == null) result = caseGReferrable(periodicConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REACTION_CONSTRAINT:
      {
        ReactionConstraint reactionConstraint = (ReactionConstraint)theEObject;
        T result = caseReactionConstraint(reactionConstraint);
        if (result == null) result = caseTimingConstraint(reactionConstraint);
        if (result == null) result = caseEAElement(reactionConstraint);
        if (result == null) result = caseIdentifiable(reactionConstraint);
        if (result == null) result = caseReferrable(reactionConstraint);
        if (result == null) result = caseGIdentifiable(reactionConstraint);
        if (result == null) result = caseGReferrable(reactionConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REPETITION_CONSTRAINT:
      {
        RepetitionConstraint repetitionConstraint = (RepetitionConstraint)theEObject;
        T result = caseRepetitionConstraint(repetitionConstraint);
        if (result == null) result = caseTimingConstraint(repetitionConstraint);
        if (result == null) result = caseEAElement(repetitionConstraint);
        if (result == null) result = caseIdentifiable(repetitionConstraint);
        if (result == null) result = caseReferrable(repetitionConstraint);
        if (result == null) result = caseGIdentifiable(repetitionConstraint);
        if (result == null) result = caseGReferrable(repetitionConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SPORADIC_CONSTRAINT:
      {
        SporadicConstraint sporadicConstraint = (SporadicConstraint)theEObject;
        T result = caseSporadicConstraint(sporadicConstraint);
        if (result == null) result = caseTimingConstraint(sporadicConstraint);
        if (result == null) result = caseEAElement(sporadicConstraint);
        if (result == null) result = caseIdentifiable(sporadicConstraint);
        if (result == null) result = caseReferrable(sporadicConstraint);
        if (result == null) result = caseGIdentifiable(sporadicConstraint);
        if (result == null) result = caseGReferrable(sporadicConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.STRONG_DELAY_CONSTRAINT:
      {
        StrongDelayConstraint strongDelayConstraint = (StrongDelayConstraint)theEObject;
        T result = caseStrongDelayConstraint(strongDelayConstraint);
        if (result == null) result = caseTimingConstraint(strongDelayConstraint);
        if (result == null) result = caseEAElement(strongDelayConstraint);
        if (result == null) result = caseIdentifiable(strongDelayConstraint);
        if (result == null) result = caseReferrable(strongDelayConstraint);
        if (result == null) result = caseGIdentifiable(strongDelayConstraint);
        if (result == null) result = caseGReferrable(strongDelayConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.STRONG_SYNCHRONIZATION_CONSTRAINT:
      {
        StrongSynchronizationConstraint strongSynchronizationConstraint = (StrongSynchronizationConstraint)theEObject;
        T result = caseStrongSynchronizationConstraint(strongSynchronizationConstraint);
        if (result == null) result = caseTimingConstraint(strongSynchronizationConstraint);
        if (result == null) result = caseEAElement(strongSynchronizationConstraint);
        if (result == null) result = caseIdentifiable(strongSynchronizationConstraint);
        if (result == null) result = caseReferrable(strongSynchronizationConstraint);
        if (result == null) result = caseGIdentifiable(strongSynchronizationConstraint);
        if (result == null) result = caseGReferrable(strongSynchronizationConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SYNCHRONIZATION_CONSTRAINT:
      {
        SynchronizationConstraint synchronizationConstraint = (SynchronizationConstraint)theEObject;
        T result = caseSynchronizationConstraint(synchronizationConstraint);
        if (result == null) result = caseTimingConstraint(synchronizationConstraint);
        if (result == null) result = caseEAElement(synchronizationConstraint);
        if (result == null) result = caseIdentifiable(synchronizationConstraint);
        if (result == null) result = caseReferrable(synchronizationConstraint);
        if (result == null) result = caseGIdentifiable(synchronizationConstraint);
        if (result == null) result = caseGReferrable(synchronizationConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PRECEDENCE_CONSTRAINT_PRECEDING:
      {
        PrecedenceConstraint_preceding precedenceConstraint_preceding = (PrecedenceConstraint_preceding)theEObject;
        T result = casePrecedenceConstraint_preceding(precedenceConstraint_preceding);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PRECEDENCE_CONSTRAINT_SUCCESSIVE:
      {
        PrecedenceConstraint_successive precedenceConstraint_successive = (PrecedenceConstraint_successive)theEObject;
        T result = casePrecedenceConstraint_successive(precedenceConstraint_successive);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.DEPENDABILITY:
      {
        Dependability dependability = (Dependability)theEObject;
        T result = caseDependability(dependability);
        if (result == null) result = caseContext(dependability);
        if (result == null) result = caseEAPackageableElement(dependability);
        if (result == null) result = caseEAElement(dependability);
        if (result == null) result = caseGEAPackageableElement(dependability);
        if (result == null) result = caseIdentifiable(dependability);
        if (result == null) result = caseReferrable(dependability);
        if (result == null) result = caseGIdentifiable(dependability);
        if (result == null) result = caseGReferrable(dependability);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FEATURE_FLAW:
      {
        FeatureFlaw featureFlaw = (FeatureFlaw)theEObject;
        T result = caseFeatureFlaw(featureFlaw);
        if (result == null) result = caseTraceableSpecification(featureFlaw);
        if (result == null) result = caseEAPackageableElement(featureFlaw);
        if (result == null) result = caseEAElement(featureFlaw);
        if (result == null) result = caseGEAPackageableElement(featureFlaw);
        if (result == null) result = caseIdentifiable(featureFlaw);
        if (result == null) result = caseReferrable(featureFlaw);
        if (result == null) result = caseGIdentifiable(featureFlaw);
        if (result == null) result = caseGReferrable(featureFlaw);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HAZARD:
      {
        Hazard hazard = (Hazard)theEObject;
        T result = caseHazard(hazard);
        if (result == null) result = caseTraceableSpecification(hazard);
        if (result == null) result = caseEAPackageableElement(hazard);
        if (result == null) result = caseEAElement(hazard);
        if (result == null) result = caseGEAPackageableElement(hazard);
        if (result == null) result = caseIdentifiable(hazard);
        if (result == null) result = caseReferrable(hazard);
        if (result == null) result = caseGIdentifiable(hazard);
        if (result == null) result = caseGReferrable(hazard);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.HAZARDOUS_EVENT:
      {
        HazardousEvent hazardousEvent = (HazardousEvent)theEObject;
        T result = caseHazardousEvent(hazardousEvent);
        if (result == null) result = caseTraceableSpecification(hazardousEvent);
        if (result == null) result = caseEAPackageableElement(hazardousEvent);
        if (result == null) result = caseEAElement(hazardousEvent);
        if (result == null) result = caseGEAPackageableElement(hazardousEvent);
        if (result == null) result = caseIdentifiable(hazardousEvent);
        if (result == null) result = caseReferrable(hazardousEvent);
        if (result == null) result = caseGIdentifiable(hazardousEvent);
        if (result == null) result = caseGReferrable(hazardousEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ITEM:
      {
        Item item = (Item)theEObject;
        T result = caseItem(item);
        if (result == null) result = caseTraceableSpecification(item);
        if (result == null) result = caseEAPackageableElement(item);
        if (result == null) result = caseEAElement(item);
        if (result == null) result = caseGEAPackageableElement(item);
        if (result == null) result = caseIdentifiable(item);
        if (result == null) result = caseReferrable(item);
        if (result == null) result = caseGIdentifiable(item);
        if (result == null) result = caseGReferrable(item);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE:
      {
        FaultFailure faultFailure = (FaultFailure)theEObject;
        T result = caseFaultFailure(faultFailure);
        if (result == null) result = caseTraceableSpecification(faultFailure);
        if (result == null) result = caseEAPackageableElement(faultFailure);
        if (result == null) result = caseEAElement(faultFailure);
        if (result == null) result = caseGEAPackageableElement(faultFailure);
        if (result == null) result = caseIdentifiable(faultFailure);
        if (result == null) result = caseReferrable(faultFailure);
        if (result == null) result = caseGIdentifiable(faultFailure);
        if (result == null) result = caseGReferrable(faultFailure);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.QUANTITATIVE_SAFETY_CONSTRAINT:
      {
        QuantitativeSafetyConstraint quantitativeSafetyConstraint = (QuantitativeSafetyConstraint)theEObject;
        T result = caseQuantitativeSafetyConstraint(quantitativeSafetyConstraint);
        if (result == null) result = caseTraceableSpecification(quantitativeSafetyConstraint);
        if (result == null) result = caseEAPackageableElement(quantitativeSafetyConstraint);
        if (result == null) result = caseEAElement(quantitativeSafetyConstraint);
        if (result == null) result = caseGEAPackageableElement(quantitativeSafetyConstraint);
        if (result == null) result = caseIdentifiable(quantitativeSafetyConstraint);
        if (result == null) result = caseReferrable(quantitativeSafetyConstraint);
        if (result == null) result = caseGIdentifiable(quantitativeSafetyConstraint);
        if (result == null) result = caseGReferrable(quantitativeSafetyConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SAFETY_CONSTRAINT:
      {
        SafetyConstraint safetyConstraint = (SafetyConstraint)theEObject;
        T result = caseSafetyConstraint(safetyConstraint);
        if (result == null) result = caseTraceableSpecification(safetyConstraint);
        if (result == null) result = caseEAPackageableElement(safetyConstraint);
        if (result == null) result = caseEAElement(safetyConstraint);
        if (result == null) result = caseGEAPackageableElement(safetyConstraint);
        if (result == null) result = caseIdentifiable(safetyConstraint);
        if (result == null) result = caseReferrable(safetyConstraint);
        if (result == null) result = caseGIdentifiable(safetyConstraint);
        if (result == null) result = caseGReferrable(safetyConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_ANOMALY:
      {
        FaultFailure_anomaly faultFailure_anomaly = (FaultFailure_anomaly)theEObject;
        T result = caseFaultFailure_anomaly(faultFailure_anomaly);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ANOMALY:
      {
        Anomaly anomaly = (Anomaly)theEObject;
        T result = caseAnomaly(anomaly);
        if (result == null) result = caseEAElement(anomaly);
        if (result == null) result = caseIdentifiable(anomaly);
        if (result == null) result = caseReferrable(anomaly);
        if (result == null) result = caseGIdentifiable(anomaly);
        if (result == null) result = caseGReferrable(anomaly);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ERROR_BEHAVIOR:
      {
        ErrorBehavior errorBehavior = (ErrorBehavior)theEObject;
        T result = caseErrorBehavior(errorBehavior);
        if (result == null) result = caseEAElement(errorBehavior);
        if (result == null) result = caseIdentifiable(errorBehavior);
        if (result == null) result = caseReferrable(errorBehavior);
        if (result == null) result = caseGIdentifiable(errorBehavior);
        if (result == null) result = caseGReferrable(errorBehavior);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE:
      {
        ErrorModelPrototype errorModelPrototype = (ErrorModelPrototype)theEObject;
        T result = caseErrorModelPrototype(errorModelPrototype);
        if (result == null) result = caseEAElement(errorModelPrototype);
        if (result == null) result = caseEAPrototype(errorModelPrototype);
        if (result == null) result = caseIdentifiable(errorModelPrototype);
        if (result == null) result = caseReferrable(errorModelPrototype);
        if (result == null) result = caseGIdentifiable(errorModelPrototype);
        if (result == null) result = caseGReferrable(errorModelPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ERROR_MODEL_TYPE:
      {
        ErrorModelType errorModelType = (ErrorModelType)theEObject;
        T result = caseErrorModelType(errorModelType);
        if (result == null) result = caseTraceableSpecification(errorModelType);
        if (result == null) result = caseEAType(errorModelType);
        if (result == null) result = caseEAPackageableElement(errorModelType);
        if (result == null) result = caseEAElement(errorModelType);
        if (result == null) result = caseGEAPackageableElement(errorModelType);
        if (result == null) result = caseIdentifiable(errorModelType);
        if (result == null) result = caseReferrable(errorModelType);
        if (result == null) result = caseGIdentifiable(errorModelType);
        if (result == null) result = caseGReferrable(errorModelType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAILURE_OUT_PORT:
      {
        FailureOutPort failureOutPort = (FailureOutPort)theEObject;
        T result = caseFailureOutPort(failureOutPort);
        if (result == null) result = caseFaultFailurePort(failureOutPort);
        if (result == null) result = caseAnomaly(failureOutPort);
        if (result == null) result = caseEAPort(failureOutPort);
        if (result == null) result = caseEAElement(failureOutPort);
        if (result == null) result = caseIdentifiable(failureOutPort);
        if (result == null) result = caseReferrable(failureOutPort);
        if (result == null) result = caseGIdentifiable(failureOutPort);
        if (result == null) result = caseGReferrable(failureOutPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_PORT:
      {
        FaultFailurePort faultFailurePort = (FaultFailurePort)theEObject;
        T result = caseFaultFailurePort(faultFailurePort);
        if (result == null) result = caseAnomaly(faultFailurePort);
        if (result == null) result = caseEAPort(faultFailurePort);
        if (result == null) result = caseEAElement(faultFailurePort);
        if (result == null) result = caseIdentifiable(faultFailurePort);
        if (result == null) result = caseReferrable(faultFailurePort);
        if (result == null) result = caseGIdentifiable(faultFailurePort);
        if (result == null) result = caseGReferrable(faultFailurePort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK:
      {
        FaultFailurePropagationLink faultFailurePropagationLink = (FaultFailurePropagationLink)theEObject;
        T result = caseFaultFailurePropagationLink(faultFailurePropagationLink);
        if (result == null) result = caseEAElement(faultFailurePropagationLink);
        if (result == null) result = caseEAConnector(faultFailurePropagationLink);
        if (result == null) result = caseIdentifiable(faultFailurePropagationLink);
        if (result == null) result = caseReferrable(faultFailurePropagationLink);
        if (result == null) result = caseGIdentifiable(faultFailurePropagationLink);
        if (result == null) result = caseGReferrable(faultFailurePropagationLink);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_IN_PORT:
      {
        FaultInPort faultInPort = (FaultInPort)theEObject;
        T result = caseFaultInPort(faultInPort);
        if (result == null) result = caseFaultFailurePort(faultInPort);
        if (result == null) result = caseAnomaly(faultInPort);
        if (result == null) result = caseEAPort(faultInPort);
        if (result == null) result = caseEAElement(faultInPort);
        if (result == null) result = caseIdentifiable(faultInPort);
        if (result == null) result = caseReferrable(faultInPort);
        if (result == null) result = caseGIdentifiable(faultInPort);
        if (result == null) result = caseGReferrable(faultInPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.INTERNAL_FAULT_PROTOTYPE:
      {
        InternalFaultPrototype internalFaultPrototype = (InternalFaultPrototype)theEObject;
        T result = caseInternalFaultPrototype(internalFaultPrototype);
        if (result == null) result = caseAnomaly(internalFaultPrototype);
        if (result == null) result = caseEAElement(internalFaultPrototype);
        if (result == null) result = caseIdentifiable(internalFaultPrototype);
        if (result == null) result = caseReferrable(internalFaultPrototype);
        if (result == null) result = caseGIdentifiable(internalFaultPrototype);
        if (result == null) result = caseGReferrable(internalFaultPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PROCESS_FAULT_PROTOTYPE:
      {
        ProcessFaultPrototype processFaultPrototype = (ProcessFaultPrototype)theEObject;
        T result = caseProcessFaultPrototype(processFaultPrototype);
        if (result == null) result = caseAnomaly(processFaultPrototype);
        if (result == null) result = caseEAElement(processFaultPrototype);
        if (result == null) result = caseIdentifiable(processFaultPrototype);
        if (result == null) result = caseReferrable(processFaultPrototype);
        if (result == null) result = caseGIdentifiable(processFaultPrototype);
        if (result == null) result = caseGReferrable(processFaultPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE_FUNCTION_TARGET:
      {
        ErrorModelPrototype_functionTarget errorModelPrototype_functionTarget = (ErrorModelPrototype_functionTarget)theEObject;
        T result = caseErrorModelPrototype_functionTarget(errorModelPrototype_functionTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ERROR_MODEL_PROTOTYPE_HW_TARGET:
      {
        ErrorModelPrototype_hwTarget errorModelPrototype_hwTarget = (ErrorModelPrototype_hwTarget)theEObject;
        T result = caseErrorModelPrototype_hwTarget(errorModelPrototype_hwTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_PORT_FUNCTION_TARGET:
      {
        FaultFailurePort_functionTarget faultFailurePort_functionTarget = (FaultFailurePort_functionTarget)theEObject;
        T result = caseFaultFailurePort_functionTarget(faultFailurePort_functionTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_PORT_HW_TARGET:
      {
        FaultFailurePort_hwTarget faultFailurePort_hwTarget = (FaultFailurePort_hwTarget)theEObject;
        T result = caseFaultFailurePort_hwTarget(faultFailurePort_hwTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT:
      {
        FaultFailurePropagationLink_fromPort faultFailurePropagationLink_fromPort = (FaultFailurePropagationLink_fromPort)theEObject;
        T result = caseFaultFailurePropagationLink_fromPort(faultFailurePropagationLink_fromPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FAULT_FAILURE_PROPAGATION_LINK_TO_PORT:
      {
        FaultFailurePropagationLink_toPort faultFailurePropagationLink_toPort = (FaultFailurePropagationLink_toPort)theEObject;
        T result = caseFaultFailurePropagationLink_toPort(faultFailurePropagationLink_toPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.FUNCTIONAL_SAFETY_CONCEPT:
      {
        FunctionalSafetyConcept functionalSafetyConcept = (FunctionalSafetyConcept)theEObject;
        T result = caseFunctionalSafetyConcept(functionalSafetyConcept);
        if (result == null) result = caseRequirementsHierarchy(functionalSafetyConcept);
        if (result == null) result = caseTraceableSpecification(functionalSafetyConcept);
        if (result == null) result = caseEAPackageableElement(functionalSafetyConcept);
        if (result == null) result = caseEAElement(functionalSafetyConcept);
        if (result == null) result = caseGEAPackageableElement(functionalSafetyConcept);
        if (result == null) result = caseIdentifiable(functionalSafetyConcept);
        if (result == null) result = caseReferrable(functionalSafetyConcept);
        if (result == null) result = caseGIdentifiable(functionalSafetyConcept);
        if (result == null) result = caseGReferrable(functionalSafetyConcept);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SAFETY_GOAL:
      {
        SafetyGoal safetyGoal = (SafetyGoal)theEObject;
        T result = caseSafetyGoal(safetyGoal);
        if (result == null) result = caseEAElement(safetyGoal);
        if (result == null) result = caseIdentifiable(safetyGoal);
        if (result == null) result = caseReferrable(safetyGoal);
        if (result == null) result = caseGIdentifiable(safetyGoal);
        if (result == null) result = caseGReferrable(safetyGoal);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TECHNICAL_SAFETY_CONCEPT:
      {
        TechnicalSafetyConcept technicalSafetyConcept = (TechnicalSafetyConcept)theEObject;
        T result = caseTechnicalSafetyConcept(technicalSafetyConcept);
        if (result == null) result = caseRequirementsHierarchy(technicalSafetyConcept);
        if (result == null) result = caseTraceableSpecification(technicalSafetyConcept);
        if (result == null) result = caseEAPackageableElement(technicalSafetyConcept);
        if (result == null) result = caseEAElement(technicalSafetyConcept);
        if (result == null) result = caseGEAPackageableElement(technicalSafetyConcept);
        if (result == null) result = caseIdentifiable(technicalSafetyConcept);
        if (result == null) result = caseReferrable(technicalSafetyConcept);
        if (result == null) result = caseGIdentifiable(technicalSafetyConcept);
        if (result == null) result = caseGReferrable(technicalSafetyConcept);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CLAIM:
      {
        Claim claim = (Claim)theEObject;
        T result = caseClaim(claim);
        if (result == null) result = caseTraceableSpecification(claim);
        if (result == null) result = caseEAPackageableElement(claim);
        if (result == null) result = caseEAElement(claim);
        if (result == null) result = caseGEAPackageableElement(claim);
        if (result == null) result = caseIdentifiable(claim);
        if (result == null) result = caseReferrable(claim);
        if (result == null) result = caseGIdentifiable(claim);
        if (result == null) result = caseGReferrable(claim);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.GROUND:
      {
        Ground ground = (Ground)theEObject;
        T result = caseGround(ground);
        if (result == null) result = caseTraceableSpecification(ground);
        if (result == null) result = caseEAPackageableElement(ground);
        if (result == null) result = caseEAElement(ground);
        if (result == null) result = caseGEAPackageableElement(ground);
        if (result == null) result = caseIdentifiable(ground);
        if (result == null) result = caseReferrable(ground);
        if (result == null) result = caseGIdentifiable(ground);
        if (result == null) result = caseGReferrable(ground);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SAFETY_CASE:
      {
        SafetyCase safetyCase = (SafetyCase)theEObject;
        T result = caseSafetyCase(safetyCase);
        if (result == null) result = caseTraceableSpecification(safetyCase);
        if (result == null) result = caseEAPackageableElement(safetyCase);
        if (result == null) result = caseEAElement(safetyCase);
        if (result == null) result = caseGEAPackageableElement(safetyCase);
        if (result == null) result = caseIdentifiable(safetyCase);
        if (result == null) result = caseReferrable(safetyCase);
        if (result == null) result = caseGIdentifiable(safetyCase);
        if (result == null) result = caseGReferrable(safetyCase);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.WARRANT:
      {
        Warrant warrant = (Warrant)theEObject;
        T result = caseWarrant(warrant);
        if (result == null) result = caseTraceableSpecification(warrant);
        if (result == null) result = caseEAPackageableElement(warrant);
        if (result == null) result = caseEAElement(warrant);
        if (result == null) result = caseGEAPackageableElement(warrant);
        if (result == null) result = caseIdentifiable(warrant);
        if (result == null) result = caseReferrable(warrant);
        if (result == null) result = caseGIdentifiable(warrant);
        if (result == null) result = caseGReferrable(warrant);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.GENERIC_CONSTRAINT:
      {
        GenericConstraint genericConstraint = (GenericConstraint)theEObject;
        T result = caseGenericConstraint(genericConstraint);
        if (result == null) result = caseTraceableSpecification(genericConstraint);
        if (result == null) result = caseEAPackageableElement(genericConstraint);
        if (result == null) result = caseEAElement(genericConstraint);
        if (result == null) result = caseGEAPackageableElement(genericConstraint);
        if (result == null) result = caseIdentifiable(genericConstraint);
        if (result == null) result = caseReferrable(genericConstraint);
        if (result == null) result = caseGIdentifiable(genericConstraint);
        if (result == null) result = caseGReferrable(genericConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.GENERIC_CONSTRAINT_SET:
      {
        GenericConstraintSet genericConstraintSet = (GenericConstraintSet)theEObject;
        T result = caseGenericConstraintSet(genericConstraintSet);
        if (result == null) result = caseContext(genericConstraintSet);
        if (result == null) result = caseEAPackageableElement(genericConstraintSet);
        if (result == null) result = caseEAElement(genericConstraintSet);
        if (result == null) result = caseGEAPackageableElement(genericConstraintSet);
        if (result == null) result = caseIdentifiable(genericConstraintSet);
        if (result == null) result = caseReferrable(genericConstraintSet);
        if (result == null) result = caseGIdentifiable(genericConstraintSet);
        if (result == null) result = caseGReferrable(genericConstraintSet);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TAKE_RATE_CONSTRAINT:
      {
        TakeRateConstraint takeRateConstraint = (TakeRateConstraint)theEObject;
        T result = caseTakeRateConstraint(takeRateConstraint);
        if (result == null) result = caseGenericConstraint(takeRateConstraint);
        if (result == null) result = caseTraceableSpecification(takeRateConstraint);
        if (result == null) result = caseEAPackageableElement(takeRateConstraint);
        if (result == null) result = caseEAElement(takeRateConstraint);
        if (result == null) result = caseGEAPackageableElement(takeRateConstraint);
        if (result == null) result = caseIdentifiable(takeRateConstraint);
        if (result == null) result = caseReferrable(takeRateConstraint);
        if (result == null) result = caseGIdentifiable(takeRateConstraint);
        if (result == null) result = caseGReferrable(takeRateConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.COMMENT:
      {
        Comment comment = (Comment)theEObject;
        T result = caseComment(comment);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONTEXT:
      {
        Context context = (Context)theEObject;
        T result = caseContext(context);
        if (result == null) result = caseEAPackageableElement(context);
        if (result == null) result = caseEAElement(context);
        if (result == null) result = caseGEAPackageableElement(context);
        if (result == null) result = caseIdentifiable(context);
        if (result == null) result = caseReferrable(context);
        if (result == null) result = caseGIdentifiable(context);
        if (result == null) result = caseGReferrable(context);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_CONNECTOR:
      {
        EAConnector eaConnector = (EAConnector)theEObject;
        T result = caseEAConnector(eaConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_ELEMENT:
      {
        EAElement eaElement = (EAElement)theEObject;
        T result = caseEAElement(eaElement);
        if (result == null) result = caseIdentifiable(eaElement);
        if (result == null) result = caseReferrable(eaElement);
        if (result == null) result = caseGIdentifiable(eaElement);
        if (result == null) result = caseGReferrable(eaElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_PACKAGE:
      {
        EAPackage eaPackage = (EAPackage)theEObject;
        T result = caseEAPackage(eaPackage);
        if (result == null) result = caseEAElement(eaPackage);
        if (result == null) result = caseGEAPackage(eaPackage);
        if (result == null) result = caseIdentifiable(eaPackage);
        if (result == null) result = caseReferrable(eaPackage);
        if (result == null) result = caseGIdentifiable(eaPackage);
        if (result == null) result = caseGReferrable(eaPackage);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_PACKAGEABLE_ELEMENT:
      {
        EAPackageableElement eaPackageableElement = (EAPackageableElement)theEObject;
        T result = caseEAPackageableElement(eaPackageableElement);
        if (result == null) result = caseEAElement(eaPackageableElement);
        if (result == null) result = caseGEAPackageableElement(eaPackageableElement);
        if (result == null) result = caseIdentifiable(eaPackageableElement);
        if (result == null) result = caseReferrable(eaPackageableElement);
        if (result == null) result = caseGIdentifiable(eaPackageableElement);
        if (result == null) result = caseGReferrable(eaPackageableElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_PORT:
      {
        EAPort eaPort = (EAPort)theEObject;
        T result = caseEAPort(eaPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_PROTOTYPE:
      {
        EAPrototype eaPrototype = (EAPrototype)theEObject;
        T result = caseEAPrototype(eaPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_TYPE:
      {
        EAType eaType = (EAType)theEObject;
        T result = caseEAType(eaType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EAXML:
      {
        EAXML eaxml = (EAXML)theEObject;
        T result = caseEAXML(eaxml);
        if (result == null) result = caseGEAXML(eaxml);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.RATIONALE:
      {
        Rationale rationale = (Rationale)theEObject;
        T result = caseRationale(rationale);
        if (result == null) result = caseComment(rationale);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REALIZATION:
      {
        Realization realization = (Realization)theEObject;
        T result = caseRealization(realization);
        if (result == null) result = caseRelationship(realization);
        if (result == null) result = caseEAElement(realization);
        if (result == null) result = caseIdentifiable(realization);
        if (result == null) result = caseReferrable(realization);
        if (result == null) result = caseGIdentifiable(realization);
        if (result == null) result = caseGReferrable(realization);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REFERRABLE:
      {
        Referrable referrable = (Referrable)theEObject;
        T result = caseReferrable(referrable);
        if (result == null) result = caseGReferrable(referrable);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.RELATIONSHIP:
      {
        Relationship relationship = (Relationship)theEObject;
        T result = caseRelationship(relationship);
        if (result == null) result = caseEAElement(relationship);
        if (result == null) result = caseIdentifiable(relationship);
        if (result == null) result = caseReferrable(relationship);
        if (result == null) result = caseGIdentifiable(relationship);
        if (result == null) result = caseGReferrable(relationship);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TRACEABLE_SPECIFICATION:
      {
        TraceableSpecification traceableSpecification = (TraceableSpecification)theEObject;
        T result = caseTraceableSpecification(traceableSpecification);
        if (result == null) result = caseEAPackageableElement(traceableSpecification);
        if (result == null) result = caseEAElement(traceableSpecification);
        if (result == null) result = caseGEAPackageableElement(traceableSpecification);
        if (result == null) result = caseIdentifiable(traceableSpecification);
        if (result == null) result = caseReferrable(traceableSpecification);
        if (result == null) result = caseGIdentifiable(traceableSpecification);
        if (result == null) result = caseGReferrable(traceableSpecification);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.IDENTIFIABLE:
      {
        Identifiable identifiable = (Identifiable)theEObject;
        T result = caseIdentifiable(identifiable);
        if (result == null) result = caseReferrable(identifiable);
        if (result == null) result = caseGIdentifiable(identifiable);
        if (result == null) result = caseGReferrable(identifiable);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REALIZATION_REALIZED:
      {
        Realization_realized realization_realized = (Realization_realized)theEObject;
        T result = caseRealization_realized(realization_realized);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.REALIZATION_REALIZED_BY:
      {
        Realization_realizedBy realization_realizedBy = (Realization_realizedBy)theEObject;
        T result = caseRealization_realizedBy(realization_realizedBy);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ARRAY_DATATYPE:
      {
        ArrayDatatype arrayDatatype = (ArrayDatatype)theEObject;
        T result = caseArrayDatatype(arrayDatatype);
        if (result == null) result = caseEADatatype(arrayDatatype);
        if (result == null) result = caseTraceableSpecification(arrayDatatype);
        if (result == null) result = caseEAPackageableElement(arrayDatatype);
        if (result == null) result = caseEAElement(arrayDatatype);
        if (result == null) result = caseGEAPackageableElement(arrayDatatype);
        if (result == null) result = caseIdentifiable(arrayDatatype);
        if (result == null) result = caseReferrable(arrayDatatype);
        if (result == null) result = caseGIdentifiable(arrayDatatype);
        if (result == null) result = caseGReferrable(arrayDatatype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.COMPOSITE_DATATYPE:
      {
        CompositeDatatype compositeDatatype = (CompositeDatatype)theEObject;
        T result = caseCompositeDatatype(compositeDatatype);
        if (result == null) result = caseEADatatype(compositeDatatype);
        if (result == null) result = caseTraceableSpecification(compositeDatatype);
        if (result == null) result = caseEAPackageableElement(compositeDatatype);
        if (result == null) result = caseEAElement(compositeDatatype);
        if (result == null) result = caseGEAPackageableElement(compositeDatatype);
        if (result == null) result = caseIdentifiable(compositeDatatype);
        if (result == null) result = caseReferrable(compositeDatatype);
        if (result == null) result = caseGIdentifiable(compositeDatatype);
        if (result == null) result = caseGReferrable(compositeDatatype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_BOOLEAN:
      {
        EABoolean eaBoolean = (EABoolean)theEObject;
        T result = caseEABoolean(eaBoolean);
        if (result == null) result = caseEADatatype(eaBoolean);
        if (result == null) result = caseTraceableSpecification(eaBoolean);
        if (result == null) result = caseEAPackageableElement(eaBoolean);
        if (result == null) result = caseEAElement(eaBoolean);
        if (result == null) result = caseGEAPackageableElement(eaBoolean);
        if (result == null) result = caseIdentifiable(eaBoolean);
        if (result == null) result = caseReferrable(eaBoolean);
        if (result == null) result = caseGIdentifiable(eaBoolean);
        if (result == null) result = caseGReferrable(eaBoolean);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_DATATYPE:
      {
        EADatatype eaDatatype = (EADatatype)theEObject;
        T result = caseEADatatype(eaDatatype);
        if (result == null) result = caseTraceableSpecification(eaDatatype);
        if (result == null) result = caseEAPackageableElement(eaDatatype);
        if (result == null) result = caseEAElement(eaDatatype);
        if (result == null) result = caseGEAPackageableElement(eaDatatype);
        if (result == null) result = caseIdentifiable(eaDatatype);
        if (result == null) result = caseReferrable(eaDatatype);
        if (result == null) result = caseGIdentifiable(eaDatatype);
        if (result == null) result = caseGReferrable(eaDatatype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_DATATYPE_PROTOTYPE:
      {
        EADatatypePrototype eaDatatypePrototype = (EADatatypePrototype)theEObject;
        T result = caseEADatatypePrototype(eaDatatypePrototype);
        if (result == null) result = caseEAElement(eaDatatypePrototype);
        if (result == null) result = caseIdentifiable(eaDatatypePrototype);
        if (result == null) result = caseReferrable(eaDatatypePrototype);
        if (result == null) result = caseGIdentifiable(eaDatatypePrototype);
        if (result == null) result = caseGReferrable(eaDatatypePrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_NUMERICAL:
      {
        EANumerical eaNumerical = (EANumerical)theEObject;
        T result = caseEANumerical(eaNumerical);
        if (result == null) result = caseEADatatype(eaNumerical);
        if (result == null) result = caseTraceableSpecification(eaNumerical);
        if (result == null) result = caseEAPackageableElement(eaNumerical);
        if (result == null) result = caseEAElement(eaNumerical);
        if (result == null) result = caseGEAPackageableElement(eaNumerical);
        if (result == null) result = caseIdentifiable(eaNumerical);
        if (result == null) result = caseReferrable(eaNumerical);
        if (result == null) result = caseGIdentifiable(eaNumerical);
        if (result == null) result = caseGReferrable(eaNumerical);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_STRING:
      {
        EAString eaString = (EAString)theEObject;
        T result = caseEAString(eaString);
        if (result == null) result = caseEADatatype(eaString);
        if (result == null) result = caseTraceableSpecification(eaString);
        if (result == null) result = caseEAPackageableElement(eaString);
        if (result == null) result = caseEAElement(eaString);
        if (result == null) result = caseGEAPackageableElement(eaString);
        if (result == null) result = caseIdentifiable(eaString);
        if (result == null) result = caseReferrable(eaString);
        if (result == null) result = caseGIdentifiable(eaString);
        if (result == null) result = caseGReferrable(eaString);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ENUMERATION:
      {
        Enumeration enumeration = (Enumeration)theEObject;
        T result = caseEnumeration(enumeration);
        if (result == null) result = caseEADatatype(enumeration);
        if (result == null) result = caseTraceableSpecification(enumeration);
        if (result == null) result = caseEAPackageableElement(enumeration);
        if (result == null) result = caseEAElement(enumeration);
        if (result == null) result = caseGEAPackageableElement(enumeration);
        if (result == null) result = caseIdentifiable(enumeration);
        if (result == null) result = caseReferrable(enumeration);
        if (result == null) result = caseGIdentifiable(enumeration);
        if (result == null) result = caseGReferrable(enumeration);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ENUMERATION_LITERAL:
      {
        EnumerationLiteral enumerationLiteral = (EnumerationLiteral)theEObject;
        T result = caseEnumerationLiteral(enumerationLiteral);
        if (result == null) result = caseEAElement(enumerationLiteral);
        if (result == null) result = caseIdentifiable(enumerationLiteral);
        if (result == null) result = caseReferrable(enumerationLiteral);
        if (result == null) result = caseGIdentifiable(enumerationLiteral);
        if (result == null) result = caseGReferrable(enumerationLiteral);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.QUANTITY:
      {
        Quantity quantity = (Quantity)theEObject;
        T result = caseQuantity(quantity);
        if (result == null) result = caseEAPackageableElement(quantity);
        if (result == null) result = caseEAElement(quantity);
        if (result == null) result = caseGEAPackageableElement(quantity);
        if (result == null) result = caseIdentifiable(quantity);
        if (result == null) result = caseReferrable(quantity);
        if (result == null) result = caseGIdentifiable(quantity);
        if (result == null) result = caseGReferrable(quantity);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.RANGEABLE_VALUE_TYPE:
      {
        RangeableValueType rangeableValueType = (RangeableValueType)theEObject;
        T result = caseRangeableValueType(rangeableValueType);
        if (result == null) result = caseEADatatype(rangeableValueType);
        if (result == null) result = caseTraceableSpecification(rangeableValueType);
        if (result == null) result = caseEAPackageableElement(rangeableValueType);
        if (result == null) result = caseEAElement(rangeableValueType);
        if (result == null) result = caseGEAPackageableElement(rangeableValueType);
        if (result == null) result = caseIdentifiable(rangeableValueType);
        if (result == null) result = caseReferrable(rangeableValueType);
        if (result == null) result = caseGIdentifiable(rangeableValueType);
        if (result == null) result = caseGReferrable(rangeableValueType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.UNIT:
      {
        Unit unit = (Unit)theEObject;
        T result = caseUnit(unit);
        if (result == null) result = caseEAPackageableElement(unit);
        if (result == null) result = caseEAElement(unit);
        if (result == null) result = caseGEAPackageableElement(unit);
        if (result == null) result = caseIdentifiable(unit);
        if (result == null) result = caseReferrable(unit);
        if (result == null) result = caseGIdentifiable(unit);
        if (result == null) result = caseGReferrable(unit);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_ARRAY_VALUE:
      {
        EAArrayValue eaArrayValue = (EAArrayValue)theEObject;
        T result = caseEAArrayValue(eaArrayValue);
        if (result == null) result = caseEAValue(eaArrayValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_BOOLEAN_VALUE:
      {
        EABooleanValue eaBooleanValue = (EABooleanValue)theEObject;
        T result = caseEABooleanValue(eaBooleanValue);
        if (result == null) result = caseEAValue(eaBooleanValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_COMPOSITE_VALUE:
      {
        EACompositeValue eaCompositeValue = (EACompositeValue)theEObject;
        T result = caseEACompositeValue(eaCompositeValue);
        if (result == null) result = caseEAValue(eaCompositeValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_ENUMERATION_VALUE:
      {
        EAEnumerationValue eaEnumerationValue = (EAEnumerationValue)theEObject;
        T result = caseEAEnumerationValue(eaEnumerationValue);
        if (result == null) result = caseEAValue(eaEnumerationValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_EXPRESSION:
      {
        EAExpression eaExpression = (EAExpression)theEObject;
        T result = caseEAExpression(eaExpression);
        if (result == null) result = caseEAValue(eaExpression);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_NUMERICAL_VALUE:
      {
        EANumericalValue eaNumericalValue = (EANumericalValue)theEObject;
        T result = caseEANumericalValue(eaNumericalValue);
        if (result == null) result = caseEAValue(eaNumericalValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_STRING_VALUE:
      {
        EAStringValue eaStringValue = (EAStringValue)theEObject;
        T result = caseEAStringValue(eaStringValue);
        if (result == null) result = caseEAValue(eaStringValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.EA_VALUE:
      {
        EAValue eaValue = (EAValue)theEObject;
        T result = caseEAValue(eaValue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.USER_ATTRIBUTE_DEFINITION:
      {
        UserAttributeDefinition userAttributeDefinition = (UserAttributeDefinition)theEObject;
        T result = caseUserAttributeDefinition(userAttributeDefinition);
        if (result == null) result = caseEAPackageableElement(userAttributeDefinition);
        if (result == null) result = caseEAElement(userAttributeDefinition);
        if (result == null) result = caseGEAPackageableElement(userAttributeDefinition);
        if (result == null) result = caseIdentifiable(userAttributeDefinition);
        if (result == null) result = caseReferrable(userAttributeDefinition);
        if (result == null) result = caseGIdentifiable(userAttributeDefinition);
        if (result == null) result = caseGReferrable(userAttributeDefinition);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.USER_ATTRIBUTED_ELEMENT:
      {
        UserAttributedElement userAttributedElement = (UserAttributedElement)theEObject;
        T result = caseUserAttributedElement(userAttributedElement);
        if (result == null) result = caseEAPackageableElement(userAttributedElement);
        if (result == null) result = caseEAElement(userAttributedElement);
        if (result == null) result = caseGEAPackageableElement(userAttributedElement);
        if (result == null) result = caseIdentifiable(userAttributedElement);
        if (result == null) result = caseReferrable(userAttributedElement);
        if (result == null) result = caseGIdentifiable(userAttributedElement);
        if (result == null) result = caseGReferrable(userAttributedElement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.USER_ELEMENT_TYPE:
      {
        UserElementType userElementType = (UserElementType)theEObject;
        T result = caseUserElementType(userElementType);
        if (result == null) result = caseEAPackageableElement(userElementType);
        if (result == null) result = caseEAElement(userElementType);
        if (result == null) result = caseGEAPackageableElement(userElementType);
        if (result == null) result = caseIdentifiable(userElementType);
        if (result == null) result = caseReferrable(userElementType);
        if (result == null) result = caseGIdentifiable(userElementType);
        if (result == null) result = caseGReferrable(userElementType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_BINDING_ATTRIBUTE:
      {
        BehaviorConstraintBindingAttribute behaviorConstraintBindingAttribute = (BehaviorConstraintBindingAttribute)theEObject;
        T result = caseBehaviorConstraintBindingAttribute(behaviorConstraintBindingAttribute);
        if (result == null) result = caseBehaviorConstraintInternalBinding(behaviorConstraintBindingAttribute);
        if (result == null) result = caseAttribute(behaviorConstraintBindingAttribute);
        if (result == null) result = caseEAElement(behaviorConstraintBindingAttribute);
        if (result == null) result = caseBehaviorConstraintParameter(behaviorConstraintBindingAttribute);
        if (result == null) result = caseIdentifiable(behaviorConstraintBindingAttribute);
        if (result == null) result = caseReferrable(behaviorConstraintBindingAttribute);
        if (result == null) result = caseGIdentifiable(behaviorConstraintBindingAttribute);
        if (result == null) result = caseGReferrable(behaviorConstraintBindingAttribute);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT:
      {
        BehaviorConstraintBindingEvent behaviorConstraintBindingEvent = (BehaviorConstraintBindingEvent)theEObject;
        T result = caseBehaviorConstraintBindingEvent(behaviorConstraintBindingEvent);
        if (result == null) result = caseTransitionEvent(behaviorConstraintBindingEvent);
        if (result == null) result = caseBehaviorConstraintInternalBinding(behaviorConstraintBindingEvent);
        if (result == null) result = caseBehaviorConstraintParameter(behaviorConstraintBindingEvent);
        if (result == null) result = caseEAElement(behaviorConstraintBindingEvent);
        if (result == null) result = caseIdentifiable(behaviorConstraintBindingEvent);
        if (result == null) result = caseReferrable(behaviorConstraintBindingEvent);
        if (result == null) result = caseGIdentifiable(behaviorConstraintBindingEvent);
        if (result == null) result = caseGReferrable(behaviorConstraintBindingEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING:
      {
        BehaviorConstraintInternalBinding behaviorConstraintInternalBinding = (BehaviorConstraintInternalBinding)theEObject;
        T result = caseBehaviorConstraintInternalBinding(behaviorConstraintInternalBinding);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PARAMETER:
      {
        BehaviorConstraintParameter behaviorConstraintParameter = (BehaviorConstraintParameter)theEObject;
        T result = caseBehaviorConstraintParameter(behaviorConstraintParameter);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE:
      {
        BehaviorConstraintPrototype behaviorConstraintPrototype = (BehaviorConstraintPrototype)theEObject;
        T result = caseBehaviorConstraintPrototype(behaviorConstraintPrototype);
        if (result == null) result = caseTraceableSpecification(behaviorConstraintPrototype);
        if (result == null) result = caseEAPackageableElement(behaviorConstraintPrototype);
        if (result == null) result = caseEAElement(behaviorConstraintPrototype);
        if (result == null) result = caseGEAPackageableElement(behaviorConstraintPrototype);
        if (result == null) result = caseIdentifiable(behaviorConstraintPrototype);
        if (result == null) result = caseReferrable(behaviorConstraintPrototype);
        if (result == null) result = caseGIdentifiable(behaviorConstraintPrototype);
        if (result == null) result = caseGReferrable(behaviorConstraintPrototype);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING:
      {
        BehaviorConstraintTargetBinding behaviorConstraintTargetBinding = (BehaviorConstraintTargetBinding)theEObject;
        T result = caseBehaviorConstraintTargetBinding(behaviorConstraintTargetBinding);
        if (result == null) result = caseRelationship(behaviorConstraintTargetBinding);
        if (result == null) result = caseEAElement(behaviorConstraintTargetBinding);
        if (result == null) result = caseIdentifiable(behaviorConstraintTargetBinding);
        if (result == null) result = caseReferrable(behaviorConstraintTargetBinding);
        if (result == null) result = caseGIdentifiable(behaviorConstraintTargetBinding);
        if (result == null) result = caseGReferrable(behaviorConstraintTargetBinding);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TYPE:
      {
        BehaviorConstraintType behaviorConstraintType = (BehaviorConstraintType)theEObject;
        T result = caseBehaviorConstraintType(behaviorConstraintType);
        if (result == null) result = caseContext(behaviorConstraintType);
        if (result == null) result = caseEAPackageableElement(behaviorConstraintType);
        if (result == null) result = caseEAElement(behaviorConstraintType);
        if (result == null) result = caseGEAPackageableElement(behaviorConstraintType);
        if (result == null) result = caseIdentifiable(behaviorConstraintType);
        if (result == null) result = caseReferrable(behaviorConstraintType);
        if (result == null) result = caseGIdentifiable(behaviorConstraintType);
        if (result == null) result = caseGReferrable(behaviorConstraintType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR:
      {
        BehaviorConstraintInternalBinding_bindingThroughFunctionConnector behaviorConstraintInternalBinding_bindingThroughFunctionConnector = (BehaviorConstraintInternalBinding_bindingThroughFunctionConnector)theEObject;
        T result = caseBehaviorConstraintInternalBinding_bindingThroughFunctionConnector(behaviorConstraintInternalBinding_bindingThroughFunctionConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_HARDWARE_CONNECTOR:
      {
        BehaviorConstraintInternalBinding_bindingThroughHardwareConnector behaviorConstraintInternalBinding_bindingThroughHardwareConnector = (BehaviorConstraintInternalBinding_bindingThroughHardwareConnector)theEObject;
        T result = caseBehaviorConstraintInternalBinding_bindingThroughHardwareConnector(behaviorConstraintInternalBinding_bindingThroughHardwareConnector);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET:
      {
        BehaviorConstraintPrototype_errorModelTarget behaviorConstraintPrototype_errorModelTarget = (BehaviorConstraintPrototype_errorModelTarget)theEObject;
        T result = caseBehaviorConstraintPrototype_errorModelTarget(behaviorConstraintPrototype_errorModelTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_FUNCTION_TARGET:
      {
        BehaviorConstraintPrototype_functionTarget behaviorConstraintPrototype_functionTarget = (BehaviorConstraintPrototype_functionTarget)theEObject;
        T result = caseBehaviorConstraintPrototype_functionTarget(behaviorConstraintPrototype_functionTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_HARDWARE_COMPONENT_TARGET:
      {
        BehaviorConstraintPrototype_hardwareComponentTarget behaviorConstraintPrototype_hardwareComponentTarget = (BehaviorConstraintPrototype_hardwareComponentTarget)theEObject;
        T result = caseBehaviorConstraintPrototype_hardwareComponentTarget(behaviorConstraintPrototype_hardwareComponentTarget);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ATTRIBUTE:
      {
        Attribute attribute = (Attribute)theEObject;
        T result = caseAttribute(attribute);
        if (result == null) result = caseEAElement(attribute);
        if (result == null) result = caseBehaviorConstraintParameter(attribute);
        if (result == null) result = caseIdentifiable(attribute);
        if (result == null) result = caseReferrable(attribute);
        if (result == null) result = caseGIdentifiable(attribute);
        if (result == null) result = caseGReferrable(attribute);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT:
      {
        AttributeQuantificationConstraint attributeQuantificationConstraint = (AttributeQuantificationConstraint)theEObject;
        T result = caseAttributeQuantificationConstraint(attributeQuantificationConstraint);
        if (result == null) result = caseEAElement(attributeQuantificationConstraint);
        if (result == null) result = caseIdentifiable(attributeQuantificationConstraint);
        if (result == null) result = caseReferrable(attributeQuantificationConstraint);
        if (result == null) result = caseGIdentifiable(attributeQuantificationConstraint);
        if (result == null) result = caseGReferrable(attributeQuantificationConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BEHAVIOR_ATTRIBUTE_BINDING:
      {
        BehaviorAttributeBinding behaviorAttributeBinding = (BehaviorAttributeBinding)theEObject;
        T result = caseBehaviorAttributeBinding(behaviorAttributeBinding);
        if (result == null) result = caseRelationship(behaviorAttributeBinding);
        if (result == null) result = caseEAElement(behaviorAttributeBinding);
        if (result == null) result = caseIdentifiable(behaviorAttributeBinding);
        if (result == null) result = caseReferrable(behaviorAttributeBinding);
        if (result == null) result = caseGIdentifiable(behaviorAttributeBinding);
        if (result == null) result = caseGReferrable(behaviorAttributeBinding);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.LOGICAL_EVENT:
      {
        LogicalEvent logicalEvent = (LogicalEvent)theEObject;
        T result = caseLogicalEvent(logicalEvent);
        if (result == null) result = caseQuantification(logicalEvent);
        if (result == null) result = caseEAElement(logicalEvent);
        if (result == null) result = caseEAExpression(logicalEvent);
        if (result == null) result = caseIdentifiable(logicalEvent);
        if (result == null) result = caseEAValue(logicalEvent);
        if (result == null) result = caseReferrable(logicalEvent);
        if (result == null) result = caseGIdentifiable(logicalEvent);
        if (result == null) result = caseGReferrable(logicalEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.QUANTIFICATION:
      {
        Quantification quantification = (Quantification)theEObject;
        T result = caseQuantification(quantification);
        if (result == null) result = caseEAElement(quantification);
        if (result == null) result = caseEAExpression(quantification);
        if (result == null) result = caseIdentifiable(quantification);
        if (result == null) result = caseEAValue(quantification);
        if (result == null) result = caseReferrable(quantification);
        if (result == null) result = caseGIdentifiable(quantification);
        if (result == null) result = caseGReferrable(quantification);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.COMPUTATION_CONSTRAINT:
      {
        ComputationConstraint computationConstraint = (ComputationConstraint)theEObject;
        T result = caseComputationConstraint(computationConstraint);
        if (result == null) result = caseEAElement(computationConstraint);
        if (result == null) result = caseIdentifiable(computationConstraint);
        if (result == null) result = caseReferrable(computationConstraint);
        if (result == null) result = caseGIdentifiable(computationConstraint);
        if (result == null) result = caseGReferrable(computationConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.LOGICAL_PATH:
      {
        LogicalPath logicalPath = (LogicalPath)theEObject;
        T result = caseLogicalPath(logicalPath);
        if (result == null) result = caseEAElement(logicalPath);
        if (result == null) result = caseIdentifiable(logicalPath);
        if (result == null) result = caseReferrable(logicalPath);
        if (result == null) result = caseGIdentifiable(logicalPath);
        if (result == null) result = caseGReferrable(logicalPath);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.LOGICAL_TRANSFORMATION:
      {
        LogicalTransformation logicalTransformation = (LogicalTransformation)theEObject;
        T result = caseLogicalTransformation(logicalTransformation);
        if (result == null) result = caseEAElement(logicalTransformation);
        if (result == null) result = caseIdentifiable(logicalTransformation);
        if (result == null) result = caseReferrable(logicalTransformation);
        if (result == null) result = caseGIdentifiable(logicalTransformation);
        if (result == null) result = caseGReferrable(logicalTransformation);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TRANSFORMATION_OCCURRENCE:
      {
        TransformationOccurrence transformationOccurrence = (TransformationOccurrence)theEObject;
        T result = caseTransformationOccurrence(transformationOccurrence);
        if (result == null) result = caseEAElement(transformationOccurrence);
        if (result == null) result = caseIdentifiable(transformationOccurrence);
        if (result == null) result = caseReferrable(transformationOccurrence);
        if (result == null) result = caseGIdentifiable(transformationOccurrence);
        if (result == null) result = caseGReferrable(transformationOccurrence);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.LOGICAL_TIME_CONDITION:
      {
        LogicalTimeCondition logicalTimeCondition = (LogicalTimeCondition)theEObject;
        T result = caseLogicalTimeCondition(logicalTimeCondition);
        if (result == null) result = caseEAElement(logicalTimeCondition);
        if (result == null) result = caseIdentifiable(logicalTimeCondition);
        if (result == null) result = caseReferrable(logicalTimeCondition);
        if (result == null) result = caseGIdentifiable(logicalTimeCondition);
        if (result == null) result = caseGReferrable(logicalTimeCondition);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.STATE:
      {
        State state = (State)theEObject;
        T result = caseState(state);
        if (result == null) result = caseEAElement(state);
        if (result == null) result = caseIdentifiable(state);
        if (result == null) result = caseReferrable(state);
        if (result == null) result = caseGIdentifiable(state);
        if (result == null) result = caseGReferrable(state);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.STATE_EVENT:
      {
        StateEvent stateEvent = (StateEvent)theEObject;
        T result = caseStateEvent(stateEvent);
        if (result == null) result = caseEvent(stateEvent);
        if (result == null) result = caseTimingDescription(stateEvent);
        if (result == null) result = caseEAElement(stateEvent);
        if (result == null) result = caseIdentifiable(stateEvent);
        if (result == null) result = caseReferrable(stateEvent);
        if (result == null) result = caseGIdentifiable(stateEvent);
        if (result == null) result = caseGReferrable(stateEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SYNCHRONOUS_TRANSITION:
      {
        SynchronousTransition synchronousTransition = (SynchronousTransition)theEObject;
        T result = caseSynchronousTransition(synchronousTransition);
        if (result == null) result = caseTransition(synchronousTransition);
        if (result == null) result = caseEAElement(synchronousTransition);
        if (result == null) result = caseIdentifiable(synchronousTransition);
        if (result == null) result = caseReferrable(synchronousTransition);
        if (result == null) result = caseGIdentifiable(synchronousTransition);
        if (result == null) result = caseGReferrable(synchronousTransition);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TEMPORAL_CONSTRAINT:
      {
        TemporalConstraint temporalConstraint = (TemporalConstraint)theEObject;
        T result = caseTemporalConstraint(temporalConstraint);
        if (result == null) result = caseEAElement(temporalConstraint);
        if (result == null) result = caseIdentifiable(temporalConstraint);
        if (result == null) result = caseReferrable(temporalConstraint);
        if (result == null) result = caseGIdentifiable(temporalConstraint);
        if (result == null) result = caseGReferrable(temporalConstraint);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TRANSITION:
      {
        Transition transition = (Transition)theEObject;
        T result = caseTransition(transition);
        if (result == null) result = caseEAElement(transition);
        if (result == null) result = caseIdentifiable(transition);
        if (result == null) result = caseReferrable(transition);
        if (result == null) result = caseGIdentifiable(transition);
        if (result == null) result = caseGReferrable(transition);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TRANSITION_EVENT:
      {
        TransitionEvent transitionEvent = (TransitionEvent)theEObject;
        T result = caseTransitionEvent(transitionEvent);
        if (result == null) result = caseBehaviorConstraintParameter(transitionEvent);
        if (result == null) result = caseEAElement(transitionEvent);
        if (result == null) result = caseIdentifiable(transitionEvent);
        if (result == null) result = caseReferrable(transitionEvent);
        if (result == null) result = caseGIdentifiable(transitionEvent);
        if (result == null) result = caseGReferrable(transitionEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ARCHITECTURAL_DESCRIPTION:
      {
        ArchitecturalDescription architecturalDescription = (ArchitecturalDescription)theEObject;
        T result = caseArchitecturalDescription(architecturalDescription);
        if (result == null) result = caseConcept(architecturalDescription);
        if (result == null) result = caseEAElement(architecturalDescription);
        if (result == null) result = caseIdentifiable(architecturalDescription);
        if (result == null) result = caseReferrable(architecturalDescription);
        if (result == null) result = caseGIdentifiable(architecturalDescription);
        if (result == null) result = caseGReferrable(architecturalDescription);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ARCHITECTURAL_MODEL:
      {
        ArchitecturalModel architecturalModel = (ArchitecturalModel)theEObject;
        T result = caseArchitecturalModel(architecturalModel);
        if (result == null) result = caseConcept(architecturalModel);
        if (result == null) result = caseEAElement(architecturalModel);
        if (result == null) result = caseIdentifiable(architecturalModel);
        if (result == null) result = caseReferrable(architecturalModel);
        if (result == null) result = caseGIdentifiable(architecturalModel);
        if (result == null) result = caseGReferrable(architecturalModel);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.ARCHITECTURE:
      {
        Architecture architecture = (Architecture)theEObject;
        T result = caseArchitecture(architecture);
        if (result == null) result = caseConcept(architecture);
        if (result == null) result = caseEAElement(architecture);
        if (result == null) result = caseIdentifiable(architecture);
        if (result == null) result = caseReferrable(architecture);
        if (result == null) result = caseGIdentifiable(architecture);
        if (result == null) result = caseGReferrable(architecture);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.CONCEPT:
      {
        Concept concept = (Concept)theEObject;
        T result = caseConcept(concept);
        if (result == null) result = caseEAElement(concept);
        if (result == null) result = caseIdentifiable(concept);
        if (result == null) result = caseReferrable(concept);
        if (result == null) result = caseGIdentifiable(concept);
        if (result == null) result = caseGReferrable(concept);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.MISSION:
      {
        Mission mission = (Mission)theEObject;
        T result = caseMission(mission);
        if (result == null) result = caseConcept(mission);
        if (result == null) result = caseEAElement(mission);
        if (result == null) result = caseIdentifiable(mission);
        if (result == null) result = caseReferrable(mission);
        if (result == null) result = caseGIdentifiable(mission);
        if (result == null) result = caseGReferrable(mission);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.VEHICLE_SYSTEM:
      {
        VehicleSystem vehicleSystem = (VehicleSystem)theEObject;
        T result = caseVehicleSystem(vehicleSystem);
        if (result == null) result = caseConcept(vehicleSystem);
        if (result == null) result = caseEAElement(vehicleSystem);
        if (result == null) result = caseIdentifiable(vehicleSystem);
        if (result == null) result = caseReferrable(vehicleSystem);
        if (result == null) result = caseGIdentifiable(vehicleSystem);
        if (result == null) result = caseGReferrable(vehicleSystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.STAKEHOLDER:
      {
        Stakeholder stakeholder = (Stakeholder)theEObject;
        T result = caseStakeholder(stakeholder);
        if (result == null) result = caseTraceableSpecification(stakeholder);
        if (result == null) result = caseEAPackageableElement(stakeholder);
        if (result == null) result = caseEAElement(stakeholder);
        if (result == null) result = caseGEAPackageableElement(stakeholder);
        if (result == null) result = caseIdentifiable(stakeholder);
        if (result == null) result = caseReferrable(stakeholder);
        if (result == null) result = caseGIdentifiable(stakeholder);
        if (result == null) result = caseGReferrable(stakeholder);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.STAKEHOLDER_NEED:
      {
        StakeholderNeed stakeholderNeed = (StakeholderNeed)theEObject;
        T result = caseStakeholderNeed(stakeholderNeed);
        if (result == null) result = caseTraceableSpecification(stakeholderNeed);
        if (result == null) result = caseEAPackageableElement(stakeholderNeed);
        if (result == null) result = caseEAElement(stakeholderNeed);
        if (result == null) result = caseGEAPackageableElement(stakeholderNeed);
        if (result == null) result = caseIdentifiable(stakeholderNeed);
        if (result == null) result = caseReferrable(stakeholderNeed);
        if (result == null) result = caseGIdentifiable(stakeholderNeed);
        if (result == null) result = caseGReferrable(stakeholderNeed);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.BUSINESS_OPPORTUNITY:
      {
        BusinessOpportunity businessOpportunity = (BusinessOpportunity)theEObject;
        T result = caseBusinessOpportunity(businessOpportunity);
        if (result == null) result = caseTraceableSpecification(businessOpportunity);
        if (result == null) result = caseEAPackageableElement(businessOpportunity);
        if (result == null) result = caseEAElement(businessOpportunity);
        if (result == null) result = caseGEAPackageableElement(businessOpportunity);
        if (result == null) result = caseIdentifiable(businessOpportunity);
        if (result == null) result = caseReferrable(businessOpportunity);
        if (result == null) result = caseGIdentifiable(businessOpportunity);
        if (result == null) result = caseGReferrable(businessOpportunity);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PROBLEM_STATEMENT:
      {
        ProblemStatement problemStatement = (ProblemStatement)theEObject;
        T result = caseProblemStatement(problemStatement);
        if (result == null) result = caseTraceableSpecification(problemStatement);
        if (result == null) result = caseEAPackageableElement(problemStatement);
        if (result == null) result = caseEAElement(problemStatement);
        if (result == null) result = caseGEAPackageableElement(problemStatement);
        if (result == null) result = caseIdentifiable(problemStatement);
        if (result == null) result = caseReferrable(problemStatement);
        if (result == null) result = caseGIdentifiable(problemStatement);
        if (result == null) result = caseGReferrable(problemStatement);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.PRODUCT_POSITIONING:
      {
        ProductPositioning productPositioning = (ProductPositioning)theEObject;
        T result = caseProductPositioning(productPositioning);
        if (result == null) result = caseTraceableSpecification(productPositioning);
        if (result == null) result = caseEAPackageableElement(productPositioning);
        if (result == null) result = caseEAElement(productPositioning);
        if (result == null) result = caseGEAPackageableElement(productPositioning);
        if (result == null) result = caseIdentifiable(productPositioning);
        if (result == null) result = caseReferrable(productPositioning);
        if (result == null) result = caseGIdentifiable(productPositioning);
        if (result == null) result = caseGReferrable(productPositioning);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.SYSTEM:
      {
        org.eclipse.eatop.eastadl21.System system = (org.eclipse.eatop.eastadl21.System)theEObject;
        T result = caseSystem(system);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case Eastadl21Package.TIMING_DESCRIPTION_EVENT:
      {
        TimingDescriptionEvent timingDescriptionEvent = (TimingDescriptionEvent)theEObject;
        T result = caseTimingDescriptionEvent(timingDescriptionEvent);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      default: return defaultCase(theEObject);
    }
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Vehicle Level</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Vehicle Level</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVehicleLevel(VehicleLevel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>System Model</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>System Model</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSystemModel(SystemModel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Analysis Level</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Analysis Level</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAnalysisLevel(AnalysisLevel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Design Level</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Design Level</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDesignLevel(DesignLevel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Implementation Level</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Implementation Level</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseImplementationLevel(ImplementationLevel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Binding Time</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Binding Time</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBindingTime(BindingTime object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeature(Feature object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureConstraint(FeatureConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Group</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Group</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureGroup(FeatureGroup object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Link</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Link</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureLink(FeatureLink object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Model</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Model</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureModel(FeatureModel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Tree Node</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Tree Node</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureTreeNode(FeatureTreeNode object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Deviation Attribute Set</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Deviation Attribute Set</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDeviationAttributeSet(DeviationAttributeSet object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Vehicle Feature</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Vehicle Feature</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVehicleFeature(VehicleFeature object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Allocateable Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Allocateable Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAllocateableElement(AllocateableElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Allocation</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Allocation</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAllocation(Allocation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Analysis Function Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Analysis Function Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAnalysisFunctionPrototype(AnalysisFunctionPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Analysis Function Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Analysis Function Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAnalysisFunctionType(AnalysisFunctionType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Basic Software Function Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Basic Software Function Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBasicSoftwareFunctionType(BasicSoftwareFunctionType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Design Function Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Design Function Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDesignFunctionPrototype(DesignFunctionPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Design Function Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Design Function Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDesignFunctionType(DesignFunctionType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Functional Device</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Functional Device</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionalDevice(FunctionalDevice object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Allocation</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Allocation</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionAllocation(FunctionAllocation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Client Server Interface</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Client Server Interface</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionClientServerInterface(FunctionClientServerInterface object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Client Server Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Client Server Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionClientServerPort(FunctionClientServerPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionConnector(FunctionConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Flow Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Flow Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionFlowPort(FunctionFlowPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionPort(FunctionPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Power Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Power Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionPowerPort(FunctionPowerPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionPrototype(FunctionPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionType(FunctionType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Function Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Function Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwareFunctionType(HardwareFunctionType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Local Device Manager</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Local Device Manager</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseLocalDeviceManager(LocalDeviceManager object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Operation</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Operation</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOperation(Operation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Port Group</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Port Group</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePortGroup(PortGroup object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Allocation allocated Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Allocation allocated Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionAllocation_allocatedElement(FunctionAllocation_allocatedElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Allocation target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Allocation target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionAllocation_target(FunctionAllocation_target object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Connector port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Connector port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionConnector_port(FunctionConnector_port object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Actuator</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Actuator</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseActuator(Actuator object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Communication Hardware Pin</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Communication Hardware Pin</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseCommunicationHardwarePin(CommunicationHardwarePin object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Electrical Component</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Electrical Component</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseElectricalComponent(ElectricalComponent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Component Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Component Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwareComponentPrototype(HardwareComponentPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Component Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Component Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwareComponentType(HardwareComponentType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwareConnector(HardwareConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Pin</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Pin</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwarePin(HardwarePin object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwarePort(HardwarePort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Port Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Port Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwarePortConnector(HardwarePortConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>IO Hardware Pin</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>IO Hardware Pin</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIOHardwarePin(IOHardwarePin object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Node</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Node</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseNode(Node object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Power Hardware Pin</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Power Hardware Pin</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePowerHardwarePin(PowerHardwarePin object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Sensor</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Sensor</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSensor(Sensor object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Allocation Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Allocation Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAllocationTarget(AllocationTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Connector port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Connector port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwareConnector_port(HardwareConnector_port object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware Port Connector port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware Port Connector port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardwarePortConnector_port(HardwarePortConnector_port object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Clamp Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Clamp Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseClampConnector(ClampConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Environment</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Environment</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEnvironment(Environment object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Clamp Connector port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Clamp Connector port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseClampConnector_port(ClampConnector_port object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehavior(Behavior object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Mode</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Mode</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseMode(Mode object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Mode Group</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Mode Group</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseModeGroup(ModeGroup object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Behavior</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Behavior</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionBehavior(FunctionBehavior object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Function Trigger</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Function Trigger</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionTrigger(FunctionTrigger object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Configurable Container</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Configurable Container</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigurableContainer(ConfigurableContainer object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Configuration Decision</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Configuration Decision</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigurationDecision(ConfigurationDecision object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Configuration Decision Folder</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Configuration Decision Folder</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigurationDecisionFolder(ConfigurationDecisionFolder object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Configuration Decision Model</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Configuration Decision Model</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigurationDecisionModel(ConfigurationDecisionModel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Configuration Decision Model Entry</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Configuration Decision Model Entry</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigurationDecisionModelEntry(ConfigurationDecisionModelEntry object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Container Configuration</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Container Configuration</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseContainerConfiguration(ContainerConfiguration object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Configuration</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Configuration</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureConfiguration(FeatureConfiguration object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Internal Binding</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Internal Binding</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInternalBinding(InternalBinding object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Private Content</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Private Content</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePrivateContent(PrivateContent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Reuse Meta Information</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Reuse Meta Information</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseReuseMetaInformation(ReuseMetaInformation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Selection Criterion</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Selection Criterion</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSelectionCriterion(SelectionCriterion object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Variability</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Variability</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVariability(Variability object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Variable Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Variable Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVariableElement(VariableElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Variation Group</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Variation Group</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVariationGroup(VariationGroup object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Vehicle Level Binding</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Vehicle Level Binding</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVehicleLevelBinding(VehicleLevelBinding object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Derive Requirement</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Derive Requirement</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDeriveRequirement(DeriveRequirement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Operational Situation</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Operational Situation</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOperationalSituation(OperationalSituation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Requirements Model</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Requirements Model</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRequirementsModel(RequirementsModel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Requirements Relationship</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Requirements Relationship</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRequirementsRelationship(RequirementsRelationship object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Requirement</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Requirement</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRequirement(Requirement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Requirements Hierarchy</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Requirements Hierarchy</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRequirementsHierarchy(RequirementsHierarchy object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Refine</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Refine</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRefine(Refine object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Satisfy</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Satisfy</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSatisfy(Satisfy object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Requirements Link</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Requirements Link</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRequirementsLink(RequirementsLink object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Requirements Relationship Group</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Requirements Relationship Group</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRequirementsRelationshipGroup(RequirementsRelationshipGroup object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Quality Requirement</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Quality Requirement</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseQualityRequirement(QualityRequirement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Refine refined By</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Refine refined By</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRefine_refinedBy(Refine_refinedBy object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Satisfy satisfied By</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Satisfy satisfied By</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSatisfy_satisfiedBy(Satisfy_satisfiedBy object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Actor</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Actor</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseActor(Actor object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Extend</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Extend</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseExtend(Extend object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Extension Point</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Extension Point</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseExtensionPoint(ExtensionPoint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Include</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Include</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInclude(Include object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Redefinable Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Redefinable Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRedefinableElement(RedefinableElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Use Case</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Use Case</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUseCase(UseCase object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Verification Validation</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Verification Validation</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVerificationValidation(VerificationValidation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Verify</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Verify</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVerify(Verify object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Actual Outcome</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Actual Outcome</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVActualOutcome(VVActualOutcome object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Case</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Case</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVCase(VVCase object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Intended Outcome</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Intended Outcome</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVIntendedOutcome(VVIntendedOutcome object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Log</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Log</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVLog(VVLog object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Procedure</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Procedure</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVProcedure(VVProcedure object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Stimuli</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Stimuli</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVStimuli(VVStimuli object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVTarget(VVTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Case vv Subject</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Case vv Subject</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVCase_vvSubject(VVCase_vvSubject object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>VV Target element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>VV Target element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVVTarget_element(VVTarget_element object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEvent(Event object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Chain</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Chain</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventChain(EventChain object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Precedence Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Precedence Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePrecedenceConstraint(PrecedenceConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Timing</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Timing</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTiming(Timing object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Timing Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Timing Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTimingConstraint(TimingConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Timing Description</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Timing Description</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTimingDescription(TimingDescription object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Timing Expression</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Timing Expression</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTimingExpression(TimingExpression object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>AUTOSAR Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>AUTOSAR Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAUTOSAREvent(AUTOSAREvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Fault Failure</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Fault Failure</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFaultFailure(EventFaultFailure object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Feature Flaw</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Feature Flaw</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFeatureFlaw(EventFeatureFlaw object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Function</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Function</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFunction(EventFunction object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Function Client Server Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Function Client Server Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFunctionClientServerPort(EventFunctionClientServerPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Function Flow Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Function Flow Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFunctionFlowPort(EventFunctionFlowPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>External Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>External Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseExternalEvent(ExternalEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Mode Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Mode Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseModeEvent(ModeEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Function function</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Function function</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFunction_function(EventFunction_function object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Function Client Server Port port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Function Client Server Port port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFunctionClientServerPort_port(EventFunctionClientServerPort_port object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Event Function Flow Port port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Event Function Flow Port port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEventFunctionFlowPort_port(EventFunctionFlowPort_port object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Age Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Age Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAgeConstraint(AgeConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Arbitrary Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Arbitrary Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseArbitraryConstraint(ArbitraryConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Burst Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Burst Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBurstConstraint(BurstConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Comparison Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Comparison Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseComparisonConstraint(ComparisonConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Delay Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Delay Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDelayConstraint(DelayConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Execution Time Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Execution Time Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseExecutionTimeConstraint(ExecutionTimeConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Synchronization Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Synchronization Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputSynchronizationConstraint(InputSynchronizationConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Order Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Order Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOrderConstraint(OrderConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Synchronization Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Synchronization Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputSynchronizationConstraint(OutputSynchronizationConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Pattern Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Pattern Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePatternConstraint(PatternConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Periodic Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Periodic Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePeriodicConstraint(PeriodicConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Reaction Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Reaction Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseReactionConstraint(ReactionConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Repetition Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Repetition Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRepetitionConstraint(RepetitionConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Sporadic Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Sporadic Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSporadicConstraint(SporadicConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Strong Delay Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Strong Delay Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStrongDelayConstraint(StrongDelayConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Strong Synchronization Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Strong Synchronization Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStrongSynchronizationConstraint(StrongSynchronizationConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Synchronization Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Synchronization Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSynchronizationConstraint(SynchronizationConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Precedence Constraint preceding</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Precedence Constraint preceding</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePrecedenceConstraint_preceding(PrecedenceConstraint_preceding object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Precedence Constraint successive</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Precedence Constraint successive</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePrecedenceConstraint_successive(PrecedenceConstraint_successive object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Dependability</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Dependability</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDependability(Dependability object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Feature Flaw</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Feature Flaw</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFeatureFlaw(FeatureFlaw object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hazard</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hazard</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHazard(Hazard object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hazardous Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hazardous Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHazardousEvent(HazardousEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Item</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Item</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseItem(Item object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailure(FaultFailure object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Quantitative Safety Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Quantitative Safety Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseQuantitativeSafetyConstraint(QuantitativeSafetyConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Safety Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Safety Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSafetyConstraint(SafetyConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure anomaly</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure anomaly</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailure_anomaly(FaultFailure_anomaly object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Anomaly</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Anomaly</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAnomaly(Anomaly object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Error Behavior</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Error Behavior</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseErrorBehavior(ErrorBehavior object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Error Model Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Error Model Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseErrorModelPrototype(ErrorModelPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Error Model Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Error Model Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseErrorModelType(ErrorModelType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Failure Out Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Failure Out Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFailureOutPort(FailureOutPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailurePort(FaultFailurePort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure Propagation Link</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure Propagation Link</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailurePropagationLink(FaultFailurePropagationLink object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault In Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault In Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultInPort(FaultInPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Internal Fault Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Internal Fault Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInternalFaultPrototype(InternalFaultPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Process Fault Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Process Fault Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseProcessFaultPrototype(ProcessFaultPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Error Model Prototype function Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Error Model Prototype function Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseErrorModelPrototype_functionTarget(ErrorModelPrototype_functionTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Error Model Prototype hw Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Error Model Prototype hw Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseErrorModelPrototype_hwTarget(ErrorModelPrototype_hwTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure Port function Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure Port function Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailurePort_functionTarget(FaultFailurePort_functionTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure Port hw Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure Port hw Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailurePort_hwTarget(FaultFailurePort_hwTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure Propagation Link from Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure Propagation Link from Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailurePropagationLink_fromPort(FaultFailurePropagationLink_fromPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fault Failure Propagation Link to Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fault Failure Propagation Link to Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFaultFailurePropagationLink_toPort(FaultFailurePropagationLink_toPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Functional Safety Concept</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Functional Safety Concept</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFunctionalSafetyConcept(FunctionalSafetyConcept object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Safety Goal</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Safety Goal</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSafetyGoal(SafetyGoal object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Technical Safety Concept</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Technical Safety Concept</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTechnicalSafetyConcept(TechnicalSafetyConcept object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Claim</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Claim</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseClaim(Claim object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Ground</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Ground</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGround(Ground object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Safety Case</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Safety Case</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSafetyCase(SafetyCase object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Warrant</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Warrant</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseWarrant(Warrant object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Generic Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Generic Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGenericConstraint(GenericConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Generic Constraint Set</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Generic Constraint Set</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGenericConstraintSet(GenericConstraintSet object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Take Rate Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Take Rate Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTakeRateConstraint(TakeRateConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Comment</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Comment</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseComment(Comment object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Context</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Context</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseContext(Context object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAConnector(EAConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAElement(EAElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Package</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Package</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAPackage(EAPackage object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Packageable Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Packageable Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAPackageableElement(EAPackageableElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAPort(EAPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAPrototype(EAPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAType(EAType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EAXML</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EAXML</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAXML(EAXML object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Rationale</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Rationale</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRationale(Rationale object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Realization</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Realization</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRealization(Realization object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Referrable</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Referrable</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseReferrable(Referrable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Relationship</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Relationship</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRelationship(Relationship object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Traceable Specification</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Traceable Specification</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTraceableSpecification(TraceableSpecification object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Identifiable</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Identifiable</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIdentifiable(Identifiable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Realization realized</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Realization realized</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRealization_realized(Realization_realized object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Realization realized By</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Realization realized By</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRealization_realizedBy(Realization_realizedBy object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Array Datatype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Array Datatype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseArrayDatatype(ArrayDatatype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Composite Datatype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Composite Datatype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseCompositeDatatype(CompositeDatatype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Boolean</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Boolean</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEABoolean(EABoolean object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Datatype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Datatype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEADatatype(EADatatype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Datatype Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Datatype Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEADatatypePrototype(EADatatypePrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Numerical</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Numerical</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEANumerical(EANumerical object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA String</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA String</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAString(EAString object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Enumeration</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Enumeration</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEnumeration(Enumeration object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Enumeration Literal</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Enumeration Literal</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEnumerationLiteral(EnumerationLiteral object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Quantity</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Quantity</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseQuantity(Quantity object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Rangeable Value Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Rangeable Value Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRangeableValueType(RangeableValueType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Unit</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Unit</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUnit(Unit object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Array Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Array Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAArrayValue(EAArrayValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Boolean Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Boolean Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEABooleanValue(EABooleanValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Composite Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Composite Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEACompositeValue(EACompositeValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Enumeration Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Enumeration Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAEnumerationValue(EAEnumerationValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Expression</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Expression</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAExpression(EAExpression object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Numerical Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Numerical Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEANumericalValue(EANumericalValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA String Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA String Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAStringValue(EAStringValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EA Value</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EA Value</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseEAValue(EAValue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>User Attribute Definition</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>User Attribute Definition</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUserAttributeDefinition(UserAttributeDefinition object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>User Attributed Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>User Attributed Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUserAttributedElement(UserAttributedElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>User Element Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>User Element Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUserElementType(UserElementType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Binding Attribute</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Binding Attribute</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintBindingAttribute(BehaviorConstraintBindingAttribute object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Binding Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Binding Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintBindingEvent(BehaviorConstraintBindingEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Internal Binding</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Internal Binding</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintInternalBinding(BehaviorConstraintInternalBinding object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Parameter</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Parameter</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintParameter(BehaviorConstraintParameter object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintPrototype(BehaviorConstraintPrototype object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Target Binding</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Target Binding</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintTargetBinding(BehaviorConstraintTargetBinding object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintType(BehaviorConstraintType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Internal Binding binding Through Function Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Internal Binding binding Through Function Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintInternalBinding_bindingThroughFunctionConnector(BehaviorConstraintInternalBinding_bindingThroughFunctionConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Internal Binding binding Through Hardware Connector</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Internal Binding binding Through Hardware Connector</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintInternalBinding_bindingThroughHardwareConnector(BehaviorConstraintInternalBinding_bindingThroughHardwareConnector object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype error Model Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype error Model Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintPrototype_errorModelTarget(BehaviorConstraintPrototype_errorModelTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype function Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype function Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintPrototype_functionTarget(BehaviorConstraintPrototype_functionTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype hardware Component Target</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Constraint Prototype hardware Component Target</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorConstraintPrototype_hardwareComponentTarget(BehaviorConstraintPrototype_hardwareComponentTarget object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Attribute</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Attribute</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAttribute(Attribute object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Attribute Quantification Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Attribute Quantification Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAttributeQuantificationConstraint(AttributeQuantificationConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Behavior Attribute Binding</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Behavior Attribute Binding</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBehaviorAttributeBinding(BehaviorAttributeBinding object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Logical Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Logical Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseLogicalEvent(LogicalEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Quantification</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Quantification</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseQuantification(Quantification object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Computation Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Computation Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseComputationConstraint(ComputationConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Logical Path</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Logical Path</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseLogicalPath(LogicalPath object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Logical Transformation</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Logical Transformation</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseLogicalTransformation(LogicalTransformation object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Transformation Occurrence</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Transformation Occurrence</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTransformationOccurrence(TransformationOccurrence object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Logical Time Condition</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Logical Time Condition</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseLogicalTimeCondition(LogicalTimeCondition object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>State</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>State</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseState(State object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>State Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>State Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStateEvent(StateEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Synchronous Transition</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Synchronous Transition</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSynchronousTransition(SynchronousTransition object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Temporal Constraint</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Temporal Constraint</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTemporalConstraint(TemporalConstraint object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Transition</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Transition</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTransition(Transition object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Transition Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Transition Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTransitionEvent(TransitionEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Architectural Description</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Architectural Description</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseArchitecturalDescription(ArchitecturalDescription object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Architectural Model</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Architectural Model</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseArchitecturalModel(ArchitecturalModel object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Architecture</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Architecture</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseArchitecture(Architecture object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Concept</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Concept</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConcept(Concept object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Mission</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Mission</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseMission(Mission object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Vehicle System</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Vehicle System</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVehicleSystem(VehicleSystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Stakeholder</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Stakeholder</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStakeholder(Stakeholder object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Stakeholder Need</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Stakeholder Need</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStakeholderNeed(StakeholderNeed object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Business Opportunity</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Business Opportunity</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBusinessOpportunity(BusinessOpportunity object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Problem Statement</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Problem Statement</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseProblemStatement(ProblemStatement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Product Positioning</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Product Positioning</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseProductPositioning(ProductPositioning object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>System</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>System</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSystem(org.eclipse.eatop.eastadl21.System object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Timing Description Event</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Timing Description Event</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTimingDescriptionEvent(TimingDescriptionEvent object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>GReferrable</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>GReferrable</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGReferrable(GReferrable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>GIdentifiable</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>GIdentifiable</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGIdentifiable(GIdentifiable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>GEA Packageable Element</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>GEA Packageable Element</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGEAPackageableElement(GEAPackageableElement object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>GEA Package</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>GEA Package</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGEAPackage(GEAPackage object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>GEAXML</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>GEAXML</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGEAXML(GEAXML object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch, but this is the last case anyway.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject)
   * @generated
   */
  public T defaultCase(EObject object)
  {
    return null;
  }

} //Eastadl21Switch
