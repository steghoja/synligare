/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.HardwarePin;
import org.eclipse.eatop.eastadl21.HardwarePort;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hardware Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortImpl#getIsShield <em>Is Shield</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortImpl#getContainedPin <em>Contained Pin</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortImpl#getContainedPort <em>Contained Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.HardwarePortImpl#getReferencedPin <em>Referenced Pin</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class HardwarePortImpl extends AllocationTargetImpl implements HardwarePort
{
  /**
   * The default value of the '{@link #getIsShield() <em>Is Shield</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsShield()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_SHIELD_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsShield() <em>Is Shield</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsShield()
   * @generated
   * @ordered
   */
  protected Boolean isShield = IS_SHIELD_EDEFAULT;

  /**
   * This is true if the Is Shield attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isShieldESet;

  /**
   * The cached value of the '{@link #getContainedPin() <em>Contained Pin</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getContainedPin()
   * @generated
   * @ordered
   */
  protected EList<HardwarePin> containedPin;

  /**
   * The cached value of the '{@link #getContainedPort() <em>Contained Port</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getContainedPort()
   * @generated
   * @ordered
   */
  protected EList<HardwarePort> containedPort;

  /**
   * The cached value of the '{@link #getReferencedPin() <em>Referenced Pin</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReferencedPin()
   * @generated
   * @ordered
   */
  protected EList<HardwarePin> referencedPin;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected HardwarePortImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getHardwarePort();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsShield()
  {
    return isShield;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsShield(Boolean newIsShield)
  {
    Boolean oldIsShield = isShield;
    isShield = newIsShield;
    boolean oldIsShieldESet = isShieldESet;
    isShieldESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.HARDWARE_PORT__IS_SHIELD, oldIsShield, isShield, !oldIsShieldESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsShield()
  {
    Boolean oldIsShield = isShield;
    boolean oldIsShieldESet = isShieldESet;
    isShield = IS_SHIELD_EDEFAULT;
    isShieldESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.HARDWARE_PORT__IS_SHIELD, oldIsShield, IS_SHIELD_EDEFAULT, oldIsShieldESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsShield()
  {
    return isShieldESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<HardwarePin> getContainedPin()
  {
    if (containedPin == null)
    {
      containedPin = new EObjectContainmentEList<HardwarePin>(HardwarePin.class, this, Eastadl21Package.HARDWARE_PORT__CONTAINED_PIN);
    }
    return containedPin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<HardwarePort> getContainedPort()
  {
    if (containedPort == null)
    {
      containedPort = new EObjectContainmentEList<HardwarePort>(HardwarePort.class, this, Eastadl21Package.HARDWARE_PORT__CONTAINED_PORT);
    }
    return containedPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<HardwarePin> getReferencedPin()
  {
    if (referencedPin == null)
    {
      referencedPin = new EObjectResolvingEList<HardwarePin>(HardwarePin.class, this, Eastadl21Package.HARDWARE_PORT__REFERENCED_PIN);
    }
    return referencedPin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PIN:
        return ((InternalEList<?>)getContainedPin()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PORT:
        return ((InternalEList<?>)getContainedPort()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT__IS_SHIELD:
        return getIsShield();
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PIN:
        return getContainedPin();
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PORT:
        return getContainedPort();
      case Eastadl21Package.HARDWARE_PORT__REFERENCED_PIN:
        return getReferencedPin();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT__IS_SHIELD:
   			setIsShield((Boolean)newValue);
        return;
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PIN:
        getContainedPin().clear();
        getContainedPin().addAll((Collection<? extends HardwarePin>)newValue);
        return;
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PORT:
        getContainedPort().clear();
        getContainedPort().addAll((Collection<? extends HardwarePort>)newValue);
        return;
      case Eastadl21Package.HARDWARE_PORT__REFERENCED_PIN:
        getReferencedPin().clear();
        getReferencedPin().addAll((Collection<? extends HardwarePin>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT__IS_SHIELD:
        unsetIsShield();
        return;
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PIN:
        getContainedPin().clear();
        return;
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PORT:
        getContainedPort().clear();
        return;
      case Eastadl21Package.HARDWARE_PORT__REFERENCED_PIN:
        getReferencedPin().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.HARDWARE_PORT__IS_SHIELD:
        return isSetIsShield();
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PIN:
        return containedPin != null && !containedPin.isEmpty();
      case Eastadl21Package.HARDWARE_PORT__CONTAINED_PORT:
        return containedPort != null && !containedPort.isEmpty();
      case Eastadl21Package.HARDWARE_PORT__REFERENCED_PIN:
        return referencedPin != null && !referencedPin.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (isShield: ");
    if (isShieldESet) result.append(isShield); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //HardwarePortImpl
