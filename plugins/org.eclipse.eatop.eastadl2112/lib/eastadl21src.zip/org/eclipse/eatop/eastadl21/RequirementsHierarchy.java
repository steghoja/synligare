/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirements Hierarchy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * RequirementsHierarchy represents a larger unit or module of specification information. It is used to bundle several Requirements which are semantically related to each other. Thus, to preserve the ordering of requirement specification objects, the order of child hierarchies is very important here.
 * 
 * The RequirementsHierarchy with its reference to Requirement is the basic element for structuring requirement information into a forest structure.
 * 
 * RequirementsHierarchy correponds to ReqIF SpecHierarchy.
 * 
 * Constraints:
 * [1] Only non-root RequirementsHierarchy which is contained in another RequirementHierarchy are allowed to reference a Requirement.
 * 
 * Semantics:
 * RequirementsHierarchy organizes Requirements in groups. The semantics of the group is user-defined.
 * 
 * Notation:
 * RequirementsHierarchy is shown as a solid-outline rectangle containing the name. Contained entities may also be shown inside (White-box view)
 * 
 * Extension: Package
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.RequirementsHierarchy</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsHierarchy#getContainedRequirement <em>Contained Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.RequirementsHierarchy#getChildHierarchy <em>Child Hierarchy</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsHierarchy()
 * @model annotation="MetaData guid='{9DFDE1B5-6B12-4b6a-AE02-F3D7EB85CB5E}' id='113' EA\040name='RequirementsHierarchy'"
 *        extendedMetaData="name='REQUIREMENTS-HIERARCHY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-HIERARCHYS'"
 * @generated
 */
public interface RequirementsHierarchy extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Contained Requirement</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Contained Requirement</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Contained Requirement</em>' reference.
   * @see #setContainedRequirement(Requirement)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsHierarchy_ContainedRequirement()
   * @model annotation="MetaData guid='{49F5AFB1-E54E-4025-A32D-D62596202AA9}' id='-325966672' EA\040name=''"
   *        extendedMetaData="name='CONTAINED-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTAINED-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Requirement getContainedRequirement();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.RequirementsHierarchy#getContainedRequirement <em>Contained Requirement</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Contained Requirement</em>' reference.
   * @see #getContainedRequirement()
   * @generated
   */
  void setContainedRequirement(Requirement value);

  /**
   * Returns the value of the '<em><b>Child Hierarchy</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.RequirementsHierarchy}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Child Hierarchy</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Child Hierarchy</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsHierarchy_ChildHierarchy()
   * @model containment="true"
   *        annotation="MetaData guid='{D36F60DF-AFF4-404f-848D-589D1E4D5E1D}' id='1251915798' EA\040name=''"
   *        extendedMetaData="name='CHILD-HIERARCHY' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CHILD-HIERARCHYS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<RequirementsHierarchy> getChildHierarchy();

} // RequirementsHierarchy
