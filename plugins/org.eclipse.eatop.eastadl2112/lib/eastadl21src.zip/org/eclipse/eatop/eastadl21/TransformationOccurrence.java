/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transformation Occurrence</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A transformation occurrence (TransformationOccurrence) denotes the activations of logical transformations due to state transitions or logical paths. A transformation occurrence can also have a time condition (timeCondition), stating the time instances when the invocation happens. If a logical transformation is invoked, its in-data will be assigned with particular values by the invocation context (inQuantification). As the consequence of transformation, the out-data will also be assigned with particular value (outQuantification).
 * 
 * Semantics:
 * A logical transformation can only occur in a state transition or a logical path. In such an occurrence, a set of logical transformations are invoked. Given some particular quantifications of in-data (inQuantification) and time conditions (timeCondition), some the particular quantifications of out-data will be satisfied after the invocation.
 * 
 * Extension: 
 * EAElement.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.ComputationConstraint.TransformationOccurrence</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransformationOccurrence#getOutQuantification <em>Out Quantification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransformationOccurrence#getTimeCondition <em>Time Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransformationOccurrence#getInQuantification <em>In Quantification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.TransformationOccurrence#getInvokedLogicalTransformation <em>Invoked Logical Transformation</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransformationOccurrence()
 * @model annotation="MetaData guid='{2968182A-7408-4377-8354-406790B530BB}' id='1115087650' EA\040name='TransformationOccurrence'"
 *        extendedMetaData="name='TRANSFORMATION-OCCURRENCE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRANSFORMATION-OCCURRENCES'"
 * @generated
 */
public interface TransformationOccurrence extends EAElement
{
  /**
   * Returns the value of the '<em><b>Out Quantification</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Quantification}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Out Quantification</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Out Quantification</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransformationOccurrence_OutQuantification()
   * @model annotation="MetaData guid='{578514CE-1E9D-4744-A3C1-3441BB1A1F73}' id='-2056874678' EA\040name=''"
   *        extendedMetaData="name='OUT-QUANTIFICATION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OUT-QUANTIFICATION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Quantification> getOutQuantification();

  /**
   * Returns the value of the '<em><b>Time Condition</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Time Condition</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Time Condition</em>' reference.
   * @see #setTimeCondition(LogicalTimeCondition)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransformationOccurrence_TimeCondition()
   * @model annotation="MetaData guid='{F4D65898-9565-4bde-A9B4-51CE1DB9D2F2}' id='-1197539343' EA\040name=''"
   *        extendedMetaData="name='TIME-CONDITION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIME-CONDITION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  LogicalTimeCondition getTimeCondition();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.TransformationOccurrence#getTimeCondition <em>Time Condition</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Time Condition</em>' reference.
   * @see #getTimeCondition()
   * @generated
   */
  void setTimeCondition(LogicalTimeCondition value);

  /**
   * Returns the value of the '<em><b>In Quantification</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Quantification}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>In Quantification</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>In Quantification</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransformationOccurrence_InQuantification()
   * @model annotation="MetaData guid='{246A9899-36F6-4e7e-B3A8-952F597E4017}' id='-544775032' EA\040name=''"
   *        extendedMetaData="name='IN-QUANTIFICATION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IN-QUANTIFICATION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Quantification> getInQuantification();

  /**
   * Returns the value of the '<em><b>Invoked Logical Transformation</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Invoked Logical Transformation</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Invoked Logical Transformation</em>' reference.
   * @see #setInvokedLogicalTransformation(LogicalTransformation)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getTransformationOccurrence_InvokedLogicalTransformation()
   * @model required="true"
   *        annotation="MetaData guid='{4202F1B8-1084-4a54-B148-D414A8D402A4}' id='756976519' EA\040name=''"
   *        extendedMetaData="name='INVOKED-LOGICAL-TRANSFORMATION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INVOKED-LOGICAL-TRANSFORMATION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  LogicalTransformation getInvokedLogicalTransformation();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.TransformationOccurrence#getInvokedLogicalTransformation <em>Invoked Logical Transformation</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Invoked Logical Transformation</em>' reference.
   * @see #getInvokedLogicalTransformation()
   * @generated
   */
  void setInvokedLogicalTransformation(LogicalTransformation value);

} // TransformationOccurrence
