/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Log</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Concrete VVCase represents the precise description of a V&amp;V effort on a concrete technical level and thus provides all necessary information to actually perform this V&amp;V effort. 
 * 
 * However, it does not represent the actual execution of the effort. 
 * 
 * This is the purpose of the VVLog. Each VVLog metaclass represents an execution of a concrete VVCase.
 * 
 * For example, if the HIL test of the wiper system with a certain set of stimuli was performed on Friday afternoon and, for checkup, again on Monday, then there will be one ConcreteVVCase describing the HIL test and two VVLogs describing the test results from Friday and Monday respectively.
 * 
 * Semantics:
 * VVLog captures an execution of a ConcreteVVCase.
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.VerificationValidation.VVLog</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVLog#getDate <em>Date</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVLog#getVvActualOutcome <em>Vv Actual Outcome</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVLog#getPerformedVVProcedure <em>Performed VV Procedure</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVLog()
 * @model annotation="MetaData guid='{6FBD9CAF-F237-4886-B347-EAC4B36CD34D}' id='152' EA\040name='VVLog'"
 *        extendedMetaData="name='VV-LOG' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-LOGS'"
 * @generated
 */
public interface VVLog extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Date</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Date and time when this log was captured.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Date</em>' attribute.
   * @see #isSetDate()
   * @see #unsetDate()
   * @see #setDate(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVLog_Date()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{D71222B8-DED1-4acf-A82A-9508F7271601}' id='127' EA\040name='date'"
   *        extendedMetaData="name='DATE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DATES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getDate();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VVLog#getDate <em>Date</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Date</em>' attribute.
   * @see #isSetDate()
   * @see #Date()
   * @see #getDate()
   * @generated
   */
  void setDate(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.VVLog#getDate <em>Date</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetDate()
   * @see #getDate()
   * @see #setDate(String)
   * @generated
   */
  void unsetDate();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.VVLog#getDate <em>Date</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Date</em>' attribute is set.
   * @see #Date()
   * @see #getDate()
   * @see #setDate(String)
   * @generated
   */
  boolean isSetDate();

  /**
   * Returns the value of the '<em><b>Vv Actual Outcome</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.VVActualOutcome}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vv Actual Outcome</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vv Actual Outcome</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVLog_VvActualOutcome()
   * @model containment="true"
   *        annotation="MetaData guid='{EA501AB0-A7FE-4370-8600-3B059CFF2C72}' id='-1613350019' EA\040name=''"
   *        extendedMetaData="name='VV-ACTUAL-OUTCOME' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-ACTUAL-OUTCOMES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<VVActualOutcome> getVvActualOutcome();

  /**
   * Returns the value of the '<em><b>Performed VV Procedure</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Performed VV Procedure</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Performed VV Procedure</em>' reference.
   * @see #setPerformedVVProcedure(VVProcedure)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVLog_PerformedVVProcedure()
   * @model required="true"
   *        annotation="MetaData guid='{4A367C1C-05F2-4763-BB7D-505F2A3E355B}' id='40' EA\040name=''"
   *        extendedMetaData="name='PERFORMED-VV-PROCEDURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PERFORMED-VV-PROCEDURE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  VVProcedure getPerformedVVProcedure();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VVLog#getPerformedVVProcedure <em>Performed VV Procedure</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Performed VV Procedure</em>' reference.
   * @see #getPerformedVVProcedure()
   * @generated
   */
  void setPerformedVVProcedure(VVProcedure value);

} // VVLog
