/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A Feature represents a characteristic or trait of some object of consideration. The actual object of consideration depends on the particular purpose of the feature's containing feature model.
 * 
 * Example 1: The core technical feature model on vehicle level defines the technical properties of the complete system, i.e., vehicle. So its object of consideration is the vehicle as a whole and therefore its features represent characteristics or traits of the vehicle as a whole.
 * 
 * Example 2: The public feature model of some function F in the FDA defines the features of this particular software function. So its object of consideration is function F and therefore its features represent characteristics or traits of this function F.
 * 
 * 
 * Semantics:
 * Feature is a (non)functional characteristic, constraint or property that can be present or not in a (vehicle) product line.
 * 
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Structure.FeatureModeling.Feature</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Feature#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Feature#getRequiredBindingTime <em>Required Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Feature#getActualBindingTime <em>Actual Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Feature#getFeatureParameter <em>Feature Parameter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Feature#getChildNode <em>Child Node</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeature()
 * @model annotation="MetaData guid='{30E1CD16-D6CF-4d0f-AA67-711A72E1628C}' id='39' EA\040name='Feature'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='FEATURE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURES'"
 * @generated
 */
public interface Feature extends FeatureTreeNode
{
  /**
   * Returns the value of the '<em><b>Cardinality</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Specifies the Feature's cardinality stating how often this feature may be selected during configuration.
   * 
   * Typical cardinalities include:
   * 
   * - A cardinality of 0..1 means that this Feature is optional, i.e. it can be selected or deselected during configuration.
   * 
   * - A cardinality of 1 means that this Feature is mandatory, i.e. it cannot be deselected but is always present in a configuration if its parent feature is present; mandatory root features are present in all configurations.
   * 
   * - A cardinality of 0 means that this Feature is abstract, i.e. it cannot be selected and is never present in any configuration. This can be used to completely disable a feature and, in the case of non-leaf features, the whole subtree below it, for example to tentatively remove a subtree without (yet) deleting it completely from the model.
   * 
   * - A cardinality with an upper bound greater than 1 or * (infinite), such as [0..2], [1..*], or [2..8], means that this Feature is cloned, i.e. it may be selected more than once during configuration. If such a feature is actually selected more than once in a particular configuration, then its entire subtree may be configured differently for each selection. Cloned features are in fact instantiated during configuration and each instance is provided with a name.
   * 
   * Note that using cloned features, i.e. features with cardinality having an upper bound greater than 1, has far-reaching consequences for how Features are applied. If this is not desired/needed in a certain project, cardinalities &gt;1 can be prohibited by specifying an appropriate complianceLevel in the FeatureModel. As a general guideline, cloned features should be avoided as far as possible. In some situations, however, they can prove extremely useful and elegant. For example, consider the feature model of a wiper system; in order to allow for an extremely flexible configuration of the interval modes, a single parameterized cloned feature can be used: "IntervalMode[2..*] : Float". With this single cloned feature, any number of intervals can be created (but at least 2) and for each interval a precise duration in sec can be configured; without cloned features, this degree of flexibility could not easily be achieved.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Cardinality</em>' attribute.
   * @see #isSetCardinality()
   * @see #unsetCardinality()
   * @see #setCardinality(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeature_Cardinality()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{4977A7F8-92C4-4ab2-8D1D-06E1E68E3EB4}' id='31' EA\040name='cardinality'"
   *        extendedMetaData="name='CARDINALITY' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CARDINALITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getCardinality();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Feature#getCardinality <em>Cardinality</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Cardinality</em>' attribute.
   * @see #isSetCardinality()
   * @see #Cardinality()
   * @see #getCardinality()
   * @generated
   */
  void setCardinality(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.Feature#getCardinality <em>Cardinality</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetCardinality()
   * @see #getCardinality()
   * @see #setCardinality(String)
   * @generated
   */
  void unsetCardinality();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.Feature#getCardinality <em>Cardinality</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Cardinality</em>' attribute is set.
   * @see #Cardinality()
   * @see #getCardinality()
   * @see #setCardinality(String)
   * @generated
   */
  boolean isSetCardinality();

  /**
   * Returns the value of the '<em><b>Required Binding Time</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Required Binding Time</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Required Binding Time</em>' containment reference.
   * @see #setRequiredBindingTime(BindingTime)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeature_RequiredBindingTime()
   * @model containment="true"
   *        annotation="MetaData guid='{41E44F63-C60D-48db-B809-2BCE46201129}' id='251' EA\040name=''"
   *        extendedMetaData="name='REQUIRED-BINDING-TIME' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIRED-BINDING-TIMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  BindingTime getRequiredBindingTime();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Feature#getRequiredBindingTime <em>Required Binding Time</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Required Binding Time</em>' containment reference.
   * @see #getRequiredBindingTime()
   * @generated
   */
  void setRequiredBindingTime(BindingTime value);

  /**
   * Returns the value of the '<em><b>Actual Binding Time</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Actual Binding Time</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Actual Binding Time</em>' containment reference.
   * @see #setActualBindingTime(BindingTime)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeature_ActualBindingTime()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{1DF30D06-651A-42c5-8D0F-693B97E858E3}' id='252' EA\040name=''"
   *        extendedMetaData="name='ACTUAL-BINDING-TIME' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ACTUAL-BINDING-TIMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  BindingTime getActualBindingTime();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Feature#getActualBindingTime <em>Actual Binding Time</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Actual Binding Time</em>' containment reference.
   * @see #getActualBindingTime()
   * @generated
   */
  void setActualBindingTime(BindingTime value);

  /**
   * Returns the value of the '<em><b>Feature Parameter</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Feature Parameter</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Feature Parameter</em>' reference.
   * @see #setFeatureParameter(EADatatype)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeature_FeatureParameter()
   * @model annotation="MetaData guid='{4887A1EB-DEE7-4e18-9421-F3746D44748D}' id='1363737942' EA\040name=''"
   *        extendedMetaData="name='FEATURE-PARAMETER-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-PARAMETER-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EADatatype getFeatureParameter();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Feature#getFeatureParameter <em>Feature Parameter</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Feature Parameter</em>' reference.
   * @see #getFeatureParameter()
   * @generated
   */
  void setFeatureParameter(EADatatype value);

  /**
   * Returns the value of the '<em><b>Child Node</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FeatureTreeNode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Child Node</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Child Node</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFeature_ChildNode()
   * @model containment="true"
   *        annotation="MetaData guid='{365B2FAB-6E5A-43c2-91C4-857331140F04}' id='1267600133' EA\040name=''"
   *        extendedMetaData="name='CHILD-NODE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CHILD-NODES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<FeatureTreeNode> getChildNode();

} // Feature
