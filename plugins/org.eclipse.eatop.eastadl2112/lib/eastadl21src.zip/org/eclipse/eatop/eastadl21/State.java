/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A system or component can have a finite set of discrete states. Each state defines a situation where certain value invariant (quantificationInvariant) and/or time invariant (timeInvariant) hold.
 * 
 * A state s is an initial state when isInitState=true. 
 * 
 * In the context of system design, a state s can represent one or multiple operation modes when isMode=true; or one or multiple errors in the system when isError=true, or hazards when isHazard=true.
 * 
 * Semantics:
 * Each state defines a situation where certain value- and/or time-conditions in terms of state invariants hold.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.TemporalConstraint.State</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getIsErrorState <em>Is Error State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getIsHazard <em>Is Hazard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getIsInitState <em>Is Init State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getIsMode <em>Is Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getHazardDeclaration <em>Hazard Declaration</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getTimeInvariant <em>Time Invariant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getModeDeclaration <em>Mode Declaration</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.State#getQuantificationInvariant <em>Quantification Invariant</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState()
 * @model annotation="MetaData guid='{C5180EAC-B307-4a58-9A45-548923114D66}' id='-1643080085' EA\040name='State'"
 *        extendedMetaData="name='STATE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STATES'"
 * @generated
 */
public interface State extends EAElement
{
  /**
   * Returns the value of the '<em><b>Is Error State</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Is Error State</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Is Error State</em>' attribute.
   * @see #isSetIsErrorState()
   * @see #unsetIsErrorState()
   * @see #setIsErrorState(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_IsErrorState()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{EC7F16FD-0C8E-4a88-954E-F561684CAE33}' id='1942917840' EA\040name='isErrorState'"
   *        extendedMetaData="name='IS-ERROR-STATE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-ERROR-STATES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsErrorState();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsErrorState <em>Is Error State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Error State</em>' attribute.
   * @see #isSetIsErrorState()
   * @see #IsErrorState()
   * @see #getIsErrorState()
   * @generated
   */
  void setIsErrorState(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsErrorState <em>Is Error State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsErrorState()
   * @see #getIsErrorState()
   * @see #setIsErrorState(Boolean)
   * @generated
   */
  void unsetIsErrorState();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsErrorState <em>Is Error State</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Error State</em>' attribute is set.
   * @see #IsErrorState()
   * @see #getIsErrorState()
   * @see #setIsErrorState(Boolean)
   * @generated
   */
  boolean isSetIsErrorState();

  /**
   * Returns the value of the '<em><b>Is Hazard</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Is Hazard</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Is Hazard</em>' attribute.
   * @see #isSetIsHazard()
   * @see #unsetIsHazard()
   * @see #setIsHazard(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_IsHazard()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{F4E422A9-C6BB-4dcf-A1FA-E2BACDE033AC}' id='-1758024047' EA\040name='isHazard'"
   *        extendedMetaData="name='IS-HAZARD' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-HAZARDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsHazard();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsHazard <em>Is Hazard</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Hazard</em>' attribute.
   * @see #isSetIsHazard()
   * @see #IsHazard()
   * @see #getIsHazard()
   * @generated
   */
  void setIsHazard(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsHazard <em>Is Hazard</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsHazard()
   * @see #getIsHazard()
   * @see #setIsHazard(Boolean)
   * @generated
   */
  void unsetIsHazard();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsHazard <em>Is Hazard</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Hazard</em>' attribute is set.
   * @see #IsHazard()
   * @see #getIsHazard()
   * @see #setIsHazard(Boolean)
   * @generated
   */
  boolean isSetIsHazard();

  /**
   * Returns the value of the '<em><b>Is Init State</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Indicating an initial state when the value is true.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Is Init State</em>' attribute.
   * @see #isSetIsInitState()
   * @see #unsetIsInitState()
   * @see #setIsInitState(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_IsInitState()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{E68D8CD7-7220-4590-A41A-5204FF8790BE}' id='1152578942' EA\040name='isInitState'"
   *        extendedMetaData="name='IS-INIT-STATE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-INIT-STATES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsInitState();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsInitState <em>Is Init State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Init State</em>' attribute.
   * @see #isSetIsInitState()
   * @see #IsInitState()
   * @see #getIsInitState()
   * @generated
   */
  void setIsInitState(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsInitState <em>Is Init State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsInitState()
   * @see #getIsInitState()
   * @see #setIsInitState(Boolean)
   * @generated
   */
  void unsetIsInitState();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsInitState <em>Is Init State</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Init State</em>' attribute is set.
   * @see #IsInitState()
   * @see #getIsInitState()
   * @see #setIsInitState(Boolean)
   * @generated
   */
  boolean isSetIsInitState();

  /**
   * Returns the value of the '<em><b>Is Mode</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Is Mode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Is Mode</em>' attribute.
   * @see #isSetIsMode()
   * @see #unsetIsMode()
   * @see #setIsMode(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_IsMode()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{7D7744D1-8B5C-476a-8ECC-EDFF4B98CB61}' id='1166301991' EA\040name='isMode'"
   *        extendedMetaData="name='IS-MODE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-MODES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsMode();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsMode <em>Is Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Mode</em>' attribute.
   * @see #isSetIsMode()
   * @see #IsMode()
   * @see #getIsMode()
   * @generated
   */
  void setIsMode(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsMode <em>Is Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsMode()
   * @see #getIsMode()
   * @see #setIsMode(Boolean)
   * @generated
   */
  void unsetIsMode();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.State#getIsMode <em>Is Mode</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Mode</em>' attribute is set.
   * @see #IsMode()
   * @see #getIsMode()
   * @see #setIsMode(Boolean)
   * @generated
   */
  boolean isSetIsMode();

  /**
   * Returns the value of the '<em><b>Hazard Declaration</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Hazard}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hazard Declaration</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hazard Declaration</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_HazardDeclaration()
   * @model annotation="MetaData guid='{2617B42D-50B2-4e90-81BB-36BF1439E732}' id='-2030916327' EA\040name=''"
   *        extendedMetaData="name='HAZARD-DECLARATION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARD-DECLARATION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Hazard> getHazardDeclaration();

  /**
   * Returns the value of the '<em><b>Time Invariant</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.LogicalTimeCondition}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Time Invariant</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Time Invariant</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_TimeInvariant()
   * @model annotation="MetaData guid='{BD0C623F-994C-4773-97C0-7C2034062D1C}' id='1260351143' EA\040name=''"
   *        extendedMetaData="name='TIME-INVARIANT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIME-INVARIANT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<LogicalTimeCondition> getTimeInvariant();

  /**
   * Returns the value of the '<em><b>Mode Declaration</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Mode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mode Declaration</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mode Declaration</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_ModeDeclaration()
   * @model annotation="MetaData guid='{75C35503-CB53-4baa-A3C3-8124F3986161}' id='1650911352' EA\040name=''"
   *        extendedMetaData="name='MODE-DECLARATION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-DECLARATION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Mode> getModeDeclaration();

  /**
   * Returns the value of the '<em><b>Quantification Invariant</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Quantification}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Quantification Invariant</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Quantification Invariant</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getState_QuantificationInvariant()
   * @model annotation="MetaData guid='{11CF41B0-37E9-46d7-B1C6-4065C7D7ACAA}' id='1763630057' EA\040name=''"
   *        extendedMetaData="name='QUANTIFICATION-INVARIANT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTIFICATION-INVARIANT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Quantification> getQuantificationInvariant();

} // State
