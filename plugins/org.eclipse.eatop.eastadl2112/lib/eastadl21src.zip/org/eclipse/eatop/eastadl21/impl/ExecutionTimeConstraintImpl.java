/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Event;
import org.eclipse.eatop.eastadl21.ExecutionTimeConstraint;
import org.eclipse.eatop.eastadl21.TimingExpression;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Execution Time Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExecutionTimeConstraintImpl#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExecutionTimeConstraintImpl#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExecutionTimeConstraintImpl#getResume <em>Resume</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExecutionTimeConstraintImpl#getStart <em>Start</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExecutionTimeConstraintImpl#getPreemption <em>Preemption</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.ExecutionTimeConstraintImpl#getStop <em>Stop</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ExecutionTimeConstraintImpl extends TimingConstraintImpl implements ExecutionTimeConstraint
{
  /**
   * The cached value of the '{@link #getLower() <em>Lower</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLower()
   * @generated
   * @ordered
   */
  protected TimingExpression lower;

  /**
   * The cached value of the '{@link #getUpper() <em>Upper</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpper()
   * @generated
   * @ordered
   */
  protected TimingExpression upper;

  /**
   * The cached value of the '{@link #getResume() <em>Resume</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getResume()
   * @generated
   * @ordered
   */
  protected EList<Event> resume;

  /**
   * The cached value of the '{@link #getStart() <em>Start</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStart()
   * @generated
   * @ordered
   */
  protected Event start;

  /**
   * The cached value of the '{@link #getPreemption() <em>Preemption</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPreemption()
   * @generated
   * @ordered
   */
  protected EList<Event> preemption;

  /**
   * The cached value of the '{@link #getStop() <em>Stop</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStop()
   * @generated
   * @ordered
   */
  protected Event stop;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ExecutionTimeConstraintImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getExecutionTimeConstraint();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression getLower()
  {
    return lower;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetLower(TimingExpression newLower, NotificationChain msgs)
  {
    TimingExpression oldLower = lower;
    lower = newLower;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER, oldLower, newLower);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLower(TimingExpression newLower)
  {
    if (newLower != lower)
    {
      NotificationChain msgs = null;
      if (lower != null)
        msgs = ((InternalEObject)lower).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER, null, msgs);
      if (newLower != null)
        msgs = ((InternalEObject)newLower).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER, null, msgs);
      msgs = basicSetLower(newLower, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER, newLower, newLower));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression getUpper()
  {
    return upper;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetUpper(TimingExpression newUpper, NotificationChain msgs)
  {
    TimingExpression oldUpper = upper;
    upper = newUpper;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER, oldUpper, newUpper);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUpper(TimingExpression newUpper)
  {
    if (newUpper != upper)
    {
      NotificationChain msgs = null;
      if (upper != null)
        msgs = ((InternalEObject)upper).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER, null, msgs);
      if (newUpper != null)
        msgs = ((InternalEObject)newUpper).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER, null, msgs);
      msgs = basicSetUpper(newUpper, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER, newUpper, newUpper));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Event> getResume()
  {
    if (resume == null)
    {
      resume = new EObjectResolvingEList<Event>(Event.class, this, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__RESUME);
    }
    return resume;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Event getStart()
  {
    if (start != null && start.eIsProxy())
    {
      InternalEObject oldStart = (InternalEObject)start;
      start = (Event)eResolveProxy(oldStart);
      if (start != oldStart)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__START, oldStart, start));
      }
    }
    return start;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Event basicGetStart()
  {
    return start;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStart(Event newStart)
  {
    Event oldStart = start;
    start = newStart;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__START, oldStart, start));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Event> getPreemption()
  {
    if (preemption == null)
    {
      preemption = new EObjectResolvingEList<Event>(Event.class, this, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__PREEMPTION);
    }
    return preemption;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Event getStop()
  {
    if (stop != null && stop.eIsProxy())
    {
      InternalEObject oldStop = (InternalEObject)stop;
      stop = (Event)eResolveProxy(oldStop);
      if (stop != oldStop)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__STOP, oldStop, stop));
      }
    }
    return stop;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Event basicGetStop()
  {
    return stop;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStop(Event newStop)
  {
    Event oldStop = stop;
    stop = newStop;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.EXECUTION_TIME_CONSTRAINT__STOP, oldStop, stop));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER:
        return basicSetLower(null, msgs);
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER:
        return basicSetUpper(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER:
        return getLower();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER:
        return getUpper();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__RESUME:
        return getResume();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__START:
        if (resolve) return getStart();
        return basicGetStart();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__PREEMPTION:
        return getPreemption();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__STOP:
        if (resolve) return getStop();
        return basicGetStop();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER:
   			setLower((TimingExpression)newValue);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER:
   			setUpper((TimingExpression)newValue);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__RESUME:
        getResume().clear();
        getResume().addAll((Collection<? extends Event>)newValue);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__START:
   			setStart((Event)newValue);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__PREEMPTION:
        getPreemption().clear();
        getPreemption().addAll((Collection<? extends Event>)newValue);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__STOP:
   			setStop((Event)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER:
        	setLower((TimingExpression)null);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER:
        	setUpper((TimingExpression)null);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__RESUME:
        getResume().clear();
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__START:
        	setStart((Event)null);
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__PREEMPTION:
        getPreemption().clear();
        return;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__STOP:
        	setStop((Event)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__LOWER:
        return lower != null;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__UPPER:
        return upper != null;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__RESUME:
        return resume != null && !resume.isEmpty();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__START:
        return start != null;
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__PREEMPTION:
        return preemption != null && !preemption.isEmpty();
      case Eastadl21Package.EXECUTION_TIME_CONSTRAINT__STOP:
        return stop != null;
    }
    return super.eIsSet(featureID);
  }

} //ExecutionTimeConstraintImpl
