/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The SystemModel is used to organize models/architectures according to their abstraction level; it can also hold with relationships between the different levels.
 * 
 * Semantics:
 * The SystemModel represents the electrical/electronic system of the vehicle, and concepts related to the various abstraction levels.
 * 
 * Notation:
 * The default notation for a SystemModel is a solid-outline rectangle containing the SystemModel's name, and with compartments separating by horizontal lines containing features or other members of the SystemModel. Contained entities may also be shown with their connectors (White-box view).
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Structure.SystemModeling.SystemModel</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.SystemModel#getVehicleLevel <em>Vehicle Level</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SystemModel#getAnalysisLevel <em>Analysis Level</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SystemModel#getDesignLevel <em>Design Level</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.SystemModel#getImplementationLevel <em>Implementation Level</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSystemModel()
 * @model annotation="MetaData guid='{E05BBD43-9DAD-4cd8-AEE2-A237F81995FB}' id='30' EA\040name='SystemModel'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='SYSTEM-MODEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SYSTEM-MODELS'"
 * @generated
 */
public interface SystemModel extends Context
{
  /**
   * Returns the value of the '<em><b>Vehicle Level</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vehicle Level</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vehicle Level</em>' containment reference.
   * @see #setVehicleLevel(VehicleLevel)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSystemModel_VehicleLevel()
   * @model containment="true"
   *        annotation="MetaData guid='{AE52620B-7F1F-4d1d-9B45-248E1E7A637A}' id='-2120224842' EA\040name=''"
   *        extendedMetaData="name='VEHICLE-LEVEL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VEHICLE-LEVELS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  VehicleLevel getVehicleLevel();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SystemModel#getVehicleLevel <em>Vehicle Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Vehicle Level</em>' containment reference.
   * @see #getVehicleLevel()
   * @generated
   */
  void setVehicleLevel(VehicleLevel value);

  /**
   * Returns the value of the '<em><b>Analysis Level</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Analysis Level</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Analysis Level</em>' containment reference.
   * @see #setAnalysisLevel(AnalysisLevel)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSystemModel_AnalysisLevel()
   * @model containment="true"
   *        annotation="MetaData guid='{7E28CD08-4203-4e8f-8FBB-D1EDF1CB773D}' id='272' EA\040name=''"
   *        extendedMetaData="name='ANALYSIS-LEVEL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ANALYSIS-LEVELS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  AnalysisLevel getAnalysisLevel();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SystemModel#getAnalysisLevel <em>Analysis Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Analysis Level</em>' containment reference.
   * @see #getAnalysisLevel()
   * @generated
   */
  void setAnalysisLevel(AnalysisLevel value);

  /**
   * Returns the value of the '<em><b>Design Level</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Design Level</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Design Level</em>' containment reference.
   * @see #setDesignLevel(DesignLevel)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSystemModel_DesignLevel()
   * @model containment="true"
   *        annotation="MetaData guid='{376D7BA3-3D34-4ebf-BA2C-0E3606EE4561}' id='276' EA\040name=''"
   *        extendedMetaData="name='DESIGN-LEVEL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DESIGN-LEVELS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  DesignLevel getDesignLevel();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SystemModel#getDesignLevel <em>Design Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Design Level</em>' containment reference.
   * @see #getDesignLevel()
   * @generated
   */
  void setDesignLevel(DesignLevel value);

  /**
   * Returns the value of the '<em><b>Implementation Level</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Implementation Level</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Implementation Level</em>' containment reference.
   * @see #setImplementationLevel(ImplementationLevel)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getSystemModel_ImplementationLevel()
   * @model containment="true"
   *        annotation="MetaData guid='{640FAAC8-ED97-4093-82A3-C846CEAF9E9C}' id='268' EA\040name=''"
   *        extendedMetaData="name='IMPLEMENTATION-LEVEL' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IMPLEMENTATION-LEVELS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ImplementationLevel getImplementationLevel();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.SystemModel#getImplementationLevel <em>Implementation Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Implementation Level</em>' containment reference.
   * @see #getImplementationLevel()
   * @generated
   */
  void setImplementationLevel(ImplementationLevel value);

} // SystemModel
