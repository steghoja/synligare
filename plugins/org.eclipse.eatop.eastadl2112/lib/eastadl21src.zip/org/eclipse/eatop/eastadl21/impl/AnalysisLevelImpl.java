/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import org.eclipse.eatop.eastadl21.AnalysisFunctionPrototype;
import org.eclipse.eatop.eastadl21.AnalysisLevel;
import org.eclipse.eatop.eastadl21.Eastadl21Package;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Analysis Level</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.AnalysisLevelImpl#getFunctionalAnalysisArchitecture <em>Functional Analysis Architecture</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AnalysisLevelImpl extends ContextImpl implements AnalysisLevel
{
  /**
   * The cached value of the '{@link #getFunctionalAnalysisArchitecture() <em>Functional Analysis Architecture</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFunctionalAnalysisArchitecture()
   * @generated
   * @ordered
   */
  protected AnalysisFunctionPrototype functionalAnalysisArchitecture;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AnalysisLevelImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getAnalysisLevel();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AnalysisFunctionPrototype getFunctionalAnalysisArchitecture()
  {
    return functionalAnalysisArchitecture;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetFunctionalAnalysisArchitecture(AnalysisFunctionPrototype newFunctionalAnalysisArchitecture, NotificationChain msgs)
  {
    AnalysisFunctionPrototype oldFunctionalAnalysisArchitecture = functionalAnalysisArchitecture;
    functionalAnalysisArchitecture = newFunctionalAnalysisArchitecture;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE, oldFunctionalAnalysisArchitecture, newFunctionalAnalysisArchitecture);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFunctionalAnalysisArchitecture(AnalysisFunctionPrototype newFunctionalAnalysisArchitecture)
  {
    if (newFunctionalAnalysisArchitecture != functionalAnalysisArchitecture)
    {
      NotificationChain msgs = null;
      if (functionalAnalysisArchitecture != null)
        msgs = ((InternalEObject)functionalAnalysisArchitecture).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE, null, msgs);
      if (newFunctionalAnalysisArchitecture != null)
        msgs = ((InternalEObject)newFunctionalAnalysisArchitecture).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE, null, msgs);
      msgs = basicSetFunctionalAnalysisArchitecture(newFunctionalAnalysisArchitecture, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE, newFunctionalAnalysisArchitecture, newFunctionalAnalysisArchitecture));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE:
        return basicSetFunctionalAnalysisArchitecture(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE:
        return getFunctionalAnalysisArchitecture();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE:
   			setFunctionalAnalysisArchitecture((AnalysisFunctionPrototype)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE:
        	setFunctionalAnalysisArchitecture((AnalysisFunctionPrototype)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.ANALYSIS_LEVEL__FUNCTIONAL_ANALYSIS_ARCHITECTURE:
        return functionalAnalysisArchitecture != null;
    }
    return super.eIsSet(featureID);
  }

} //AnalysisLevelImpl
