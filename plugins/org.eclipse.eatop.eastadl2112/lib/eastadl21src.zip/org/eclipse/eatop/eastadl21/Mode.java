/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mode</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Modes are a way to introduce various configurations in the system to account for different states of the system, or of a hardware entity, or an application. The use of modes can be used to filter different views of the model.
 * 
 * Modes are characterized by a Boolean condition provided as a String, which evaluates to true when the Mode is active.
 * 
 * As far as behavior is concerned, Modes enable the logical organization of a set of triggers and behaviors over a set of functions. Modes are referred to by both FunctionTriggers and FunctionBehaviors (see FunctionTrigger and FunctionBehavior).
 * 
 * Modes can be further organized in mutually exclusive sets with ModeGroups (see that element).
 * 
 * Semantics:
 * The Mode is active if and only if the condition is true.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Behavior.Mode</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Mode#getCondition <em>Condition</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getMode()
 * @model annotation="MetaData guid='{5780D908-600B-46c6-A660-4416418EF785}' id='-1871768364' EA\040name='Mode'"
 *        extendedMetaData="name='MODE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODES'"
 * @generated
 */
public interface Mode extends EAElement
{
  /**
   * Returns the value of the '<em><b>Condition</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * A Boolean expression that characterizes the Mode, it evaluates to true when the Mode is active. The syntax and grammar of this expression is unspecified.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Condition</em>' attribute.
   * @see #isSetCondition()
   * @see #unsetCondition()
   * @see #setCondition(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getMode_Condition()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{686AD74C-106E-488f-AD13-8D40D281A32A}' id='1094525253' EA\040name='condition'"
   *        extendedMetaData="name='CONDITION' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONDITIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getCondition();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Mode#getCondition <em>Condition</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Condition</em>' attribute.
   * @see #isSetCondition()
   * @see #Condition()
   * @see #getCondition()
   * @generated
   */
  void setCondition(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.Mode#getCondition <em>Condition</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetCondition()
   * @see #getCondition()
   * @see #setCondition(String)
   * @generated
   */
  void unsetCondition();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.Mode#getCondition <em>Condition</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Condition</em>' attribute is set.
   * @see #Condition()
   * @see #getCondition()
   * @see #setCondition(String)
   * @generated
   */
  boolean isSetCondition();

} // Mode
