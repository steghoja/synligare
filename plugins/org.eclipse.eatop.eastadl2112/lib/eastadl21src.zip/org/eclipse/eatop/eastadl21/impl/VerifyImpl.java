/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Requirement;
import org.eclipse.eatop.eastadl21.VVCase;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.Verify;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Verify</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VerifyImpl#getVerifiedByCase <em>Verified By Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VerifyImpl#getVerifiedByProcedure <em>Verified By Procedure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VerifyImpl#getVerifiedRequirement <em>Verified Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VerifyImpl extends RequirementsRelationshipImpl implements Verify
{
  /**
   * The cached value of the '{@link #getVerifiedByCase() <em>Verified By Case</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVerifiedByCase()
   * @generated
   * @ordered
   */
  protected EList<VVCase> verifiedByCase;

  /**
   * The cached value of the '{@link #getVerifiedByProcedure() <em>Verified By Procedure</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVerifiedByProcedure()
   * @generated
   * @ordered
   */
  protected EList<VVProcedure> verifiedByProcedure;

  /**
   * The cached value of the '{@link #getVerifiedRequirement() <em>Verified Requirement</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVerifiedRequirement()
   * @generated
   * @ordered
   */
  protected EList<Requirement> verifiedRequirement;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VerifyImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getVerify();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVCase> getVerifiedByCase()
  {
    if (verifiedByCase == null)
    {
      verifiedByCase = new EObjectResolvingEList<VVCase>(VVCase.class, this, Eastadl21Package.VERIFY__VERIFIED_BY_CASE);
    }
    return verifiedByCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVProcedure> getVerifiedByProcedure()
  {
    if (verifiedByProcedure == null)
    {
      verifiedByProcedure = new EObjectResolvingEList<VVProcedure>(VVProcedure.class, this, Eastadl21Package.VERIFY__VERIFIED_BY_PROCEDURE);
    }
    return verifiedByProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Requirement> getVerifiedRequirement()
  {
    if (verifiedRequirement == null)
    {
      verifiedRequirement = new EObjectResolvingEList<Requirement>(Requirement.class, this, Eastadl21Package.VERIFY__VERIFIED_REQUIREMENT);
    }
    return verifiedRequirement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.VERIFY__VERIFIED_BY_CASE:
        return getVerifiedByCase();
      case Eastadl21Package.VERIFY__VERIFIED_BY_PROCEDURE:
        return getVerifiedByProcedure();
      case Eastadl21Package.VERIFY__VERIFIED_REQUIREMENT:
        return getVerifiedRequirement();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.VERIFY__VERIFIED_BY_CASE:
        getVerifiedByCase().clear();
        getVerifiedByCase().addAll((Collection<? extends VVCase>)newValue);
        return;
      case Eastadl21Package.VERIFY__VERIFIED_BY_PROCEDURE:
        getVerifiedByProcedure().clear();
        getVerifiedByProcedure().addAll((Collection<? extends VVProcedure>)newValue);
        return;
      case Eastadl21Package.VERIFY__VERIFIED_REQUIREMENT:
        getVerifiedRequirement().clear();
        getVerifiedRequirement().addAll((Collection<? extends Requirement>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VERIFY__VERIFIED_BY_CASE:
        getVerifiedByCase().clear();
        return;
      case Eastadl21Package.VERIFY__VERIFIED_BY_PROCEDURE:
        getVerifiedByProcedure().clear();
        return;
      case Eastadl21Package.VERIFY__VERIFIED_REQUIREMENT:
        getVerifiedRequirement().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VERIFY__VERIFIED_BY_CASE:
        return verifiedByCase != null && !verifiedByCase.isEmpty();
      case Eastadl21Package.VERIFY__VERIFIED_BY_PROCEDURE:
        return verifiedByProcedure != null && !verifiedByProcedure.isEmpty();
      case Eastadl21Package.VERIFY__VERIFIED_REQUIREMENT:
        return verifiedRequirement != null && !verifiedRequirement.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //VerifyImpl
