/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Hazard;
import org.eclipse.eatop.eastadl21.LogicalTimeCondition;
import org.eclipse.eatop.eastadl21.Mode;
import org.eclipse.eatop.eastadl21.Quantification;
import org.eclipse.eatop.eastadl21.State;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getIsErrorState <em>Is Error State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getIsHazard <em>Is Hazard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getIsInitState <em>Is Init State</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getIsMode <em>Is Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getHazardDeclaration <em>Hazard Declaration</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getTimeInvariant <em>Time Invariant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getModeDeclaration <em>Mode Declaration</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.StateImpl#getQuantificationInvariant <em>Quantification Invariant</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StateImpl extends EAElementImpl implements State
{
  /**
   * The default value of the '{@link #getIsErrorState() <em>Is Error State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsErrorState()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_ERROR_STATE_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsErrorState() <em>Is Error State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsErrorState()
   * @generated
   * @ordered
   */
  protected Boolean isErrorState = IS_ERROR_STATE_EDEFAULT;

  /**
   * This is true if the Is Error State attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isErrorStateESet;

  /**
   * The default value of the '{@link #getIsHazard() <em>Is Hazard</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsHazard()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_HAZARD_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsHazard() <em>Is Hazard</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsHazard()
   * @generated
   * @ordered
   */
  protected Boolean isHazard = IS_HAZARD_EDEFAULT;

  /**
   * This is true if the Is Hazard attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isHazardESet;

  /**
   * The default value of the '{@link #getIsInitState() <em>Is Init State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsInitState()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_INIT_STATE_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsInitState() <em>Is Init State</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsInitState()
   * @generated
   * @ordered
   */
  protected Boolean isInitState = IS_INIT_STATE_EDEFAULT;

  /**
   * This is true if the Is Init State attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isInitStateESet;

  /**
   * The default value of the '{@link #getIsMode() <em>Is Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsMode()
   * @generated
   * @ordered
   */
  protected static final Boolean IS_MODE_EDEFAULT = Boolean.FALSE;

  /**
   * The cached value of the '{@link #getIsMode() <em>Is Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIsMode()
   * @generated
   * @ordered
   */
  protected Boolean isMode = IS_MODE_EDEFAULT;

  /**
   * This is true if the Is Mode attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean isModeESet;

  /**
   * The cached value of the '{@link #getHazardDeclaration() <em>Hazard Declaration</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHazardDeclaration()
   * @generated
   * @ordered
   */
  protected EList<Hazard> hazardDeclaration;

  /**
   * The cached value of the '{@link #getTimeInvariant() <em>Time Invariant</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTimeInvariant()
   * @generated
   * @ordered
   */
  protected EList<LogicalTimeCondition> timeInvariant;

  /**
   * The cached value of the '{@link #getModeDeclaration() <em>Mode Declaration</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getModeDeclaration()
   * @generated
   * @ordered
   */
  protected EList<Mode> modeDeclaration;

  /**
   * The cached value of the '{@link #getQuantificationInvariant() <em>Quantification Invariant</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getQuantificationInvariant()
   * @generated
   * @ordered
   */
  protected EList<Quantification> quantificationInvariant;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StateImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getState();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsErrorState()
  {
    return isErrorState;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsErrorState(Boolean newIsErrorState)
  {
    Boolean oldIsErrorState = isErrorState;
    isErrorState = newIsErrorState;
    boolean oldIsErrorStateESet = isErrorStateESet;
    isErrorStateESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.STATE__IS_ERROR_STATE, oldIsErrorState, isErrorState, !oldIsErrorStateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsErrorState()
  {
    Boolean oldIsErrorState = isErrorState;
    boolean oldIsErrorStateESet = isErrorStateESet;
    isErrorState = IS_ERROR_STATE_EDEFAULT;
    isErrorStateESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.STATE__IS_ERROR_STATE, oldIsErrorState, IS_ERROR_STATE_EDEFAULT, oldIsErrorStateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsErrorState()
  {
    return isErrorStateESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsHazard()
  {
    return isHazard;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsHazard(Boolean newIsHazard)
  {
    Boolean oldIsHazard = isHazard;
    isHazard = newIsHazard;
    boolean oldIsHazardESet = isHazardESet;
    isHazardESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.STATE__IS_HAZARD, oldIsHazard, isHazard, !oldIsHazardESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsHazard()
  {
    Boolean oldIsHazard = isHazard;
    boolean oldIsHazardESet = isHazardESet;
    isHazard = IS_HAZARD_EDEFAULT;
    isHazardESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.STATE__IS_HAZARD, oldIsHazard, IS_HAZARD_EDEFAULT, oldIsHazardESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsHazard()
  {
    return isHazardESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsInitState()
  {
    return isInitState;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsInitState(Boolean newIsInitState)
  {
    Boolean oldIsInitState = isInitState;
    isInitState = newIsInitState;
    boolean oldIsInitStateESet = isInitStateESet;
    isInitStateESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.STATE__IS_INIT_STATE, oldIsInitState, isInitState, !oldIsInitStateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsInitState()
  {
    Boolean oldIsInitState = isInitState;
    boolean oldIsInitStateESet = isInitStateESet;
    isInitState = IS_INIT_STATE_EDEFAULT;
    isInitStateESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.STATE__IS_INIT_STATE, oldIsInitState, IS_INIT_STATE_EDEFAULT, oldIsInitStateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsInitState()
  {
    return isInitStateESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Boolean getIsMode()
  {
    return isMode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIsMode(Boolean newIsMode)
  {
    Boolean oldIsMode = isMode;
    isMode = newIsMode;
    boolean oldIsModeESet = isModeESet;
    isModeESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.STATE__IS_MODE, oldIsMode, isMode, !oldIsModeESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetIsMode()
  {
    Boolean oldIsMode = isMode;
    boolean oldIsModeESet = isModeESet;
    isMode = IS_MODE_EDEFAULT;
    isModeESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.STATE__IS_MODE, oldIsMode, IS_MODE_EDEFAULT, oldIsModeESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetIsMode()
  {
    return isModeESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Hazard> getHazardDeclaration()
  {
    if (hazardDeclaration == null)
    {
      hazardDeclaration = new EObjectResolvingEList<Hazard>(Hazard.class, this, Eastadl21Package.STATE__HAZARD_DECLARATION);
    }
    return hazardDeclaration;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<LogicalTimeCondition> getTimeInvariant()
  {
    if (timeInvariant == null)
    {
      timeInvariant = new EObjectResolvingEList<LogicalTimeCondition>(LogicalTimeCondition.class, this, Eastadl21Package.STATE__TIME_INVARIANT);
    }
    return timeInvariant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Mode> getModeDeclaration()
  {
    if (modeDeclaration == null)
    {
      modeDeclaration = new EObjectResolvingEList<Mode>(Mode.class, this, Eastadl21Package.STATE__MODE_DECLARATION);
    }
    return modeDeclaration;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Quantification> getQuantificationInvariant()
  {
    if (quantificationInvariant == null)
    {
      quantificationInvariant = new EObjectResolvingEList<Quantification>(Quantification.class, this, Eastadl21Package.STATE__QUANTIFICATION_INVARIANT);
    }
    return quantificationInvariant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.STATE__IS_ERROR_STATE:
        return getIsErrorState();
      case Eastadl21Package.STATE__IS_HAZARD:
        return getIsHazard();
      case Eastadl21Package.STATE__IS_INIT_STATE:
        return getIsInitState();
      case Eastadl21Package.STATE__IS_MODE:
        return getIsMode();
      case Eastadl21Package.STATE__HAZARD_DECLARATION:
        return getHazardDeclaration();
      case Eastadl21Package.STATE__TIME_INVARIANT:
        return getTimeInvariant();
      case Eastadl21Package.STATE__MODE_DECLARATION:
        return getModeDeclaration();
      case Eastadl21Package.STATE__QUANTIFICATION_INVARIANT:
        return getQuantificationInvariant();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.STATE__IS_ERROR_STATE:
   			setIsErrorState((Boolean)newValue);
        return;
      case Eastadl21Package.STATE__IS_HAZARD:
   			setIsHazard((Boolean)newValue);
        return;
      case Eastadl21Package.STATE__IS_INIT_STATE:
   			setIsInitState((Boolean)newValue);
        return;
      case Eastadl21Package.STATE__IS_MODE:
   			setIsMode((Boolean)newValue);
        return;
      case Eastadl21Package.STATE__HAZARD_DECLARATION:
        getHazardDeclaration().clear();
        getHazardDeclaration().addAll((Collection<? extends Hazard>)newValue);
        return;
      case Eastadl21Package.STATE__TIME_INVARIANT:
        getTimeInvariant().clear();
        getTimeInvariant().addAll((Collection<? extends LogicalTimeCondition>)newValue);
        return;
      case Eastadl21Package.STATE__MODE_DECLARATION:
        getModeDeclaration().clear();
        getModeDeclaration().addAll((Collection<? extends Mode>)newValue);
        return;
      case Eastadl21Package.STATE__QUANTIFICATION_INVARIANT:
        getQuantificationInvariant().clear();
        getQuantificationInvariant().addAll((Collection<? extends Quantification>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.STATE__IS_ERROR_STATE:
        unsetIsErrorState();
        return;
      case Eastadl21Package.STATE__IS_HAZARD:
        unsetIsHazard();
        return;
      case Eastadl21Package.STATE__IS_INIT_STATE:
        unsetIsInitState();
        return;
      case Eastadl21Package.STATE__IS_MODE:
        unsetIsMode();
        return;
      case Eastadl21Package.STATE__HAZARD_DECLARATION:
        getHazardDeclaration().clear();
        return;
      case Eastadl21Package.STATE__TIME_INVARIANT:
        getTimeInvariant().clear();
        return;
      case Eastadl21Package.STATE__MODE_DECLARATION:
        getModeDeclaration().clear();
        return;
      case Eastadl21Package.STATE__QUANTIFICATION_INVARIANT:
        getQuantificationInvariant().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.STATE__IS_ERROR_STATE:
        return isSetIsErrorState();
      case Eastadl21Package.STATE__IS_HAZARD:
        return isSetIsHazard();
      case Eastadl21Package.STATE__IS_INIT_STATE:
        return isSetIsInitState();
      case Eastadl21Package.STATE__IS_MODE:
        return isSetIsMode();
      case Eastadl21Package.STATE__HAZARD_DECLARATION:
        return hazardDeclaration != null && !hazardDeclaration.isEmpty();
      case Eastadl21Package.STATE__TIME_INVARIANT:
        return timeInvariant != null && !timeInvariant.isEmpty();
      case Eastadl21Package.STATE__MODE_DECLARATION:
        return modeDeclaration != null && !modeDeclaration.isEmpty();
      case Eastadl21Package.STATE__QUANTIFICATION_INVARIANT:
        return quantificationInvariant != null && !quantificationInvariant.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (isErrorState: ");
    if (isErrorStateESet) result.append(isErrorState); else result.append("<unset>");
    result.append(", isHazard: ");
    if (isHazardESet) result.append(isHazard); else result.append("<unset>");
    result.append(", isInitState: ");
    if (isInitStateESet) result.append(isInitState); else result.append("<unset>");
    result.append(", isMode: ");
    if (isModeESet) result.append(isMode); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //StateImpl
