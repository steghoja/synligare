/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Product Positioning</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The problem positioning represents an overall brief statement summarizing, at the highest level, the unique position the product intends to fill in the marketplace which gives the opportunity to establish traceability from artifacts created later, for example to provide rationales to design decisions or trade-off analysis.
 * 
 * Positioning is assumed to belong to a particular context, typically a system, but also for a smaller part of a system.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.Needs.ProductPositioning</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProductPositioning#getDrivingNeeds <em>Driving Needs</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProductPositioning#getKeyCapabilities <em>Key Capabilities</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryCompetitiveAlternative <em>Primary Competitive Alternative</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryDifferentiation <em>Primary Differentiation</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.ProductPositioning#getTargetCustomers <em>Target Customers</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProductPositioning()
 * @model annotation="MetaData guid='{C090E565-10F6-4565-AB1F-2540FE18C362}' id='1307258702' EA\040name='ProductPositioning'"
 *        extendedMetaData="name='PRODUCT-POSITIONING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRODUCT-POSITIONINGS'"
 * @generated
 */
public interface ProductPositioning extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Driving Needs</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Brief statement of key benefit; that is, the compelling need for the product.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Driving Needs</em>' attribute.
   * @see #isSetDrivingNeeds()
   * @see #unsetDrivingNeeds()
   * @see #setDrivingNeeds(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProductPositioning_DrivingNeeds()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{B50DB47F-3D25-457a-AEF6-0B22CF096E5F}' id='1560663485' EA\040name='drivingNeeds'"
   *        extendedMetaData="name='DRIVING-NEEDS' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DRIVING-NEEDSS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getDrivingNeeds();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getDrivingNeeds <em>Driving Needs</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driving Needs</em>' attribute.
   * @see #isSetDrivingNeeds()
   * @see #DrivingNeeds()
   * @see #getDrivingNeeds()
   * @generated
   */
  void setDrivingNeeds(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getDrivingNeeds <em>Driving Needs</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetDrivingNeeds()
   * @see #getDrivingNeeds()
   * @see #setDrivingNeeds(String)
   * @generated
   */
  void unsetDrivingNeeds();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getDrivingNeeds <em>Driving Needs</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Driving Needs</em>' attribute is set.
   * @see #DrivingNeeds()
   * @see #getDrivingNeeds()
   * @see #setDrivingNeeds(String)
   * @generated
   */
  boolean isSetDrivingNeeds();

  /**
   * Returns the value of the '<em><b>Key Capabilities</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Brief statement of the key capabilities.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Key Capabilities</em>' attribute.
   * @see #isSetKeyCapabilities()
   * @see #unsetKeyCapabilities()
   * @see #setKeyCapabilities(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProductPositioning_KeyCapabilities()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{AF6C21CF-43C8-43b3-9B9E-ECF456129CBA}' id='-1027930573' EA\040name='keyCapabilities'"
   *        extendedMetaData="name='KEY-CAPABILITIES' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='KEY-CAPABILITIESS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getKeyCapabilities();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getKeyCapabilities <em>Key Capabilities</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Key Capabilities</em>' attribute.
   * @see #isSetKeyCapabilities()
   * @see #KeyCapabilities()
   * @see #getKeyCapabilities()
   * @generated
   */
  void setKeyCapabilities(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getKeyCapabilities <em>Key Capabilities</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetKeyCapabilities()
   * @see #getKeyCapabilities()
   * @see #setKeyCapabilities(String)
   * @generated
   */
  void unsetKeyCapabilities();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getKeyCapabilities <em>Key Capabilities</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Key Capabilities</em>' attribute is set.
   * @see #KeyCapabilities()
   * @see #getKeyCapabilities()
   * @see #setKeyCapabilities(String)
   * @generated
   */
  boolean isSetKeyCapabilities();

  /**
   * Returns the value of the '<em><b>Primary Competitive Alternative</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Brief statement of primary competitive alternative.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Primary Competitive Alternative</em>' attribute.
   * @see #isSetPrimaryCompetitiveAlternative()
   * @see #unsetPrimaryCompetitiveAlternative()
   * @see #setPrimaryCompetitiveAlternative(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProductPositioning_PrimaryCompetitiveAlternative()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{A6E8F188-A27C-466c-AC4B-665631A8CC79}' id='374235194' EA\040name='primaryCompetitiveAlternative'"
   *        extendedMetaData="name='PRIMARY-COMPETITIVE-ALTERNATIVE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRIMARY-COMPETITIVE-ALTERNATIVES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getPrimaryCompetitiveAlternative();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryCompetitiveAlternative <em>Primary Competitive Alternative</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Primary Competitive Alternative</em>' attribute.
   * @see #isSetPrimaryCompetitiveAlternative()
   * @see #PrimaryCompetitiveAlternative()
   * @see #getPrimaryCompetitiveAlternative()
   * @generated
   */
  void setPrimaryCompetitiveAlternative(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryCompetitiveAlternative <em>Primary Competitive Alternative</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetPrimaryCompetitiveAlternative()
   * @see #getPrimaryCompetitiveAlternative()
   * @see #setPrimaryCompetitiveAlternative(String)
   * @generated
   */
  void unsetPrimaryCompetitiveAlternative();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryCompetitiveAlternative <em>Primary Competitive Alternative</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Primary Competitive Alternative</em>' attribute is set.
   * @see #PrimaryCompetitiveAlternative()
   * @see #getPrimaryCompetitiveAlternative()
   * @see #setPrimaryCompetitiveAlternative(String)
   * @generated
   */
  boolean isSetPrimaryCompetitiveAlternative();

  /**
   * Returns the value of the '<em><b>Primary Differentiation</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Brief statement of primary differentiation.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Primary Differentiation</em>' attribute.
   * @see #isSetPrimaryDifferentiation()
   * @see #unsetPrimaryDifferentiation()
   * @see #setPrimaryDifferentiation(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProductPositioning_PrimaryDifferentiation()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{C01341A7-C0B4-4b2b-B767-9C714A470178}' id='271706360' EA\040name='primaryDifferentiation'"
   *        extendedMetaData="name='PRIMARY-DIFFERENTIATION' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRIMARY-DIFFERENTIATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getPrimaryDifferentiation();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryDifferentiation <em>Primary Differentiation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Primary Differentiation</em>' attribute.
   * @see #isSetPrimaryDifferentiation()
   * @see #PrimaryDifferentiation()
   * @see #getPrimaryDifferentiation()
   * @generated
   */
  void setPrimaryDifferentiation(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryDifferentiation <em>Primary Differentiation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetPrimaryDifferentiation()
   * @see #getPrimaryDifferentiation()
   * @see #setPrimaryDifferentiation(String)
   * @generated
   */
  void unsetPrimaryDifferentiation();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getPrimaryDifferentiation <em>Primary Differentiation</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Primary Differentiation</em>' attribute is set.
   * @see #PrimaryDifferentiation()
   * @see #getPrimaryDifferentiation()
   * @see #setPrimaryDifferentiation(String)
   * @generated
   */
  boolean isSetPrimaryDifferentiation();

  /**
   * Returns the value of the '<em><b>Target Customers</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * Brief statement of target customers.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Target Customers</em>' attribute.
   * @see #isSetTargetCustomers()
   * @see #unsetTargetCustomers()
   * @see #setTargetCustomers(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getProductPositioning_TargetCustomers()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{D5F2E0FE-BE0F-4e05-ADDD-105A89953288}' id='1251548716' EA\040name='targetCustomers'"
   *        extendedMetaData="name='TARGET-CUSTOMERS' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-CUSTOMERSS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getTargetCustomers();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getTargetCustomers <em>Target Customers</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Customers</em>' attribute.
   * @see #isSetTargetCustomers()
   * @see #TargetCustomers()
   * @see #getTargetCustomers()
   * @generated
   */
  void setTargetCustomers(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getTargetCustomers <em>Target Customers</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetTargetCustomers()
   * @see #getTargetCustomers()
   * @see #setTargetCustomers(String)
   * @generated
   */
  void unsetTargetCustomers();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.ProductPositioning#getTargetCustomers <em>Target Customers</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Target Customers</em>' attribute is set.
   * @see #TargetCustomers()
   * @see #getTargetCustomers()
   * @see #setTargetCustomers(String)
   * @generated
   */
  boolean isSetTargetCustomers();

} // ProductPositioning
