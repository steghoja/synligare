/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure Port hw Target</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel._instanceRef.FaultFailurePort_hwTarget</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget#getHardwarePort <em>Hardware Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget#getHardwareComponentPrototype <em>Hardware Component Prototype</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePort_hwTarget()
 * @model annotation="MetaData guid='{FF857670-A396-4aed-B35E-8CF68D4809D2}' id='885444244' EA\040name='FaultFailurePort_hwTarget'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='FAULT-FAILURE-PORT--HW-TARGET-IREF'"
 *        extendedMetaData="name='FAULT-FAILURE-PORT--HW-TARGET-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-PORT--HW-TARGET-IREFS'"
 * @generated
 */
public interface FaultFailurePort_hwTarget extends EObject
{
  /**
   * Returns the value of the '<em><b>Hardware Port</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hardware Port</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hardware Port</em>' reference.
   * @see #setHardwarePort(HardwarePin)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePort_hwTarget_HardwarePort()
   * @model required="true"
   *        annotation="MetaData guid='{1E82B2C6-EACD-4043-BD4D-B74D765826A1}' id='-1517598715' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='HARDWARE-PORT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-PORT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  HardwarePin getHardwarePort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.FaultFailurePort_hwTarget#getHardwarePort <em>Hardware Port</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Hardware Port</em>' reference.
   * @see #getHardwarePort()
   * @generated
   */
  void setHardwarePort(HardwarePin value);

  /**
   * Returns the value of the '<em><b>Hardware Component Prototype</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HardwareComponentPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hardware Component Prototype</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hardware Component Prototype</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFaultFailurePort_hwTarget_HardwareComponentPrototype()
   * @model annotation="MetaData guid='{58636EEA-DA71-46fc-9771-9CF5A3014751}' id='-462412062' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='HARDWARE-COMPONENT-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-COMPONENT-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<HardwareComponentPrototype> getHardwareComponentPrototype();

} // FaultFailurePort_hwTarget
