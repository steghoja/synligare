/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.VVActualOutcome;
import org.eclipse.eatop.eastadl21.VVLog;
import org.eclipse.eatop.eastadl21.VVProcedure;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VV Log</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVLogImpl#getDate <em>Date</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVLogImpl#getVvActualOutcome <em>Vv Actual Outcome</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVLogImpl#getPerformedVVProcedure <em>Performed VV Procedure</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VVLogImpl extends TraceableSpecificationImpl implements VVLog
{
  /**
   * The default value of the '{@link #getDate() <em>Date</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDate()
   * @generated
   * @ordered
   */
  protected static final String DATE_EDEFAULT = "";

  /**
   * The cached value of the '{@link #getDate() <em>Date</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDate()
   * @generated
   * @ordered
   */
  protected String date = DATE_EDEFAULT;

  /**
   * This is true if the Date attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean dateESet;

  /**
   * The cached value of the '{@link #getVvActualOutcome() <em>Vv Actual Outcome</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvActualOutcome()
   * @generated
   * @ordered
   */
  protected EList<VVActualOutcome> vvActualOutcome;

  /**
   * The cached value of the '{@link #getPerformedVVProcedure() <em>Performed VV Procedure</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPerformedVVProcedure()
   * @generated
   * @ordered
   */
  protected VVProcedure performedVVProcedure;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VVLogImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getVVLog();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDate()
  {
    return date;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDate(String newDate)
  {
    String oldDate = date;
    date = newDate;
    boolean oldDateESet = dateESet;
    dateESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.VV_LOG__DATE, oldDate, date, !oldDateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetDate()
  {
    String oldDate = date;
    boolean oldDateESet = dateESet;
    date = DATE_EDEFAULT;
    dateESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl21Package.VV_LOG__DATE, oldDate, DATE_EDEFAULT, oldDateESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetDate()
  {
    return dateESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVActualOutcome> getVvActualOutcome()
  {
    if (vvActualOutcome == null)
    {
      vvActualOutcome = new EObjectContainmentEList<VVActualOutcome>(VVActualOutcome.class, this, Eastadl21Package.VV_LOG__VV_ACTUAL_OUTCOME);
    }
    return vvActualOutcome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVProcedure getPerformedVVProcedure()
  {
    if (performedVVProcedure != null && performedVVProcedure.eIsProxy())
    {
      InternalEObject oldPerformedVVProcedure = (InternalEObject)performedVVProcedure;
      performedVVProcedure = (VVProcedure)eResolveProxy(oldPerformedVVProcedure);
      if (performedVVProcedure != oldPerformedVVProcedure)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.VV_LOG__PERFORMED_VV_PROCEDURE, oldPerformedVVProcedure, performedVVProcedure));
      }
    }
    return performedVVProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVProcedure basicGetPerformedVVProcedure()
  {
    return performedVVProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPerformedVVProcedure(VVProcedure newPerformedVVProcedure)
  {
    VVProcedure oldPerformedVVProcedure = performedVVProcedure;
    performedVVProcedure = newPerformedVVProcedure;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.VV_LOG__PERFORMED_VV_PROCEDURE, oldPerformedVVProcedure, performedVVProcedure));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_LOG__VV_ACTUAL_OUTCOME:
        return ((InternalEList<?>)getVvActualOutcome()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_LOG__DATE:
        return getDate();
      case Eastadl21Package.VV_LOG__VV_ACTUAL_OUTCOME:
        return getVvActualOutcome();
      case Eastadl21Package.VV_LOG__PERFORMED_VV_PROCEDURE:
        if (resolve) return getPerformedVVProcedure();
        return basicGetPerformedVVProcedure();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_LOG__DATE:
   			setDate((String)newValue);
        return;
      case Eastadl21Package.VV_LOG__VV_ACTUAL_OUTCOME:
        getVvActualOutcome().clear();
        getVvActualOutcome().addAll((Collection<? extends VVActualOutcome>)newValue);
        return;
      case Eastadl21Package.VV_LOG__PERFORMED_VV_PROCEDURE:
   			setPerformedVVProcedure((VVProcedure)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_LOG__DATE:
        unsetDate();
        return;
      case Eastadl21Package.VV_LOG__VV_ACTUAL_OUTCOME:
        getVvActualOutcome().clear();
        return;
      case Eastadl21Package.VV_LOG__PERFORMED_VV_PROCEDURE:
        	setPerformedVVProcedure((VVProcedure)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_LOG__DATE:
        return isSetDate();
      case Eastadl21Package.VV_LOG__VV_ACTUAL_OUTCOME:
        return vvActualOutcome != null && !vvActualOutcome.isEmpty();
      case Eastadl21Package.VV_LOG__PERFORMED_VV_PROCEDURE:
        return performedVVProcedure != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (date: ");
    if (dateESet) result.append(date); else result.append("<unset>");
    result.append(')');
    return result.toString();
  }

} //VVLogImpl
