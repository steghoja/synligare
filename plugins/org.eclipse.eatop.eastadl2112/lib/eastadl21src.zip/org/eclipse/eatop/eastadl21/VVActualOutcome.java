/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Actual Outcome</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VVActualOutcome represents the actual output of the testing environment as represented by VVTarget when triggered by the VVStimuli of the concrete VVProcedure. This is defined by the association 'performedVVProcedure' of the containing VVLog. It should be equivalent to the VVIntendedOutcome defined by the association 'intendedOutcome'.
 * 
 * Semantics:
 * VVActualOutcome represents the actual output of a verification effort as defined by the V&amp;V elements.
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.VerificationValidation.VVActualOutcome</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.VVActualOutcome#getIntendedOutcome <em>Intended Outcome</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVActualOutcome()
 * @model annotation="MetaData guid='{C5D354D0-AC56-489b-8594-D4722EEC6300}' id='156' EA\040name='VVActualOutcome'"
 *        extendedMetaData="name='VV-ACTUAL-OUTCOME' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-ACTUAL-OUTCOMES'"
 * @generated
 */
public interface VVActualOutcome extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Intended Outcome</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Intended Outcome</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Intended Outcome</em>' reference.
   * @see #setIntendedOutcome(VVIntendedOutcome)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getVVActualOutcome_IntendedOutcome()
   * @model annotation="MetaData guid='{00F05CE0-73E0-4065-837C-5E2C96A4A521}' id='31' EA\040name=''"
   *        extendedMetaData="name='INTENDED-OUTCOME-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTENDED-OUTCOME-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  VVIntendedOutcome getIntendedOutcome();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.VVActualOutcome#getIntendedOutcome <em>Intended Outcome</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Intended Outcome</em>' reference.
   * @see #getIntendedOutcome()
   * @generated
   */
  void setIntendedOutcome(VVIntendedOutcome value);

} // VVActualOutcome
