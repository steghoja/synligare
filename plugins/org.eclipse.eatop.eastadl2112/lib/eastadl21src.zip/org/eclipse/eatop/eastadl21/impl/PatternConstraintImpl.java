/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.Event;
import org.eclipse.eatop.eastadl21.PatternConstraint;
import org.eclipse.eatop.eastadl21.TimingExpression;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pattern Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.PatternConstraintImpl#getPeriod <em>Period</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.PatternConstraintImpl#getEvent <em>Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.PatternConstraintImpl#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.PatternConstraintImpl#getOffset <em>Offset</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.PatternConstraintImpl#getJitter <em>Jitter</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PatternConstraintImpl extends TimingConstraintImpl implements PatternConstraint
{
  /**
   * The cached value of the '{@link #getPeriod() <em>Period</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPeriod()
   * @generated
   * @ordered
   */
  protected TimingExpression period;

  /**
   * The cached value of the '{@link #getEvent() <em>Event</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEvent()
   * @generated
   * @ordered
   */
  protected Event event;

  /**
   * The cached value of the '{@link #getMinimum() <em>Minimum</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMinimum()
   * @generated
   * @ordered
   */
  protected TimingExpression minimum;

  /**
   * The cached value of the '{@link #getOffset() <em>Offset</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOffset()
   * @generated
   * @ordered
   */
  protected EList<TimingExpression> offset;

  /**
   * The cached value of the '{@link #getJitter() <em>Jitter</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJitter()
   * @generated
   * @ordered
   */
  protected TimingExpression jitter;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected PatternConstraintImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getPatternConstraint();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression getPeriod()
  {
    return period;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetPeriod(TimingExpression newPeriod, NotificationChain msgs)
  {
    TimingExpression oldPeriod = period;
    period = newPeriod;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__PERIOD, oldPeriod, newPeriod);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPeriod(TimingExpression newPeriod)
  {
    if (newPeriod != period)
    {
      NotificationChain msgs = null;
      if (period != null)
        msgs = ((InternalEObject)period).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.PATTERN_CONSTRAINT__PERIOD, null, msgs);
      if (newPeriod != null)
        msgs = ((InternalEObject)newPeriod).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.PATTERN_CONSTRAINT__PERIOD, null, msgs);
      msgs = basicSetPeriod(newPeriod, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__PERIOD, newPeriod, newPeriod));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Event getEvent()
  {
    if (event != null && event.eIsProxy())
    {
      InternalEObject oldEvent = (InternalEObject)event;
      event = (Event)eResolveProxy(oldEvent);
      if (event != oldEvent)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.PATTERN_CONSTRAINT__EVENT, oldEvent, event));
      }
    }
    return event;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Event basicGetEvent()
  {
    return event;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEvent(Event newEvent)
  {
    Event oldEvent = event;
    event = newEvent;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__EVENT, oldEvent, event));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression getMinimum()
  {
    return minimum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetMinimum(TimingExpression newMinimum, NotificationChain msgs)
  {
    TimingExpression oldMinimum = minimum;
    minimum = newMinimum;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM, oldMinimum, newMinimum);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMinimum(TimingExpression newMinimum)
  {
    if (newMinimum != minimum)
    {
      NotificationChain msgs = null;
      if (minimum != null)
        msgs = ((InternalEObject)minimum).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM, null, msgs);
      if (newMinimum != null)
        msgs = ((InternalEObject)newMinimum).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM, null, msgs);
      msgs = basicSetMinimum(newMinimum, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM, newMinimum, newMinimum));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<TimingExpression> getOffset()
  {
    if (offset == null)
    {
      offset = new EObjectContainmentEList<TimingExpression>(TimingExpression.class, this, Eastadl21Package.PATTERN_CONSTRAINT__OFFSET);
    }
    return offset;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TimingExpression getJitter()
  {
    return jitter;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetJitter(TimingExpression newJitter, NotificationChain msgs)
  {
    TimingExpression oldJitter = jitter;
    jitter = newJitter;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__JITTER, oldJitter, newJitter);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setJitter(TimingExpression newJitter)
  {
    if (newJitter != jitter)
    {
      NotificationChain msgs = null;
      if (jitter != null)
        msgs = ((InternalEObject)jitter).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.PATTERN_CONSTRAINT__JITTER, null, msgs);
      if (newJitter != null)
        msgs = ((InternalEObject)newJitter).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.PATTERN_CONSTRAINT__JITTER, null, msgs);
      msgs = basicSetJitter(newJitter, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.PATTERN_CONSTRAINT__JITTER, newJitter, newJitter));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.PATTERN_CONSTRAINT__PERIOD:
        return basicSetPeriod(null, msgs);
      case Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM:
        return basicSetMinimum(null, msgs);
      case Eastadl21Package.PATTERN_CONSTRAINT__OFFSET:
        return ((InternalEList<?>)getOffset()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.PATTERN_CONSTRAINT__JITTER:
        return basicSetJitter(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.PATTERN_CONSTRAINT__PERIOD:
        return getPeriod();
      case Eastadl21Package.PATTERN_CONSTRAINT__EVENT:
        if (resolve) return getEvent();
        return basicGetEvent();
      case Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM:
        return getMinimum();
      case Eastadl21Package.PATTERN_CONSTRAINT__OFFSET:
        return getOffset();
      case Eastadl21Package.PATTERN_CONSTRAINT__JITTER:
        return getJitter();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.PATTERN_CONSTRAINT__PERIOD:
   			setPeriod((TimingExpression)newValue);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__EVENT:
   			setEvent((Event)newValue);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM:
   			setMinimum((TimingExpression)newValue);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__OFFSET:
        getOffset().clear();
        getOffset().addAll((Collection<? extends TimingExpression>)newValue);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__JITTER:
   			setJitter((TimingExpression)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.PATTERN_CONSTRAINT__PERIOD:
        	setPeriod((TimingExpression)null);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__EVENT:
        	setEvent((Event)null);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM:
        	setMinimum((TimingExpression)null);
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__OFFSET:
        getOffset().clear();
        return;
      case Eastadl21Package.PATTERN_CONSTRAINT__JITTER:
        	setJitter((TimingExpression)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.PATTERN_CONSTRAINT__PERIOD:
        return period != null;
      case Eastadl21Package.PATTERN_CONSTRAINT__EVENT:
        return event != null;
      case Eastadl21Package.PATTERN_CONSTRAINT__MINIMUM:
        return minimum != null;
      case Eastadl21Package.PATTERN_CONSTRAINT__OFFSET:
        return offset != null && !offset.isEmpty();
      case Eastadl21Package.PATTERN_CONSTRAINT__JITTER:
        return jitter != null;
    }
    return super.eIsSet(featureID);
  }

} //PatternConstraintImpl
