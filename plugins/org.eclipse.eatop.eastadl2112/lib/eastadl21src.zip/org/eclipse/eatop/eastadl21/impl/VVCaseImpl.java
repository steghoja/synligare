/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.VVCase;
import org.eclipse.eatop.eastadl21.VVCase_vvSubject;
import org.eclipse.eatop.eastadl21.VVLog;
import org.eclipse.eatop.eastadl21.VVProcedure;
import org.eclipse.eatop.eastadl21.VVTarget;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VV Case</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCaseImpl#getVvTarget <em>Vv Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCaseImpl#getVvProcedure <em>Vv Procedure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCaseImpl#getVvLog <em>Vv Log</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCaseImpl#getAbstractVVCase <em>Abstract VV Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.VVCaseImpl#getVvSubject <em>Vv Subject</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VVCaseImpl extends TraceableSpecificationImpl implements VVCase
{
  /**
   * The cached value of the '{@link #getVvTarget() <em>Vv Target</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvTarget()
   * @generated
   * @ordered
   */
  protected EList<VVTarget> vvTarget;

  /**
   * The cached value of the '{@link #getVvProcedure() <em>Vv Procedure</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvProcedure()
   * @generated
   * @ordered
   */
  protected EList<VVProcedure> vvProcedure;

  /**
   * The cached value of the '{@link #getVvLog() <em>Vv Log</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvLog()
   * @generated
   * @ordered
   */
  protected EList<VVLog> vvLog;

  /**
   * The cached value of the '{@link #getAbstractVVCase() <em>Abstract VV Case</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAbstractVVCase()
   * @generated
   * @ordered
   */
  protected VVCase abstractVVCase;

  /**
   * The cached value of the '{@link #getVvSubject() <em>Vv Subject</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVvSubject()
   * @generated
   * @ordered
   */
  protected EList<VVCase_vvSubject> vvSubject;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VVCaseImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getVVCase();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVTarget> getVvTarget()
  {
    if (vvTarget == null)
    {
      vvTarget = new EObjectResolvingEList<VVTarget>(VVTarget.class, this, Eastadl21Package.VV_CASE__VV_TARGET);
    }
    return vvTarget;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVProcedure> getVvProcedure()
  {
    if (vvProcedure == null)
    {
      vvProcedure = new EObjectContainmentEList<VVProcedure>(VVProcedure.class, this, Eastadl21Package.VV_CASE__VV_PROCEDURE);
    }
    return vvProcedure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVLog> getVvLog()
  {
    if (vvLog == null)
    {
      vvLog = new EObjectContainmentEList<VVLog>(VVLog.class, this, Eastadl21Package.VV_CASE__VV_LOG);
    }
    return vvLog;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVCase getAbstractVVCase()
  {
    if (abstractVVCase != null && abstractVVCase.eIsProxy())
    {
      InternalEObject oldAbstractVVCase = (InternalEObject)abstractVVCase;
      abstractVVCase = (VVCase)eResolveProxy(oldAbstractVVCase);
      if (abstractVVCase != oldAbstractVVCase)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.VV_CASE__ABSTRACT_VV_CASE, oldAbstractVVCase, abstractVVCase));
      }
    }
    return abstractVVCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VVCase basicGetAbstractVVCase()
  {
    return abstractVVCase;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAbstractVVCase(VVCase newAbstractVVCase)
  {
    VVCase oldAbstractVVCase = abstractVVCase;
    abstractVVCase = newAbstractVVCase;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.VV_CASE__ABSTRACT_VV_CASE, oldAbstractVVCase, abstractVVCase));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VVCase_vvSubject> getVvSubject()
  {
    if (vvSubject == null)
    {
      vvSubject = new EObjectContainmentEList<VVCase_vvSubject>(VVCase_vvSubject.class, this, Eastadl21Package.VV_CASE__VV_SUBJECT);
    }
    return vvSubject;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE__VV_PROCEDURE:
        return ((InternalEList<?>)getVvProcedure()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.VV_CASE__VV_LOG:
        return ((InternalEList<?>)getVvLog()).basicRemove(otherEnd, msgs);
      case Eastadl21Package.VV_CASE__VV_SUBJECT:
        return ((InternalEList<?>)getVvSubject()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE__VV_TARGET:
        return getVvTarget();
      case Eastadl21Package.VV_CASE__VV_PROCEDURE:
        return getVvProcedure();
      case Eastadl21Package.VV_CASE__VV_LOG:
        return getVvLog();
      case Eastadl21Package.VV_CASE__ABSTRACT_VV_CASE:
        if (resolve) return getAbstractVVCase();
        return basicGetAbstractVVCase();
      case Eastadl21Package.VV_CASE__VV_SUBJECT:
        return getVvSubject();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE__VV_TARGET:
        getVvTarget().clear();
        getVvTarget().addAll((Collection<? extends VVTarget>)newValue);
        return;
      case Eastadl21Package.VV_CASE__VV_PROCEDURE:
        getVvProcedure().clear();
        getVvProcedure().addAll((Collection<? extends VVProcedure>)newValue);
        return;
      case Eastadl21Package.VV_CASE__VV_LOG:
        getVvLog().clear();
        getVvLog().addAll((Collection<? extends VVLog>)newValue);
        return;
      case Eastadl21Package.VV_CASE__ABSTRACT_VV_CASE:
   			setAbstractVVCase((VVCase)newValue);
        return;
      case Eastadl21Package.VV_CASE__VV_SUBJECT:
        getVvSubject().clear();
        getVvSubject().addAll((Collection<? extends VVCase_vvSubject>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE__VV_TARGET:
        getVvTarget().clear();
        return;
      case Eastadl21Package.VV_CASE__VV_PROCEDURE:
        getVvProcedure().clear();
        return;
      case Eastadl21Package.VV_CASE__VV_LOG:
        getVvLog().clear();
        return;
      case Eastadl21Package.VV_CASE__ABSTRACT_VV_CASE:
        	setAbstractVVCase((VVCase)null);
        return;
      case Eastadl21Package.VV_CASE__VV_SUBJECT:
        getVvSubject().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.VV_CASE__VV_TARGET:
        return vvTarget != null && !vvTarget.isEmpty();
      case Eastadl21Package.VV_CASE__VV_PROCEDURE:
        return vvProcedure != null && !vvProcedure.isEmpty();
      case Eastadl21Package.VV_CASE__VV_LOG:
        return vvLog != null && !vvLog.isEmpty();
      case Eastadl21Package.VV_CASE__ABSTRACT_VV_CASE:
        return abstractVVCase != null;
      case Eastadl21Package.VV_CASE__VV_SUBJECT:
        return vvSubject != null && !vvSubject.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //VVCaseImpl
