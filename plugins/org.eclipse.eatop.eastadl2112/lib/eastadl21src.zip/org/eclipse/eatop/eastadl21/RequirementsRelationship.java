/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirements Relationship</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Semantics:
 * RequirementsRelationship is an abstract association. The semantics is defined by its specializations.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements.RequirementsRelationship</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRequirementsRelationship()
 * @model abstract="true"
 *        annotation="MetaData guid='{6BF35C6C-ED0C-4a75-AD09-54CF98ABFA93}' id='-745441925' EA\040name='RequirementsRelationship'"
 *        extendedMetaData="name='REQUIREMENTS-RELATIONSHIP' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-RELATIONSHIPS'"
 * @generated
 */
public interface RequirementsRelationship extends Relationship
{
} // RequirementsRelationship
