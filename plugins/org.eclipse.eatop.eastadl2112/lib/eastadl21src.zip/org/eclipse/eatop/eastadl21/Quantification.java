/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quantification</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A quantification is a statement over the attributes about their value condition or relation.
 * 
 * Together with the attribute definitions, it also provides the support for annotating acausal dynamic behavior constraints in terms of continuous-time and discrete-time dynamics models. In the development of embedded systems, such acausal specifications of behaviors are necessary for the definitions of system environments (e.g. the physical plants), electrical and electronics devices (e.g. the transfer functions of actuators)
 * 
 * Constraints:
 * [1] A quantification is applied to at least one attribute.
 * 
 * Semantics:
 * The quantification is a tuple of: 1. the operands of quantification expressions given by attributes; 2. the time conditions of concern; 3. the actual expressions of properties over single or multiple attributes.
 * 
 * EAST-ADL does not define logic and arithmetic operators for the expressions of parameter conditions but would support the definitions in future extensions.
 * 
 * Extension: 
 * EAElement.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.BehaviorDescription.AttributeQuantificationConstraint.Quantification</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Quantification#getTimeCondition <em>Time Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Quantification#getOperand <em>Operand</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantification()
 * @model annotation="MetaData guid='{BB9CB34E-1D24-4e5d-BF9F-2F343F2AF5BA}' id='14689023' EA\040name='Quantification'"
 *        extendedMetaData="name='QUANTIFICATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTIFICATIONS'"
 * @generated
 */
public interface Quantification extends EAElement, EAExpression
{
  /**
   * Returns the value of the '<em><b>Time Condition</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Time Condition</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Time Condition</em>' reference.
   * @see #setTimeCondition(LogicalTimeCondition)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantification_TimeCondition()
   * @model annotation="MetaData guid='{FCD5DEA5-7A5A-41bf-B4A7-AFD16E2A2890}' id='-974477249' EA\040name=''"
   *        extendedMetaData="name='TIME-CONDITION-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIME-CONDITION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  LogicalTimeCondition getTimeCondition();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Quantification#getTimeCondition <em>Time Condition</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Time Condition</em>' reference.
   * @see #getTimeCondition()
   * @generated
   */
  void setTimeCondition(LogicalTimeCondition value);

  /**
   * Returns the value of the '<em><b>Operand</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Attribute}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Operand</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Operand</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantification_Operand()
   * @model required="true"
   *        annotation="MetaData guid='{73EB35E6-6677-4ce9-B1E0-3A1DB1427976}' id='1797116475' EA\040name=''"
   *        extendedMetaData="name='OPERAND-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPERAND-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Attribute> getOperand();

} // Quantification
