/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Refine refined By</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Requirements._instanceRef.Refine_refinedBy</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.Refine_refinedBy#getIdentifiable_context <em>Identifiable context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.Refine_refinedBy#getIdentifiable_target <em>Identifiable target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRefine_refinedBy()
 * @model annotation="MetaData guid='{1104BD24-8F07-473f-862E-D9A6ADD48DC2}' id='1357964520' EA\040name='Refine_refinedBy'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='REFINE--REFINED-BY-IREF'"
 *        extendedMetaData="name='REFINE--REFINED-BY-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REFINE--REFINED-BY-IREFS'"
 * @generated
 */
public interface Refine_refinedBy extends EObject
{
  /**
   * Returns the value of the '<em><b>Identifiable context</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Identifiable}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Identifiable context</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Identifiable context</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRefine_refinedBy_Identifiable_context()
   * @model annotation="MetaData guid='{11A448E0-D0A3-4110-BF03-4F351D35D0E2}' id='357421503' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='IDENTIFIABLE-CONTEXT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIABLE-CONTEXT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Identifiable> getIdentifiable_context();

  /**
   * Returns the value of the '<em><b>Identifiable target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Identifiable target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Identifiable target</em>' reference.
   * @see #setIdentifiable_target(Identifiable)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getRefine_refinedBy_Identifiable_target()
   * @model required="true"
   *        annotation="MetaData guid='{A4C399D9-A11F-420e-A575-587F250681C1}' id='455623396' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='IDENTIFIABLE-TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIABLE-TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Identifiable getIdentifiable_target();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.Refine_refinedBy#getIdentifiable_target <em>Identifiable target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Identifiable target</em>' reference.
   * @see #getIdentifiable_target()
   * @generated
   */
  void setIdentifiable_target(Identifiable value);

} // Refine_refinedBy
