/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Private Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * PrivateContent is a marker class that marks the artifact element denoted by association privateElement as private, i.e., it will not be presented to the outside of the containing ConfigurableContainer.
 * 
 * Refer to the documentation of meta-class ConfigurableContainer for a detailed explanation of how ConfigurableContainer and PrivateContent work together.
 * 
 * Constraints:
 * [1] Identifies either one FunctionPrototype or one FunctionPort or one FunctionConnector or one HardwareComponentPrototype or one HardwarePort or one ClampConnector.
 * 
 * Semantics:
 * Marks the element identified by association privateElement as private. Otherwise the elements visibility defaults to public.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Variability.PrivateContent</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.PrivateContent#getPrivateElement <em>Private Element</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrivateContent()
 * @model annotation="MetaData guid='{271BA06D-90E5-4673-9E8A-905312AEFE8B}' id='1270737684' EA\040name='PrivateContent'"
 *        extendedMetaData="name='PRIVATE-CONTENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRIVATE-CONTENTS'"
 * @generated
 */
public interface PrivateContent extends EAElement
{
  /**
   * Returns the value of the '<em><b>Private Element</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Private Element</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Private Element</em>' reference.
   * @see #setPrivateElement(Identifiable)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getPrivateContent_PrivateElement()
   * @model required="true"
   *        annotation="MetaData guid='{5D1B6702-D852-4441-B0A7-F35D78AB275A}' id='-518171938' EA\040name=''"
   *        extendedMetaData="name='PRIVATE-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRIVATE-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Identifiable getPrivateElement();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.PrivateContent#getPrivateElement <em>Private Element</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Private Element</em>' reference.
   * @see #getPrivateElement()
   * @generated
   */
  void setPrivateElement(Identifiable value);

} // PrivateContent
