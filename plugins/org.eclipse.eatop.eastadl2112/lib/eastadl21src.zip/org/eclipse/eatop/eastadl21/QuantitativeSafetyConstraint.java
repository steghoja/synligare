/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quantitative Safety Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The QuantitativeSafetyConstraint metaclass represents the quantitative integrity constraints on a fault or failure. Thus, the system has the same or better performance with respect to the constrained fault or failure, and depending on the role this is either a requirement or a property.
 * 
 * Semantics:
 * A QuantitativeSafetyConstraint provides information about the probabilistic estimates of target faults/failures, further specified by the failureRate and repairRate attribute.
 * 
 * Extension:
 * (see ADLTraceableSpecification)
 * 
 * 
 * 
 * 
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.SafetyConstraints.QuantitativeSafetyConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getFailureRate <em>Failure Rate</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getRepairRate <em>Repair Rate</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getConstrainedFaultFailure <em>Constrained Fault Failure</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantitativeSafetyConstraint()
 * @model annotation="MetaData guid='{819DBC16-6E63-4654-8684-706B521A5492}' id='570754347' EA\040name='QuantitativeSafetyConstraint'"
 *        extendedMetaData="name='QUANTITATIVE-SAFETY-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTITATIVE-SAFETY-CONSTRAINTS'"
 * @generated
 */
public interface QuantitativeSafetyConstraint extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Failure Rate</b></em>' attribute.
   * The default value is <code>"0.0"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * failureRate denotes the number of failures per unit time, i.e. the density of probability of failure divided by probability of survival for a hardware element (ISO26262 definition). For exponential failure distributions it is often denoted by lambda.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Failure Rate</em>' attribute.
   * @see #isSetFailureRate()
   * @see #unsetFailureRate()
   * @see #setFailureRate(Double)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantitativeSafetyConstraint_FailureRate()
   * @model default="0.0" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Float" required="true"
   *        annotation="MetaData guid='{2870FDF2-02E4-4c66-AAC2-3412EC229B52}' id='-1701661890' EA\040name='failureRate'"
   *        extendedMetaData="name='FAILURE-RATE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAILURE-RATES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Double getFailureRate();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getFailureRate <em>Failure Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Failure Rate</em>' attribute.
   * @see #isSetFailureRate()
   * @see #FailureRate()
   * @see #getFailureRate()
   * @generated
   */
  void setFailureRate(Double value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getFailureRate <em>Failure Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetFailureRate()
   * @see #getFailureRate()
   * @see #setFailureRate(Double)
   * @generated
   */
  void unsetFailureRate();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getFailureRate <em>Failure Rate</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Failure Rate</em>' attribute is set.
   * @see #FailureRate()
   * @see #getFailureRate()
   * @see #setFailureRate(Double)
   * @generated
   */
  boolean isSetFailureRate();

  /**
   * Returns the value of the '<em><b>Repair Rate</b></em>' attribute.
   * The default value is <code>"0.0"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * repairRate denotes the number of repairs per unit time. For exponential repair distributions it is often denoted by mu.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Repair Rate</em>' attribute.
   * @see #isSetRepairRate()
   * @see #unsetRepairRate()
   * @see #setRepairRate(Double)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantitativeSafetyConstraint_RepairRate()
   * @model default="0.0" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Float" required="true"
   *        annotation="MetaData guid='{9E60A22E-9B54-41d4-B271-5EFC90643173}' id='307443175' EA\040name='repairRate'"
   *        extendedMetaData="name='REPAIR-RATE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REPAIR-RATES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Double getRepairRate();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getRepairRate <em>Repair Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Repair Rate</em>' attribute.
   * @see #isSetRepairRate()
   * @see #RepairRate()
   * @see #getRepairRate()
   * @generated
   */
  void setRepairRate(Double value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getRepairRate <em>Repair Rate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetRepairRate()
   * @see #getRepairRate()
   * @see #setRepairRate(Double)
   * @generated
   */
  void unsetRepairRate();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.QuantitativeSafetyConstraint#getRepairRate <em>Repair Rate</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Repair Rate</em>' attribute is set.
   * @see #RepairRate()
   * @see #getRepairRate()
   * @see #setRepairRate(Double)
   * @generated
   */
  boolean isSetRepairRate();

  /**
   * Returns the value of the '<em><b>Constrained Fault Failure</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FaultFailure}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Constrained Fault Failure</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Constrained Fault Failure</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getQuantitativeSafetyConstraint_ConstrainedFaultFailure()
   * @model required="true"
   *        annotation="MetaData guid='{DD4F4C22-82A0-4f05-84ED-7062BAB042E1}' id='835584924' EA\040name=''"
   *        extendedMetaData="name='CONSTRAINED-FAULT-FAILURE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINED-FAULT-FAILURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FaultFailure> getConstrainedFaultFailure();

} // QuantitativeSafetyConstraint
