/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stakeholder Need</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Stakeholder needs represent a list of the key problems as perceived by the stakeholder, and it gives the opportunity to establish traceability from artifacts created later, for example to provide rationales to design decisions or trade-off analysis.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Annexes.Needs.StakeholderNeed</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getNeed <em>Need</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getPriority <em>Priority</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getStakeholder <em>Stakeholder</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getProblemStatement <em>Problem Statement</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getStakeholderNeed()
 * @model annotation="MetaData guid='{3C90DB4B-A1E1-4ab2-8A84-7E1B2D742C9F}' id='691788945' EA\040name='StakeholderNeed'"
 *        extendedMetaData="name='STAKEHOLDER-NEED' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STAKEHOLDER-NEEDS'"
 * @generated
 */
public interface StakeholderNeed extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Need</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The brief need statement. Redefines text.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Need</em>' attribute.
   * @see #isSetNeed()
   * @see #unsetNeed()
   * @see #setNeed(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getStakeholderNeed_Need()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String" required="true"
   *        annotation="MetaData guid='{F77F1F62-1AA3-44d6-AD84-75CFAF20CF45}' id='1926552152' EA\040name='need'"
   *        extendedMetaData="name='NEED' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NEEDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getNeed();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getNeed <em>Need</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Need</em>' attribute.
   * @see #isSetNeed()
   * @see #Need()
   * @see #getNeed()
   * @generated
   */
  void setNeed(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getNeed <em>Need</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetNeed()
   * @see #getNeed()
   * @see #setNeed(String)
   * @generated
   */
  void unsetNeed();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getNeed <em>Need</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Need</em>' attribute is set.
   * @see #Need()
   * @see #getNeed()
   * @see #setNeed(String)
   * @generated
   */
  boolean isSetNeed();

  /**
   * Returns the value of the '<em><b>Priority</b></em>' attribute.
   * The default value is <code>"0"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The priority of the need.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Priority</em>' attribute.
   * @see #isSetPriority()
   * @see #unsetPriority()
   * @see #setPriority(Integer)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getStakeholderNeed_Priority()
   * @model default="0" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Integer" required="true"
   *        annotation="MetaData guid='{2C15E648-907C-4a52-A65A-9F3887679D84}' id='1234530681' EA\040name='priority'"
   *        extendedMetaData="name='PRIORITY' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRIORITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Integer getPriority();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getPriority <em>Priority</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Priority</em>' attribute.
   * @see #isSetPriority()
   * @see #Priority()
   * @see #getPriority()
   * @generated
   */
  void setPriority(Integer value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getPriority <em>Priority</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetPriority()
   * @see #getPriority()
   * @see #setPriority(Integer)
   * @generated
   */
  void unsetPriority();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.StakeholderNeed#getPriority <em>Priority</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Priority</em>' attribute is set.
   * @see #Priority()
   * @see #getPriority()
   * @see #setPriority(Integer)
   * @generated
   */
  boolean isSetPriority();

  /**
   * Returns the value of the '<em><b>Stakeholder</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Stakeholder}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Stakeholder</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Stakeholder</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getStakeholderNeed_Stakeholder()
   * @model required="true"
   *        annotation="MetaData guid='{7952713A-9A1F-4ac4-B0D3-83618C81B766}' id='408649645' EA\040name=''"
   *        extendedMetaData="name='STAKEHOLDER-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STAKEHOLDER-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Stakeholder> getStakeholder();

  /**
   * Returns the value of the '<em><b>Problem Statement</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.ProblemStatement}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Problem Statement</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Problem Statement</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getStakeholderNeed_ProblemStatement()
   * @model required="true"
   *        annotation="MetaData guid='{121A842A-333A-42d5-97D0-50781E1DD6AB}' id='686487827' EA\040name=''"
   *        extendedMetaData="name='PROBLEM-STATEMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROBLEM-STATEMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<ProblemStatement> getProblemStatement();

} // StakeholderNeed
