/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import org.eclipse.eatop.eastadl21.AnalysisLevel;
import org.eclipse.eatop.eastadl21.DesignLevel;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ImplementationLevel;
import org.eclipse.eatop.eastadl21.SystemModel;
import org.eclipse.eatop.eastadl21.VehicleLevel;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.SystemModelImpl#getVehicleLevel <em>Vehicle Level</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.SystemModelImpl#getAnalysisLevel <em>Analysis Level</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.SystemModelImpl#getDesignLevel <em>Design Level</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.SystemModelImpl#getImplementationLevel <em>Implementation Level</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SystemModelImpl extends ContextImpl implements SystemModel
{
  /**
   * The cached value of the '{@link #getVehicleLevel() <em>Vehicle Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVehicleLevel()
   * @generated
   * @ordered
   */
  protected VehicleLevel vehicleLevel;

  /**
   * The cached value of the '{@link #getAnalysisLevel() <em>Analysis Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAnalysisLevel()
   * @generated
   * @ordered
   */
  protected AnalysisLevel analysisLevel;

  /**
   * The cached value of the '{@link #getDesignLevel() <em>Design Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDesignLevel()
   * @generated
   * @ordered
   */
  protected DesignLevel designLevel;

  /**
   * The cached value of the '{@link #getImplementationLevel() <em>Implementation Level</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getImplementationLevel()
   * @generated
   * @ordered
   */
  protected ImplementationLevel implementationLevel;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SystemModelImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getSystemModel();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public VehicleLevel getVehicleLevel()
  {
    return vehicleLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetVehicleLevel(VehicleLevel newVehicleLevel, NotificationChain msgs)
  {
    VehicleLevel oldVehicleLevel = vehicleLevel;
    vehicleLevel = newVehicleLevel;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL, oldVehicleLevel, newVehicleLevel);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVehicleLevel(VehicleLevel newVehicleLevel)
  {
    if (newVehicleLevel != vehicleLevel)
    {
      NotificationChain msgs = null;
      if (vehicleLevel != null)
        msgs = ((InternalEObject)vehicleLevel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL, null, msgs);
      if (newVehicleLevel != null)
        msgs = ((InternalEObject)newVehicleLevel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL, null, msgs);
      msgs = basicSetVehicleLevel(newVehicleLevel, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL, newVehicleLevel, newVehicleLevel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AnalysisLevel getAnalysisLevel()
  {
    return analysisLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetAnalysisLevel(AnalysisLevel newAnalysisLevel, NotificationChain msgs)
  {
    AnalysisLevel oldAnalysisLevel = analysisLevel;
    analysisLevel = newAnalysisLevel;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL, oldAnalysisLevel, newAnalysisLevel);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAnalysisLevel(AnalysisLevel newAnalysisLevel)
  {
    if (newAnalysisLevel != analysisLevel)
    {
      NotificationChain msgs = null;
      if (analysisLevel != null)
        msgs = ((InternalEObject)analysisLevel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL, null, msgs);
      if (newAnalysisLevel != null)
        msgs = ((InternalEObject)newAnalysisLevel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL, null, msgs);
      msgs = basicSetAnalysisLevel(newAnalysisLevel, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL, newAnalysisLevel, newAnalysisLevel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DesignLevel getDesignLevel()
  {
    return designLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetDesignLevel(DesignLevel newDesignLevel, NotificationChain msgs)
  {
    DesignLevel oldDesignLevel = designLevel;
    designLevel = newDesignLevel;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL, oldDesignLevel, newDesignLevel);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDesignLevel(DesignLevel newDesignLevel)
  {
    if (newDesignLevel != designLevel)
    {
      NotificationChain msgs = null;
      if (designLevel != null)
        msgs = ((InternalEObject)designLevel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL, null, msgs);
      if (newDesignLevel != null)
        msgs = ((InternalEObject)newDesignLevel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL, null, msgs);
      msgs = basicSetDesignLevel(newDesignLevel, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL, newDesignLevel, newDesignLevel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ImplementationLevel getImplementationLevel()
  {
    return implementationLevel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetImplementationLevel(ImplementationLevel newImplementationLevel, NotificationChain msgs)
  {
    ImplementationLevel oldImplementationLevel = implementationLevel;
    implementationLevel = newImplementationLevel;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL, oldImplementationLevel, newImplementationLevel);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setImplementationLevel(ImplementationLevel newImplementationLevel)
  {
    if (newImplementationLevel != implementationLevel)
    {
      NotificationChain msgs = null;
      if (implementationLevel != null)
        msgs = ((InternalEObject)implementationLevel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL, null, msgs);
      if (newImplementationLevel != null)
        msgs = ((InternalEObject)newImplementationLevel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL, null, msgs);
      msgs = basicSetImplementationLevel(newImplementationLevel, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL, newImplementationLevel, newImplementationLevel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL:
        return basicSetVehicleLevel(null, msgs);
      case Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL:
        return basicSetAnalysisLevel(null, msgs);
      case Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL:
        return basicSetDesignLevel(null, msgs);
      case Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL:
        return basicSetImplementationLevel(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL:
        return getVehicleLevel();
      case Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL:
        return getAnalysisLevel();
      case Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL:
        return getDesignLevel();
      case Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL:
        return getImplementationLevel();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL:
   			setVehicleLevel((VehicleLevel)newValue);
        return;
      case Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL:
   			setAnalysisLevel((AnalysisLevel)newValue);
        return;
      case Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL:
   			setDesignLevel((DesignLevel)newValue);
        return;
      case Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL:
   			setImplementationLevel((ImplementationLevel)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL:
        	setVehicleLevel((VehicleLevel)null);
        return;
      case Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL:
        	setAnalysisLevel((AnalysisLevel)null);
        return;
      case Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL:
        	setDesignLevel((DesignLevel)null);
        return;
      case Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL:
        	setImplementationLevel((ImplementationLevel)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.SYSTEM_MODEL__VEHICLE_LEVEL:
        return vehicleLevel != null;
      case Eastadl21Package.SYSTEM_MODEL__ANALYSIS_LEVEL:
        return analysisLevel != null;
      case Eastadl21Package.SYSTEM_MODEL__DESIGN_LEVEL:
        return designLevel != null;
      case Eastadl21Package.SYSTEM_MODEL__IMPLEMENTATION_LEVEL:
        return implementationLevel != null;
    }
    return super.eIsSet(featureID);
  }

} //SystemModelImpl
