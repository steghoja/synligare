/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Function Flow Port port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Events._instanceRef.EventFunctionFlowPort_port</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port#getFunctionPrototype <em>Function Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port#getFunctionFlowPort <em>Function Flow Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFunctionFlowPort_port()
 * @model annotation="MetaData guid='{49C1CA6F-279A-4922-9137-C08F8E3A5082}' id='-175374769' EA\040name='EventFunctionFlowPort_port'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='EVENT-FUNCTION-FLOW-PORT--PORT-IREF'"
 *        extendedMetaData="name='EVENT-FUNCTION-FLOW-PORT--PORT-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FUNCTION-FLOW-PORT--PORT-IREFS'"
 * @generated
 */
public interface EventFunctionFlowPort_port extends EObject
{
  /**
   * Returns the value of the '<em><b>Function Prototype</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.FunctionPrototype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Function Prototype</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Function Prototype</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFunctionFlowPort_port_FunctionPrototype()
   * @model annotation="MetaData guid='{8F68F43A-1AD2-418e-8224-4BE935841C08}' id='-3379243' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.context'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FUNCTION-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<FunctionPrototype> getFunctionPrototype();

  /**
   * Returns the value of the '<em><b>Function Flow Port</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Function Flow Port</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Function Flow Port</em>' reference.
   * @see #setFunctionFlowPort(FunctionFlowPort)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFunctionFlowPort_port_FunctionFlowPort()
   * @model required="true"
   *        annotation="MetaData guid='{AA799580-5A8A-41b8-B499-CC7298BACE35}' id='1663575223' EA\040name=''"
   *        annotation="Stereotype Stereotype='instanceRef.target'"
   *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
   *        extendedMetaData="name='FUNCTION-FLOW-PORT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-FLOW-PORT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  FunctionFlowPort getFunctionFlowPort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort_port#getFunctionFlowPort <em>Function Flow Port</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Function Flow Port</em>' reference.
   * @see #getFunctionFlowPort()
   * @generated
   */
  void setFunctionFlowPort(FunctionFlowPort value);

} // EventFunctionFlowPort_port
