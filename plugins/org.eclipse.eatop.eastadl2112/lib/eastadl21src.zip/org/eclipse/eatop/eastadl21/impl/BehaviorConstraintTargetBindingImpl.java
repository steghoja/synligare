/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl21.BehaviorConstraintTargetBinding;
import org.eclipse.eatop.eastadl21.BehaviorConstraintType;
import org.eclipse.eatop.eastadl21.Eastadl21Package;
import org.eclipse.eatop.eastadl21.ErrorModelType;
import org.eclipse.eatop.eastadl21.FunctionBehavior;
import org.eclipse.eatop.eastadl21.FunctionTrigger;
import org.eclipse.eatop.eastadl21.FunctionType;
import org.eclipse.eatop.eastadl21.HardwareComponentType;
import org.eclipse.eatop.eastadl21.Mode;
import org.eclipse.eatop.eastadl21.VehicleFeature;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Behavior Constraint Target Binding</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getTargetedVehicleFeature <em>Targeted Vehicle Feature</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getConstrainedModeBehavior <em>Constrained Mode Behavior</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getTargetedHardwareComponentType <em>Targeted Hardware Component Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getBehaviorConstraintType <em>Behavior Constraint Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getTargetedFunctionType <em>Targeted Function Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getConstrainedFunctionTriggering <em>Constrained Function Triggering</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getConstrainedFunctionBehavior <em>Constrained Function Behavior</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.impl.BehaviorConstraintTargetBindingImpl#getConstrainedErrorModel <em>Constrained Error Model</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BehaviorConstraintTargetBindingImpl extends RelationshipImpl implements BehaviorConstraintTargetBinding
{
  /**
   * The cached value of the '{@link #getTargetedVehicleFeature() <em>Targeted Vehicle Feature</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetedVehicleFeature()
   * @generated
   * @ordered
   */
  protected EList<VehicleFeature> targetedVehicleFeature;

  /**
   * The cached value of the '{@link #getConstrainedModeBehavior() <em>Constrained Mode Behavior</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstrainedModeBehavior()
   * @generated
   * @ordered
   */
  protected EList<Mode> constrainedModeBehavior;

  /**
   * The cached value of the '{@link #getTargetedHardwareComponentType() <em>Targeted Hardware Component Type</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetedHardwareComponentType()
   * @generated
   * @ordered
   */
  protected EList<HardwareComponentType> targetedHardwareComponentType;

  /**
   * The cached value of the '{@link #getBehaviorConstraintType() <em>Behavior Constraint Type</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBehaviorConstraintType()
   * @generated
   * @ordered
   */
  protected BehaviorConstraintType behaviorConstraintType;

  /**
   * The cached value of the '{@link #getTargetedFunctionType() <em>Targeted Function Type</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetedFunctionType()
   * @generated
   * @ordered
   */
  protected EList<FunctionType> targetedFunctionType;

  /**
   * The cached value of the '{@link #getConstrainedFunctionTriggering() <em>Constrained Function Triggering</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstrainedFunctionTriggering()
   * @generated
   * @ordered
   */
  protected EList<FunctionTrigger> constrainedFunctionTriggering;

  /**
   * The cached value of the '{@link #getConstrainedFunctionBehavior() <em>Constrained Function Behavior</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstrainedFunctionBehavior()
   * @generated
   * @ordered
   */
  protected EList<FunctionBehavior> constrainedFunctionBehavior;

  /**
   * The cached value of the '{@link #getConstrainedErrorModel() <em>Constrained Error Model</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstrainedErrorModel()
   * @generated
   * @ordered
   */
  protected EList<ErrorModelType> constrainedErrorModel;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BehaviorConstraintTargetBindingImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Eastadl21Package.eINSTANCE.getBehaviorConstraintTargetBinding();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<VehicleFeature> getTargetedVehicleFeature()
  {
    if (targetedVehicleFeature == null)
    {
      targetedVehicleFeature = new EObjectResolvingEList<VehicleFeature>(VehicleFeature.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_VEHICLE_FEATURE);
    }
    return targetedVehicleFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Mode> getConstrainedModeBehavior()
  {
    if (constrainedModeBehavior == null)
    {
      constrainedModeBehavior = new EObjectResolvingEList<Mode>(Mode.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_MODE_BEHAVIOR);
    }
    return constrainedModeBehavior;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<HardwareComponentType> getTargetedHardwareComponentType()
  {
    if (targetedHardwareComponentType == null)
    {
      targetedHardwareComponentType = new EObjectResolvingEList<HardwareComponentType>(HardwareComponentType.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_HARDWARE_COMPONENT_TYPE);
    }
    return targetedHardwareComponentType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintType getBehaviorConstraintType()
  {
    if (behaviorConstraintType != null && behaviorConstraintType.eIsProxy())
    {
      InternalEObject oldBehaviorConstraintType = (InternalEObject)behaviorConstraintType;
      behaviorConstraintType = (BehaviorConstraintType)eResolveProxy(oldBehaviorConstraintType);
      if (behaviorConstraintType != oldBehaviorConstraintType)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__BEHAVIOR_CONSTRAINT_TYPE, oldBehaviorConstraintType, behaviorConstraintType));
      }
    }
    return behaviorConstraintType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BehaviorConstraintType basicGetBehaviorConstraintType()
  {
    return behaviorConstraintType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBehaviorConstraintType(BehaviorConstraintType newBehaviorConstraintType)
  {
    BehaviorConstraintType oldBehaviorConstraintType = behaviorConstraintType;
    behaviorConstraintType = newBehaviorConstraintType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__BEHAVIOR_CONSTRAINT_TYPE, oldBehaviorConstraintType, behaviorConstraintType));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<FunctionType> getTargetedFunctionType()
  {
    if (targetedFunctionType == null)
    {
      targetedFunctionType = new EObjectResolvingEList<FunctionType>(FunctionType.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_FUNCTION_TYPE);
    }
    return targetedFunctionType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<FunctionTrigger> getConstrainedFunctionTriggering()
  {
    if (constrainedFunctionTriggering == null)
    {
      constrainedFunctionTriggering = new EObjectResolvingEList<FunctionTrigger>(FunctionTrigger.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_TRIGGERING);
    }
    return constrainedFunctionTriggering;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<FunctionBehavior> getConstrainedFunctionBehavior()
  {
    if (constrainedFunctionBehavior == null)
    {
      constrainedFunctionBehavior = new EObjectResolvingEList<FunctionBehavior>(FunctionBehavior.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_BEHAVIOR);
    }
    return constrainedFunctionBehavior;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ErrorModelType> getConstrainedErrorModel()
  {
    if (constrainedErrorModel == null)
    {
      constrainedErrorModel = new EObjectResolvingEList<ErrorModelType>(ErrorModelType.class, this, Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_ERROR_MODEL);
    }
    return constrainedErrorModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_VEHICLE_FEATURE:
        return getTargetedVehicleFeature();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_MODE_BEHAVIOR:
        return getConstrainedModeBehavior();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_HARDWARE_COMPONENT_TYPE:
        return getTargetedHardwareComponentType();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__BEHAVIOR_CONSTRAINT_TYPE:
        if (resolve) return getBehaviorConstraintType();
        return basicGetBehaviorConstraintType();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_FUNCTION_TYPE:
        return getTargetedFunctionType();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_TRIGGERING:
        return getConstrainedFunctionTriggering();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_BEHAVIOR:
        return getConstrainedFunctionBehavior();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_ERROR_MODEL:
        return getConstrainedErrorModel();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_VEHICLE_FEATURE:
        getTargetedVehicleFeature().clear();
        getTargetedVehicleFeature().addAll((Collection<? extends VehicleFeature>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_MODE_BEHAVIOR:
        getConstrainedModeBehavior().clear();
        getConstrainedModeBehavior().addAll((Collection<? extends Mode>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_HARDWARE_COMPONENT_TYPE:
        getTargetedHardwareComponentType().clear();
        getTargetedHardwareComponentType().addAll((Collection<? extends HardwareComponentType>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__BEHAVIOR_CONSTRAINT_TYPE:
   			setBehaviorConstraintType((BehaviorConstraintType)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_FUNCTION_TYPE:
        getTargetedFunctionType().clear();
        getTargetedFunctionType().addAll((Collection<? extends FunctionType>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_TRIGGERING:
        getConstrainedFunctionTriggering().clear();
        getConstrainedFunctionTriggering().addAll((Collection<? extends FunctionTrigger>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_BEHAVIOR:
        getConstrainedFunctionBehavior().clear();
        getConstrainedFunctionBehavior().addAll((Collection<? extends FunctionBehavior>)newValue);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_ERROR_MODEL:
        getConstrainedErrorModel().clear();
        getConstrainedErrorModel().addAll((Collection<? extends ErrorModelType>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_VEHICLE_FEATURE:
        getTargetedVehicleFeature().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_MODE_BEHAVIOR:
        getConstrainedModeBehavior().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_HARDWARE_COMPONENT_TYPE:
        getTargetedHardwareComponentType().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__BEHAVIOR_CONSTRAINT_TYPE:
        	setBehaviorConstraintType((BehaviorConstraintType)null);
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_FUNCTION_TYPE:
        getTargetedFunctionType().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_TRIGGERING:
        getConstrainedFunctionTriggering().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_BEHAVIOR:
        getConstrainedFunctionBehavior().clear();
        return;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_ERROR_MODEL:
        getConstrainedErrorModel().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_VEHICLE_FEATURE:
        return targetedVehicleFeature != null && !targetedVehicleFeature.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_MODE_BEHAVIOR:
        return constrainedModeBehavior != null && !constrainedModeBehavior.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_HARDWARE_COMPONENT_TYPE:
        return targetedHardwareComponentType != null && !targetedHardwareComponentType.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__BEHAVIOR_CONSTRAINT_TYPE:
        return behaviorConstraintType != null;
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__TARGETED_FUNCTION_TYPE:
        return targetedFunctionType != null && !targetedFunctionType.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_TRIGGERING:
        return constrainedFunctionTriggering != null && !constrainedFunctionTriggering.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_FUNCTION_BEHAVIOR:
        return constrainedFunctionBehavior != null && !constrainedFunctionBehavior.isEmpty();
      case Eastadl21Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING__CONSTRAINED_ERROR_MODEL:
        return constrainedErrorModel != null && !constrainedErrorModel.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //BehaviorConstraintTargetBindingImpl
