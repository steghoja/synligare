/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hazardous Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The HazardousEvent metaclass represents a combination of a Hazard and a specific situation, the latter being characterized by operating mode and operational situation in terms of a particular use case, environment and traffic. 
 * 
 * Semantics:
 * The HazardousEvent denotes a combination of a Hazard and an operational situation. The controllability and severity attributes shall be consistent with the operational situation and operational scenario, and the Exposure shall reflect the likelihood of the operational situation and scenario.
 * 
 * Notation:
 * The HazardousEvent is shown as a solid-outline rectangle with "Haz" at the top right. It contains the name of the HazardousEvent and optionally the name of the source entity.
 * 
 * Extension: 
 * UML::Class
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.HazardousEvent</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getClassificationAssumptions <em>Classification Assumptions</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getControllability <em>Controllability</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getExposure <em>Exposure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getHazardClassification <em>Hazard Classification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getSeverity <em>Severity</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getOperatingMode <em>Operating Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getExternalMeasures <em>External Measures</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getOperationalSituationUseCase <em>Operational Situation Use Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getEnvironment <em>Environment</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getHazard <em>Hazard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HazardousEvent#getTraffic <em>Traffic</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent()
 * @model annotation="MetaData guid='{E06D3E28-A159-44b4-9B6C-2F16058C7580}' id='1804799898' EA\040name='HazardousEvent'"
 *        extendedMetaData="name='HAZARDOUS-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARDOUS-EVENTS'"
 * @generated
 */
public interface HazardousEvent extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Classification Assumptions</b></em>' attribute.
   * The default value is <code>""</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The classificationAssumptions attribute denotes assumptions concerning the classification of the Hazard.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Classification Assumptions</em>' attribute.
   * @see #isSetClassificationAssumptions()
   * @see #unsetClassificationAssumptions()
   * @see #setClassificationAssumptions(String)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_ClassificationAssumptions()
   * @model default="" unsettable="true" dataType="org.eclipse.eatop.eastadl21.String"
   *        annotation="MetaData guid='{CC599C2C-78EB-4671-8357-63C4351C238F}' id='1026079972' EA\040name='classificationAssumptions'"
   *        extendedMetaData="name='CLASSIFICATION-ASSUMPTIONS' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CLASSIFICATION-ASSUMPTIONSS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  String getClassificationAssumptions();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getClassificationAssumptions <em>Classification Assumptions</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Classification Assumptions</em>' attribute.
   * @see #isSetClassificationAssumptions()
   * @see #ClassificationAssumptions()
   * @see #getClassificationAssumptions()
   * @generated
   */
  void setClassificationAssumptions(String value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getClassificationAssumptions <em>Classification Assumptions</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetClassificationAssumptions()
   * @see #getClassificationAssumptions()
   * @see #setClassificationAssumptions(String)
   * @generated
   */
  void unsetClassificationAssumptions();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getClassificationAssumptions <em>Classification Assumptions</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Classification Assumptions</em>' attribute is set.
   * @see #ClassificationAssumptions()
   * @see #getClassificationAssumptions()
   * @see #setClassificationAssumptions(String)
   * @generated
   */
  boolean isSetClassificationAssumptions();

  /**
   * Returns the value of the '<em><b>Controllability</b></em>' attribute.
   * The default value is <code>"C0"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.ControllabilityClassKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The controllability by the driver or other traffic participants defined by the enumeration C0, C1, C2 or C3 in accordance with ISO26262.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Controllability</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ControllabilityClassKind
   * @see #isSetControllability()
   * @see #unsetControllability()
   * @see #setControllability(ControllabilityClassKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_Controllability()
   * @model default="C0" unsettable="true" required="true"
   *        annotation="MetaData guid='{5D31F627-C761-4dcf-9C25-2BA1C77D1051}' id='1834883603' EA\040name='controllability'"
   *        extendedMetaData="name='CONTROLLABILITY' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTROLLABILITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ControllabilityClassKind getControllability();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getControllability <em>Controllability</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Controllability</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ControllabilityClassKind
   * @see #isSetControllability()
   * @see #Controllability()
   * @see #getControllability()
   * @generated
   */
  void setControllability(ControllabilityClassKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getControllability <em>Controllability</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetControllability()
   * @see #getControllability()
   * @see #setControllability(ControllabilityClassKind)
   * @generated
   */
  void unsetControllability();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getControllability <em>Controllability</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Controllability</em>' attribute is set.
   * @see #Controllability()
   * @see #getControllability()
   * @see #setControllability(ControllabilityClassKind)
   * @generated
   */
  boolean isSetControllability();

  /**
   * Returns the value of the '<em><b>Exposure</b></em>' attribute.
   * The default value is <code>"E1"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.ExposureClassKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The probability of exposure of the operational situations defined by the probability attributes E1, E2, E3 or E4 in accordance with ISO26262.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Exposure</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ExposureClassKind
   * @see #isSetExposure()
   * @see #unsetExposure()
   * @see #setExposure(ExposureClassKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_Exposure()
   * @model default="E1" unsettable="true" required="true"
   *        annotation="MetaData guid='{7E5ADEC9-AF33-4d9e-B73A-CBC434680D2D}' id='716679000' EA\040name='exposure'"
   *        extendedMetaData="name='EXPOSURE' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXPOSURES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ExposureClassKind getExposure();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getExposure <em>Exposure</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Exposure</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ExposureClassKind
   * @see #isSetExposure()
   * @see #Exposure()
   * @see #getExposure()
   * @generated
   */
  void setExposure(ExposureClassKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getExposure <em>Exposure</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetExposure()
   * @see #getExposure()
   * @see #setExposure(ExposureClassKind)
   * @generated
   */
  void unsetExposure();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getExposure <em>Exposure</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Exposure</em>' attribute is set.
   * @see #Exposure()
   * @see #getExposure()
   * @see #setExposure(ExposureClassKind)
   * @generated
   */
  boolean isSetExposure();

  /**
   * Returns the value of the '<em><b>Hazard Classification</b></em>' attribute.
   * The default value is <code>"ASIL_A"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.ASILKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The ASIL-Level shall be determined for each hazardous event using the estimation parameters in accordance with ISO26262.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Hazard Classification</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ASILKind
   * @see #isSetHazardClassification()
   * @see #unsetHazardClassification()
   * @see #setHazardClassification(ASILKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_HazardClassification()
   * @model default="ASIL_A" unsettable="true" required="true"
   *        annotation="MetaData guid='{30D89C12-8B3B-4bac-BB9D-ECCA98561428}' id='1370176838' EA\040name='hazardClassification'"
   *        extendedMetaData="name='HAZARD-CLASSIFICATION' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARD-CLASSIFICATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  ASILKind getHazardClassification();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getHazardClassification <em>Hazard Classification</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Hazard Classification</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.ASILKind
   * @see #isSetHazardClassification()
   * @see #HazardClassification()
   * @see #getHazardClassification()
   * @generated
   */
  void setHazardClassification(ASILKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getHazardClassification <em>Hazard Classification</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetHazardClassification()
   * @see #getHazardClassification()
   * @see #setHazardClassification(ASILKind)
   * @generated
   */
  void unsetHazardClassification();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getHazardClassification <em>Hazard Classification</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Hazard Classification</em>' attribute is set.
   * @see #HazardClassification()
   * @see #getHazardClassification()
   * @see #setHazardClassification(ASILKind)
   * @generated
   */
  boolean isSetHazardClassification();

  /**
   * Returns the value of the '<em><b>Severity</b></em>' attribute.
   * The default value is <code>"S0"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.SeverityClassKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The severity of potential harm defined by the severity attributes S0, S1, S2 or S3 in accordance with ISO26262.
   * 
   * <!-- end-model-doc -->
   * @return the value of the '<em>Severity</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.SeverityClassKind
   * @see #isSetSeverity()
   * @see #unsetSeverity()
   * @see #setSeverity(SeverityClassKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_Severity()
   * @model default="S0" unsettable="true" required="true"
   *        annotation="MetaData guid='{B1ED38FF-5DED-4133-8837-CF3B2CBB8C16}' id='-1600030087' EA\040name='severity'"
   *        extendedMetaData="name='SEVERITY' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SEVERITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  SeverityClassKind getSeverity();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getSeverity <em>Severity</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Severity</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.SeverityClassKind
   * @see #isSetSeverity()
   * @see #Severity()
   * @see #getSeverity()
   * @generated
   */
  void setSeverity(SeverityClassKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getSeverity <em>Severity</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetSeverity()
   * @see #getSeverity()
   * @see #setSeverity(SeverityClassKind)
   * @generated
   */
  void unsetSeverity();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HazardousEvent#getSeverity <em>Severity</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Severity</em>' attribute is set.
   * @see #Severity()
   * @see #getSeverity()
   * @see #setSeverity(SeverityClassKind)
   * @generated
   */
  boolean isSetSeverity();

  /**
   * Returns the value of the '<em><b>Operating Mode</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Mode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Operating Mode</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Operating Mode</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_OperatingMode()
   * @model annotation="MetaData guid='{A280BB5A-A1B7-42a5-B41D-92ACFED6BFB2}' id='-1443955490' EA\040name=''"
   *        extendedMetaData="name='OPERATING-MODE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPERATING-MODE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Mode> getOperatingMode();

  /**
   * Returns the value of the '<em><b>External Measures</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.RequirementsRelationship}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>External Measures</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>External Measures</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_ExternalMeasures()
   * @model annotation="MetaData guid='{6C52661C-6FB1-44c0-8CDF-F372240A155C}' id='-1415783738' EA\040name=''"
   *        extendedMetaData="name='EXTERNAL-MEASURES-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTERNAL-MEASURES-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<RequirementsRelationship> getExternalMeasures();

  /**
   * Returns the value of the '<em><b>Operational Situation Use Case</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.UseCase}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Operational Situation Use Case</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Operational Situation Use Case</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_OperationalSituationUseCase()
   * @model required="true"
   *        annotation="MetaData guid='{0B67549B-AB00-4d35-AFFD-C228EE1BDC75}' id='-977815074' EA\040name=''"
   *        extendedMetaData="name='OPERATIONAL-SITUATION-USE-CASE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPERATIONAL-SITUATION-USE-CASE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<UseCase> getOperationalSituationUseCase();

  /**
   * Returns the value of the '<em><b>Environment</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.OperationalSituation}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Environment</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Environment</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_Environment()
   * @model annotation="MetaData guid='{56C2A31E-6EC6-4732-A3AA-CAC3D4DA37E2}' id='1557276916' EA\040name=''"
   *        extendedMetaData="name='ENVIRONMENT-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ENVIRONMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<OperationalSituation> getEnvironment();

  /**
   * Returns the value of the '<em><b>Hazard</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Hazard}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hazard</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hazard</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_Hazard()
   * @model required="true"
   *        annotation="MetaData guid='{E9A32BAF-C4F7-4fea-AD9C-D4114DD16EDB}' id='1774272097' EA\040name=''"
   *        extendedMetaData="name='HAZARD-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARD-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Hazard> getHazard();

  /**
   * Returns the value of the '<em><b>Traffic</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.OperationalSituation}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Traffic</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Traffic</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHazardousEvent_Traffic()
   * @model annotation="MetaData guid='{098AB1C3-406F-4840-8662-3980DFB4153A}' id='2070448194' EA\040name=''"
   *        extendedMetaData="name='TRAFFIC-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRAFFIC-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<OperationalSituation> getTraffic();

} // HazardousEvent
