/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generic Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The GenericConstraint denotes a property, requirement, or a validation result for the identified element of the model. The kind of GenericConstraint is described as one of the GenericConstraintKind literals.
 * 
 * Example: If the attribute genericConstraintType is cableLength, the value could be "5 meters" (value of a numerical datatype with unit "meters").
 * 
 * Semantics:
 * The GenericConstraint does not describe what is classically referred to as a "design" constraint but has the role of a property, requirement, or a validation result. It is a requirement if this GenericConstraint refines a Requirement (by the Refine relationship). The GenericConstraint is a validation result if it realizes a VVActualOutcome, it is an intended validation result if it realizes a VVIntendedOutcome, and in other cases it denotes a property.
 * 
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.GenericConstraints.GenericConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.GenericConstraint#getKind <em>Kind</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.GenericConstraint#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.GenericConstraint#getMode <em>Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.GenericConstraint#getValue <em>Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraint()
 * @model annotation="MetaData guid='{E800C4EE-CC44-4fb0-A358-2B41D0600CAA}' id='-1881010928' EA\040name='GenericConstraint'"
 *        extendedMetaData="name='GENERIC-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='GENERIC-CONSTRAINTS'"
 * @generated
 */
public interface GenericConstraint extends TraceableSpecification
{
  /**
   * Returns the value of the '<em><b>Kind</b></em>' attribute.
   * The default value is <code>"CABLELENGTH"</code>.
   * The literals are from the enumeration {@link org.eclipse.eatop.eastadl21.GenericConstraintKind}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * The type of the GenericConstraint, see GenericConstraintKind.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Kind</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.GenericConstraintKind
   * @see #isSetKind()
   * @see #unsetKind()
   * @see #setKind(GenericConstraintKind)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraint_Kind()
   * @model default="CABLELENGTH" unsettable="true" required="true"
   *        annotation="MetaData guid='{B9A787A0-2777-413f-BDEE-26A78C9AFDB5}' id='1627361774' EA\040name='kind'"
   *        extendedMetaData="name='KIND' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='KINDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  GenericConstraintKind getKind();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.GenericConstraint#getKind <em>Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Kind</em>' attribute.
   * @see org.eclipse.eatop.eastadl21.GenericConstraintKind
   * @see #isSetKind()
   * @see #Kind()
   * @see #getKind()
   * @generated
   */
  void setKind(GenericConstraintKind value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.GenericConstraint#getKind <em>Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetKind()
   * @see #getKind()
   * @see #setKind(GenericConstraintKind)
   * @generated
   */
  void unsetKind();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.GenericConstraint#getKind <em>Kind</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Kind</em>' attribute is set.
   * @see #Kind()
   * @see #getKind()
   * @see #setKind(GenericConstraintKind)
   * @generated
   */
  boolean isSetKind();

  /**
   * Returns the value of the '<em><b>Target</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Identifiable}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraint_Target()
   * @model annotation="MetaData guid='{06BE9E62-032C-41f8-AB7D-49880EB72C13}' id='-946001403' EA\040name=''"
   *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Identifiable> getTarget();

  /**
   * Returns the value of the '<em><b>Mode</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.Mode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mode</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mode</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraint_Mode()
   * @model annotation="MetaData guid='{3B145733-49E3-428b-88D9-9292406AA26F}' id='1018730558' EA\040name=''"
   *        extendedMetaData="name='MODE-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<Mode> getMode();

  /**
   * Returns the value of the '<em><b>Value</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' containment reference.
   * @see #setValue(EAValue)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getGenericConstraint_Value()
   * @model containment="true"
   *        annotation="MetaData guid='{042D7D48-5D6E-4419-8660-2F21EF4C41E6}' id='-820982161' EA\040name=''"
   *        extendedMetaData="name='VALUE' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VALUES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EAValue getValue();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.GenericConstraint#getValue <em>Value</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' containment reference.
   * @see #getValue()
   * @generated
   */
  void setValue(EAValue value);

} // GenericConstraint
