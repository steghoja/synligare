/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hardware Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Structure.HardwareModeling.HardwarePort</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePort#getIsShield <em>Is Shield</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePort#getContainedPin <em>Contained Pin</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePort#getContainedPort <em>Contained Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl21.HardwarePort#getReferencedPin <em>Referenced Pin</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePort()
 * @model annotation="MetaData guid='{A6C752FF-247C-4782-A671-EE3D86AC5028}' id='1357550245' EA\040name='HardwarePort'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='HARDWARE-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-PORTS'"
 * @generated
 */
public interface HardwarePort extends AllocationTarget, EAPort
{
  /**
   * Returns the value of the '<em><b>Is Shield</b></em>' attribute.
   * The default value is <code>"false"</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * <!-- begin-model-doc -->
   * True if this port is representing the shield.
   * <!-- end-model-doc -->
   * @return the value of the '<em>Is Shield</em>' attribute.
   * @see #isSetIsShield()
   * @see #unsetIsShield()
   * @see #setIsShield(Boolean)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePort_IsShield()
   * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl21.Boolean" required="true"
   *        annotation="MetaData guid='{1CACE436-2824-46a4-A964-B557592AA32A}' id='1358417128' EA\040name='isShield'"
   *        extendedMetaData="name='IS-SHIELD' kind='element'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-SHIELDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  Boolean getIsShield();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePort#getIsShield <em>Is Shield</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Is Shield</em>' attribute.
   * @see #isSetIsShield()
   * @see #IsShield()
   * @see #getIsShield()
   * @generated
   */
  void setIsShield(Boolean value);

  /**
   * Unsets the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePort#getIsShield <em>Is Shield</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetIsShield()
   * @see #getIsShield()
   * @see #setIsShield(Boolean)
   * @generated
   */
  void unsetIsShield();

  /**
   * Returns whether the value of the '{@link org.eclipse.eatop.eastadl21.HardwarePort#getIsShield <em>Is Shield</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Is Shield</em>' attribute is set.
   * @see #IsShield()
   * @see #getIsShield()
   * @see #setIsShield(Boolean)
   * @generated
   */
  boolean isSetIsShield();

  /**
   * Returns the value of the '<em><b>Contained Pin</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HardwarePin}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Contained Pin</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Contained Pin</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePort_ContainedPin()
   * @model containment="true"
   *        annotation="MetaData guid='{C5347C2A-0716-4775-907B-392DC7E28AB8}' id='372148509' EA\040name=''"
   *        extendedMetaData="name='CONTAINED-PIN' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTAINED-PINS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<HardwarePin> getContainedPin();

  /**
   * Returns the value of the '<em><b>Contained Port</b></em>' containment reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HardwarePort}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Contained Port</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Contained Port</em>' containment reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePort_ContainedPort()
   * @model containment="true"
   *        annotation="MetaData guid='{14391AD1-846F-4e1e-997F-1FEB0CDF0A57}' id='1532507522' EA\040name=''"
   *        extendedMetaData="name='CONTAINED-PORT' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTAINED-PORTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
   * @generated
   */
  EList<HardwarePort> getContainedPort();

  /**
   * Returns the value of the '<em><b>Referenced Pin</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.eatop.eastadl21.HardwarePin}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Referenced Pin</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Referenced Pin</em>' reference list.
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getHardwarePort_ReferencedPin()
   * @model annotation="MetaData guid='{5D6381B6-D179-41c6-9D1A-4B2BDFB31AFA}' id='2012907797' EA\040name=''"
   *        extendedMetaData="name='REFERENCED-PIN-REF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REFERENCED-PIN-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EList<HardwarePin> getReferencedPin();

} // HardwarePort
