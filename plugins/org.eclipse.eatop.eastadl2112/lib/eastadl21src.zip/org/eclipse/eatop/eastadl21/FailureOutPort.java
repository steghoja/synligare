/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Failure Out Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The FailureOutPort represents a propagation point for failures that propagate out from the containing ErrorModelType.The EADatatype of the FailureOutPort defines the range of valid failures.
 * 
 * 
 * Constraints:
 * [1] The direction of the nominal port must be 'out'.
 * 
 * Semantics:
 * The value range of a FailureOutPort represents failures that can propagate to FaultInPorts in other ErrorModels. The value range is defined by the FailureOutPort's EADatatype.
 * 
 * If nominal ports, HWTargets or FunctionTargets are referenced, the failures of the FailureOutPort correspond to data on these nominal ports.
 * 
 * 
 * Extension: 
 * UML::Port
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Dependability.ErrorModel.FailureOutPort</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getFailureOutPort()
 * @model annotation="MetaData guid='{9B85F907-3FD7-4f87-AF99-DE58FE4A9562}' id='-401431329' EA\040name='FailureOutPort'"
 *        extendedMetaData="name='FAILURE-OUT-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAILURE-OUT-PORTS'"
 * @generated
 */
public interface FailureOutPort extends FaultFailurePort
{
} // FailureOutPort
