/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Function Flow Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Event that refers to the occurrence of data being sent (out port) or received (in port) at the flow port, i.e., when data is sent or received.
 * 
 * Semantics:
 * EventFunctionFlowPort refers to the time when data is sent or received at the FunctionFlowPort.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Timing.Events.EventFunctionFlowPort</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort#getPort <em>Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFunctionFlowPort()
 * @model annotation="MetaData guid='{ED2849C2-654C-4121-BD45-42430BCC24DE}' id='1254357917' EA\040name='EventFunctionFlowPort'"
 *        extendedMetaData="name='EVENT-FUNCTION-FLOW-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FUNCTION-FLOW-PORTS'"
 * @generated
 */
public interface EventFunctionFlowPort extends EAExpression, Event
{
  /**
   * Returns the value of the '<em><b>Port</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Port</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Port</em>' containment reference.
   * @see #setPort(EventFunctionFlowPort_port)
   * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEventFunctionFlowPort_Port()
   * @model containment="true" required="true"
   *        annotation="MetaData guid='{11208CC5-DF17-4b8e-B5C1-A9268EF170B2}' id='-1968194480' EA\040name=''"
   *        annotation="TaggedValues xml.name='PORT-IREF' xml.namePlural='PORT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
   *        extendedMetaData="name='PORT-IREF' kind='element' namespace='http://east-adl.info/2.1.12'"
   *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PORT-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
   * @generated
   */
  EventFunctionFlowPort_port getPort();

  /**
   * Sets the value of the '{@link org.eclipse.eatop.eastadl21.EventFunctionFlowPort#getPort <em>Port</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Port</em>' containment reference.
   * @see #getPort()
   * @generated
   */
  void setPort(EventFunctionFlowPort_port value);

} // EventFunctionFlowPort
