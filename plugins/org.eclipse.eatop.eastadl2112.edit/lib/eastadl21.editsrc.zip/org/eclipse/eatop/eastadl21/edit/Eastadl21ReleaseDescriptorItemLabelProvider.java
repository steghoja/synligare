/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.edit;

import org.eclipse.core.runtime.IAdapterFactory;

import org.eclipse.eatop.eastadl21.util.Eastadl21ReleaseDescriptor;

import org.eclipse.emf.edit.provider.IItemLabelProvider;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class Eastadl21ReleaseDescriptorItemLabelProvider implements IItemLabelProvider {

  private static String IMG_OVR_EASTADL2112 = "full/ovr16/eastadl2112_ovr";
  
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.eclipse.emf.edit.provider.IItemLabelProvider#getImage(java.lang.Object)
     * @generated
     */
  public Object getImage(Object object) {
    if (object instanceof Eastadl21ReleaseDescriptor) {
      return Activator.INSTANCE.getImage(IMG_OVR_EASTADL2112);
    }
    return null;
  }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @see org.eclipse.emf.edit.provider.IItemLabelProvider#getText(java.lang.Object)
   * @generated
   */
  public String getText(Object object) {
    if (object instanceof Eastadl21ReleaseDescriptor) {
      return ((Eastadl21ReleaseDescriptor) object).getName();
    }
    return null;
  }
}
